const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./Builder-DANMFasp.js","./Dashboard-B6tzCIQb.js","./Scan-1E3DM2pr.js","./Admin-BYfOqgqc.js"])))=>i.map(i=>d[i]);
function E3(n,a){for(var i=0;i<a.length;i++){const r=a[i];if(typeof r!="string"&&!Array.isArray(r)){for(const l in r)if(l!=="default"&&!(l in n)){const d=Object.getOwnPropertyDescriptor(r,l);d&&Object.defineProperty(n,l,d.get?d:{enumerable:!0,get:()=>r[l]})}}}return Object.freeze(Object.defineProperty(n,Symbol.toStringTag,{value:"Module"}))}(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const l of document.querySelectorAll('link[rel="modulepreload"]'))r(l);new MutationObserver(l=>{for(const d of l)if(d.type==="childList")for(const h of d.addedNodes)h.tagName==="LINK"&&h.rel==="modulepreload"&&r(h)}).observe(document,{childList:!0,subtree:!0});function i(l){const d={};return l.integrity&&(d.integrity=l.integrity),l.referrerPolicy&&(d.referrerPolicy=l.referrerPolicy),l.crossOrigin==="use-credentials"?d.credentials="include":l.crossOrigin==="anonymous"?d.credentials="omit":d.credentials="same-origin",d}function r(l){if(l.ep)return;l.ep=!0;const d=i(l);fetch(l.href,d)}})();function A3(n){return n&&n.__esModule&&Object.prototype.hasOwnProperty.call(n,"default")?n.default:n}var Od={exports:{}},Rr={};var X0;function C3(){if(X0)return Rr;X0=1;var n=Symbol.for("react.transitional.element"),a=Symbol.for("react.fragment");function i(r,l,d){var h=null;if(d!==void 0&&(h=""+d),l.key!==void 0&&(h=""+l.key),"key"in l){d={};for(var y in l)y!=="key"&&(d[y]=l[y])}else d=l;return l=d.ref,{$$typeof:n,type:r,key:h,ref:l!==void 0?l:null,props:d}}return Rr.Fragment=a,Rr.jsx=i,Rr.jsxs=i,Rr}var $0;function k3(){return $0||($0=1,Od.exports=C3()),Od.exports}var u=k3(),Ld={exports:{}},pe={};var Q0;function D3(){if(Q0)return pe;Q0=1;var n=Symbol.for("react.transitional.element"),a=Symbol.for("react.portal"),i=Symbol.for("react.fragment"),r=Symbol.for("react.strict_mode"),l=Symbol.for("react.profiler"),d=Symbol.for("react.consumer"),h=Symbol.for("react.context"),y=Symbol.for("react.forward_ref"),p=Symbol.for("react.suspense"),m=Symbol.for("react.memo"),g=Symbol.for("react.lazy"),x=Symbol.for("react.activity"),b=Symbol.iterator;function M(A){return A===null||typeof A!="object"?null:(A=b&&A[b]||A["@@iterator"],typeof A=="function"?A:null)}var S={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},T=Object.assign,j={};function O(A,I,Z){this.props=A,this.context=I,this.refs=j,this.updater=Z||S}O.prototype.isReactComponent={},O.prototype.setState=function(A,I){if(typeof A!="object"&&typeof A!="function"&&A!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,A,I,"setState")},O.prototype.forceUpdate=function(A){this.updater.enqueueForceUpdate(this,A,"forceUpdate")};function L(){}L.prototype=O.prototype;function z(A,I,Z){this.props=A,this.context=I,this.refs=j,this.updater=Z||S}var D=z.prototype=new L;D.constructor=z,T(D,O.prototype),D.isPureReactComponent=!0;var X=Array.isArray;function J(){}var Q={H:null,A:null,T:null,S:null},E=Object.prototype.hasOwnProperty;function q(A,I,Z){var W=Z.ref;return{$$typeof:n,type:A,key:I,ref:W!==void 0?W:null,props:Z}}function ee(A,I){return q(A.type,I,A.props)}function oe(A){return typeof A=="object"&&A!==null&&A.$$typeof===n}function me(A){var I={"=":"=0",":":"=2"};return"$"+A.replace(/[=:]/g,function(Z){return I[Z]})}var He=/\/+/g;function Te(A,I){return typeof A=="object"&&A!==null&&A.key!=null?me(""+A.key):I.toString(36)}function de(A){switch(A.status){case"fulfilled":return A.value;case"rejected":throw A.reason;default:switch(typeof A.status=="string"?A.then(J,J):(A.status="pending",A.then(function(I){A.status==="pending"&&(A.status="fulfilled",A.value=I)},function(I){A.status==="pending"&&(A.status="rejected",A.reason=I)})),A.status){case"fulfilled":return A.value;case"rejected":throw A.reason}}throw A}function U(A,I,Z,W,he){var ve=typeof A;(ve==="undefined"||ve==="boolean")&&(A=null);var ue=!1;if(A===null)ue=!0;else switch(ve){case"bigint":case"string":case"number":ue=!0;break;case"object":switch(A.$$typeof){case n:case a:ue=!0;break;case g:return ue=A._init,U(ue(A._payload),I,Z,W,he)}}if(ue)return he=he(A),ue=W===""?"."+Te(A,0):W,X(he)?(Z="",ue!=null&&(Z=ue.replace(He,"$&/")+"/"),U(he,I,Z,"",function(Vn){return Vn})):he!=null&&(oe(he)&&(he=ee(he,Z+(he.key==null||A&&A.key===he.key?"":(""+he.key).replace(He,"$&/")+"/")+ue)),I.push(he)),1;ue=0;var vt=W===""?".":W+":";if(X(A))for(var Fe=0;Fe<A.length;Fe++)W=A[Fe],ve=vt+Te(W,Fe),ue+=U(W,I,Z,ve,he);else if(Fe=M(A),typeof Fe=="function")for(A=Fe.call(A),Fe=0;!(W=A.next()).done;)W=W.value,ve=vt+Te(W,Fe++),ue+=U(W,I,Z,ve,he);else if(ve==="object"){if(typeof A.then=="function")return U(de(A),I,Z,W,he);throw I=String(A),Error("Objects are not valid as a React child (found: "+(I==="[object Object]"?"object with keys {"+Object.keys(A).join(", ")+"}":I)+"). If you meant to render a collection of children, use an array instead.")}return ue}function K(A,I,Z){if(A==null)return A;var W=[],he=0;return U(A,W,"","",function(ve){return I.call(Z,ve,he++)}),W}function Y(A){if(A._status===-1){var I=A._result;I=I(),I.then(function(Z){(A._status===0||A._status===-1)&&(A._status=1,A._result=Z)},function(Z){(A._status===0||A._status===-1)&&(A._status=2,A._result=Z)}),A._status===-1&&(A._status=0,A._result=I)}if(A._status===1)return A._result.default;throw A._result}var fe=typeof reportError=="function"?reportError:function(A){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var I=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof A=="object"&&A!==null&&typeof A.message=="string"?String(A.message):String(A),error:A});if(!window.dispatchEvent(I))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",A);return}console.error(A)},ye={map:K,forEach:function(A,I,Z){K(A,function(){I.apply(this,arguments)},Z)},count:function(A){var I=0;return K(A,function(){I++}),I},toArray:function(A){return K(A,function(I){return I})||[]},only:function(A){if(!oe(A))throw Error("React.Children.only expected to receive a single React element child.");return A}};return pe.Activity=x,pe.Children=ye,pe.Component=O,pe.Fragment=i,pe.Profiler=l,pe.PureComponent=z,pe.StrictMode=r,pe.Suspense=p,pe.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=Q,pe.__COMPILER_RUNTIME={__proto__:null,c:function(A){return Q.H.useMemoCache(A)}},pe.cache=function(A){return function(){return A.apply(null,arguments)}},pe.cacheSignal=function(){return null},pe.cloneElement=function(A,I,Z){if(A==null)throw Error("The argument must be a React element, but you passed "+A+".");var W=T({},A.props),he=A.key;if(I!=null)for(ve in I.key!==void 0&&(he=""+I.key),I)!E.call(I,ve)||ve==="key"||ve==="__self"||ve==="__source"||ve==="ref"&&I.ref===void 0||(W[ve]=I[ve]);var ve=arguments.length-2;if(ve===1)W.children=Z;else if(1<ve){for(var ue=Array(ve),vt=0;vt<ve;vt++)ue[vt]=arguments[vt+2];W.children=ue}return q(A.type,he,W)},pe.createContext=function(A){return A={$$typeof:h,_currentValue:A,_currentValue2:A,_threadCount:0,Provider:null,Consumer:null},A.Provider=A,A.Consumer={$$typeof:d,_context:A},A},pe.createElement=function(A,I,Z){var W,he={},ve=null;if(I!=null)for(W in I.key!==void 0&&(ve=""+I.key),I)E.call(I,W)&&W!=="key"&&W!=="__self"&&W!=="__source"&&(he[W]=I[W]);var ue=arguments.length-2;if(ue===1)he.children=Z;else if(1<ue){for(var vt=Array(ue),Fe=0;Fe<ue;Fe++)vt[Fe]=arguments[Fe+2];he.children=vt}if(A&&A.defaultProps)for(W in ue=A.defaultProps,ue)he[W]===void 0&&(he[W]=ue[W]);return q(A,ve,he)},pe.createRef=function(){return{current:null}},pe.forwardRef=function(A){return{$$typeof:y,render:A}},pe.isValidElement=oe,pe.lazy=function(A){return{$$typeof:g,_payload:{_status:-1,_result:A},_init:Y}},pe.memo=function(A,I){return{$$typeof:m,type:A,compare:I===void 0?null:I}},pe.startTransition=function(A){var I=Q.T,Z={};Q.T=Z;try{var W=A(),he=Q.S;he!==null&&he(Z,W),typeof W=="object"&&W!==null&&typeof W.then=="function"&&W.then(J,fe)}catch(ve){fe(ve)}finally{I!==null&&Z.types!==null&&(I.types=Z.types),Q.T=I}},pe.unstable_useCacheRefresh=function(){return Q.H.useCacheRefresh()},pe.use=function(A){return Q.H.use(A)},pe.useActionState=function(A,I,Z){return Q.H.useActionState(A,I,Z)},pe.useCallback=function(A,I){return Q.H.useCallback(A,I)},pe.useContext=function(A){return Q.H.useContext(A)},pe.useDebugValue=function(){},pe.useDeferredValue=function(A,I){return Q.H.useDeferredValue(A,I)},pe.useEffect=function(A,I){return Q.H.useEffect(A,I)},pe.useEffectEvent=function(A){return Q.H.useEffectEvent(A)},pe.useId=function(){return Q.H.useId()},pe.useImperativeHandle=function(A,I,Z){return Q.H.useImperativeHandle(A,I,Z)},pe.useInsertionEffect=function(A,I){return Q.H.useInsertionEffect(A,I)},pe.useLayoutEffect=function(A,I){return Q.H.useLayoutEffect(A,I)},pe.useMemo=function(A,I){return Q.H.useMemo(A,I)},pe.useOptimistic=function(A,I){return Q.H.useOptimistic(A,I)},pe.useReducer=function(A,I,Z){return Q.H.useReducer(A,I,Z)},pe.useRef=function(A){return Q.H.useRef(A)},pe.useState=function(A){return Q.H.useState(A)},pe.useSyncExternalStore=function(A,I,Z){return Q.H.useSyncExternalStore(A,I,Z)},pe.useTransition=function(){return Q.H.useTransition()},pe.version="19.2.3",pe}var Z0;function Qf(){return Z0||(Z0=1,Ld.exports=D3()),Ld.exports}var w=Qf();const ut=A3(w),z3=E3({__proto__:null,default:ut},[w]);var Gd={exports:{}},wr={},_d={exports:{}},Bd={};var K0;function V3(){return K0||(K0=1,(function(n){function a(U,K){var Y=U.length;U.push(K);e:for(;0<Y;){var fe=Y-1>>>1,ye=U[fe];if(0<l(ye,K))U[fe]=K,U[Y]=ye,Y=fe;else break e}}function i(U){return U.length===0?null:U[0]}function r(U){if(U.length===0)return null;var K=U[0],Y=U.pop();if(Y!==K){U[0]=Y;e:for(var fe=0,ye=U.length,A=ye>>>1;fe<A;){var I=2*(fe+1)-1,Z=U[I],W=I+1,he=U[W];if(0>l(Z,Y))W<ye&&0>l(he,Z)?(U[fe]=he,U[W]=Y,fe=W):(U[fe]=Z,U[I]=Y,fe=I);else if(W<ye&&0>l(he,Y))U[fe]=he,U[W]=Y,fe=W;else break e}}return K}function l(U,K){var Y=U.sortIndex-K.sortIndex;return Y!==0?Y:U.id-K.id}if(n.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var d=performance;n.unstable_now=function(){return d.now()}}else{var h=Date,y=h.now();n.unstable_now=function(){return h.now()-y}}var p=[],m=[],g=1,x=null,b=3,M=!1,S=!1,T=!1,j=!1,O=typeof setTimeout=="function"?setTimeout:null,L=typeof clearTimeout=="function"?clearTimeout:null,z=typeof setImmediate<"u"?setImmediate:null;function D(U){for(var K=i(m);K!==null;){if(K.callback===null)r(m);else if(K.startTime<=U)r(m),K.sortIndex=K.expirationTime,a(p,K);else break;K=i(m)}}function X(U){if(T=!1,D(U),!S)if(i(p)!==null)S=!0,J||(J=!0,me());else{var K=i(m);K!==null&&de(X,K.startTime-U)}}var J=!1,Q=-1,E=5,q=-1;function ee(){return j?!0:!(n.unstable_now()-q<E)}function oe(){if(j=!1,J){var U=n.unstable_now();q=U;var K=!0;try{e:{S=!1,T&&(T=!1,L(Q),Q=-1),M=!0;var Y=b;try{t:{for(D(U),x=i(p);x!==null&&!(x.expirationTime>U&&ee());){var fe=x.callback;if(typeof fe=="function"){x.callback=null,b=x.priorityLevel;var ye=fe(x.expirationTime<=U);if(U=n.unstable_now(),typeof ye=="function"){x.callback=ye,D(U),K=!0;break t}x===i(p)&&r(p),D(U)}else r(p);x=i(p)}if(x!==null)K=!0;else{var A=i(m);A!==null&&de(X,A.startTime-U),K=!1}}break e}finally{x=null,b=Y,M=!1}K=void 0}}finally{K?me():J=!1}}}var me;if(typeof z=="function")me=function(){z(oe)};else if(typeof MessageChannel<"u"){var He=new MessageChannel,Te=He.port2;He.port1.onmessage=oe,me=function(){Te.postMessage(null)}}else me=function(){O(oe,0)};function de(U,K){Q=O(function(){U(n.unstable_now())},K)}n.unstable_IdlePriority=5,n.unstable_ImmediatePriority=1,n.unstable_LowPriority=4,n.unstable_NormalPriority=3,n.unstable_Profiling=null,n.unstable_UserBlockingPriority=2,n.unstable_cancelCallback=function(U){U.callback=null},n.unstable_forceFrameRate=function(U){0>U||125<U?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):E=0<U?Math.floor(1e3/U):5},n.unstable_getCurrentPriorityLevel=function(){return b},n.unstable_next=function(U){switch(b){case 1:case 2:case 3:var K=3;break;default:K=b}var Y=b;b=K;try{return U()}finally{b=Y}},n.unstable_requestPaint=function(){j=!0},n.unstable_runWithPriority=function(U,K){switch(U){case 1:case 2:case 3:case 4:case 5:break;default:U=3}var Y=b;b=U;try{return K()}finally{b=Y}},n.unstable_scheduleCallback=function(U,K,Y){var fe=n.unstable_now();switch(typeof Y=="object"&&Y!==null?(Y=Y.delay,Y=typeof Y=="number"&&0<Y?fe+Y:fe):Y=fe,U){case 1:var ye=-1;break;case 2:ye=250;break;case 5:ye=1073741823;break;case 4:ye=1e4;break;default:ye=5e3}return ye=Y+ye,U={id:g++,callback:K,priorityLevel:U,startTime:Y,expirationTime:ye,sortIndex:-1},Y>fe?(U.sortIndex=Y,a(m,U),i(p)===null&&U===i(m)&&(T?(L(Q),Q=-1):T=!0,de(X,Y-fe))):(U.sortIndex=ye,a(p,U),S||M||(S=!0,J||(J=!0,me()))),U},n.unstable_shouldYield=ee,n.unstable_wrapCallback=function(U){var K=b;return function(){var Y=b;b=K;try{return U.apply(this,arguments)}finally{b=Y}}}})(Bd)),Bd}var J0;function O3(){return J0||(J0=1,_d.exports=V3()),_d.exports}var Ud={exports:{}},Dt={};var W0;function L3(){if(W0)return Dt;W0=1;var n=Qf();function a(p){var m="https://react.dev/errors/"+p;if(1<arguments.length){m+="?args[]="+encodeURIComponent(arguments[1]);for(var g=2;g<arguments.length;g++)m+="&args[]="+encodeURIComponent(arguments[g])}return"Minified React error #"+p+"; visit "+m+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function i(){}var r={d:{f:i,r:function(){throw Error(a(522))},D:i,C:i,L:i,m:i,X:i,S:i,M:i},p:0,findDOMNode:null},l=Symbol.for("react.portal");function d(p,m,g){var x=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:l,key:x==null?null:""+x,children:p,containerInfo:m,implementation:g}}var h=n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function y(p,m){if(p==="font")return"";if(typeof m=="string")return m==="use-credentials"?m:""}return Dt.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=r,Dt.createPortal=function(p,m){var g=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!m||m.nodeType!==1&&m.nodeType!==9&&m.nodeType!==11)throw Error(a(299));return d(p,m,null,g)},Dt.flushSync=function(p){var m=h.T,g=r.p;try{if(h.T=null,r.p=2,p)return p()}finally{h.T=m,r.p=g,r.d.f()}},Dt.preconnect=function(p,m){typeof p=="string"&&(m?(m=m.crossOrigin,m=typeof m=="string"?m==="use-credentials"?m:"":void 0):m=null,r.d.C(p,m))},Dt.prefetchDNS=function(p){typeof p=="string"&&r.d.D(p)},Dt.preinit=function(p,m){if(typeof p=="string"&&m&&typeof m.as=="string"){var g=m.as,x=y(g,m.crossOrigin),b=typeof m.integrity=="string"?m.integrity:void 0,M=typeof m.fetchPriority=="string"?m.fetchPriority:void 0;g==="style"?r.d.S(p,typeof m.precedence=="string"?m.precedence:void 0,{crossOrigin:x,integrity:b,fetchPriority:M}):g==="script"&&r.d.X(p,{crossOrigin:x,integrity:b,fetchPriority:M,nonce:typeof m.nonce=="string"?m.nonce:void 0})}},Dt.preinitModule=function(p,m){if(typeof p=="string")if(typeof m=="object"&&m!==null){if(m.as==null||m.as==="script"){var g=y(m.as,m.crossOrigin);r.d.M(p,{crossOrigin:g,integrity:typeof m.integrity=="string"?m.integrity:void 0,nonce:typeof m.nonce=="string"?m.nonce:void 0})}}else m==null&&r.d.M(p)},Dt.preload=function(p,m){if(typeof p=="string"&&typeof m=="object"&&m!==null&&typeof m.as=="string"){var g=m.as,x=y(g,m.crossOrigin);r.d.L(p,g,{crossOrigin:x,integrity:typeof m.integrity=="string"?m.integrity:void 0,nonce:typeof m.nonce=="string"?m.nonce:void 0,type:typeof m.type=="string"?m.type:void 0,fetchPriority:typeof m.fetchPriority=="string"?m.fetchPriority:void 0,referrerPolicy:typeof m.referrerPolicy=="string"?m.referrerPolicy:void 0,imageSrcSet:typeof m.imageSrcSet=="string"?m.imageSrcSet:void 0,imageSizes:typeof m.imageSizes=="string"?m.imageSizes:void 0,media:typeof m.media=="string"?m.media:void 0})}},Dt.preloadModule=function(p,m){if(typeof p=="string")if(m){var g=y(m.as,m.crossOrigin);r.d.m(p,{as:typeof m.as=="string"&&m.as!=="script"?m.as:void 0,crossOrigin:g,integrity:typeof m.integrity=="string"?m.integrity:void 0})}else r.d.m(p)},Dt.requestFormReset=function(p){r.d.r(p)},Dt.unstable_batchedUpdates=function(p,m){return p(m)},Dt.useFormState=function(p,m,g){return h.H.useFormState(p,m,g)},Dt.useFormStatus=function(){return h.H.useHostTransitionStatus()},Dt.version="19.2.3",Dt}var ey;function G3(){if(ey)return Ud.exports;ey=1;function n(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(a){console.error(a)}}return n(),Ud.exports=L3(),Ud.exports}var ty;function _3(){if(ty)return wr;ty=1;var n=O3(),a=Qf(),i=G3();function r(e){var t="https://react.dev/errors/"+e;if(1<arguments.length){t+="?args[]="+encodeURIComponent(arguments[1]);for(var s=2;s<arguments.length;s++)t+="&args[]="+encodeURIComponent(arguments[s])}return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function l(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function d(e){var t=e,s=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,(t.flags&4098)!==0&&(s=t.return),e=t.return;while(e)}return t.tag===3?s:null}function h(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function y(e){if(e.tag===31){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function p(e){if(d(e)!==e)throw Error(r(188))}function m(e){var t=e.alternate;if(!t){if(t=d(e),t===null)throw Error(r(188));return t!==e?null:e}for(var s=e,o=t;;){var c=s.return;if(c===null)break;var f=c.alternate;if(f===null){if(o=c.return,o!==null){s=o;continue}break}if(c.child===f.child){for(f=c.child;f;){if(f===s)return p(c),e;if(f===o)return p(c),t;f=f.sibling}throw Error(r(188))}if(s.return!==o.return)s=c,o=f;else{for(var v=!1,R=c.child;R;){if(R===s){v=!0,s=c,o=f;break}if(R===o){v=!0,o=c,s=f;break}R=R.sibling}if(!v){for(R=f.child;R;){if(R===s){v=!0,s=f,o=c;break}if(R===o){v=!0,o=f,s=c;break}R=R.sibling}if(!v)throw Error(r(189))}}if(s.alternate!==o)throw Error(r(190))}if(s.tag!==3)throw Error(r(188));return s.stateNode.current===s?e:t}function g(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e;for(e=e.child;e!==null;){if(t=g(e),t!==null)return t;e=e.sibling}return null}var x=Object.assign,b=Symbol.for("react.element"),M=Symbol.for("react.transitional.element"),S=Symbol.for("react.portal"),T=Symbol.for("react.fragment"),j=Symbol.for("react.strict_mode"),O=Symbol.for("react.profiler"),L=Symbol.for("react.consumer"),z=Symbol.for("react.context"),D=Symbol.for("react.forward_ref"),X=Symbol.for("react.suspense"),J=Symbol.for("react.suspense_list"),Q=Symbol.for("react.memo"),E=Symbol.for("react.lazy"),q=Symbol.for("react.activity"),ee=Symbol.for("react.memo_cache_sentinel"),oe=Symbol.iterator;function me(e){return e===null||typeof e!="object"?null:(e=oe&&e[oe]||e["@@iterator"],typeof e=="function"?e:null)}var He=Symbol.for("react.client.reference");function Te(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===He?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case T:return"Fragment";case O:return"Profiler";case j:return"StrictMode";case X:return"Suspense";case J:return"SuspenseList";case q:return"Activity"}if(typeof e=="object")switch(e.$$typeof){case S:return"Portal";case z:return e.displayName||"Context";case L:return(e._context.displayName||"Context")+".Consumer";case D:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case Q:return t=e.displayName||null,t!==null?t:Te(e.type)||"Memo";case E:t=e._payload,e=e._init;try{return Te(e(t))}catch{}}return null}var de=Array.isArray,U=a.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,K=i.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,Y={pending:!1,data:null,method:null,action:null},fe=[],ye=-1;function A(e){return{current:e}}function I(e){0>ye||(e.current=fe[ye],fe[ye]=null,ye--)}function Z(e,t){ye++,fe[ye]=e.current,e.current=t}var W=A(null),he=A(null),ve=A(null),ue=A(null);function vt(e,t){switch(Z(ve,t),Z(he,e),Z(W,null),t.nodeType){case 9:case 11:e=(e=t.documentElement)&&(e=e.namespaceURI)?g0(e):0;break;default:if(e=t.tagName,t=t.namespaceURI)t=g0(t),e=y0(t,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}I(W),Z(W,e)}function Fe(){I(W),I(he),I(ve)}function Vn(e){e.memoizedState!==null&&Z(ue,e);var t=W.current,s=y0(t,e.type);t!==s&&(Z(he,e),Z(W,s))}function pa(e){he.current===e&&(I(W),I(he)),ue.current===e&&(I(ue),yr._currentValue=Y)}var ma,qh;function Xa(e){if(ma===void 0)try{throw Error()}catch(s){var t=s.stack.trim().match(/\n( *(at )?)/);ma=t&&t[1]||"",qh=-1<s.stack.indexOf(`
    at`)?" (<anonymous>)":-1<s.stack.indexOf("@")?"@unknown:0:0":""}return`
`+ma+e+qh}var xc=!1;function vc(e,t){if(!e||xc)return"";xc=!0;var s=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var o={DetermineComponentFrameRoot:function(){try{if(t){var $=function(){throw Error()};if(Object.defineProperty($.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct($,[])}catch(H){var B=H}Reflect.construct(e,[],$)}else{try{$.call()}catch(H){B=H}e.call($.prototype)}}else{try{throw Error()}catch(H){B=H}($=e())&&typeof $.catch=="function"&&$.catch(function(){})}}catch(H){if(H&&B&&typeof H.stack=="string")return[H.stack,B.stack]}return[null,null]}};o.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var c=Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot,"name");c&&c.configurable&&Object.defineProperty(o.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var f=o.DetermineComponentFrameRoot(),v=f[0],R=f[1];if(v&&R){var N=v.split(`
`),_=R.split(`
`);for(c=o=0;o<N.length&&!N[o].includes("DetermineComponentFrameRoot");)o++;for(;c<_.length&&!_[c].includes("DetermineComponentFrameRoot");)c++;if(o===N.length||c===_.length)for(o=N.length-1,c=_.length-1;1<=o&&0<=c&&N[o]!==_[c];)c--;for(;1<=o&&0<=c;o--,c--)if(N[o]!==_[c]){if(o!==1||c!==1)do if(o--,c--,0>c||N[o]!==_[c]){var F=`
`+N[o].replace(" at new "," at ");return e.displayName&&F.includes("<anonymous>")&&(F=F.replace("<anonymous>",e.displayName)),F}while(1<=o&&0<=c);break}}}finally{xc=!1,Error.prepareStackTrace=s}return(s=e?e.displayName||e.name:"")?Xa(s):""}function i2(e,t){switch(e.tag){case 26:case 27:case 5:return Xa(e.type);case 16:return Xa("Lazy");case 13:return e.child!==t&&t!==null?Xa("Suspense Fallback"):Xa("Suspense");case 19:return Xa("SuspenseList");case 0:case 15:return vc(e.type,!1);case 11:return vc(e.type.render,!1);case 1:return vc(e.type,!0);case 31:return Xa("Activity");default:return""}}function Xh(e){try{var t="",s=null;do t+=i2(e,s),s=e,e=e.return;while(e);return t}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}var bc=Object.prototype.hasOwnProperty,Rc=n.unstable_scheduleCallback,wc=n.unstable_cancelCallback,r2=n.unstable_shouldYield,o2=n.unstable_requestPaint,Qt=n.unstable_now,l2=n.unstable_getCurrentPriorityLevel,$h=n.unstable_ImmediatePriority,Qh=n.unstable_UserBlockingPriority,ao=n.unstable_NormalPriority,c2=n.unstable_LowPriority,Zh=n.unstable_IdlePriority,u2=n.log,d2=n.unstable_setDisableYieldValue,Ai=null,Zt=null;function ga(e){if(typeof u2=="function"&&d2(e),Zt&&typeof Zt.setStrictMode=="function")try{Zt.setStrictMode(Ai,e)}catch{}}var Kt=Math.clz32?Math.clz32:p2,f2=Math.log,h2=Math.LN2;function p2(e){return e>>>=0,e===0?32:31-(f2(e)/h2|0)|0}var so=256,io=262144,ro=4194304;function $a(e){var t=e&42;if(t!==0)return t;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function oo(e,t,s){var o=e.pendingLanes;if(o===0)return 0;var c=0,f=e.suspendedLanes,v=e.pingedLanes;e=e.warmLanes;var R=o&134217727;return R!==0?(o=R&~f,o!==0?c=$a(o):(v&=R,v!==0?c=$a(v):s||(s=R&~e,s!==0&&(c=$a(s))))):(R=o&~f,R!==0?c=$a(R):v!==0?c=$a(v):s||(s=o&~e,s!==0&&(c=$a(s)))),c===0?0:t!==0&&t!==c&&(t&f)===0&&(f=c&-c,s=t&-t,f>=s||f===32&&(s&4194048)!==0)?t:c}function Ci(e,t){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)===0}function m2(e,t){switch(e){case 1:case 2:case 4:case 8:case 64:return t+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Kh(){var e=ro;return ro<<=1,(ro&62914560)===0&&(ro=4194304),e}function Sc(e){for(var t=[],s=0;31>s;s++)t.push(e);return t}function ki(e,t){e.pendingLanes|=t,t!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function g2(e,t,s,o,c,f){var v=e.pendingLanes;e.pendingLanes=s,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=s,e.entangledLanes&=s,e.errorRecoveryDisabledLanes&=s,e.shellSuspendCounter=0;var R=e.entanglements,N=e.expirationTimes,_=e.hiddenUpdates;for(s=v&~s;0<s;){var F=31-Kt(s),$=1<<F;R[F]=0,N[F]=-1;var B=_[F];if(B!==null)for(_[F]=null,F=0;F<B.length;F++){var H=B[F];H!==null&&(H.lane&=-536870913)}s&=~$}o!==0&&Jh(e,o,0),f!==0&&c===0&&e.tag!==0&&(e.suspendedLanes|=f&~(v&~t))}function Jh(e,t,s){e.pendingLanes|=t,e.suspendedLanes&=~t;var o=31-Kt(t);e.entangledLanes|=t,e.entanglements[o]=e.entanglements[o]|1073741824|s&261930}function Wh(e,t){var s=e.entangledLanes|=t;for(e=e.entanglements;s;){var o=31-Kt(s),c=1<<o;c&t|e[o]&t&&(e[o]|=t),s&=~c}}function ep(e,t){var s=t&-t;return s=(s&42)!==0?1:jc(s),(s&(e.suspendedLanes|t))!==0?0:s}function jc(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function Mc(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function tp(){var e=K.p;return e!==0?e:(e=window.event,e===void 0?32:U0(e.type))}function np(e,t){var s=K.p;try{return K.p=e,t()}finally{K.p=s}}var ya=Math.random().toString(36).slice(2),Tt="__reactFiber$"+ya,Ut="__reactProps$"+ya,Ss="__reactContainer$"+ya,Tc="__reactEvents$"+ya,y2="__reactListeners$"+ya,x2="__reactHandles$"+ya,ap="__reactResources$"+ya,Di="__reactMarker$"+ya;function Nc(e){delete e[Tt],delete e[Ut],delete e[Tc],delete e[y2],delete e[x2]}function js(e){var t=e[Tt];if(t)return t;for(var s=e.parentNode;s;){if(t=s[Ss]||s[Tt]){if(s=t.alternate,t.child!==null||s!==null&&s.child!==null)for(e=j0(e);e!==null;){if(s=e[Tt])return s;e=j0(e)}return t}e=s,s=e.parentNode}return null}function Ms(e){if(e=e[Tt]||e[Ss]){var t=e.tag;if(t===5||t===6||t===13||t===31||t===26||t===27||t===3)return e}return null}function zi(e){var t=e.tag;if(t===5||t===26||t===27||t===6)return e.stateNode;throw Error(r(33))}function Ts(e){var t=e[ap];return t||(t=e[ap]={hoistableStyles:new Map,hoistableScripts:new Map}),t}function bt(e){e[Di]=!0}var sp=new Set,ip={};function Qa(e,t){Ns(e,t),Ns(e+"Capture",t)}function Ns(e,t){for(ip[e]=t,e=0;e<t.length;e++)sp.add(t[e])}var v2=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),rp={},op={};function b2(e){return bc.call(op,e)?!0:bc.call(rp,e)?!1:v2.test(e)?op[e]=!0:(rp[e]=!0,!1)}function lo(e,t,s){if(b2(t))if(s===null)e.removeAttribute(t);else{switch(typeof s){case"undefined":case"function":case"symbol":e.removeAttribute(t);return;case"boolean":var o=t.toLowerCase().slice(0,5);if(o!=="data-"&&o!=="aria-"){e.removeAttribute(t);return}}e.setAttribute(t,""+s)}}function co(e,t,s){if(s===null)e.removeAttribute(t);else{switch(typeof s){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(t);return}e.setAttribute(t,""+s)}}function Yn(e,t,s,o){if(o===null)e.removeAttribute(s);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(s);return}e.setAttributeNS(t,s,""+o)}}function ln(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function lp(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function R2(e,t,s){var o=Object.getOwnPropertyDescriptor(e.constructor.prototype,t);if(!e.hasOwnProperty(t)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var c=o.get,f=o.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return c.call(this)},set:function(v){s=""+v,f.call(this,v)}}),Object.defineProperty(e,t,{enumerable:o.enumerable}),{getValue:function(){return s},setValue:function(v){s=""+v},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function Ec(e){if(!e._valueTracker){var t=lp(e)?"checked":"value";e._valueTracker=R2(e,t,""+e[t])}}function cp(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var s=t.getValue(),o="";return e&&(o=lp(e)?e.checked?"true":"false":e.value),e=o,e!==s?(t.setValue(e),!0):!1}function uo(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}var w2=/[\n"\\]/g;function cn(e){return e.replace(w2,function(t){return"\\"+t.charCodeAt(0).toString(16)+" "})}function Ac(e,t,s,o,c,f,v,R){e.name="",v!=null&&typeof v!="function"&&typeof v!="symbol"&&typeof v!="boolean"?e.type=v:e.removeAttribute("type"),t!=null?v==="number"?(t===0&&e.value===""||e.value!=t)&&(e.value=""+ln(t)):e.value!==""+ln(t)&&(e.value=""+ln(t)):v!=="submit"&&v!=="reset"||e.removeAttribute("value"),t!=null?Cc(e,v,ln(t)):s!=null?Cc(e,v,ln(s)):o!=null&&e.removeAttribute("value"),c==null&&f!=null&&(e.defaultChecked=!!f),c!=null&&(e.checked=c&&typeof c!="function"&&typeof c!="symbol"),R!=null&&typeof R!="function"&&typeof R!="symbol"&&typeof R!="boolean"?e.name=""+ln(R):e.removeAttribute("name")}function up(e,t,s,o,c,f,v,R){if(f!=null&&typeof f!="function"&&typeof f!="symbol"&&typeof f!="boolean"&&(e.type=f),t!=null||s!=null){if(!(f!=="submit"&&f!=="reset"||t!=null)){Ec(e);return}s=s!=null?""+ln(s):"",t=t!=null?""+ln(t):s,R||t===e.value||(e.value=t),e.defaultValue=t}o=o??c,o=typeof o!="function"&&typeof o!="symbol"&&!!o,e.checked=R?e.checked:!!o,e.defaultChecked=!!o,v!=null&&typeof v!="function"&&typeof v!="symbol"&&typeof v!="boolean"&&(e.name=v),Ec(e)}function Cc(e,t,s){t==="number"&&uo(e.ownerDocument)===e||e.defaultValue===""+s||(e.defaultValue=""+s)}function Es(e,t,s,o){if(e=e.options,t){t={};for(var c=0;c<s.length;c++)t["$"+s[c]]=!0;for(s=0;s<e.length;s++)c=t.hasOwnProperty("$"+e[s].value),e[s].selected!==c&&(e[s].selected=c),c&&o&&(e[s].defaultSelected=!0)}else{for(s=""+ln(s),t=null,c=0;c<e.length;c++){if(e[c].value===s){e[c].selected=!0,o&&(e[c].defaultSelected=!0);return}t!==null||e[c].disabled||(t=e[c])}t!==null&&(t.selected=!0)}}function dp(e,t,s){if(t!=null&&(t=""+ln(t),t!==e.value&&(e.value=t),s==null)){e.defaultValue!==t&&(e.defaultValue=t);return}e.defaultValue=s!=null?""+ln(s):""}function fp(e,t,s,o){if(t==null){if(o!=null){if(s!=null)throw Error(r(92));if(de(o)){if(1<o.length)throw Error(r(93));o=o[0]}s=o}s==null&&(s=""),t=s}s=ln(t),e.defaultValue=s,o=e.textContent,o===s&&o!==""&&o!==null&&(e.value=o),Ec(e)}function As(e,t){if(t){var s=e.firstChild;if(s&&s===e.lastChild&&s.nodeType===3){s.nodeValue=t;return}}e.textContent=t}var S2=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function hp(e,t,s){var o=t.indexOf("--")===0;s==null||typeof s=="boolean"||s===""?o?e.setProperty(t,""):t==="float"?e.cssFloat="":e[t]="":o?e.setProperty(t,s):typeof s!="number"||s===0||S2.has(t)?t==="float"?e.cssFloat=s:e[t]=(""+s).trim():e[t]=s+"px"}function pp(e,t,s){if(t!=null&&typeof t!="object")throw Error(r(62));if(e=e.style,s!=null){for(var o in s)!s.hasOwnProperty(o)||t!=null&&t.hasOwnProperty(o)||(o.indexOf("--")===0?e.setProperty(o,""):o==="float"?e.cssFloat="":e[o]="");for(var c in t)o=t[c],t.hasOwnProperty(c)&&s[c]!==o&&hp(e,c,o)}else for(var f in t)t.hasOwnProperty(f)&&hp(e,f,t[f])}function kc(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var j2=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),M2=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function fo(e){return M2.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function qn(){}var Dc=null;function zc(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var Cs=null,ks=null;function mp(e){var t=Ms(e);if(t&&(e=t.stateNode)){var s=e[Ut]||null;e:switch(e=t.stateNode,t.type){case"input":if(Ac(e,s.value,s.defaultValue,s.defaultValue,s.checked,s.defaultChecked,s.type,s.name),t=s.name,s.type==="radio"&&t!=null){for(s=e;s.parentNode;)s=s.parentNode;for(s=s.querySelectorAll('input[name="'+cn(""+t)+'"][type="radio"]'),t=0;t<s.length;t++){var o=s[t];if(o!==e&&o.form===e.form){var c=o[Ut]||null;if(!c)throw Error(r(90));Ac(o,c.value,c.defaultValue,c.defaultValue,c.checked,c.defaultChecked,c.type,c.name)}}for(t=0;t<s.length;t++)o=s[t],o.form===e.form&&cp(o)}break e;case"textarea":dp(e,s.value,s.defaultValue);break e;case"select":t=s.value,t!=null&&Es(e,!!s.multiple,t,!1)}}}var Vc=!1;function gp(e,t,s){if(Vc)return e(t,s);Vc=!0;try{var o=e(t);return o}finally{if(Vc=!1,(Cs!==null||ks!==null)&&(Wo(),Cs&&(t=Cs,e=ks,ks=Cs=null,mp(t),e)))for(t=0;t<e.length;t++)mp(e[t])}}function Vi(e,t){var s=e.stateNode;if(s===null)return null;var o=s[Ut]||null;if(o===null)return null;s=o[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(e=e.type,o=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!o;break e;default:e=!1}if(e)return null;if(s&&typeof s!="function")throw Error(r(231,t,typeof s));return s}var Xn=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Oc=!1;if(Xn)try{var Oi={};Object.defineProperty(Oi,"passive",{get:function(){Oc=!0}}),window.addEventListener("test",Oi,Oi),window.removeEventListener("test",Oi,Oi)}catch{Oc=!1}var xa=null,Lc=null,ho=null;function yp(){if(ho)return ho;var e,t=Lc,s=t.length,o,c="value"in xa?xa.value:xa.textContent,f=c.length;for(e=0;e<s&&t[e]===c[e];e++);var v=s-e;for(o=1;o<=v&&t[s-o]===c[f-o];o++);return ho=c.slice(e,1<o?1-o:void 0)}function po(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function mo(){return!0}function xp(){return!1}function Ht(e){function t(s,o,c,f,v){this._reactName=s,this._targetInst=c,this.type=o,this.nativeEvent=f,this.target=v,this.currentTarget=null;for(var R in e)e.hasOwnProperty(R)&&(s=e[R],this[R]=s?s(f):f[R]);return this.isDefaultPrevented=(f.defaultPrevented!=null?f.defaultPrevented:f.returnValue===!1)?mo:xp,this.isPropagationStopped=xp,this}return x(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var s=this.nativeEvent;s&&(s.preventDefault?s.preventDefault():typeof s.returnValue!="unknown"&&(s.returnValue=!1),this.isDefaultPrevented=mo)},stopPropagation:function(){var s=this.nativeEvent;s&&(s.stopPropagation?s.stopPropagation():typeof s.cancelBubble!="unknown"&&(s.cancelBubble=!0),this.isPropagationStopped=mo)},persist:function(){},isPersistent:mo}),t}var Za={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},go=Ht(Za),Li=x({},Za,{view:0,detail:0}),T2=Ht(Li),Gc,_c,Gi,yo=x({},Li,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Uc,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==Gi&&(Gi&&e.type==="mousemove"?(Gc=e.screenX-Gi.screenX,_c=e.screenY-Gi.screenY):_c=Gc=0,Gi=e),Gc)},movementY:function(e){return"movementY"in e?e.movementY:_c}}),vp=Ht(yo),N2=x({},yo,{dataTransfer:0}),E2=Ht(N2),A2=x({},Li,{relatedTarget:0}),Bc=Ht(A2),C2=x({},Za,{animationName:0,elapsedTime:0,pseudoElement:0}),k2=Ht(C2),D2=x({},Za,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),z2=Ht(D2),V2=x({},Za,{data:0}),bp=Ht(V2),O2={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},L2={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},G2={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function _2(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=G2[e])?!!t[e]:!1}function Uc(){return _2}var B2=x({},Li,{key:function(e){if(e.key){var t=O2[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=po(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?L2[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Uc,charCode:function(e){return e.type==="keypress"?po(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?po(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),U2=Ht(B2),H2=x({},yo,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Rp=Ht(H2),F2=x({},Li,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Uc}),I2=Ht(F2),P2=x({},Za,{propertyName:0,elapsedTime:0,pseudoElement:0}),Y2=Ht(P2),q2=x({},yo,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),X2=Ht(q2),$2=x({},Za,{newState:0,oldState:0}),Q2=Ht($2),Z2=[9,13,27,32],Hc=Xn&&"CompositionEvent"in window,_i=null;Xn&&"documentMode"in document&&(_i=document.documentMode);var K2=Xn&&"TextEvent"in window&&!_i,wp=Xn&&(!Hc||_i&&8<_i&&11>=_i),Sp=" ",jp=!1;function Mp(e,t){switch(e){case"keyup":return Z2.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Tp(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var Ds=!1;function J2(e,t){switch(e){case"compositionend":return Tp(t);case"keypress":return t.which!==32?null:(jp=!0,Sp);case"textInput":return e=t.data,e===Sp&&jp?null:e;default:return null}}function W2(e,t){if(Ds)return e==="compositionend"||!Hc&&Mp(e,t)?(e=yp(),ho=Lc=xa=null,Ds=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return wp&&t.locale!=="ko"?null:t.data;default:return null}}var e5={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Np(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!e5[e.type]:t==="textarea"}function Ep(e,t,s,o){Cs?ks?ks.push(o):ks=[o]:Cs=o,t=rl(t,"onChange"),0<t.length&&(s=new go("onChange","change",null,s,o),e.push({event:s,listeners:t}))}var Bi=null,Ui=null;function t5(e){u0(e,0)}function xo(e){var t=zi(e);if(cp(t))return e}function Ap(e,t){if(e==="change")return t}var Cp=!1;if(Xn){var Fc;if(Xn){var Ic="oninput"in document;if(!Ic){var kp=document.createElement("div");kp.setAttribute("oninput","return;"),Ic=typeof kp.oninput=="function"}Fc=Ic}else Fc=!1;Cp=Fc&&(!document.documentMode||9<document.documentMode)}function Dp(){Bi&&(Bi.detachEvent("onpropertychange",zp),Ui=Bi=null)}function zp(e){if(e.propertyName==="value"&&xo(Ui)){var t=[];Ep(t,Ui,e,zc(e)),gp(t5,t)}}function n5(e,t,s){e==="focusin"?(Dp(),Bi=t,Ui=s,Bi.attachEvent("onpropertychange",zp)):e==="focusout"&&Dp()}function a5(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return xo(Ui)}function s5(e,t){if(e==="click")return xo(t)}function i5(e,t){if(e==="input"||e==="change")return xo(t)}function r5(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var Jt=typeof Object.is=="function"?Object.is:r5;function Hi(e,t){if(Jt(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var s=Object.keys(e),o=Object.keys(t);if(s.length!==o.length)return!1;for(o=0;o<s.length;o++){var c=s[o];if(!bc.call(t,c)||!Jt(e[c],t[c]))return!1}return!0}function Vp(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Op(e,t){var s=Vp(e);e=0;for(var o;s;){if(s.nodeType===3){if(o=e+s.textContent.length,e<=t&&o>=t)return{node:s,offset:t-e};e=o}e:{for(;s;){if(s.nextSibling){s=s.nextSibling;break e}s=s.parentNode}s=void 0}s=Vp(s)}}function Lp(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Lp(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Gp(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var t=uo(e.document);t instanceof e.HTMLIFrameElement;){try{var s=typeof t.contentWindow.location.href=="string"}catch{s=!1}if(s)e=t.contentWindow;else break;t=uo(e.document)}return t}function Pc(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}var o5=Xn&&"documentMode"in document&&11>=document.documentMode,zs=null,Yc=null,Fi=null,qc=!1;function _p(e,t,s){var o=s.window===s?s.document:s.nodeType===9?s:s.ownerDocument;qc||zs==null||zs!==uo(o)||(o=zs,"selectionStart"in o&&Pc(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),Fi&&Hi(Fi,o)||(Fi=o,o=rl(Yc,"onSelect"),0<o.length&&(t=new go("onSelect","select",null,t,s),e.push({event:t,listeners:o}),t.target=zs)))}function Ka(e,t){var s={};return s[e.toLowerCase()]=t.toLowerCase(),s["Webkit"+e]="webkit"+t,s["Moz"+e]="moz"+t,s}var Vs={animationend:Ka("Animation","AnimationEnd"),animationiteration:Ka("Animation","AnimationIteration"),animationstart:Ka("Animation","AnimationStart"),transitionrun:Ka("Transition","TransitionRun"),transitionstart:Ka("Transition","TransitionStart"),transitioncancel:Ka("Transition","TransitionCancel"),transitionend:Ka("Transition","TransitionEnd")},Xc={},Bp={};Xn&&(Bp=document.createElement("div").style,"AnimationEvent"in window||(delete Vs.animationend.animation,delete Vs.animationiteration.animation,delete Vs.animationstart.animation),"TransitionEvent"in window||delete Vs.transitionend.transition);function Ja(e){if(Xc[e])return Xc[e];if(!Vs[e])return e;var t=Vs[e],s;for(s in t)if(t.hasOwnProperty(s)&&s in Bp)return Xc[e]=t[s];return e}var Up=Ja("animationend"),Hp=Ja("animationiteration"),Fp=Ja("animationstart"),l5=Ja("transitionrun"),c5=Ja("transitionstart"),u5=Ja("transitioncancel"),Ip=Ja("transitionend"),Pp=new Map,$c="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");$c.push("scrollEnd");function wn(e,t){Pp.set(e,t),Qa(t,[e])}var vo=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(t))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},un=[],Os=0,Qc=0;function bo(){for(var e=Os,t=Qc=Os=0;t<e;){var s=un[t];un[t++]=null;var o=un[t];un[t++]=null;var c=un[t];un[t++]=null;var f=un[t];if(un[t++]=null,o!==null&&c!==null){var v=o.pending;v===null?c.next=c:(c.next=v.next,v.next=c),o.pending=c}f!==0&&Yp(s,c,f)}}function Ro(e,t,s,o){un[Os++]=e,un[Os++]=t,un[Os++]=s,un[Os++]=o,Qc|=o,e.lanes|=o,e=e.alternate,e!==null&&(e.lanes|=o)}function Zc(e,t,s,o){return Ro(e,t,s,o),wo(e)}function Wa(e,t){return Ro(e,null,null,t),wo(e)}function Yp(e,t,s){e.lanes|=s;var o=e.alternate;o!==null&&(o.lanes|=s);for(var c=!1,f=e.return;f!==null;)f.childLanes|=s,o=f.alternate,o!==null&&(o.childLanes|=s),f.tag===22&&(e=f.stateNode,e===null||e._visibility&1||(c=!0)),e=f,f=f.return;return e.tag===3?(f=e.stateNode,c&&t!==null&&(c=31-Kt(s),e=f.hiddenUpdates,o=e[c],o===null?e[c]=[t]:o.push(t),t.lane=s|536870912),f):null}function wo(e){if(50<ur)throw ur=0,id=null,Error(r(185));for(var t=e.return;t!==null;)e=t,t=e.return;return e.tag===3?e.stateNode:null}var Ls={};function d5(e,t,s,o){this.tag=e,this.key=s,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Wt(e,t,s,o){return new d5(e,t,s,o)}function Kc(e){return e=e.prototype,!(!e||!e.isReactComponent)}function $n(e,t){var s=e.alternate;return s===null?(s=Wt(e.tag,t,e.key,e.mode),s.elementType=e.elementType,s.type=e.type,s.stateNode=e.stateNode,s.alternate=e,e.alternate=s):(s.pendingProps=t,s.type=e.type,s.flags=0,s.subtreeFlags=0,s.deletions=null),s.flags=e.flags&65011712,s.childLanes=e.childLanes,s.lanes=e.lanes,s.child=e.child,s.memoizedProps=e.memoizedProps,s.memoizedState=e.memoizedState,s.updateQueue=e.updateQueue,t=e.dependencies,s.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},s.sibling=e.sibling,s.index=e.index,s.ref=e.ref,s.refCleanup=e.refCleanup,s}function qp(e,t){e.flags&=65011714;var s=e.alternate;return s===null?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=s.childLanes,e.lanes=s.lanes,e.child=s.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=s.memoizedProps,e.memoizedState=s.memoizedState,e.updateQueue=s.updateQueue,e.type=s.type,t=s.dependencies,e.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext}),e}function So(e,t,s,o,c,f){var v=0;if(o=e,typeof e=="function")Kc(e)&&(v=1);else if(typeof e=="string")v=g3(e,s,W.current)?26:e==="html"||e==="head"||e==="body"?27:5;else e:switch(e){case q:return e=Wt(31,s,t,c),e.elementType=q,e.lanes=f,e;case T:return es(s.children,c,f,t);case j:v=8,c|=24;break;case O:return e=Wt(12,s,t,c|2),e.elementType=O,e.lanes=f,e;case X:return e=Wt(13,s,t,c),e.elementType=X,e.lanes=f,e;case J:return e=Wt(19,s,t,c),e.elementType=J,e.lanes=f,e;default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case z:v=10;break e;case L:v=9;break e;case D:v=11;break e;case Q:v=14;break e;case E:v=16,o=null;break e}v=29,s=Error(r(130,e===null?"null":typeof e,"")),o=null}return t=Wt(v,s,t,c),t.elementType=e,t.type=o,t.lanes=f,t}function es(e,t,s,o){return e=Wt(7,e,o,t),e.lanes=s,e}function Jc(e,t,s){return e=Wt(6,e,null,t),e.lanes=s,e}function Xp(e){var t=Wt(18,null,null,0);return t.stateNode=e,t}function Wc(e,t,s){return t=Wt(4,e.children!==null?e.children:[],e.key,t),t.lanes=s,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}var $p=new WeakMap;function dn(e,t){if(typeof e=="object"&&e!==null){var s=$p.get(e);return s!==void 0?s:(t={value:e,source:t,stack:Xh(t)},$p.set(e,t),t)}return{value:e,source:t,stack:Xh(t)}}var Gs=[],_s=0,jo=null,Ii=0,fn=[],hn=0,va=null,On=1,Ln="";function Qn(e,t){Gs[_s++]=Ii,Gs[_s++]=jo,jo=e,Ii=t}function Qp(e,t,s){fn[hn++]=On,fn[hn++]=Ln,fn[hn++]=va,va=e;var o=On;e=Ln;var c=32-Kt(o)-1;o&=~(1<<c),s+=1;var f=32-Kt(t)+c;if(30<f){var v=c-c%5;f=(o&(1<<v)-1).toString(32),o>>=v,c-=v,On=1<<32-Kt(t)+c|s<<c|o,Ln=f+e}else On=1<<f|s<<c|o,Ln=e}function eu(e){e.return!==null&&(Qn(e,1),Qp(e,1,0))}function tu(e){for(;e===jo;)jo=Gs[--_s],Gs[_s]=null,Ii=Gs[--_s],Gs[_s]=null;for(;e===va;)va=fn[--hn],fn[hn]=null,Ln=fn[--hn],fn[hn]=null,On=fn[--hn],fn[hn]=null}function Zp(e,t){fn[hn++]=On,fn[hn++]=Ln,fn[hn++]=va,On=t.id,Ln=t.overflow,va=e}var Nt=null,Ye=null,Ne=!1,ba=null,pn=!1,nu=Error(r(519));function Ra(e){var t=Error(r(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw Pi(dn(t,e)),nu}function Kp(e){var t=e.stateNode,s=e.type,o=e.memoizedProps;switch(t[Tt]=e,t[Ut]=o,s){case"dialog":we("cancel",t),we("close",t);break;case"iframe":case"object":case"embed":we("load",t);break;case"video":case"audio":for(s=0;s<fr.length;s++)we(fr[s],t);break;case"source":we("error",t);break;case"img":case"image":case"link":we("error",t),we("load",t);break;case"details":we("toggle",t);break;case"input":we("invalid",t),up(t,o.value,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name,!0);break;case"select":we("invalid",t);break;case"textarea":we("invalid",t),fp(t,o.value,o.defaultValue,o.children)}s=o.children,typeof s!="string"&&typeof s!="number"&&typeof s!="bigint"||t.textContent===""+s||o.suppressHydrationWarning===!0||p0(t.textContent,s)?(o.popover!=null&&(we("beforetoggle",t),we("toggle",t)),o.onScroll!=null&&we("scroll",t),o.onScrollEnd!=null&&we("scrollend",t),o.onClick!=null&&(t.onclick=qn),t=!0):t=!1,t||Ra(e,!0)}function Jp(e){for(Nt=e.return;Nt;)switch(Nt.tag){case 5:case 31:case 13:pn=!1;return;case 27:case 3:pn=!0;return;default:Nt=Nt.return}}function Bs(e){if(e!==Nt)return!1;if(!Ne)return Jp(e),Ne=!0,!1;var t=e.tag,s;if((s=t!==3&&t!==27)&&((s=t===5)&&(s=e.type,s=!(s!=="form"&&s!=="button")||bd(e.type,e.memoizedProps)),s=!s),s&&Ye&&Ra(e),Jp(e),t===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(r(317));Ye=S0(e)}else if(t===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(r(317));Ye=S0(e)}else t===27?(t=Ye,Oa(e.type)?(e=Md,Md=null,Ye=e):Ye=t):Ye=Nt?gn(e.stateNode.nextSibling):null;return!0}function ts(){Ye=Nt=null,Ne=!1}function au(){var e=ba;return e!==null&&(Yt===null?Yt=e:Yt.push.apply(Yt,e),ba=null),e}function Pi(e){ba===null?ba=[e]:ba.push(e)}var su=A(null),ns=null,Zn=null;function wa(e,t,s){Z(su,t._currentValue),t._currentValue=s}function Kn(e){e._currentValue=su.current,I(su)}function iu(e,t,s){for(;e!==null;){var o=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,o!==null&&(o.childLanes|=t)):o!==null&&(o.childLanes&t)!==t&&(o.childLanes|=t),e===s)break;e=e.return}}function ru(e,t,s,o){var c=e.child;for(c!==null&&(c.return=e);c!==null;){var f=c.dependencies;if(f!==null){var v=c.child;f=f.firstContext;e:for(;f!==null;){var R=f;f=c;for(var N=0;N<t.length;N++)if(R.context===t[N]){f.lanes|=s,R=f.alternate,R!==null&&(R.lanes|=s),iu(f.return,s,e),o||(v=null);break e}f=R.next}}else if(c.tag===18){if(v=c.return,v===null)throw Error(r(341));v.lanes|=s,f=v.alternate,f!==null&&(f.lanes|=s),iu(v,s,e),v=null}else v=c.child;if(v!==null)v.return=c;else for(v=c;v!==null;){if(v===e){v=null;break}if(c=v.sibling,c!==null){c.return=v.return,v=c;break}v=v.return}c=v}}function Us(e,t,s,o){e=null;for(var c=t,f=!1;c!==null;){if(!f){if((c.flags&524288)!==0)f=!0;else if((c.flags&262144)!==0)break}if(c.tag===10){var v=c.alternate;if(v===null)throw Error(r(387));if(v=v.memoizedProps,v!==null){var R=c.type;Jt(c.pendingProps.value,v.value)||(e!==null?e.push(R):e=[R])}}else if(c===ue.current){if(v=c.alternate,v===null)throw Error(r(387));v.memoizedState.memoizedState!==c.memoizedState.memoizedState&&(e!==null?e.push(yr):e=[yr])}c=c.return}e!==null&&ru(t,e,s,o),t.flags|=262144}function Mo(e){for(e=e.firstContext;e!==null;){if(!Jt(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function as(e){ns=e,Zn=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function Et(e){return Wp(ns,e)}function To(e,t){return ns===null&&as(e),Wp(e,t)}function Wp(e,t){var s=t._currentValue;if(t={context:t,memoizedValue:s,next:null},Zn===null){if(e===null)throw Error(r(308));Zn=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288}else Zn=Zn.next=t;return s}var f5=typeof AbortController<"u"?AbortController:function(){var e=[],t=this.signal={aborted:!1,addEventListener:function(s,o){e.push(o)}};this.abort=function(){t.aborted=!0,e.forEach(function(s){return s()})}},h5=n.unstable_scheduleCallback,p5=n.unstable_NormalPriority,rt={$$typeof:z,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function ou(){return{controller:new f5,data:new Map,refCount:0}}function Yi(e){e.refCount--,e.refCount===0&&h5(p5,function(){e.controller.abort()})}var qi=null,lu=0,Hs=0,Fs=null;function m5(e,t){if(qi===null){var s=qi=[];lu=0,Hs=dd(),Fs={status:"pending",value:void 0,then:function(o){s.push(o)}}}return lu++,t.then(em,em),t}function em(){if(--lu===0&&qi!==null){Fs!==null&&(Fs.status="fulfilled");var e=qi;qi=null,Hs=0,Fs=null;for(var t=0;t<e.length;t++)(0,e[t])()}}function g5(e,t){var s=[],o={status:"pending",value:null,reason:null,then:function(c){s.push(c)}};return e.then(function(){o.status="fulfilled",o.value=t;for(var c=0;c<s.length;c++)(0,s[c])(t)},function(c){for(o.status="rejected",o.reason=c,c=0;c<s.length;c++)(0,s[c])(void 0)}),o}var tm=U.S;U.S=function(e,t){_g=Qt(),typeof t=="object"&&t!==null&&typeof t.then=="function"&&m5(e,t),tm!==null&&tm(e,t)};var ss=A(null);function cu(){var e=ss.current;return e!==null?e:Be.pooledCache}function No(e,t){t===null?Z(ss,ss.current):Z(ss,t.pool)}function nm(){var e=cu();return e===null?null:{parent:rt._currentValue,pool:e}}var Is=Error(r(460)),uu=Error(r(474)),Eo=Error(r(542)),Ao={then:function(){}};function am(e){return e=e.status,e==="fulfilled"||e==="rejected"}function sm(e,t,s){switch(s=e[s],s===void 0?e.push(t):s!==t&&(t.then(qn,qn),t=s),t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,rm(e),e;default:if(typeof t.status=="string")t.then(qn,qn);else{if(e=Be,e!==null&&100<e.shellSuspendCounter)throw Error(r(482));e=t,e.status="pending",e.then(function(o){if(t.status==="pending"){var c=t;c.status="fulfilled",c.value=o}},function(o){if(t.status==="pending"){var c=t;c.status="rejected",c.reason=o}})}switch(t.status){case"fulfilled":return t.value;case"rejected":throw e=t.reason,rm(e),e}throw rs=t,Is}}function is(e){try{var t=e._init;return t(e._payload)}catch(s){throw s!==null&&typeof s=="object"&&typeof s.then=="function"?(rs=s,Is):s}}var rs=null;function im(){if(rs===null)throw Error(r(459));var e=rs;return rs=null,e}function rm(e){if(e===Is||e===Eo)throw Error(r(483))}var Ps=null,Xi=0;function Co(e){var t=Xi;return Xi+=1,Ps===null&&(Ps=[]),sm(Ps,e,t)}function $i(e,t){t=t.props.ref,e.ref=t!==void 0?t:null}function ko(e,t){throw t.$$typeof===b?Error(r(525)):(e=Object.prototype.toString.call(t),Error(r(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e)))}function om(e){function t(V,C){if(e){var G=V.deletions;G===null?(V.deletions=[C],V.flags|=16):G.push(C)}}function s(V,C){if(!e)return null;for(;C!==null;)t(V,C),C=C.sibling;return null}function o(V){for(var C=new Map;V!==null;)V.key!==null?C.set(V.key,V):C.set(V.index,V),V=V.sibling;return C}function c(V,C){return V=$n(V,C),V.index=0,V.sibling=null,V}function f(V,C,G){return V.index=G,e?(G=V.alternate,G!==null?(G=G.index,G<C?(V.flags|=67108866,C):G):(V.flags|=67108866,C)):(V.flags|=1048576,C)}function v(V){return e&&V.alternate===null&&(V.flags|=67108866),V}function R(V,C,G,P){return C===null||C.tag!==6?(C=Jc(G,V.mode,P),C.return=V,C):(C=c(C,G),C.return=V,C)}function N(V,C,G,P){var le=G.type;return le===T?F(V,C,G.props.children,P,G.key):C!==null&&(C.elementType===le||typeof le=="object"&&le!==null&&le.$$typeof===E&&is(le)===C.type)?(C=c(C,G.props),$i(C,G),C.return=V,C):(C=So(G.type,G.key,G.props,null,V.mode,P),$i(C,G),C.return=V,C)}function _(V,C,G,P){return C===null||C.tag!==4||C.stateNode.containerInfo!==G.containerInfo||C.stateNode.implementation!==G.implementation?(C=Wc(G,V.mode,P),C.return=V,C):(C=c(C,G.children||[]),C.return=V,C)}function F(V,C,G,P,le){return C===null||C.tag!==7?(C=es(G,V.mode,P,le),C.return=V,C):(C=c(C,G),C.return=V,C)}function $(V,C,G){if(typeof C=="string"&&C!==""||typeof C=="number"||typeof C=="bigint")return C=Jc(""+C,V.mode,G),C.return=V,C;if(typeof C=="object"&&C!==null){switch(C.$$typeof){case M:return G=So(C.type,C.key,C.props,null,V.mode,G),$i(G,C),G.return=V,G;case S:return C=Wc(C,V.mode,G),C.return=V,C;case E:return C=is(C),$(V,C,G)}if(de(C)||me(C))return C=es(C,V.mode,G,null),C.return=V,C;if(typeof C.then=="function")return $(V,Co(C),G);if(C.$$typeof===z)return $(V,To(V,C),G);ko(V,C)}return null}function B(V,C,G,P){var le=C!==null?C.key:null;if(typeof G=="string"&&G!==""||typeof G=="number"||typeof G=="bigint")return le!==null?null:R(V,C,""+G,P);if(typeof G=="object"&&G!==null){switch(G.$$typeof){case M:return G.key===le?N(V,C,G,P):null;case S:return G.key===le?_(V,C,G,P):null;case E:return G=is(G),B(V,C,G,P)}if(de(G)||me(G))return le!==null?null:F(V,C,G,P,null);if(typeof G.then=="function")return B(V,C,Co(G),P);if(G.$$typeof===z)return B(V,C,To(V,G),P);ko(V,G)}return null}function H(V,C,G,P,le){if(typeof P=="string"&&P!==""||typeof P=="number"||typeof P=="bigint")return V=V.get(G)||null,R(C,V,""+P,le);if(typeof P=="object"&&P!==null){switch(P.$$typeof){case M:return V=V.get(P.key===null?G:P.key)||null,N(C,V,P,le);case S:return V=V.get(P.key===null?G:P.key)||null,_(C,V,P,le);case E:return P=is(P),H(V,C,G,P,le)}if(de(P)||me(P))return V=V.get(G)||null,F(C,V,P,le,null);if(typeof P.then=="function")return H(V,C,G,Co(P),le);if(P.$$typeof===z)return H(V,C,G,To(C,P),le);ko(C,P)}return null}function te(V,C,G,P){for(var le=null,Ce=null,ie=C,xe=C=0,Me=null;ie!==null&&xe<G.length;xe++){ie.index>xe?(Me=ie,ie=null):Me=ie.sibling;var ke=B(V,ie,G[xe],P);if(ke===null){ie===null&&(ie=Me);break}e&&ie&&ke.alternate===null&&t(V,ie),C=f(ke,C,xe),Ce===null?le=ke:Ce.sibling=ke,Ce=ke,ie=Me}if(xe===G.length)return s(V,ie),Ne&&Qn(V,xe),le;if(ie===null){for(;xe<G.length;xe++)ie=$(V,G[xe],P),ie!==null&&(C=f(ie,C,xe),Ce===null?le=ie:Ce.sibling=ie,Ce=ie);return Ne&&Qn(V,xe),le}for(ie=o(ie);xe<G.length;xe++)Me=H(ie,V,xe,G[xe],P),Me!==null&&(e&&Me.alternate!==null&&ie.delete(Me.key===null?xe:Me.key),C=f(Me,C,xe),Ce===null?le=Me:Ce.sibling=Me,Ce=Me);return e&&ie.forEach(function(Ua){return t(V,Ua)}),Ne&&Qn(V,xe),le}function ce(V,C,G,P){if(G==null)throw Error(r(151));for(var le=null,Ce=null,ie=C,xe=C=0,Me=null,ke=G.next();ie!==null&&!ke.done;xe++,ke=G.next()){ie.index>xe?(Me=ie,ie=null):Me=ie.sibling;var Ua=B(V,ie,ke.value,P);if(Ua===null){ie===null&&(ie=Me);break}e&&ie&&Ua.alternate===null&&t(V,ie),C=f(Ua,C,xe),Ce===null?le=Ua:Ce.sibling=Ua,Ce=Ua,ie=Me}if(ke.done)return s(V,ie),Ne&&Qn(V,xe),le;if(ie===null){for(;!ke.done;xe++,ke=G.next())ke=$(V,ke.value,P),ke!==null&&(C=f(ke,C,xe),Ce===null?le=ke:Ce.sibling=ke,Ce=ke);return Ne&&Qn(V,xe),le}for(ie=o(ie);!ke.done;xe++,ke=G.next())ke=H(ie,V,xe,ke.value,P),ke!==null&&(e&&ke.alternate!==null&&ie.delete(ke.key===null?xe:ke.key),C=f(ke,C,xe),Ce===null?le=ke:Ce.sibling=ke,Ce=ke);return e&&ie.forEach(function(N3){return t(V,N3)}),Ne&&Qn(V,xe),le}function Ge(V,C,G,P){if(typeof G=="object"&&G!==null&&G.type===T&&G.key===null&&(G=G.props.children),typeof G=="object"&&G!==null){switch(G.$$typeof){case M:e:{for(var le=G.key;C!==null;){if(C.key===le){if(le=G.type,le===T){if(C.tag===7){s(V,C.sibling),P=c(C,G.props.children),P.return=V,V=P;break e}}else if(C.elementType===le||typeof le=="object"&&le!==null&&le.$$typeof===E&&is(le)===C.type){s(V,C.sibling),P=c(C,G.props),$i(P,G),P.return=V,V=P;break e}s(V,C);break}else t(V,C);C=C.sibling}G.type===T?(P=es(G.props.children,V.mode,P,G.key),P.return=V,V=P):(P=So(G.type,G.key,G.props,null,V.mode,P),$i(P,G),P.return=V,V=P)}return v(V);case S:e:{for(le=G.key;C!==null;){if(C.key===le)if(C.tag===4&&C.stateNode.containerInfo===G.containerInfo&&C.stateNode.implementation===G.implementation){s(V,C.sibling),P=c(C,G.children||[]),P.return=V,V=P;break e}else{s(V,C);break}else t(V,C);C=C.sibling}P=Wc(G,V.mode,P),P.return=V,V=P}return v(V);case E:return G=is(G),Ge(V,C,G,P)}if(de(G))return te(V,C,G,P);if(me(G)){if(le=me(G),typeof le!="function")throw Error(r(150));return G=le.call(G),ce(V,C,G,P)}if(typeof G.then=="function")return Ge(V,C,Co(G),P);if(G.$$typeof===z)return Ge(V,C,To(V,G),P);ko(V,G)}return typeof G=="string"&&G!==""||typeof G=="number"||typeof G=="bigint"?(G=""+G,C!==null&&C.tag===6?(s(V,C.sibling),P=c(C,G),P.return=V,V=P):(s(V,C),P=Jc(G,V.mode,P),P.return=V,V=P),v(V)):s(V,C)}return function(V,C,G,P){try{Xi=0;var le=Ge(V,C,G,P);return Ps=null,le}catch(ie){if(ie===Is||ie===Eo)throw ie;var Ce=Wt(29,ie,null,V.mode);return Ce.lanes=P,Ce.return=V,Ce}}}var os=om(!0),lm=om(!1),Sa=!1;function du(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function fu(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function ja(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function Ma(e,t,s){var o=e.updateQueue;if(o===null)return null;if(o=o.shared,(De&2)!==0){var c=o.pending;return c===null?t.next=t:(t.next=c.next,c.next=t),o.pending=t,t=wo(e),Yp(e,null,s),t}return Ro(e,o,t,s),wo(e)}function Qi(e,t,s){if(t=t.updateQueue,t!==null&&(t=t.shared,(s&4194048)!==0)){var o=t.lanes;o&=e.pendingLanes,s|=o,t.lanes=s,Wh(e,s)}}function hu(e,t){var s=e.updateQueue,o=e.alternate;if(o!==null&&(o=o.updateQueue,s===o)){var c=null,f=null;if(s=s.firstBaseUpdate,s!==null){do{var v={lane:s.lane,tag:s.tag,payload:s.payload,callback:null,next:null};f===null?c=f=v:f=f.next=v,s=s.next}while(s!==null);f===null?c=f=t:f=f.next=t}else c=f=t;s={baseState:o.baseState,firstBaseUpdate:c,lastBaseUpdate:f,shared:o.shared,callbacks:o.callbacks},e.updateQueue=s;return}e=s.lastBaseUpdate,e===null?s.firstBaseUpdate=t:e.next=t,s.lastBaseUpdate=t}var pu=!1;function Zi(){if(pu){var e=Fs;if(e!==null)throw e}}function Ki(e,t,s,o){pu=!1;var c=e.updateQueue;Sa=!1;var f=c.firstBaseUpdate,v=c.lastBaseUpdate,R=c.shared.pending;if(R!==null){c.shared.pending=null;var N=R,_=N.next;N.next=null,v===null?f=_:v.next=_,v=N;var F=e.alternate;F!==null&&(F=F.updateQueue,R=F.lastBaseUpdate,R!==v&&(R===null?F.firstBaseUpdate=_:R.next=_,F.lastBaseUpdate=N))}if(f!==null){var $=c.baseState;v=0,F=_=N=null,R=f;do{var B=R.lane&-536870913,H=B!==R.lane;if(H?(je&B)===B:(o&B)===B){B!==0&&B===Hs&&(pu=!0),F!==null&&(F=F.next={lane:0,tag:R.tag,payload:R.payload,callback:null,next:null});e:{var te=e,ce=R;B=t;var Ge=s;switch(ce.tag){case 1:if(te=ce.payload,typeof te=="function"){$=te.call(Ge,$,B);break e}$=te;break e;case 3:te.flags=te.flags&-65537|128;case 0:if(te=ce.payload,B=typeof te=="function"?te.call(Ge,$,B):te,B==null)break e;$=x({},$,B);break e;case 2:Sa=!0}}B=R.callback,B!==null&&(e.flags|=64,H&&(e.flags|=8192),H=c.callbacks,H===null?c.callbacks=[B]:H.push(B))}else H={lane:B,tag:R.tag,payload:R.payload,callback:R.callback,next:null},F===null?(_=F=H,N=$):F=F.next=H,v|=B;if(R=R.next,R===null){if(R=c.shared.pending,R===null)break;H=R,R=H.next,H.next=null,c.lastBaseUpdate=H,c.shared.pending=null}}while(!0);F===null&&(N=$),c.baseState=N,c.firstBaseUpdate=_,c.lastBaseUpdate=F,f===null&&(c.shared.lanes=0),Ca|=v,e.lanes=v,e.memoizedState=$}}function cm(e,t){if(typeof e!="function")throw Error(r(191,e));e.call(t)}function um(e,t){var s=e.callbacks;if(s!==null)for(e.callbacks=null,e=0;e<s.length;e++)cm(s[e],t)}var Ys=A(null),Do=A(0);function dm(e,t){e=ra,Z(Do,e),Z(Ys,t),ra=e|t.baseLanes}function mu(){Z(Do,ra),Z(Ys,Ys.current)}function gu(){ra=Do.current,I(Ys),I(Do)}var en=A(null),mn=null;function Ta(e){var t=e.alternate;Z(st,st.current&1),Z(en,e),mn===null&&(t===null||Ys.current!==null||t.memoizedState!==null)&&(mn=e)}function yu(e){Z(st,st.current),Z(en,e),mn===null&&(mn=e)}function fm(e){e.tag===22?(Z(st,st.current),Z(en,e),mn===null&&(mn=e)):Na()}function Na(){Z(st,st.current),Z(en,en.current)}function tn(e){I(en),mn===e&&(mn=null),I(st)}var st=A(0);function zo(e){for(var t=e;t!==null;){if(t.tag===13){var s=t.memoizedState;if(s!==null&&(s=s.dehydrated,s===null||Sd(s)||jd(s)))return t}else if(t.tag===19&&(t.memoizedProps.revealOrder==="forwards"||t.memoizedProps.revealOrder==="backwards"||t.memoizedProps.revealOrder==="unstable_legacy-backwards"||t.memoizedProps.revealOrder==="together")){if((t.flags&128)!==0)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var Jn=0,ge=null,Oe=null,ot=null,Vo=!1,qs=!1,ls=!1,Oo=0,Ji=0,Xs=null,y5=0;function Je(){throw Error(r(321))}function xu(e,t){if(t===null)return!1;for(var s=0;s<t.length&&s<e.length;s++)if(!Jt(e[s],t[s]))return!1;return!0}function vu(e,t,s,o,c,f){return Jn=f,ge=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,U.H=e===null||e.memoizedState===null?Qm:Vu,ls=!1,f=s(o,c),ls=!1,qs&&(f=pm(t,s,o,c)),hm(e),f}function hm(e){U.H=tr;var t=Oe!==null&&Oe.next!==null;if(Jn=0,ot=Oe=ge=null,Vo=!1,Ji=0,Xs=null,t)throw Error(r(300));e===null||lt||(e=e.dependencies,e!==null&&Mo(e)&&(lt=!0))}function pm(e,t,s,o){ge=e;var c=0;do{if(qs&&(Xs=null),Ji=0,qs=!1,25<=c)throw Error(r(301));if(c+=1,ot=Oe=null,e.updateQueue!=null){var f=e.updateQueue;f.lastEffect=null,f.events=null,f.stores=null,f.memoCache!=null&&(f.memoCache.index=0)}U.H=Zm,f=t(s,o)}while(qs);return f}function x5(){var e=U.H,t=e.useState()[0];return t=typeof t.then=="function"?Wi(t):t,e=e.useState()[0],(Oe!==null?Oe.memoizedState:null)!==e&&(ge.flags|=1024),t}function bu(){var e=Oo!==0;return Oo=0,e}function Ru(e,t,s){t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~s}function wu(e){if(Vo){for(e=e.memoizedState;e!==null;){var t=e.queue;t!==null&&(t.pending=null),e=e.next}Vo=!1}Jn=0,ot=Oe=ge=null,qs=!1,Ji=Oo=0,Xs=null}function zt(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return ot===null?ge.memoizedState=ot=e:ot=ot.next=e,ot}function it(){if(Oe===null){var e=ge.alternate;e=e!==null?e.memoizedState:null}else e=Oe.next;var t=ot===null?ge.memoizedState:ot.next;if(t!==null)ot=t,Oe=e;else{if(e===null)throw ge.alternate===null?Error(r(467)):Error(r(310));Oe=e,e={memoizedState:Oe.memoizedState,baseState:Oe.baseState,baseQueue:Oe.baseQueue,queue:Oe.queue,next:null},ot===null?ge.memoizedState=ot=e:ot=ot.next=e}return ot}function Lo(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Wi(e){var t=Ji;return Ji+=1,Xs===null&&(Xs=[]),e=sm(Xs,e,t),t=ge,(ot===null?t.memoizedState:ot.next)===null&&(t=t.alternate,U.H=t===null||t.memoizedState===null?Qm:Vu),e}function Go(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return Wi(e);if(e.$$typeof===z)return Et(e)}throw Error(r(438,String(e)))}function Su(e){var t=null,s=ge.updateQueue;if(s!==null&&(t=s.memoCache),t==null){var o=ge.alternate;o!==null&&(o=o.updateQueue,o!==null&&(o=o.memoCache,o!=null&&(t={data:o.data.map(function(c){return c.slice()}),index:0})))}if(t==null&&(t={data:[],index:0}),s===null&&(s=Lo(),ge.updateQueue=s),s.memoCache=t,s=t.data[t.index],s===void 0)for(s=t.data[t.index]=Array(e),o=0;o<e;o++)s[o]=ee;return t.index++,s}function Wn(e,t){return typeof t=="function"?t(e):t}function _o(e){var t=it();return ju(t,Oe,e)}function ju(e,t,s){var o=e.queue;if(o===null)throw Error(r(311));o.lastRenderedReducer=s;var c=e.baseQueue,f=o.pending;if(f!==null){if(c!==null){var v=c.next;c.next=f.next,f.next=v}t.baseQueue=c=f,o.pending=null}if(f=e.baseState,c===null)e.memoizedState=f;else{t=c.next;var R=v=null,N=null,_=t,F=!1;do{var $=_.lane&-536870913;if($!==_.lane?(je&$)===$:(Jn&$)===$){var B=_.revertLane;if(B===0)N!==null&&(N=N.next={lane:0,revertLane:0,gesture:null,action:_.action,hasEagerState:_.hasEagerState,eagerState:_.eagerState,next:null}),$===Hs&&(F=!0);else if((Jn&B)===B){_=_.next,B===Hs&&(F=!0);continue}else $={lane:0,revertLane:_.revertLane,gesture:null,action:_.action,hasEagerState:_.hasEagerState,eagerState:_.eagerState,next:null},N===null?(R=N=$,v=f):N=N.next=$,ge.lanes|=B,Ca|=B;$=_.action,ls&&s(f,$),f=_.hasEagerState?_.eagerState:s(f,$)}else B={lane:$,revertLane:_.revertLane,gesture:_.gesture,action:_.action,hasEagerState:_.hasEagerState,eagerState:_.eagerState,next:null},N===null?(R=N=B,v=f):N=N.next=B,ge.lanes|=$,Ca|=$;_=_.next}while(_!==null&&_!==t);if(N===null?v=f:N.next=R,!Jt(f,e.memoizedState)&&(lt=!0,F&&(s=Fs,s!==null)))throw s;e.memoizedState=f,e.baseState=v,e.baseQueue=N,o.lastRenderedState=f}return c===null&&(o.lanes=0),[e.memoizedState,o.dispatch]}function Mu(e){var t=it(),s=t.queue;if(s===null)throw Error(r(311));s.lastRenderedReducer=e;var o=s.dispatch,c=s.pending,f=t.memoizedState;if(c!==null){s.pending=null;var v=c=c.next;do f=e(f,v.action),v=v.next;while(v!==c);Jt(f,t.memoizedState)||(lt=!0),t.memoizedState=f,t.baseQueue===null&&(t.baseState=f),s.lastRenderedState=f}return[f,o]}function mm(e,t,s){var o=ge,c=it(),f=Ne;if(f){if(s===void 0)throw Error(r(407));s=s()}else s=t();var v=!Jt((Oe||c).memoizedState,s);if(v&&(c.memoizedState=s,lt=!0),c=c.queue,Eu(xm.bind(null,o,c,e),[e]),c.getSnapshot!==t||v||ot!==null&&ot.memoizedState.tag&1){if(o.flags|=2048,$s(9,{destroy:void 0},ym.bind(null,o,c,s,t),null),Be===null)throw Error(r(349));f||(Jn&127)!==0||gm(o,t,s)}return s}function gm(e,t,s){e.flags|=16384,e={getSnapshot:t,value:s},t=ge.updateQueue,t===null?(t=Lo(),ge.updateQueue=t,t.stores=[e]):(s=t.stores,s===null?t.stores=[e]:s.push(e))}function ym(e,t,s,o){t.value=s,t.getSnapshot=o,vm(t)&&bm(e)}function xm(e,t,s){return s(function(){vm(t)&&bm(e)})}function vm(e){var t=e.getSnapshot;e=e.value;try{var s=t();return!Jt(e,s)}catch{return!0}}function bm(e){var t=Wa(e,2);t!==null&&qt(t,e,2)}function Tu(e){var t=zt();if(typeof e=="function"){var s=e;if(e=s(),ls){ga(!0);try{s()}finally{ga(!1)}}}return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Wn,lastRenderedState:e},t}function Rm(e,t,s,o){return e.baseState=s,ju(e,Oe,typeof o=="function"?o:Wn)}function v5(e,t,s,o,c){if(Ho(e))throw Error(r(485));if(e=t.action,e!==null){var f={payload:c,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(v){f.listeners.push(v)}};U.T!==null?s(!0):f.isTransition=!1,o(f),s=t.pending,s===null?(f.next=t.pending=f,wm(t,f)):(f.next=s.next,t.pending=s.next=f)}}function wm(e,t){var s=t.action,o=t.payload,c=e.state;if(t.isTransition){var f=U.T,v={};U.T=v;try{var R=s(c,o),N=U.S;N!==null&&N(v,R),Sm(e,t,R)}catch(_){Nu(e,t,_)}finally{f!==null&&v.types!==null&&(f.types=v.types),U.T=f}}else try{f=s(c,o),Sm(e,t,f)}catch(_){Nu(e,t,_)}}function Sm(e,t,s){s!==null&&typeof s=="object"&&typeof s.then=="function"?s.then(function(o){jm(e,t,o)},function(o){return Nu(e,t,o)}):jm(e,t,s)}function jm(e,t,s){t.status="fulfilled",t.value=s,Mm(t),e.state=s,t=e.pending,t!==null&&(s=t.next,s===t?e.pending=null:(s=s.next,t.next=s,wm(e,s)))}function Nu(e,t,s){var o=e.pending;if(e.pending=null,o!==null){o=o.next;do t.status="rejected",t.reason=s,Mm(t),t=t.next;while(t!==o)}e.action=null}function Mm(e){e=e.listeners;for(var t=0;t<e.length;t++)(0,e[t])()}function Tm(e,t){return t}function Nm(e,t){if(Ne){var s=Be.formState;if(s!==null){e:{var o=ge;if(Ne){if(Ye){t:{for(var c=Ye,f=pn;c.nodeType!==8;){if(!f){c=null;break t}if(c=gn(c.nextSibling),c===null){c=null;break t}}f=c.data,c=f==="F!"||f==="F"?c:null}if(c){Ye=gn(c.nextSibling),o=c.data==="F!";break e}}Ra(o)}o=!1}o&&(t=s[0])}}return s=zt(),s.memoizedState=s.baseState=t,o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Tm,lastRenderedState:t},s.queue=o,s=qm.bind(null,ge,o),o.dispatch=s,o=Tu(!1),f=zu.bind(null,ge,!1,o.queue),o=zt(),c={state:t,dispatch:null,action:e,pending:null},o.queue=c,s=v5.bind(null,ge,c,f,s),c.dispatch=s,o.memoizedState=e,[t,s,!1]}function Em(e){var t=it();return Am(t,Oe,e)}function Am(e,t,s){if(t=ju(e,t,Tm)[0],e=_o(Wn)[0],typeof t=="object"&&t!==null&&typeof t.then=="function")try{var o=Wi(t)}catch(v){throw v===Is?Eo:v}else o=t;t=it();var c=t.queue,f=c.dispatch;return s!==t.memoizedState&&(ge.flags|=2048,$s(9,{destroy:void 0},b5.bind(null,c,s),null)),[o,f,e]}function b5(e,t){e.action=t}function Cm(e){var t=it(),s=Oe;if(s!==null)return Am(t,s,e);it(),t=t.memoizedState,s=it();var o=s.queue.dispatch;return s.memoizedState=e,[t,o,!1]}function $s(e,t,s,o){return e={tag:e,create:s,deps:o,inst:t,next:null},t=ge.updateQueue,t===null&&(t=Lo(),ge.updateQueue=t),s=t.lastEffect,s===null?t.lastEffect=e.next=e:(o=s.next,s.next=e,e.next=o,t.lastEffect=e),e}function km(){return it().memoizedState}function Bo(e,t,s,o){var c=zt();ge.flags|=e,c.memoizedState=$s(1|t,{destroy:void 0},s,o===void 0?null:o)}function Uo(e,t,s,o){var c=it();o=o===void 0?null:o;var f=c.memoizedState.inst;Oe!==null&&o!==null&&xu(o,Oe.memoizedState.deps)?c.memoizedState=$s(t,f,s,o):(ge.flags|=e,c.memoizedState=$s(1|t,f,s,o))}function Dm(e,t){Bo(8390656,8,e,t)}function Eu(e,t){Uo(2048,8,e,t)}function R5(e){ge.flags|=4;var t=ge.updateQueue;if(t===null)t=Lo(),ge.updateQueue=t,t.events=[e];else{var s=t.events;s===null?t.events=[e]:s.push(e)}}function zm(e){var t=it().memoizedState;return R5({ref:t,nextImpl:e}),function(){if((De&2)!==0)throw Error(r(440));return t.impl.apply(void 0,arguments)}}function Vm(e,t){return Uo(4,2,e,t)}function Om(e,t){return Uo(4,4,e,t)}function Lm(e,t){if(typeof t=="function"){e=e();var s=t(e);return function(){typeof s=="function"?s():t(null)}}if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Gm(e,t,s){s=s!=null?s.concat([e]):null,Uo(4,4,Lm.bind(null,t,e),s)}function Au(){}function _m(e,t){var s=it();t=t===void 0?null:t;var o=s.memoizedState;return t!==null&&xu(t,o[1])?o[0]:(s.memoizedState=[e,t],e)}function Bm(e,t){var s=it();t=t===void 0?null:t;var o=s.memoizedState;if(t!==null&&xu(t,o[1]))return o[0];if(o=e(),ls){ga(!0);try{e()}finally{ga(!1)}}return s.memoizedState=[o,t],o}function Cu(e,t,s){return s===void 0||(Jn&1073741824)!==0&&(je&261930)===0?e.memoizedState=t:(e.memoizedState=s,e=Ug(),ge.lanes|=e,Ca|=e,s)}function Um(e,t,s,o){return Jt(s,t)?s:Ys.current!==null?(e=Cu(e,s,o),Jt(e,t)||(lt=!0),e):(Jn&42)===0||(Jn&1073741824)!==0&&(je&261930)===0?(lt=!0,e.memoizedState=s):(e=Ug(),ge.lanes|=e,Ca|=e,t)}function Hm(e,t,s,o,c){var f=K.p;K.p=f!==0&&8>f?f:8;var v=U.T,R={};U.T=R,zu(e,!1,t,s);try{var N=c(),_=U.S;if(_!==null&&_(R,N),N!==null&&typeof N=="object"&&typeof N.then=="function"){var F=g5(N,o);er(e,t,F,sn(e))}else er(e,t,o,sn(e))}catch($){er(e,t,{then:function(){},status:"rejected",reason:$},sn())}finally{K.p=f,v!==null&&R.types!==null&&(v.types=R.types),U.T=v}}function w5(){}function ku(e,t,s,o){if(e.tag!==5)throw Error(r(476));var c=Fm(e).queue;Hm(e,c,t,Y,s===null?w5:function(){return Im(e),s(o)})}function Fm(e){var t=e.memoizedState;if(t!==null)return t;t={memoizedState:Y,baseState:Y,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Wn,lastRenderedState:Y},next:null};var s={};return t.next={memoizedState:s,baseState:s,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Wn,lastRenderedState:s},next:null},e.memoizedState=t,e=e.alternate,e!==null&&(e.memoizedState=t),t}function Im(e){var t=Fm(e);t.next===null&&(t=e.alternate.memoizedState),er(e,t.next.queue,{},sn())}function Du(){return Et(yr)}function Pm(){return it().memoizedState}function Ym(){return it().memoizedState}function S5(e){for(var t=e.return;t!==null;){switch(t.tag){case 24:case 3:var s=sn();e=ja(s);var o=Ma(t,e,s);o!==null&&(qt(o,t,s),Qi(o,t,s)),t={cache:ou()},e.payload=t;return}t=t.return}}function j5(e,t,s){var o=sn();s={lane:o,revertLane:0,gesture:null,action:s,hasEagerState:!1,eagerState:null,next:null},Ho(e)?Xm(t,s):(s=Zc(e,t,s,o),s!==null&&(qt(s,e,o),$m(s,t,o)))}function qm(e,t,s){var o=sn();er(e,t,s,o)}function er(e,t,s,o){var c={lane:o,revertLane:0,gesture:null,action:s,hasEagerState:!1,eagerState:null,next:null};if(Ho(e))Xm(t,c);else{var f=e.alternate;if(e.lanes===0&&(f===null||f.lanes===0)&&(f=t.lastRenderedReducer,f!==null))try{var v=t.lastRenderedState,R=f(v,s);if(c.hasEagerState=!0,c.eagerState=R,Jt(R,v))return Ro(e,t,c,0),Be===null&&bo(),!1}catch{}if(s=Zc(e,t,c,o),s!==null)return qt(s,e,o),$m(s,t,o),!0}return!1}function zu(e,t,s,o){if(o={lane:2,revertLane:dd(),gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null},Ho(e)){if(t)throw Error(r(479))}else t=Zc(e,s,o,2),t!==null&&qt(t,e,2)}function Ho(e){var t=e.alternate;return e===ge||t!==null&&t===ge}function Xm(e,t){qs=Vo=!0;var s=e.pending;s===null?t.next=t:(t.next=s.next,s.next=t),e.pending=t}function $m(e,t,s){if((s&4194048)!==0){var o=t.lanes;o&=e.pendingLanes,s|=o,t.lanes=s,Wh(e,s)}}var tr={readContext:Et,use:Go,useCallback:Je,useContext:Je,useEffect:Je,useImperativeHandle:Je,useLayoutEffect:Je,useInsertionEffect:Je,useMemo:Je,useReducer:Je,useRef:Je,useState:Je,useDebugValue:Je,useDeferredValue:Je,useTransition:Je,useSyncExternalStore:Je,useId:Je,useHostTransitionStatus:Je,useFormState:Je,useActionState:Je,useOptimistic:Je,useMemoCache:Je,useCacheRefresh:Je};tr.useEffectEvent=Je;var Qm={readContext:Et,use:Go,useCallback:function(e,t){return zt().memoizedState=[e,t===void 0?null:t],e},useContext:Et,useEffect:Dm,useImperativeHandle:function(e,t,s){s=s!=null?s.concat([e]):null,Bo(4194308,4,Lm.bind(null,t,e),s)},useLayoutEffect:function(e,t){return Bo(4194308,4,e,t)},useInsertionEffect:function(e,t){Bo(4,2,e,t)},useMemo:function(e,t){var s=zt();t=t===void 0?null:t;var o=e();if(ls){ga(!0);try{e()}finally{ga(!1)}}return s.memoizedState=[o,t],o},useReducer:function(e,t,s){var o=zt();if(s!==void 0){var c=s(t);if(ls){ga(!0);try{s(t)}finally{ga(!1)}}}else c=t;return o.memoizedState=o.baseState=c,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:c},o.queue=e,e=e.dispatch=j5.bind(null,ge,e),[o.memoizedState,e]},useRef:function(e){var t=zt();return e={current:e},t.memoizedState=e},useState:function(e){e=Tu(e);var t=e.queue,s=qm.bind(null,ge,t);return t.dispatch=s,[e.memoizedState,s]},useDebugValue:Au,useDeferredValue:function(e,t){var s=zt();return Cu(s,e,t)},useTransition:function(){var e=Tu(!1);return e=Hm.bind(null,ge,e.queue,!0,!1),zt().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,t,s){var o=ge,c=zt();if(Ne){if(s===void 0)throw Error(r(407));s=s()}else{if(s=t(),Be===null)throw Error(r(349));(je&127)!==0||gm(o,t,s)}c.memoizedState=s;var f={value:s,getSnapshot:t};return c.queue=f,Dm(xm.bind(null,o,f,e),[e]),o.flags|=2048,$s(9,{destroy:void 0},ym.bind(null,o,f,s,t),null),s},useId:function(){var e=zt(),t=Be.identifierPrefix;if(Ne){var s=Ln,o=On;s=(o&~(1<<32-Kt(o)-1)).toString(32)+s,t="_"+t+"R_"+s,s=Oo++,0<s&&(t+="H"+s.toString(32)),t+="_"}else s=y5++,t="_"+t+"r_"+s.toString(32)+"_";return e.memoizedState=t},useHostTransitionStatus:Du,useFormState:Nm,useActionState:Nm,useOptimistic:function(e){var t=zt();t.memoizedState=t.baseState=e;var s={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return t.queue=s,t=zu.bind(null,ge,!0,s),s.dispatch=t,[e,t]},useMemoCache:Su,useCacheRefresh:function(){return zt().memoizedState=S5.bind(null,ge)},useEffectEvent:function(e){var t=zt(),s={impl:e};return t.memoizedState=s,function(){if((De&2)!==0)throw Error(r(440));return s.impl.apply(void 0,arguments)}}},Vu={readContext:Et,use:Go,useCallback:_m,useContext:Et,useEffect:Eu,useImperativeHandle:Gm,useInsertionEffect:Vm,useLayoutEffect:Om,useMemo:Bm,useReducer:_o,useRef:km,useState:function(){return _o(Wn)},useDebugValue:Au,useDeferredValue:function(e,t){var s=it();return Um(s,Oe.memoizedState,e,t)},useTransition:function(){var e=_o(Wn)[0],t=it().memoizedState;return[typeof e=="boolean"?e:Wi(e),t]},useSyncExternalStore:mm,useId:Pm,useHostTransitionStatus:Du,useFormState:Em,useActionState:Em,useOptimistic:function(e,t){var s=it();return Rm(s,Oe,e,t)},useMemoCache:Su,useCacheRefresh:Ym};Vu.useEffectEvent=zm;var Zm={readContext:Et,use:Go,useCallback:_m,useContext:Et,useEffect:Eu,useImperativeHandle:Gm,useInsertionEffect:Vm,useLayoutEffect:Om,useMemo:Bm,useReducer:Mu,useRef:km,useState:function(){return Mu(Wn)},useDebugValue:Au,useDeferredValue:function(e,t){var s=it();return Oe===null?Cu(s,e,t):Um(s,Oe.memoizedState,e,t)},useTransition:function(){var e=Mu(Wn)[0],t=it().memoizedState;return[typeof e=="boolean"?e:Wi(e),t]},useSyncExternalStore:mm,useId:Pm,useHostTransitionStatus:Du,useFormState:Cm,useActionState:Cm,useOptimistic:function(e,t){var s=it();return Oe!==null?Rm(s,Oe,e,t):(s.baseState=e,[e,s.queue.dispatch])},useMemoCache:Su,useCacheRefresh:Ym};Zm.useEffectEvent=zm;function Ou(e,t,s,o){t=e.memoizedState,s=s(o,t),s=s==null?t:x({},t,s),e.memoizedState=s,e.lanes===0&&(e.updateQueue.baseState=s)}var Lu={enqueueSetState:function(e,t,s){e=e._reactInternals;var o=sn(),c=ja(o);c.payload=t,s!=null&&(c.callback=s),t=Ma(e,c,o),t!==null&&(qt(t,e,o),Qi(t,e,o))},enqueueReplaceState:function(e,t,s){e=e._reactInternals;var o=sn(),c=ja(o);c.tag=1,c.payload=t,s!=null&&(c.callback=s),t=Ma(e,c,o),t!==null&&(qt(t,e,o),Qi(t,e,o))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var s=sn(),o=ja(s);o.tag=2,t!=null&&(o.callback=t),t=Ma(e,o,s),t!==null&&(qt(t,e,s),Qi(t,e,s))}};function Km(e,t,s,o,c,f,v){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(o,f,v):t.prototype&&t.prototype.isPureReactComponent?!Hi(s,o)||!Hi(c,f):!0}function Jm(e,t,s,o){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(s,o),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(s,o),t.state!==e&&Lu.enqueueReplaceState(t,t.state,null)}function cs(e,t){var s=t;if("ref"in t){s={};for(var o in t)o!=="ref"&&(s[o]=t[o])}if(e=e.defaultProps){s===t&&(s=x({},s));for(var c in e)s[c]===void 0&&(s[c]=e[c])}return s}function Wm(e){vo(e)}function eg(e){console.error(e)}function tg(e){vo(e)}function Fo(e,t){try{var s=e.onUncaughtError;s(t.value,{componentStack:t.stack})}catch(o){setTimeout(function(){throw o})}}function ng(e,t,s){try{var o=e.onCaughtError;o(s.value,{componentStack:s.stack,errorBoundary:t.tag===1?t.stateNode:null})}catch(c){setTimeout(function(){throw c})}}function Gu(e,t,s){return s=ja(s),s.tag=3,s.payload={element:null},s.callback=function(){Fo(e,t)},s}function ag(e){return e=ja(e),e.tag=3,e}function sg(e,t,s,o){var c=s.type.getDerivedStateFromError;if(typeof c=="function"){var f=o.value;e.payload=function(){return c(f)},e.callback=function(){ng(t,s,o)}}var v=s.stateNode;v!==null&&typeof v.componentDidCatch=="function"&&(e.callback=function(){ng(t,s,o),typeof c!="function"&&(ka===null?ka=new Set([this]):ka.add(this));var R=o.stack;this.componentDidCatch(o.value,{componentStack:R!==null?R:""})})}function M5(e,t,s,o,c){if(s.flags|=32768,o!==null&&typeof o=="object"&&typeof o.then=="function"){if(t=s.alternate,t!==null&&Us(t,s,c,!0),s=en.current,s!==null){switch(s.tag){case 31:case 13:return mn===null?el():s.alternate===null&&We===0&&(We=3),s.flags&=-257,s.flags|=65536,s.lanes=c,o===Ao?s.flags|=16384:(t=s.updateQueue,t===null?s.updateQueue=new Set([o]):t.add(o),ld(e,o,c)),!1;case 22:return s.flags|=65536,o===Ao?s.flags|=16384:(t=s.updateQueue,t===null?(t={transitions:null,markerInstances:null,retryQueue:new Set([o])},s.updateQueue=t):(s=t.retryQueue,s===null?t.retryQueue=new Set([o]):s.add(o)),ld(e,o,c)),!1}throw Error(r(435,s.tag))}return ld(e,o,c),el(),!1}if(Ne)return t=en.current,t!==null?((t.flags&65536)===0&&(t.flags|=256),t.flags|=65536,t.lanes=c,o!==nu&&(e=Error(r(422),{cause:o}),Pi(dn(e,s)))):(o!==nu&&(t=Error(r(423),{cause:o}),Pi(dn(t,s))),e=e.current.alternate,e.flags|=65536,c&=-c,e.lanes|=c,o=dn(o,s),c=Gu(e.stateNode,o,c),hu(e,c),We!==4&&(We=2)),!1;var f=Error(r(520),{cause:o});if(f=dn(f,s),cr===null?cr=[f]:cr.push(f),We!==4&&(We=2),t===null)return!0;o=dn(o,s),s=t;do{switch(s.tag){case 3:return s.flags|=65536,e=c&-c,s.lanes|=e,e=Gu(s.stateNode,o,e),hu(s,e),!1;case 1:if(t=s.type,f=s.stateNode,(s.flags&128)===0&&(typeof t.getDerivedStateFromError=="function"||f!==null&&typeof f.componentDidCatch=="function"&&(ka===null||!ka.has(f))))return s.flags|=65536,c&=-c,s.lanes|=c,c=ag(c),sg(c,e,s,o),hu(s,c),!1}s=s.return}while(s!==null);return!1}var _u=Error(r(461)),lt=!1;function At(e,t,s,o){t.child=e===null?lm(t,null,s,o):os(t,e.child,s,o)}function ig(e,t,s,o,c){s=s.render;var f=t.ref;if("ref"in o){var v={};for(var R in o)R!=="ref"&&(v[R]=o[R])}else v=o;return as(t),o=vu(e,t,s,v,f,c),R=bu(),e!==null&&!lt?(Ru(e,t,c),ea(e,t,c)):(Ne&&R&&eu(t),t.flags|=1,At(e,t,o,c),t.child)}function rg(e,t,s,o,c){if(e===null){var f=s.type;return typeof f=="function"&&!Kc(f)&&f.defaultProps===void 0&&s.compare===null?(t.tag=15,t.type=f,og(e,t,f,o,c)):(e=So(s.type,null,o,t,t.mode,c),e.ref=t.ref,e.return=t,t.child=e)}if(f=e.child,!qu(e,c)){var v=f.memoizedProps;if(s=s.compare,s=s!==null?s:Hi,s(v,o)&&e.ref===t.ref)return ea(e,t,c)}return t.flags|=1,e=$n(f,o),e.ref=t.ref,e.return=t,t.child=e}function og(e,t,s,o,c){if(e!==null){var f=e.memoizedProps;if(Hi(f,o)&&e.ref===t.ref)if(lt=!1,t.pendingProps=o=f,qu(e,c))(e.flags&131072)!==0&&(lt=!0);else return t.lanes=e.lanes,ea(e,t,c)}return Bu(e,t,s,o,c)}function lg(e,t,s,o){var c=o.children,f=e!==null?e.memoizedState:null;if(e===null&&t.stateNode===null&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),o.mode==="hidden"){if((t.flags&128)!==0){if(f=f!==null?f.baseLanes|s:s,e!==null){for(o=t.child=e.child,c=0;o!==null;)c=c|o.lanes|o.childLanes,o=o.sibling;o=c&~f}else o=0,t.child=null;return cg(e,t,f,s,o)}if((s&536870912)!==0)t.memoizedState={baseLanes:0,cachePool:null},e!==null&&No(t,f!==null?f.cachePool:null),f!==null?dm(t,f):mu(),fm(t);else return o=t.lanes=536870912,cg(e,t,f!==null?f.baseLanes|s:s,s,o)}else f!==null?(No(t,f.cachePool),dm(t,f),Na(),t.memoizedState=null):(e!==null&&No(t,null),mu(),Na());return At(e,t,c,s),t.child}function nr(e,t){return e!==null&&e.tag===22||t.stateNode!==null||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling}function cg(e,t,s,o,c){var f=cu();return f=f===null?null:{parent:rt._currentValue,pool:f},t.memoizedState={baseLanes:s,cachePool:f},e!==null&&No(t,null),mu(),fm(t),e!==null&&Us(e,t,o,!0),t.childLanes=c,null}function Io(e,t){return t=Yo({mode:t.mode,children:t.children},e.mode),t.ref=e.ref,e.child=t,t.return=e,t}function ug(e,t,s){return os(t,e.child,null,s),e=Io(t,t.pendingProps),e.flags|=2,tn(t),t.memoizedState=null,e}function T5(e,t,s){var o=t.pendingProps,c=(t.flags&128)!==0;if(t.flags&=-129,e===null){if(Ne){if(o.mode==="hidden")return e=Io(t,o),t.lanes=536870912,nr(null,e);if(yu(t),(e=Ye)?(e=w0(e,pn),e=e!==null&&e.data==="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:va!==null?{id:On,overflow:Ln}:null,retryLane:536870912,hydrationErrors:null},s=Xp(e),s.return=t,t.child=s,Nt=t,Ye=null)):e=null,e===null)throw Ra(t);return t.lanes=536870912,null}return Io(t,o)}var f=e.memoizedState;if(f!==null){var v=f.dehydrated;if(yu(t),c)if(t.flags&256)t.flags&=-257,t=ug(e,t,s);else if(t.memoizedState!==null)t.child=e.child,t.flags|=128,t=null;else throw Error(r(558));else if(lt||Us(e,t,s,!1),c=(s&e.childLanes)!==0,lt||c){if(o=Be,o!==null&&(v=ep(o,s),v!==0&&v!==f.retryLane))throw f.retryLane=v,Wa(e,v),qt(o,e,v),_u;el(),t=ug(e,t,s)}else e=f.treeContext,Ye=gn(v.nextSibling),Nt=t,Ne=!0,ba=null,pn=!1,e!==null&&Zp(t,e),t=Io(t,o),t.flags|=4096;return t}return e=$n(e.child,{mode:o.mode,children:o.children}),e.ref=t.ref,t.child=e,e.return=t,e}function Po(e,t){var s=t.ref;if(s===null)e!==null&&e.ref!==null&&(t.flags|=4194816);else{if(typeof s!="function"&&typeof s!="object")throw Error(r(284));(e===null||e.ref!==s)&&(t.flags|=4194816)}}function Bu(e,t,s,o,c){return as(t),s=vu(e,t,s,o,void 0,c),o=bu(),e!==null&&!lt?(Ru(e,t,c),ea(e,t,c)):(Ne&&o&&eu(t),t.flags|=1,At(e,t,s,c),t.child)}function dg(e,t,s,o,c,f){return as(t),t.updateQueue=null,s=pm(t,o,s,c),hm(e),o=bu(),e!==null&&!lt?(Ru(e,t,f),ea(e,t,f)):(Ne&&o&&eu(t),t.flags|=1,At(e,t,s,f),t.child)}function fg(e,t,s,o,c){if(as(t),t.stateNode===null){var f=Ls,v=s.contextType;typeof v=="object"&&v!==null&&(f=Et(v)),f=new s(o,f),t.memoizedState=f.state!==null&&f.state!==void 0?f.state:null,f.updater=Lu,t.stateNode=f,f._reactInternals=t,f=t.stateNode,f.props=o,f.state=t.memoizedState,f.refs={},du(t),v=s.contextType,f.context=typeof v=="object"&&v!==null?Et(v):Ls,f.state=t.memoizedState,v=s.getDerivedStateFromProps,typeof v=="function"&&(Ou(t,s,v,o),f.state=t.memoizedState),typeof s.getDerivedStateFromProps=="function"||typeof f.getSnapshotBeforeUpdate=="function"||typeof f.UNSAFE_componentWillMount!="function"&&typeof f.componentWillMount!="function"||(v=f.state,typeof f.componentWillMount=="function"&&f.componentWillMount(),typeof f.UNSAFE_componentWillMount=="function"&&f.UNSAFE_componentWillMount(),v!==f.state&&Lu.enqueueReplaceState(f,f.state,null),Ki(t,o,f,c),Zi(),f.state=t.memoizedState),typeof f.componentDidMount=="function"&&(t.flags|=4194308),o=!0}else if(e===null){f=t.stateNode;var R=t.memoizedProps,N=cs(s,R);f.props=N;var _=f.context,F=s.contextType;v=Ls,typeof F=="object"&&F!==null&&(v=Et(F));var $=s.getDerivedStateFromProps;F=typeof $=="function"||typeof f.getSnapshotBeforeUpdate=="function",R=t.pendingProps!==R,F||typeof f.UNSAFE_componentWillReceiveProps!="function"&&typeof f.componentWillReceiveProps!="function"||(R||_!==v)&&Jm(t,f,o,v),Sa=!1;var B=t.memoizedState;f.state=B,Ki(t,o,f,c),Zi(),_=t.memoizedState,R||B!==_||Sa?(typeof $=="function"&&(Ou(t,s,$,o),_=t.memoizedState),(N=Sa||Km(t,s,N,o,B,_,v))?(F||typeof f.UNSAFE_componentWillMount!="function"&&typeof f.componentWillMount!="function"||(typeof f.componentWillMount=="function"&&f.componentWillMount(),typeof f.UNSAFE_componentWillMount=="function"&&f.UNSAFE_componentWillMount()),typeof f.componentDidMount=="function"&&(t.flags|=4194308)):(typeof f.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=o,t.memoizedState=_),f.props=o,f.state=_,f.context=v,o=N):(typeof f.componentDidMount=="function"&&(t.flags|=4194308),o=!1)}else{f=t.stateNode,fu(e,t),v=t.memoizedProps,F=cs(s,v),f.props=F,$=t.pendingProps,B=f.context,_=s.contextType,N=Ls,typeof _=="object"&&_!==null&&(N=Et(_)),R=s.getDerivedStateFromProps,(_=typeof R=="function"||typeof f.getSnapshotBeforeUpdate=="function")||typeof f.UNSAFE_componentWillReceiveProps!="function"&&typeof f.componentWillReceiveProps!="function"||(v!==$||B!==N)&&Jm(t,f,o,N),Sa=!1,B=t.memoizedState,f.state=B,Ki(t,o,f,c),Zi();var H=t.memoizedState;v!==$||B!==H||Sa||e!==null&&e.dependencies!==null&&Mo(e.dependencies)?(typeof R=="function"&&(Ou(t,s,R,o),H=t.memoizedState),(F=Sa||Km(t,s,F,o,B,H,N)||e!==null&&e.dependencies!==null&&Mo(e.dependencies))?(_||typeof f.UNSAFE_componentWillUpdate!="function"&&typeof f.componentWillUpdate!="function"||(typeof f.componentWillUpdate=="function"&&f.componentWillUpdate(o,H,N),typeof f.UNSAFE_componentWillUpdate=="function"&&f.UNSAFE_componentWillUpdate(o,H,N)),typeof f.componentDidUpdate=="function"&&(t.flags|=4),typeof f.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof f.componentDidUpdate!="function"||v===e.memoizedProps&&B===e.memoizedState||(t.flags|=4),typeof f.getSnapshotBeforeUpdate!="function"||v===e.memoizedProps&&B===e.memoizedState||(t.flags|=1024),t.memoizedProps=o,t.memoizedState=H),f.props=o,f.state=H,f.context=N,o=F):(typeof f.componentDidUpdate!="function"||v===e.memoizedProps&&B===e.memoizedState||(t.flags|=4),typeof f.getSnapshotBeforeUpdate!="function"||v===e.memoizedProps&&B===e.memoizedState||(t.flags|=1024),o=!1)}return f=o,Po(e,t),o=(t.flags&128)!==0,f||o?(f=t.stateNode,s=o&&typeof s.getDerivedStateFromError!="function"?null:f.render(),t.flags|=1,e!==null&&o?(t.child=os(t,e.child,null,c),t.child=os(t,null,s,c)):At(e,t,s,c),t.memoizedState=f.state,e=t.child):e=ea(e,t,c),e}function hg(e,t,s,o){return ts(),t.flags|=256,At(e,t,s,o),t.child}var Uu={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Hu(e){return{baseLanes:e,cachePool:nm()}}function Fu(e,t,s){return e=e!==null?e.childLanes&~s:0,t&&(e|=an),e}function pg(e,t,s){var o=t.pendingProps,c=!1,f=(t.flags&128)!==0,v;if((v=f)||(v=e!==null&&e.memoizedState===null?!1:(st.current&2)!==0),v&&(c=!0,t.flags&=-129),v=(t.flags&32)!==0,t.flags&=-33,e===null){if(Ne){if(c?Ta(t):Na(),(e=Ye)?(e=w0(e,pn),e=e!==null&&e.data!=="&"?e:null,e!==null&&(t.memoizedState={dehydrated:e,treeContext:va!==null?{id:On,overflow:Ln}:null,retryLane:536870912,hydrationErrors:null},s=Xp(e),s.return=t,t.child=s,Nt=t,Ye=null)):e=null,e===null)throw Ra(t);return jd(e)?t.lanes=32:t.lanes=536870912,null}var R=o.children;return o=o.fallback,c?(Na(),c=t.mode,R=Yo({mode:"hidden",children:R},c),o=es(o,c,s,null),R.return=t,o.return=t,R.sibling=o,t.child=R,o=t.child,o.memoizedState=Hu(s),o.childLanes=Fu(e,v,s),t.memoizedState=Uu,nr(null,o)):(Ta(t),Iu(t,R))}var N=e.memoizedState;if(N!==null&&(R=N.dehydrated,R!==null)){if(f)t.flags&256?(Ta(t),t.flags&=-257,t=Pu(e,t,s)):t.memoizedState!==null?(Na(),t.child=e.child,t.flags|=128,t=null):(Na(),R=o.fallback,c=t.mode,o=Yo({mode:"visible",children:o.children},c),R=es(R,c,s,null),R.flags|=2,o.return=t,R.return=t,o.sibling=R,t.child=o,os(t,e.child,null,s),o=t.child,o.memoizedState=Hu(s),o.childLanes=Fu(e,v,s),t.memoizedState=Uu,t=nr(null,o));else if(Ta(t),jd(R)){if(v=R.nextSibling&&R.nextSibling.dataset,v)var _=v.dgst;v=_,o=Error(r(419)),o.stack="",o.digest=v,Pi({value:o,source:null,stack:null}),t=Pu(e,t,s)}else if(lt||Us(e,t,s,!1),v=(s&e.childLanes)!==0,lt||v){if(v=Be,v!==null&&(o=ep(v,s),o!==0&&o!==N.retryLane))throw N.retryLane=o,Wa(e,o),qt(v,e,o),_u;Sd(R)||el(),t=Pu(e,t,s)}else Sd(R)?(t.flags|=192,t.child=e.child,t=null):(e=N.treeContext,Ye=gn(R.nextSibling),Nt=t,Ne=!0,ba=null,pn=!1,e!==null&&Zp(t,e),t=Iu(t,o.children),t.flags|=4096);return t}return c?(Na(),R=o.fallback,c=t.mode,N=e.child,_=N.sibling,o=$n(N,{mode:"hidden",children:o.children}),o.subtreeFlags=N.subtreeFlags&65011712,_!==null?R=$n(_,R):(R=es(R,c,s,null),R.flags|=2),R.return=t,o.return=t,o.sibling=R,t.child=o,nr(null,o),o=t.child,R=e.child.memoizedState,R===null?R=Hu(s):(c=R.cachePool,c!==null?(N=rt._currentValue,c=c.parent!==N?{parent:N,pool:N}:c):c=nm(),R={baseLanes:R.baseLanes|s,cachePool:c}),o.memoizedState=R,o.childLanes=Fu(e,v,s),t.memoizedState=Uu,nr(e.child,o)):(Ta(t),s=e.child,e=s.sibling,s=$n(s,{mode:"visible",children:o.children}),s.return=t,s.sibling=null,e!==null&&(v=t.deletions,v===null?(t.deletions=[e],t.flags|=16):v.push(e)),t.child=s,t.memoizedState=null,s)}function Iu(e,t){return t=Yo({mode:"visible",children:t},e.mode),t.return=e,e.child=t}function Yo(e,t){return e=Wt(22,e,null,t),e.lanes=0,e}function Pu(e,t,s){return os(t,e.child,null,s),e=Iu(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function mg(e,t,s){e.lanes|=t;var o=e.alternate;o!==null&&(o.lanes|=t),iu(e.return,t,s)}function Yu(e,t,s,o,c,f){var v=e.memoizedState;v===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:o,tail:s,tailMode:c,treeForkCount:f}:(v.isBackwards=t,v.rendering=null,v.renderingStartTime=0,v.last=o,v.tail=s,v.tailMode=c,v.treeForkCount=f)}function gg(e,t,s){var o=t.pendingProps,c=o.revealOrder,f=o.tail;o=o.children;var v=st.current,R=(v&2)!==0;if(R?(v=v&1|2,t.flags|=128):v&=1,Z(st,v),At(e,t,o,s),o=Ne?Ii:0,!R&&e!==null&&(e.flags&128)!==0)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&mg(e,s,t);else if(e.tag===19)mg(e,s,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(c){case"forwards":for(s=t.child,c=null;s!==null;)e=s.alternate,e!==null&&zo(e)===null&&(c=s),s=s.sibling;s=c,s===null?(c=t.child,t.child=null):(c=s.sibling,s.sibling=null),Yu(t,!1,c,s,f,o);break;case"backwards":case"unstable_legacy-backwards":for(s=null,c=t.child,t.child=null;c!==null;){if(e=c.alternate,e!==null&&zo(e)===null){t.child=c;break}e=c.sibling,c.sibling=s,s=c,c=e}Yu(t,!0,s,null,f,o);break;case"together":Yu(t,!1,null,null,void 0,o);break;default:t.memoizedState=null}return t.child}function ea(e,t,s){if(e!==null&&(t.dependencies=e.dependencies),Ca|=t.lanes,(s&t.childLanes)===0)if(e!==null){if(Us(e,t,s,!1),(s&t.childLanes)===0)return null}else return null;if(e!==null&&t.child!==e.child)throw Error(r(153));if(t.child!==null){for(e=t.child,s=$n(e,e.pendingProps),t.child=s,s.return=t;e.sibling!==null;)e=e.sibling,s=s.sibling=$n(e,e.pendingProps),s.return=t;s.sibling=null}return t.child}function qu(e,t){return(e.lanes&t)!==0?!0:(e=e.dependencies,!!(e!==null&&Mo(e)))}function N5(e,t,s){switch(t.tag){case 3:vt(t,t.stateNode.containerInfo),wa(t,rt,e.memoizedState.cache),ts();break;case 27:case 5:Vn(t);break;case 4:vt(t,t.stateNode.containerInfo);break;case 10:wa(t,t.type,t.memoizedProps.value);break;case 31:if(t.memoizedState!==null)return t.flags|=128,yu(t),null;break;case 13:var o=t.memoizedState;if(o!==null)return o.dehydrated!==null?(Ta(t),t.flags|=128,null):(s&t.child.childLanes)!==0?pg(e,t,s):(Ta(t),e=ea(e,t,s),e!==null?e.sibling:null);Ta(t);break;case 19:var c=(e.flags&128)!==0;if(o=(s&t.childLanes)!==0,o||(Us(e,t,s,!1),o=(s&t.childLanes)!==0),c){if(o)return gg(e,t,s);t.flags|=128}if(c=t.memoizedState,c!==null&&(c.rendering=null,c.tail=null,c.lastEffect=null),Z(st,st.current),o)break;return null;case 22:return t.lanes=0,lg(e,t,s,t.pendingProps);case 24:wa(t,rt,e.memoizedState.cache)}return ea(e,t,s)}function yg(e,t,s){if(e!==null)if(e.memoizedProps!==t.pendingProps)lt=!0;else{if(!qu(e,s)&&(t.flags&128)===0)return lt=!1,N5(e,t,s);lt=(e.flags&131072)!==0}else lt=!1,Ne&&(t.flags&1048576)!==0&&Qp(t,Ii,t.index);switch(t.lanes=0,t.tag){case 16:e:{var o=t.pendingProps;if(e=is(t.elementType),t.type=e,typeof e=="function")Kc(e)?(o=cs(e,o),t.tag=1,t=fg(null,t,e,o,s)):(t.tag=0,t=Bu(null,t,e,o,s));else{if(e!=null){var c=e.$$typeof;if(c===D){t.tag=11,t=ig(null,t,e,o,s);break e}else if(c===Q){t.tag=14,t=rg(null,t,e,o,s);break e}}throw t=Te(e)||e,Error(r(306,t,""))}}return t;case 0:return Bu(e,t,t.type,t.pendingProps,s);case 1:return o=t.type,c=cs(o,t.pendingProps),fg(e,t,o,c,s);case 3:e:{if(vt(t,t.stateNode.containerInfo),e===null)throw Error(r(387));o=t.pendingProps;var f=t.memoizedState;c=f.element,fu(e,t),Ki(t,o,null,s);var v=t.memoizedState;if(o=v.cache,wa(t,rt,o),o!==f.cache&&ru(t,[rt],s,!0),Zi(),o=v.element,f.isDehydrated)if(f={element:o,isDehydrated:!1,cache:v.cache},t.updateQueue.baseState=f,t.memoizedState=f,t.flags&256){t=hg(e,t,o,s);break e}else if(o!==c){c=dn(Error(r(424)),t),Pi(c),t=hg(e,t,o,s);break e}else for(e=t.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,Ye=gn(e.firstChild),Nt=t,Ne=!0,ba=null,pn=!0,s=lm(t,null,o,s),t.child=s;s;)s.flags=s.flags&-3|4096,s=s.sibling;else{if(ts(),o===c){t=ea(e,t,s);break e}At(e,t,o,s)}t=t.child}return t;case 26:return Po(e,t),e===null?(s=E0(t.type,null,t.pendingProps,null))?t.memoizedState=s:Ne||(s=t.type,e=t.pendingProps,o=ol(ve.current).createElement(s),o[Tt]=t,o[Ut]=e,Ct(o,s,e),bt(o),t.stateNode=o):t.memoizedState=E0(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;case 27:return Vn(t),e===null&&Ne&&(o=t.stateNode=M0(t.type,t.pendingProps,ve.current),Nt=t,pn=!0,c=Ye,Oa(t.type)?(Md=c,Ye=gn(o.firstChild)):Ye=c),At(e,t,t.pendingProps.children,s),Po(e,t),e===null&&(t.flags|=4194304),t.child;case 5:return e===null&&Ne&&((c=o=Ye)&&(o=a3(o,t.type,t.pendingProps,pn),o!==null?(t.stateNode=o,Nt=t,Ye=gn(o.firstChild),pn=!1,c=!0):c=!1),c||Ra(t)),Vn(t),c=t.type,f=t.pendingProps,v=e!==null?e.memoizedProps:null,o=f.children,bd(c,f)?o=null:v!==null&&bd(c,v)&&(t.flags|=32),t.memoizedState!==null&&(c=vu(e,t,x5,null,null,s),yr._currentValue=c),Po(e,t),At(e,t,o,s),t.child;case 6:return e===null&&Ne&&((e=s=Ye)&&(s=s3(s,t.pendingProps,pn),s!==null?(t.stateNode=s,Nt=t,Ye=null,e=!0):e=!1),e||Ra(t)),null;case 13:return pg(e,t,s);case 4:return vt(t,t.stateNode.containerInfo),o=t.pendingProps,e===null?t.child=os(t,null,o,s):At(e,t,o,s),t.child;case 11:return ig(e,t,t.type,t.pendingProps,s);case 7:return At(e,t,t.pendingProps,s),t.child;case 8:return At(e,t,t.pendingProps.children,s),t.child;case 12:return At(e,t,t.pendingProps.children,s),t.child;case 10:return o=t.pendingProps,wa(t,t.type,o.value),At(e,t,o.children,s),t.child;case 9:return c=t.type._context,o=t.pendingProps.children,as(t),c=Et(c),o=o(c),t.flags|=1,At(e,t,o,s),t.child;case 14:return rg(e,t,t.type,t.pendingProps,s);case 15:return og(e,t,t.type,t.pendingProps,s);case 19:return gg(e,t,s);case 31:return T5(e,t,s);case 22:return lg(e,t,s,t.pendingProps);case 24:return as(t),o=Et(rt),e===null?(c=cu(),c===null&&(c=Be,f=ou(),c.pooledCache=f,f.refCount++,f!==null&&(c.pooledCacheLanes|=s),c=f),t.memoizedState={parent:o,cache:c},du(t),wa(t,rt,c)):((e.lanes&s)!==0&&(fu(e,t),Ki(t,null,null,s),Zi()),c=e.memoizedState,f=t.memoizedState,c.parent!==o?(c={parent:o,cache:o},t.memoizedState=c,t.lanes===0&&(t.memoizedState=t.updateQueue.baseState=c),wa(t,rt,o)):(o=f.cache,wa(t,rt,o),o!==c.cache&&ru(t,[rt],s,!0))),At(e,t,t.pendingProps.children,s),t.child;case 29:throw t.pendingProps}throw Error(r(156,t.tag))}function ta(e){e.flags|=4}function Xu(e,t,s,o,c){if((t=(e.mode&32)!==0)&&(t=!1),t){if(e.flags|=16777216,(c&335544128)===c)if(e.stateNode.complete)e.flags|=8192;else if(Pg())e.flags|=8192;else throw rs=Ao,uu}else e.flags&=-16777217}function xg(e,t){if(t.type!=="stylesheet"||(t.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!z0(t))if(Pg())e.flags|=8192;else throw rs=Ao,uu}function qo(e,t){t!==null&&(e.flags|=4),e.flags&16384&&(t=e.tag!==22?Kh():536870912,e.lanes|=t,Js|=t)}function ar(e,t){if(!Ne)switch(e.tailMode){case"hidden":t=e.tail;for(var s=null;t!==null;)t.alternate!==null&&(s=t),t=t.sibling;s===null?e.tail=null:s.sibling=null;break;case"collapsed":s=e.tail;for(var o=null;s!==null;)s.alternate!==null&&(o=s),s=s.sibling;o===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:o.sibling=null}}function qe(e){var t=e.alternate!==null&&e.alternate.child===e.child,s=0,o=0;if(t)for(var c=e.child;c!==null;)s|=c.lanes|c.childLanes,o|=c.subtreeFlags&65011712,o|=c.flags&65011712,c.return=e,c=c.sibling;else for(c=e.child;c!==null;)s|=c.lanes|c.childLanes,o|=c.subtreeFlags,o|=c.flags,c.return=e,c=c.sibling;return e.subtreeFlags|=o,e.childLanes=s,t}function E5(e,t,s){var o=t.pendingProps;switch(tu(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return qe(t),null;case 1:return qe(t),null;case 3:return s=t.stateNode,o=null,e!==null&&(o=e.memoizedState.cache),t.memoizedState.cache!==o&&(t.flags|=2048),Kn(rt),Fe(),s.pendingContext&&(s.context=s.pendingContext,s.pendingContext=null),(e===null||e.child===null)&&(Bs(t)?ta(t):e===null||e.memoizedState.isDehydrated&&(t.flags&256)===0||(t.flags|=1024,au())),qe(t),null;case 26:var c=t.type,f=t.memoizedState;return e===null?(ta(t),f!==null?(qe(t),xg(t,f)):(qe(t),Xu(t,c,null,o,s))):f?f!==e.memoizedState?(ta(t),qe(t),xg(t,f)):(qe(t),t.flags&=-16777217):(e=e.memoizedProps,e!==o&&ta(t),qe(t),Xu(t,c,e,o,s)),null;case 27:if(pa(t),s=ve.current,c=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&ta(t);else{if(!o){if(t.stateNode===null)throw Error(r(166));return qe(t),null}e=W.current,Bs(t)?Kp(t):(e=M0(c,o,s),t.stateNode=e,ta(t))}return qe(t),null;case 5:if(pa(t),c=t.type,e!==null&&t.stateNode!=null)e.memoizedProps!==o&&ta(t);else{if(!o){if(t.stateNode===null)throw Error(r(166));return qe(t),null}if(f=W.current,Bs(t))Kp(t);else{var v=ol(ve.current);switch(f){case 1:f=v.createElementNS("http://www.w3.org/2000/svg",c);break;case 2:f=v.createElementNS("http://www.w3.org/1998/Math/MathML",c);break;default:switch(c){case"svg":f=v.createElementNS("http://www.w3.org/2000/svg",c);break;case"math":f=v.createElementNS("http://www.w3.org/1998/Math/MathML",c);break;case"script":f=v.createElement("div"),f.innerHTML="<script><\/script>",f=f.removeChild(f.firstChild);break;case"select":f=typeof o.is=="string"?v.createElement("select",{is:o.is}):v.createElement("select"),o.multiple?f.multiple=!0:o.size&&(f.size=o.size);break;default:f=typeof o.is=="string"?v.createElement(c,{is:o.is}):v.createElement(c)}}f[Tt]=t,f[Ut]=o;e:for(v=t.child;v!==null;){if(v.tag===5||v.tag===6)f.appendChild(v.stateNode);else if(v.tag!==4&&v.tag!==27&&v.child!==null){v.child.return=v,v=v.child;continue}if(v===t)break e;for(;v.sibling===null;){if(v.return===null||v.return===t)break e;v=v.return}v.sibling.return=v.return,v=v.sibling}t.stateNode=f;e:switch(Ct(f,c,o),c){case"button":case"input":case"select":case"textarea":o=!!o.autoFocus;break e;case"img":o=!0;break e;default:o=!1}o&&ta(t)}}return qe(t),Xu(t,t.type,e===null?null:e.memoizedProps,t.pendingProps,s),null;case 6:if(e&&t.stateNode!=null)e.memoizedProps!==o&&ta(t);else{if(typeof o!="string"&&t.stateNode===null)throw Error(r(166));if(e=ve.current,Bs(t)){if(e=t.stateNode,s=t.memoizedProps,o=null,c=Nt,c!==null)switch(c.tag){case 27:case 5:o=c.memoizedProps}e[Tt]=t,e=!!(e.nodeValue===s||o!==null&&o.suppressHydrationWarning===!0||p0(e.nodeValue,s)),e||Ra(t,!0)}else e=ol(e).createTextNode(o),e[Tt]=t,t.stateNode=e}return qe(t),null;case 31:if(s=t.memoizedState,e===null||e.memoizedState!==null){if(o=Bs(t),s!==null){if(e===null){if(!o)throw Error(r(318));if(e=t.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(r(557));e[Tt]=t}else ts(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;qe(t),e=!1}else s=au(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=s),e=!0;if(!e)return t.flags&256?(tn(t),t):(tn(t),null);if((t.flags&128)!==0)throw Error(r(558))}return qe(t),null;case 13:if(o=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(c=Bs(t),o!==null&&o.dehydrated!==null){if(e===null){if(!c)throw Error(r(318));if(c=t.memoizedState,c=c!==null?c.dehydrated:null,!c)throw Error(r(317));c[Tt]=t}else ts(),(t.flags&128)===0&&(t.memoizedState=null),t.flags|=4;qe(t),c=!1}else c=au(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=c),c=!0;if(!c)return t.flags&256?(tn(t),t):(tn(t),null)}return tn(t),(t.flags&128)!==0?(t.lanes=s,t):(s=o!==null,e=e!==null&&e.memoizedState!==null,s&&(o=t.child,c=null,o.alternate!==null&&o.alternate.memoizedState!==null&&o.alternate.memoizedState.cachePool!==null&&(c=o.alternate.memoizedState.cachePool.pool),f=null,o.memoizedState!==null&&o.memoizedState.cachePool!==null&&(f=o.memoizedState.cachePool.pool),f!==c&&(o.flags|=2048)),s!==e&&s&&(t.child.flags|=8192),qo(t,t.updateQueue),qe(t),null);case 4:return Fe(),e===null&&md(t.stateNode.containerInfo),qe(t),null;case 10:return Kn(t.type),qe(t),null;case 19:if(I(st),o=t.memoizedState,o===null)return qe(t),null;if(c=(t.flags&128)!==0,f=o.rendering,f===null)if(c)ar(o,!1);else{if(We!==0||e!==null&&(e.flags&128)!==0)for(e=t.child;e!==null;){if(f=zo(e),f!==null){for(t.flags|=128,ar(o,!1),e=f.updateQueue,t.updateQueue=e,qo(t,e),t.subtreeFlags=0,e=s,s=t.child;s!==null;)qp(s,e),s=s.sibling;return Z(st,st.current&1|2),Ne&&Qn(t,o.treeForkCount),t.child}e=e.sibling}o.tail!==null&&Qt()>Ko&&(t.flags|=128,c=!0,ar(o,!1),t.lanes=4194304)}else{if(!c)if(e=zo(f),e!==null){if(t.flags|=128,c=!0,e=e.updateQueue,t.updateQueue=e,qo(t,e),ar(o,!0),o.tail===null&&o.tailMode==="hidden"&&!f.alternate&&!Ne)return qe(t),null}else 2*Qt()-o.renderingStartTime>Ko&&s!==536870912&&(t.flags|=128,c=!0,ar(o,!1),t.lanes=4194304);o.isBackwards?(f.sibling=t.child,t.child=f):(e=o.last,e!==null?e.sibling=f:t.child=f,o.last=f)}return o.tail!==null?(e=o.tail,o.rendering=e,o.tail=e.sibling,o.renderingStartTime=Qt(),e.sibling=null,s=st.current,Z(st,c?s&1|2:s&1),Ne&&Qn(t,o.treeForkCount),e):(qe(t),null);case 22:case 23:return tn(t),gu(),o=t.memoizedState!==null,e!==null?e.memoizedState!==null!==o&&(t.flags|=8192):o&&(t.flags|=8192),o?(s&536870912)!==0&&(t.flags&128)===0&&(qe(t),t.subtreeFlags&6&&(t.flags|=8192)):qe(t),s=t.updateQueue,s!==null&&qo(t,s.retryQueue),s=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(s=e.memoizedState.cachePool.pool),o=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(o=t.memoizedState.cachePool.pool),o!==s&&(t.flags|=2048),e!==null&&I(ss),null;case 24:return s=null,e!==null&&(s=e.memoizedState.cache),t.memoizedState.cache!==s&&(t.flags|=2048),Kn(rt),qe(t),null;case 25:return null;case 30:return null}throw Error(r(156,t.tag))}function A5(e,t){switch(tu(t),t.tag){case 1:return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return Kn(rt),Fe(),e=t.flags,(e&65536)!==0&&(e&128)===0?(t.flags=e&-65537|128,t):null;case 26:case 27:case 5:return pa(t),null;case 31:if(t.memoizedState!==null){if(tn(t),t.alternate===null)throw Error(r(340));ts()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 13:if(tn(t),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(r(340));ts()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return I(st),null;case 4:return Fe(),null;case 10:return Kn(t.type),null;case 22:case 23:return tn(t),gu(),e!==null&&I(ss),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 24:return Kn(rt),null;case 25:return null;default:return null}}function vg(e,t){switch(tu(t),t.tag){case 3:Kn(rt),Fe();break;case 26:case 27:case 5:pa(t);break;case 4:Fe();break;case 31:t.memoizedState!==null&&tn(t);break;case 13:tn(t);break;case 19:I(st);break;case 10:Kn(t.type);break;case 22:case 23:tn(t),gu(),e!==null&&I(ss);break;case 24:Kn(rt)}}function sr(e,t){try{var s=t.updateQueue,o=s!==null?s.lastEffect:null;if(o!==null){var c=o.next;s=c;do{if((s.tag&e)===e){o=void 0;var f=s.create,v=s.inst;o=f(),v.destroy=o}s=s.next}while(s!==c)}}catch(R){Ve(t,t.return,R)}}function Ea(e,t,s){try{var o=t.updateQueue,c=o!==null?o.lastEffect:null;if(c!==null){var f=c.next;o=f;do{if((o.tag&e)===e){var v=o.inst,R=v.destroy;if(R!==void 0){v.destroy=void 0,c=t;var N=s,_=R;try{_()}catch(F){Ve(c,N,F)}}}o=o.next}while(o!==f)}}catch(F){Ve(t,t.return,F)}}function bg(e){var t=e.updateQueue;if(t!==null){var s=e.stateNode;try{um(t,s)}catch(o){Ve(e,e.return,o)}}}function Rg(e,t,s){s.props=cs(e.type,e.memoizedProps),s.state=e.memoizedState;try{s.componentWillUnmount()}catch(o){Ve(e,t,o)}}function ir(e,t){try{var s=e.ref;if(s!==null){switch(e.tag){case 26:case 27:case 5:var o=e.stateNode;break;case 30:o=e.stateNode;break;default:o=e.stateNode}typeof s=="function"?e.refCleanup=s(o):s.current=o}}catch(c){Ve(e,t,c)}}function Gn(e,t){var s=e.ref,o=e.refCleanup;if(s!==null)if(typeof o=="function")try{o()}catch(c){Ve(e,t,c)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof s=="function")try{s(null)}catch(c){Ve(e,t,c)}else s.current=null}function wg(e){var t=e.type,s=e.memoizedProps,o=e.stateNode;try{e:switch(t){case"button":case"input":case"select":case"textarea":s.autoFocus&&o.focus();break e;case"img":s.src?o.src=s.src:s.srcSet&&(o.srcset=s.srcSet)}}catch(c){Ve(e,e.return,c)}}function $u(e,t,s){try{var o=e.stateNode;K5(o,e.type,s,t),o[Ut]=t}catch(c){Ve(e,e.return,c)}}function Sg(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Oa(e.type)||e.tag===4}function Qu(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||Sg(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Oa(e.type)||e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Zu(e,t,s){var o=e.tag;if(o===5||o===6)e=e.stateNode,t?(s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s).insertBefore(e,t):(t=s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s,t.appendChild(e),s=s._reactRootContainer,s!=null||t.onclick!==null||(t.onclick=qn));else if(o!==4&&(o===27&&Oa(e.type)&&(s=e.stateNode,t=null),e=e.child,e!==null))for(Zu(e,t,s),e=e.sibling;e!==null;)Zu(e,t,s),e=e.sibling}function Xo(e,t,s){var o=e.tag;if(o===5||o===6)e=e.stateNode,t?s.insertBefore(e,t):s.appendChild(e);else if(o!==4&&(o===27&&Oa(e.type)&&(s=e.stateNode),e=e.child,e!==null))for(Xo(e,t,s),e=e.sibling;e!==null;)Xo(e,t,s),e=e.sibling}function jg(e){var t=e.stateNode,s=e.memoizedProps;try{for(var o=e.type,c=t.attributes;c.length;)t.removeAttributeNode(c[0]);Ct(t,o,s),t[Tt]=e,t[Ut]=s}catch(f){Ve(e,e.return,f)}}var na=!1,ct=!1,Ku=!1,Mg=typeof WeakSet=="function"?WeakSet:Set,Rt=null;function C5(e,t){if(e=e.containerInfo,xd=pl,e=Gp(e),Pc(e)){if("selectionStart"in e)var s={start:e.selectionStart,end:e.selectionEnd};else e:{s=(s=e.ownerDocument)&&s.defaultView||window;var o=s.getSelection&&s.getSelection();if(o&&o.rangeCount!==0){s=o.anchorNode;var c=o.anchorOffset,f=o.focusNode;o=o.focusOffset;try{s.nodeType,f.nodeType}catch{s=null;break e}var v=0,R=-1,N=-1,_=0,F=0,$=e,B=null;t:for(;;){for(var H;$!==s||c!==0&&$.nodeType!==3||(R=v+c),$!==f||o!==0&&$.nodeType!==3||(N=v+o),$.nodeType===3&&(v+=$.nodeValue.length),(H=$.firstChild)!==null;)B=$,$=H;for(;;){if($===e)break t;if(B===s&&++_===c&&(R=v),B===f&&++F===o&&(N=v),(H=$.nextSibling)!==null)break;$=B,B=$.parentNode}$=H}s=R===-1||N===-1?null:{start:R,end:N}}else s=null}s=s||{start:0,end:0}}else s=null;for(vd={focusedElem:e,selectionRange:s},pl=!1,Rt=t;Rt!==null;)if(t=Rt,e=t.child,(t.subtreeFlags&1028)!==0&&e!==null)e.return=t,Rt=e;else for(;Rt!==null;){switch(t=Rt,f=t.alternate,e=t.flags,t.tag){case 0:if((e&4)!==0&&(e=t.updateQueue,e=e!==null?e.events:null,e!==null))for(s=0;s<e.length;s++)c=e[s],c.ref.impl=c.nextImpl;break;case 11:case 15:break;case 1:if((e&1024)!==0&&f!==null){e=void 0,s=t,c=f.memoizedProps,f=f.memoizedState,o=s.stateNode;try{var te=cs(s.type,c);e=o.getSnapshotBeforeUpdate(te,f),o.__reactInternalSnapshotBeforeUpdate=e}catch(ce){Ve(s,s.return,ce)}}break;case 3:if((e&1024)!==0){if(e=t.stateNode.containerInfo,s=e.nodeType,s===9)wd(e);else if(s===1)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":wd(e);break;default:e.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((e&1024)!==0)throw Error(r(163))}if(e=t.sibling,e!==null){e.return=t.return,Rt=e;break}Rt=t.return}}function Tg(e,t,s){var o=s.flags;switch(s.tag){case 0:case 11:case 15:sa(e,s),o&4&&sr(5,s);break;case 1:if(sa(e,s),o&4)if(e=s.stateNode,t===null)try{e.componentDidMount()}catch(v){Ve(s,s.return,v)}else{var c=cs(s.type,t.memoizedProps);t=t.memoizedState;try{e.componentDidUpdate(c,t,e.__reactInternalSnapshotBeforeUpdate)}catch(v){Ve(s,s.return,v)}}o&64&&bg(s),o&512&&ir(s,s.return);break;case 3:if(sa(e,s),o&64&&(e=s.updateQueue,e!==null)){if(t=null,s.child!==null)switch(s.child.tag){case 27:case 5:t=s.child.stateNode;break;case 1:t=s.child.stateNode}try{um(e,t)}catch(v){Ve(s,s.return,v)}}break;case 27:t===null&&o&4&&jg(s);case 26:case 5:sa(e,s),t===null&&o&4&&wg(s),o&512&&ir(s,s.return);break;case 12:sa(e,s);break;case 31:sa(e,s),o&4&&Ag(e,s);break;case 13:sa(e,s),o&4&&Cg(e,s),o&64&&(e=s.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(s=B5.bind(null,s),i3(e,s))));break;case 22:if(o=s.memoizedState!==null||na,!o){t=t!==null&&t.memoizedState!==null||ct,c=na;var f=ct;na=o,(ct=t)&&!f?ia(e,s,(s.subtreeFlags&8772)!==0):sa(e,s),na=c,ct=f}break;case 30:break;default:sa(e,s)}}function Ng(e){var t=e.alternate;t!==null&&(e.alternate=null,Ng(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&Nc(t)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var Qe=null,Ft=!1;function aa(e,t,s){for(s=s.child;s!==null;)Eg(e,t,s),s=s.sibling}function Eg(e,t,s){if(Zt&&typeof Zt.onCommitFiberUnmount=="function")try{Zt.onCommitFiberUnmount(Ai,s)}catch{}switch(s.tag){case 26:ct||Gn(s,t),aa(e,t,s),s.memoizedState?s.memoizedState.count--:s.stateNode&&(s=s.stateNode,s.parentNode.removeChild(s));break;case 27:ct||Gn(s,t);var o=Qe,c=Ft;Oa(s.type)&&(Qe=s.stateNode,Ft=!1),aa(e,t,s),pr(s.stateNode),Qe=o,Ft=c;break;case 5:ct||Gn(s,t);case 6:if(o=Qe,c=Ft,Qe=null,aa(e,t,s),Qe=o,Ft=c,Qe!==null)if(Ft)try{(Qe.nodeType===9?Qe.body:Qe.nodeName==="HTML"?Qe.ownerDocument.body:Qe).removeChild(s.stateNode)}catch(f){Ve(s,t,f)}else try{Qe.removeChild(s.stateNode)}catch(f){Ve(s,t,f)}break;case 18:Qe!==null&&(Ft?(e=Qe,b0(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,s.stateNode),ri(e)):b0(Qe,s.stateNode));break;case 4:o=Qe,c=Ft,Qe=s.stateNode.containerInfo,Ft=!0,aa(e,t,s),Qe=o,Ft=c;break;case 0:case 11:case 14:case 15:Ea(2,s,t),ct||Ea(4,s,t),aa(e,t,s);break;case 1:ct||(Gn(s,t),o=s.stateNode,typeof o.componentWillUnmount=="function"&&Rg(s,t,o)),aa(e,t,s);break;case 21:aa(e,t,s);break;case 22:ct=(o=ct)||s.memoizedState!==null,aa(e,t,s),ct=o;break;default:aa(e,t,s)}}function Ag(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{ri(e)}catch(s){Ve(t,t.return,s)}}}function Cg(e,t){if(t.memoizedState===null&&(e=t.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{ri(e)}catch(s){Ve(t,t.return,s)}}function k5(e){switch(e.tag){case 31:case 13:case 19:var t=e.stateNode;return t===null&&(t=e.stateNode=new Mg),t;case 22:return e=e.stateNode,t=e._retryCache,t===null&&(t=e._retryCache=new Mg),t;default:throw Error(r(435,e.tag))}}function $o(e,t){var s=k5(e);t.forEach(function(o){if(!s.has(o)){s.add(o);var c=U5.bind(null,e,o);o.then(c,c)}})}function It(e,t){var s=t.deletions;if(s!==null)for(var o=0;o<s.length;o++){var c=s[o],f=e,v=t,R=v;e:for(;R!==null;){switch(R.tag){case 27:if(Oa(R.type)){Qe=R.stateNode,Ft=!1;break e}break;case 5:Qe=R.stateNode,Ft=!1;break e;case 3:case 4:Qe=R.stateNode.containerInfo,Ft=!0;break e}R=R.return}if(Qe===null)throw Error(r(160));Eg(f,v,c),Qe=null,Ft=!1,f=c.alternate,f!==null&&(f.return=null),c.return=null}if(t.subtreeFlags&13886)for(t=t.child;t!==null;)kg(t,e),t=t.sibling}var Sn=null;function kg(e,t){var s=e.alternate,o=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:It(t,e),Pt(e),o&4&&(Ea(3,e,e.return),sr(3,e),Ea(5,e,e.return));break;case 1:It(t,e),Pt(e),o&512&&(ct||s===null||Gn(s,s.return)),o&64&&na&&(e=e.updateQueue,e!==null&&(o=e.callbacks,o!==null&&(s=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=s===null?o:s.concat(o))));break;case 26:var c=Sn;if(It(t,e),Pt(e),o&512&&(ct||s===null||Gn(s,s.return)),o&4){var f=s!==null?s.memoizedState:null;if(o=e.memoizedState,s===null)if(o===null)if(e.stateNode===null){e:{o=e.type,s=e.memoizedProps,c=c.ownerDocument||c;t:switch(o){case"title":f=c.getElementsByTagName("title")[0],(!f||f[Di]||f[Tt]||f.namespaceURI==="http://www.w3.org/2000/svg"||f.hasAttribute("itemprop"))&&(f=c.createElement(o),c.head.insertBefore(f,c.querySelector("head > title"))),Ct(f,o,s),f[Tt]=e,bt(f),o=f;break e;case"link":var v=k0("link","href",c).get(o+(s.href||""));if(v){for(var R=0;R<v.length;R++)if(f=v[R],f.getAttribute("href")===(s.href==null||s.href===""?null:s.href)&&f.getAttribute("rel")===(s.rel==null?null:s.rel)&&f.getAttribute("title")===(s.title==null?null:s.title)&&f.getAttribute("crossorigin")===(s.crossOrigin==null?null:s.crossOrigin)){v.splice(R,1);break t}}f=c.createElement(o),Ct(f,o,s),c.head.appendChild(f);break;case"meta":if(v=k0("meta","content",c).get(o+(s.content||""))){for(R=0;R<v.length;R++)if(f=v[R],f.getAttribute("content")===(s.content==null?null:""+s.content)&&f.getAttribute("name")===(s.name==null?null:s.name)&&f.getAttribute("property")===(s.property==null?null:s.property)&&f.getAttribute("http-equiv")===(s.httpEquiv==null?null:s.httpEquiv)&&f.getAttribute("charset")===(s.charSet==null?null:s.charSet)){v.splice(R,1);break t}}f=c.createElement(o),Ct(f,o,s),c.head.appendChild(f);break;default:throw Error(r(468,o))}f[Tt]=e,bt(f),o=f}e.stateNode=o}else D0(c,e.type,e.stateNode);else e.stateNode=C0(c,o,e.memoizedProps);else f!==o?(f===null?s.stateNode!==null&&(s=s.stateNode,s.parentNode.removeChild(s)):f.count--,o===null?D0(c,e.type,e.stateNode):C0(c,o,e.memoizedProps)):o===null&&e.stateNode!==null&&$u(e,e.memoizedProps,s.memoizedProps)}break;case 27:It(t,e),Pt(e),o&512&&(ct||s===null||Gn(s,s.return)),s!==null&&o&4&&$u(e,e.memoizedProps,s.memoizedProps);break;case 5:if(It(t,e),Pt(e),o&512&&(ct||s===null||Gn(s,s.return)),e.flags&32){c=e.stateNode;try{As(c,"")}catch(te){Ve(e,e.return,te)}}o&4&&e.stateNode!=null&&(c=e.memoizedProps,$u(e,c,s!==null?s.memoizedProps:c)),o&1024&&(Ku=!0);break;case 6:if(It(t,e),Pt(e),o&4){if(e.stateNode===null)throw Error(r(162));o=e.memoizedProps,s=e.stateNode;try{s.nodeValue=o}catch(te){Ve(e,e.return,te)}}break;case 3:if(ul=null,c=Sn,Sn=ll(t.containerInfo),It(t,e),Sn=c,Pt(e),o&4&&s!==null&&s.memoizedState.isDehydrated)try{ri(t.containerInfo)}catch(te){Ve(e,e.return,te)}Ku&&(Ku=!1,Dg(e));break;case 4:o=Sn,Sn=ll(e.stateNode.containerInfo),It(t,e),Pt(e),Sn=o;break;case 12:It(t,e),Pt(e);break;case 31:It(t,e),Pt(e),o&4&&(o=e.updateQueue,o!==null&&(e.updateQueue=null,$o(e,o)));break;case 13:It(t,e),Pt(e),e.child.flags&8192&&e.memoizedState!==null!=(s!==null&&s.memoizedState!==null)&&(Zo=Qt()),o&4&&(o=e.updateQueue,o!==null&&(e.updateQueue=null,$o(e,o)));break;case 22:c=e.memoizedState!==null;var N=s!==null&&s.memoizedState!==null,_=na,F=ct;if(na=_||c,ct=F||N,It(t,e),ct=F,na=_,Pt(e),o&8192)e:for(t=e.stateNode,t._visibility=c?t._visibility&-2:t._visibility|1,c&&(s===null||N||na||ct||us(e)),s=null,t=e;;){if(t.tag===5||t.tag===26){if(s===null){N=s=t;try{if(f=N.stateNode,c)v=f.style,typeof v.setProperty=="function"?v.setProperty("display","none","important"):v.display="none";else{R=N.stateNode;var $=N.memoizedProps.style,B=$!=null&&$.hasOwnProperty("display")?$.display:null;R.style.display=B==null||typeof B=="boolean"?"":(""+B).trim()}}catch(te){Ve(N,N.return,te)}}}else if(t.tag===6){if(s===null){N=t;try{N.stateNode.nodeValue=c?"":N.memoizedProps}catch(te){Ve(N,N.return,te)}}}else if(t.tag===18){if(s===null){N=t;try{var H=N.stateNode;c?R0(H,!0):R0(N.stateNode,!1)}catch(te){Ve(N,N.return,te)}}}else if((t.tag!==22&&t.tag!==23||t.memoizedState===null||t===e)&&t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break e;for(;t.sibling===null;){if(t.return===null||t.return===e)break e;s===t&&(s=null),t=t.return}s===t&&(s=null),t.sibling.return=t.return,t=t.sibling}o&4&&(o=e.updateQueue,o!==null&&(s=o.retryQueue,s!==null&&(o.retryQueue=null,$o(e,s))));break;case 19:It(t,e),Pt(e),o&4&&(o=e.updateQueue,o!==null&&(e.updateQueue=null,$o(e,o)));break;case 30:break;case 21:break;default:It(t,e),Pt(e)}}function Pt(e){var t=e.flags;if(t&2){try{for(var s,o=e.return;o!==null;){if(Sg(o)){s=o;break}o=o.return}if(s==null)throw Error(r(160));switch(s.tag){case 27:var c=s.stateNode,f=Qu(e);Xo(e,f,c);break;case 5:var v=s.stateNode;s.flags&32&&(As(v,""),s.flags&=-33);var R=Qu(e);Xo(e,R,v);break;case 3:case 4:var N=s.stateNode.containerInfo,_=Qu(e);Zu(e,_,N);break;default:throw Error(r(161))}}catch(F){Ve(e,e.return,F)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Dg(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var t=e;Dg(t),t.tag===5&&t.flags&1024&&t.stateNode.reset(),e=e.sibling}}function sa(e,t){if(t.subtreeFlags&8772)for(t=t.child;t!==null;)Tg(e,t.alternate,t),t=t.sibling}function us(e){for(e=e.child;e!==null;){var t=e;switch(t.tag){case 0:case 11:case 14:case 15:Ea(4,t,t.return),us(t);break;case 1:Gn(t,t.return);var s=t.stateNode;typeof s.componentWillUnmount=="function"&&Rg(t,t.return,s),us(t);break;case 27:pr(t.stateNode);case 26:case 5:Gn(t,t.return),us(t);break;case 22:t.memoizedState===null&&us(t);break;case 30:us(t);break;default:us(t)}e=e.sibling}}function ia(e,t,s){for(s=s&&(t.subtreeFlags&8772)!==0,t=t.child;t!==null;){var o=t.alternate,c=e,f=t,v=f.flags;switch(f.tag){case 0:case 11:case 15:ia(c,f,s),sr(4,f);break;case 1:if(ia(c,f,s),o=f,c=o.stateNode,typeof c.componentDidMount=="function")try{c.componentDidMount()}catch(_){Ve(o,o.return,_)}if(o=f,c=o.updateQueue,c!==null){var R=o.stateNode;try{var N=c.shared.hiddenCallbacks;if(N!==null)for(c.shared.hiddenCallbacks=null,c=0;c<N.length;c++)cm(N[c],R)}catch(_){Ve(o,o.return,_)}}s&&v&64&&bg(f),ir(f,f.return);break;case 27:jg(f);case 26:case 5:ia(c,f,s),s&&o===null&&v&4&&wg(f),ir(f,f.return);break;case 12:ia(c,f,s);break;case 31:ia(c,f,s),s&&v&4&&Ag(c,f);break;case 13:ia(c,f,s),s&&v&4&&Cg(c,f);break;case 22:f.memoizedState===null&&ia(c,f,s),ir(f,f.return);break;case 30:break;default:ia(c,f,s)}t=t.sibling}}function Ju(e,t){var s=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(s=e.memoizedState.cachePool.pool),e=null,t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(e=t.memoizedState.cachePool.pool),e!==s&&(e!=null&&e.refCount++,s!=null&&Yi(s))}function Wu(e,t){e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&Yi(e))}function jn(e,t,s,o){if(t.subtreeFlags&10256)for(t=t.child;t!==null;)zg(e,t,s,o),t=t.sibling}function zg(e,t,s,o){var c=t.flags;switch(t.tag){case 0:case 11:case 15:jn(e,t,s,o),c&2048&&sr(9,t);break;case 1:jn(e,t,s,o);break;case 3:jn(e,t,s,o),c&2048&&(e=null,t.alternate!==null&&(e=t.alternate.memoizedState.cache),t=t.memoizedState.cache,t!==e&&(t.refCount++,e!=null&&Yi(e)));break;case 12:if(c&2048){jn(e,t,s,o),e=t.stateNode;try{var f=t.memoizedProps,v=f.id,R=f.onPostCommit;typeof R=="function"&&R(v,t.alternate===null?"mount":"update",e.passiveEffectDuration,-0)}catch(N){Ve(t,t.return,N)}}else jn(e,t,s,o);break;case 31:jn(e,t,s,o);break;case 13:jn(e,t,s,o);break;case 23:break;case 22:f=t.stateNode,v=t.alternate,t.memoizedState!==null?f._visibility&2?jn(e,t,s,o):rr(e,t):f._visibility&2?jn(e,t,s,o):(f._visibility|=2,Qs(e,t,s,o,(t.subtreeFlags&10256)!==0||!1)),c&2048&&Ju(v,t);break;case 24:jn(e,t,s,o),c&2048&&Wu(t.alternate,t);break;default:jn(e,t,s,o)}}function Qs(e,t,s,o,c){for(c=c&&((t.subtreeFlags&10256)!==0||!1),t=t.child;t!==null;){var f=e,v=t,R=s,N=o,_=v.flags;switch(v.tag){case 0:case 11:case 15:Qs(f,v,R,N,c),sr(8,v);break;case 23:break;case 22:var F=v.stateNode;v.memoizedState!==null?F._visibility&2?Qs(f,v,R,N,c):rr(f,v):(F._visibility|=2,Qs(f,v,R,N,c)),c&&_&2048&&Ju(v.alternate,v);break;case 24:Qs(f,v,R,N,c),c&&_&2048&&Wu(v.alternate,v);break;default:Qs(f,v,R,N,c)}t=t.sibling}}function rr(e,t){if(t.subtreeFlags&10256)for(t=t.child;t!==null;){var s=e,o=t,c=o.flags;switch(o.tag){case 22:rr(s,o),c&2048&&Ju(o.alternate,o);break;case 24:rr(s,o),c&2048&&Wu(o.alternate,o);break;default:rr(s,o)}t=t.sibling}}var or=8192;function Zs(e,t,s){if(e.subtreeFlags&or)for(e=e.child;e!==null;)Vg(e,t,s),e=e.sibling}function Vg(e,t,s){switch(e.tag){case 26:Zs(e,t,s),e.flags&or&&e.memoizedState!==null&&y3(s,Sn,e.memoizedState,e.memoizedProps);break;case 5:Zs(e,t,s);break;case 3:case 4:var o=Sn;Sn=ll(e.stateNode.containerInfo),Zs(e,t,s),Sn=o;break;case 22:e.memoizedState===null&&(o=e.alternate,o!==null&&o.memoizedState!==null?(o=or,or=16777216,Zs(e,t,s),or=o):Zs(e,t,s));break;default:Zs(e,t,s)}}function Og(e){var t=e.alternate;if(t!==null&&(e=t.child,e!==null)){t.child=null;do t=e.sibling,e.sibling=null,e=t;while(e!==null)}}function lr(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var s=0;s<t.length;s++){var o=t[s];Rt=o,Gg(o,e)}Og(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Lg(e),e=e.sibling}function Lg(e){switch(e.tag){case 0:case 11:case 15:lr(e),e.flags&2048&&Ea(9,e,e.return);break;case 3:lr(e);break;case 12:lr(e);break;case 22:var t=e.stateNode;e.memoizedState!==null&&t._visibility&2&&(e.return===null||e.return.tag!==13)?(t._visibility&=-3,Qo(e)):lr(e);break;default:lr(e)}}function Qo(e){var t=e.deletions;if((e.flags&16)!==0){if(t!==null)for(var s=0;s<t.length;s++){var o=t[s];Rt=o,Gg(o,e)}Og(e)}for(e=e.child;e!==null;){switch(t=e,t.tag){case 0:case 11:case 15:Ea(8,t,t.return),Qo(t);break;case 22:s=t.stateNode,s._visibility&2&&(s._visibility&=-3,Qo(t));break;default:Qo(t)}e=e.sibling}}function Gg(e,t){for(;Rt!==null;){var s=Rt;switch(s.tag){case 0:case 11:case 15:Ea(8,s,t);break;case 23:case 22:if(s.memoizedState!==null&&s.memoizedState.cachePool!==null){var o=s.memoizedState.cachePool.pool;o!=null&&o.refCount++}break;case 24:Yi(s.memoizedState.cache)}if(o=s.child,o!==null)o.return=s,Rt=o;else e:for(s=e;Rt!==null;){o=Rt;var c=o.sibling,f=o.return;if(Ng(o),o===s){Rt=null;break e}if(c!==null){c.return=f,Rt=c;break e}Rt=f}}}var D5={getCacheForType:function(e){var t=Et(rt),s=t.data.get(e);return s===void 0&&(s=e(),t.data.set(e,s)),s},cacheSignal:function(){return Et(rt).controller.signal}},z5=typeof WeakMap=="function"?WeakMap:Map,De=0,Be=null,Re=null,je=0,ze=0,nn=null,Aa=!1,Ks=!1,ed=!1,ra=0,We=0,Ca=0,ds=0,td=0,an=0,Js=0,cr=null,Yt=null,nd=!1,Zo=0,_g=0,Ko=1/0,Jo=null,ka=null,ht=0,Da=null,Ws=null,oa=0,ad=0,sd=null,Bg=null,ur=0,id=null;function sn(){return(De&2)!==0&&je!==0?je&-je:U.T!==null?dd():tp()}function Ug(){if(an===0)if((je&536870912)===0||Ne){var e=io;io<<=1,(io&3932160)===0&&(io=262144),an=e}else an=536870912;return e=en.current,e!==null&&(e.flags|=32),an}function qt(e,t,s){(e===Be&&(ze===2||ze===9)||e.cancelPendingCommit!==null)&&(ei(e,0),za(e,je,an,!1)),ki(e,s),((De&2)===0||e!==Be)&&(e===Be&&((De&2)===0&&(ds|=s),We===4&&za(e,je,an,!1)),_n(e))}function Hg(e,t,s){if((De&6)!==0)throw Error(r(327));var o=!s&&(t&127)===0&&(t&e.expiredLanes)===0||Ci(e,t),c=o?L5(e,t):od(e,t,!0),f=o;do{if(c===0){Ks&&!o&&za(e,t,0,!1);break}else{if(s=e.current.alternate,f&&!V5(s)){c=od(e,t,!1),f=!1;continue}if(c===2){if(f=t,e.errorRecoveryDisabledLanes&f)var v=0;else v=e.pendingLanes&-536870913,v=v!==0?v:v&536870912?536870912:0;if(v!==0){t=v;e:{var R=e;c=cr;var N=R.current.memoizedState.isDehydrated;if(N&&(ei(R,v).flags|=256),v=od(R,v,!1),v!==2){if(ed&&!N){R.errorRecoveryDisabledLanes|=f,ds|=f,c=4;break e}f=Yt,Yt=c,f!==null&&(Yt===null?Yt=f:Yt.push.apply(Yt,f))}c=v}if(f=!1,c!==2)continue}}if(c===1){ei(e,0),za(e,t,0,!0);break}e:{switch(o=e,f=c,f){case 0:case 1:throw Error(r(345));case 4:if((t&4194048)!==t)break;case 6:za(o,t,an,!Aa);break e;case 2:Yt=null;break;case 3:case 5:break;default:throw Error(r(329))}if((t&62914560)===t&&(c=Zo+300-Qt(),10<c)){if(za(o,t,an,!Aa),oo(o,0,!0)!==0)break e;oa=t,o.timeoutHandle=x0(Fg.bind(null,o,s,Yt,Jo,nd,t,an,ds,Js,Aa,f,"Throttled",-0,0),c);break e}Fg(o,s,Yt,Jo,nd,t,an,ds,Js,Aa,f,null,-0,0)}}break}while(!0);_n(e)}function Fg(e,t,s,o,c,f,v,R,N,_,F,$,B,H){if(e.timeoutHandle=-1,$=t.subtreeFlags,$&8192||($&16785408)===16785408){$={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:qn},Vg(t,f,$);var te=(f&62914560)===f?Zo-Qt():(f&4194048)===f?_g-Qt():0;if(te=x3($,te),te!==null){oa=f,e.cancelPendingCommit=te(Zg.bind(null,e,t,f,s,o,c,v,R,N,F,$,null,B,H)),za(e,f,v,!_);return}}Zg(e,t,f,s,o,c,v,R,N)}function V5(e){for(var t=e;;){var s=t.tag;if((s===0||s===11||s===15)&&t.flags&16384&&(s=t.updateQueue,s!==null&&(s=s.stores,s!==null)))for(var o=0;o<s.length;o++){var c=s[o],f=c.getSnapshot;c=c.value;try{if(!Jt(f(),c))return!1}catch{return!1}}if(s=t.child,t.subtreeFlags&16384&&s!==null)s.return=t,t=s;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function za(e,t,s,o){t&=~td,t&=~ds,e.suspendedLanes|=t,e.pingedLanes&=~t,o&&(e.warmLanes|=t),o=e.expirationTimes;for(var c=t;0<c;){var f=31-Kt(c),v=1<<f;o[f]=-1,c&=~v}s!==0&&Jh(e,s,t)}function Wo(){return(De&6)===0?(dr(0),!1):!0}function rd(){if(Re!==null){if(ze===0)var e=Re.return;else e=Re,Zn=ns=null,wu(e),Ps=null,Xi=0,e=Re;for(;e!==null;)vg(e.alternate,e),e=e.return;Re=null}}function ei(e,t){var s=e.timeoutHandle;s!==-1&&(e.timeoutHandle=-1,e3(s)),s=e.cancelPendingCommit,s!==null&&(e.cancelPendingCommit=null,s()),oa=0,rd(),Be=e,Re=s=$n(e.current,null),je=t,ze=0,nn=null,Aa=!1,Ks=Ci(e,t),ed=!1,Js=an=td=ds=Ca=We=0,Yt=cr=null,nd=!1,(t&8)!==0&&(t|=t&32);var o=e.entangledLanes;if(o!==0)for(e=e.entanglements,o&=t;0<o;){var c=31-Kt(o),f=1<<c;t|=e[c],o&=~f}return ra=t,bo(),s}function Ig(e,t){ge=null,U.H=tr,t===Is||t===Eo?(t=im(),ze=3):t===uu?(t=im(),ze=4):ze=t===_u?8:t!==null&&typeof t=="object"&&typeof t.then=="function"?6:1,nn=t,Re===null&&(We=1,Fo(e,dn(t,e.current)))}function Pg(){var e=en.current;return e===null?!0:(je&4194048)===je?mn===null:(je&62914560)===je||(je&536870912)!==0?e===mn:!1}function Yg(){var e=U.H;return U.H=tr,e===null?tr:e}function qg(){var e=U.A;return U.A=D5,e}function el(){We=4,Aa||(je&4194048)!==je&&en.current!==null||(Ks=!0),(Ca&134217727)===0&&(ds&134217727)===0||Be===null||za(Be,je,an,!1)}function od(e,t,s){var o=De;De|=2;var c=Yg(),f=qg();(Be!==e||je!==t)&&(Jo=null,ei(e,t)),t=!1;var v=We;e:do try{if(ze!==0&&Re!==null){var R=Re,N=nn;switch(ze){case 8:rd(),v=6;break e;case 3:case 2:case 9:case 6:en.current===null&&(t=!0);var _=ze;if(ze=0,nn=null,ti(e,R,N,_),s&&Ks){v=0;break e}break;default:_=ze,ze=0,nn=null,ti(e,R,N,_)}}O5(),v=We;break}catch(F){Ig(e,F)}while(!0);return t&&e.shellSuspendCounter++,Zn=ns=null,De=o,U.H=c,U.A=f,Re===null&&(Be=null,je=0,bo()),v}function O5(){for(;Re!==null;)Xg(Re)}function L5(e,t){var s=De;De|=2;var o=Yg(),c=qg();Be!==e||je!==t?(Jo=null,Ko=Qt()+500,ei(e,t)):Ks=Ci(e,t);e:do try{if(ze!==0&&Re!==null){t=Re;var f=nn;t:switch(ze){case 1:ze=0,nn=null,ti(e,t,f,1);break;case 2:case 9:if(am(f)){ze=0,nn=null,$g(t);break}t=function(){ze!==2&&ze!==9||Be!==e||(ze=7),_n(e)},f.then(t,t);break e;case 3:ze=7;break e;case 4:ze=5;break e;case 7:am(f)?(ze=0,nn=null,$g(t)):(ze=0,nn=null,ti(e,t,f,7));break;case 5:var v=null;switch(Re.tag){case 26:v=Re.memoizedState;case 5:case 27:var R=Re;if(v?z0(v):R.stateNode.complete){ze=0,nn=null;var N=R.sibling;if(N!==null)Re=N;else{var _=R.return;_!==null?(Re=_,tl(_)):Re=null}break t}}ze=0,nn=null,ti(e,t,f,5);break;case 6:ze=0,nn=null,ti(e,t,f,6);break;case 8:rd(),We=6;break e;default:throw Error(r(462))}}G5();break}catch(F){Ig(e,F)}while(!0);return Zn=ns=null,U.H=o,U.A=c,De=s,Re!==null?0:(Be=null,je=0,bo(),We)}function G5(){for(;Re!==null&&!r2();)Xg(Re)}function Xg(e){var t=yg(e.alternate,e,ra);e.memoizedProps=e.pendingProps,t===null?tl(e):Re=t}function $g(e){var t=e,s=t.alternate;switch(t.tag){case 15:case 0:t=dg(s,t,t.pendingProps,t.type,void 0,je);break;case 11:t=dg(s,t,t.pendingProps,t.type.render,t.ref,je);break;case 5:wu(t);default:vg(s,t),t=Re=qp(t,ra),t=yg(s,t,ra)}e.memoizedProps=e.pendingProps,t===null?tl(e):Re=t}function ti(e,t,s,o){Zn=ns=null,wu(t),Ps=null,Xi=0;var c=t.return;try{if(M5(e,c,t,s,je)){We=1,Fo(e,dn(s,e.current)),Re=null;return}}catch(f){if(c!==null)throw Re=c,f;We=1,Fo(e,dn(s,e.current)),Re=null;return}t.flags&32768?(Ne||o===1?e=!0:Ks||(je&536870912)!==0?e=!1:(Aa=e=!0,(o===2||o===9||o===3||o===6)&&(o=en.current,o!==null&&o.tag===13&&(o.flags|=16384))),Qg(t,e)):tl(t)}function tl(e){var t=e;do{if((t.flags&32768)!==0){Qg(t,Aa);return}e=t.return;var s=E5(t.alternate,t,ra);if(s!==null){Re=s;return}if(t=t.sibling,t!==null){Re=t;return}Re=t=e}while(t!==null);We===0&&(We=5)}function Qg(e,t){do{var s=A5(e.alternate,e);if(s!==null){s.flags&=32767,Re=s;return}if(s=e.return,s!==null&&(s.flags|=32768,s.subtreeFlags=0,s.deletions=null),!t&&(e=e.sibling,e!==null)){Re=e;return}Re=e=s}while(e!==null);We=6,Re=null}function Zg(e,t,s,o,c,f,v,R,N){e.cancelPendingCommit=null;do nl();while(ht!==0);if((De&6)!==0)throw Error(r(327));if(t!==null){if(t===e.current)throw Error(r(177));if(f=t.lanes|t.childLanes,f|=Qc,g2(e,s,f,v,R,N),e===Be&&(Re=Be=null,je=0),Ws=t,Da=e,oa=s,ad=f,sd=c,Bg=o,(t.subtreeFlags&10256)!==0||(t.flags&10256)!==0?(e.callbackNode=null,e.callbackPriority=0,H5(ao,function(){return t0(),null})):(e.callbackNode=null,e.callbackPriority=0),o=(t.flags&13878)!==0,(t.subtreeFlags&13878)!==0||o){o=U.T,U.T=null,c=K.p,K.p=2,v=De,De|=4;try{C5(e,t,s)}finally{De=v,K.p=c,U.T=o}}ht=1,Kg(),Jg(),Wg()}}function Kg(){if(ht===1){ht=0;var e=Da,t=Ws,s=(t.flags&13878)!==0;if((t.subtreeFlags&13878)!==0||s){s=U.T,U.T=null;var o=K.p;K.p=2;var c=De;De|=4;try{kg(t,e);var f=vd,v=Gp(e.containerInfo),R=f.focusedElem,N=f.selectionRange;if(v!==R&&R&&R.ownerDocument&&Lp(R.ownerDocument.documentElement,R)){if(N!==null&&Pc(R)){var _=N.start,F=N.end;if(F===void 0&&(F=_),"selectionStart"in R)R.selectionStart=_,R.selectionEnd=Math.min(F,R.value.length);else{var $=R.ownerDocument||document,B=$&&$.defaultView||window;if(B.getSelection){var H=B.getSelection(),te=R.textContent.length,ce=Math.min(N.start,te),Ge=N.end===void 0?ce:Math.min(N.end,te);!H.extend&&ce>Ge&&(v=Ge,Ge=ce,ce=v);var V=Op(R,ce),C=Op(R,Ge);if(V&&C&&(H.rangeCount!==1||H.anchorNode!==V.node||H.anchorOffset!==V.offset||H.focusNode!==C.node||H.focusOffset!==C.offset)){var G=$.createRange();G.setStart(V.node,V.offset),H.removeAllRanges(),ce>Ge?(H.addRange(G),H.extend(C.node,C.offset)):(G.setEnd(C.node,C.offset),H.addRange(G))}}}}for($=[],H=R;H=H.parentNode;)H.nodeType===1&&$.push({element:H,left:H.scrollLeft,top:H.scrollTop});for(typeof R.focus=="function"&&R.focus(),R=0;R<$.length;R++){var P=$[R];P.element.scrollLeft=P.left,P.element.scrollTop=P.top}}pl=!!xd,vd=xd=null}finally{De=c,K.p=o,U.T=s}}e.current=t,ht=2}}function Jg(){if(ht===2){ht=0;var e=Da,t=Ws,s=(t.flags&8772)!==0;if((t.subtreeFlags&8772)!==0||s){s=U.T,U.T=null;var o=K.p;K.p=2;var c=De;De|=4;try{Tg(e,t.alternate,t)}finally{De=c,K.p=o,U.T=s}}ht=3}}function Wg(){if(ht===4||ht===3){ht=0,o2();var e=Da,t=Ws,s=oa,o=Bg;(t.subtreeFlags&10256)!==0||(t.flags&10256)!==0?ht=5:(ht=0,Ws=Da=null,e0(e,e.pendingLanes));var c=e.pendingLanes;if(c===0&&(ka=null),Mc(s),t=t.stateNode,Zt&&typeof Zt.onCommitFiberRoot=="function")try{Zt.onCommitFiberRoot(Ai,t,void 0,(t.current.flags&128)===128)}catch{}if(o!==null){t=U.T,c=K.p,K.p=2,U.T=null;try{for(var f=e.onRecoverableError,v=0;v<o.length;v++){var R=o[v];f(R.value,{componentStack:R.stack})}}finally{U.T=t,K.p=c}}(oa&3)!==0&&nl(),_n(e),c=e.pendingLanes,(s&261930)!==0&&(c&42)!==0?e===id?ur++:(ur=0,id=e):ur=0,dr(0)}}function e0(e,t){(e.pooledCacheLanes&=t)===0&&(t=e.pooledCache,t!=null&&(e.pooledCache=null,Yi(t)))}function nl(){return Kg(),Jg(),Wg(),t0()}function t0(){if(ht!==5)return!1;var e=Da,t=ad;ad=0;var s=Mc(oa),o=U.T,c=K.p;try{K.p=32>s?32:s,U.T=null,s=sd,sd=null;var f=Da,v=oa;if(ht=0,Ws=Da=null,oa=0,(De&6)!==0)throw Error(r(331));var R=De;if(De|=4,Lg(f.current),zg(f,f.current,v,s),De=R,dr(0,!1),Zt&&typeof Zt.onPostCommitFiberRoot=="function")try{Zt.onPostCommitFiberRoot(Ai,f)}catch{}return!0}finally{K.p=c,U.T=o,e0(e,t)}}function n0(e,t,s){t=dn(s,t),t=Gu(e.stateNode,t,2),e=Ma(e,t,2),e!==null&&(ki(e,2),_n(e))}function Ve(e,t,s){if(e.tag===3)n0(e,e,s);else for(;t!==null;){if(t.tag===3){n0(t,e,s);break}else if(t.tag===1){var o=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(ka===null||!ka.has(o))){e=dn(s,e),s=ag(2),o=Ma(t,s,2),o!==null&&(sg(s,o,t,e),ki(o,2),_n(o));break}}t=t.return}}function ld(e,t,s){var o=e.pingCache;if(o===null){o=e.pingCache=new z5;var c=new Set;o.set(t,c)}else c=o.get(t),c===void 0&&(c=new Set,o.set(t,c));c.has(s)||(ed=!0,c.add(s),e=_5.bind(null,e,t,s),t.then(e,e))}function _5(e,t,s){var o=e.pingCache;o!==null&&o.delete(t),e.pingedLanes|=e.suspendedLanes&s,e.warmLanes&=~s,Be===e&&(je&s)===s&&(We===4||We===3&&(je&62914560)===je&&300>Qt()-Zo?(De&2)===0&&ei(e,0):td|=s,Js===je&&(Js=0)),_n(e)}function a0(e,t){t===0&&(t=Kh()),e=Wa(e,t),e!==null&&(ki(e,t),_n(e))}function B5(e){var t=e.memoizedState,s=0;t!==null&&(s=t.retryLane),a0(e,s)}function U5(e,t){var s=0;switch(e.tag){case 31:case 13:var o=e.stateNode,c=e.memoizedState;c!==null&&(s=c.retryLane);break;case 19:o=e.stateNode;break;case 22:o=e.stateNode._retryCache;break;default:throw Error(r(314))}o!==null&&o.delete(t),a0(e,s)}function H5(e,t){return Rc(e,t)}var al=null,ni=null,cd=!1,sl=!1,ud=!1,Va=0;function _n(e){e!==ni&&e.next===null&&(ni===null?al=ni=e:ni=ni.next=e),sl=!0,cd||(cd=!0,I5())}function dr(e,t){if(!ud&&sl){ud=!0;do for(var s=!1,o=al;o!==null;){if(e!==0){var c=o.pendingLanes;if(c===0)var f=0;else{var v=o.suspendedLanes,R=o.pingedLanes;f=(1<<31-Kt(42|e)+1)-1,f&=c&~(v&~R),f=f&201326741?f&201326741|1:f?f|2:0}f!==0&&(s=!0,o0(o,f))}else f=je,f=oo(o,o===Be?f:0,o.cancelPendingCommit!==null||o.timeoutHandle!==-1),(f&3)===0||Ci(o,f)||(s=!0,o0(o,f));o=o.next}while(s);ud=!1}}function F5(){s0()}function s0(){sl=cd=!1;var e=0;Va!==0&&W5()&&(e=Va);for(var t=Qt(),s=null,o=al;o!==null;){var c=o.next,f=i0(o,t);f===0?(o.next=null,s===null?al=c:s.next=c,c===null&&(ni=s)):(s=o,(e!==0||(f&3)!==0)&&(sl=!0)),o=c}ht!==0&&ht!==5||dr(e),Va!==0&&(Va=0)}function i0(e,t){for(var s=e.suspendedLanes,o=e.pingedLanes,c=e.expirationTimes,f=e.pendingLanes&-62914561;0<f;){var v=31-Kt(f),R=1<<v,N=c[v];N===-1?((R&s)===0||(R&o)!==0)&&(c[v]=m2(R,t)):N<=t&&(e.expiredLanes|=R),f&=~R}if(t=Be,s=je,s=oo(e,e===t?s:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o=e.callbackNode,s===0||e===t&&(ze===2||ze===9)||e.cancelPendingCommit!==null)return o!==null&&o!==null&&wc(o),e.callbackNode=null,e.callbackPriority=0;if((s&3)===0||Ci(e,s)){if(t=s&-s,t===e.callbackPriority)return t;switch(o!==null&&wc(o),Mc(s)){case 2:case 8:s=Qh;break;case 32:s=ao;break;case 268435456:s=Zh;break;default:s=ao}return o=r0.bind(null,e),s=Rc(s,o),e.callbackPriority=t,e.callbackNode=s,t}return o!==null&&o!==null&&wc(o),e.callbackPriority=2,e.callbackNode=null,2}function r0(e,t){if(ht!==0&&ht!==5)return e.callbackNode=null,e.callbackPriority=0,null;var s=e.callbackNode;if(nl()&&e.callbackNode!==s)return null;var o=je;return o=oo(e,e===Be?o:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o===0?null:(Hg(e,o,t),i0(e,Qt()),e.callbackNode!=null&&e.callbackNode===s?r0.bind(null,e):null)}function o0(e,t){if(nl())return null;Hg(e,t,!0)}function I5(){t3(function(){(De&6)!==0?Rc($h,F5):s0()})}function dd(){if(Va===0){var e=Hs;e===0&&(e=so,so<<=1,(so&261888)===0&&(so=256)),Va=e}return Va}function l0(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:fo(""+e)}function c0(e,t){var s=t.ownerDocument.createElement("input");return s.name=t.name,s.value=t.value,e.id&&s.setAttribute("form",e.id),t.parentNode.insertBefore(s,t),e=new FormData(e),s.parentNode.removeChild(s),e}function P5(e,t,s,o,c){if(t==="submit"&&s&&s.stateNode===c){var f=l0((c[Ut]||null).action),v=o.submitter;v&&(t=(t=v[Ut]||null)?l0(t.formAction):v.getAttribute("formAction"),t!==null&&(f=t,v=null));var R=new go("action","action",null,o,c);e.push({event:R,listeners:[{instance:null,listener:function(){if(o.defaultPrevented){if(Va!==0){var N=v?c0(c,v):new FormData(c);ku(s,{pending:!0,data:N,method:c.method,action:f},null,N)}}else typeof f=="function"&&(R.preventDefault(),N=v?c0(c,v):new FormData(c),ku(s,{pending:!0,data:N,method:c.method,action:f},f,N))},currentTarget:c}]})}}for(var fd=0;fd<$c.length;fd++){var hd=$c[fd],Y5=hd.toLowerCase(),q5=hd[0].toUpperCase()+hd.slice(1);wn(Y5,"on"+q5)}wn(Up,"onAnimationEnd"),wn(Hp,"onAnimationIteration"),wn(Fp,"onAnimationStart"),wn("dblclick","onDoubleClick"),wn("focusin","onFocus"),wn("focusout","onBlur"),wn(l5,"onTransitionRun"),wn(c5,"onTransitionStart"),wn(u5,"onTransitionCancel"),wn(Ip,"onTransitionEnd"),Ns("onMouseEnter",["mouseout","mouseover"]),Ns("onMouseLeave",["mouseout","mouseover"]),Ns("onPointerEnter",["pointerout","pointerover"]),Ns("onPointerLeave",["pointerout","pointerover"]),Qa("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),Qa("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),Qa("onBeforeInput",["compositionend","keypress","textInput","paste"]),Qa("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),Qa("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),Qa("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var fr="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),X5=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(fr));function u0(e,t){t=(t&4)!==0;for(var s=0;s<e.length;s++){var o=e[s],c=o.event;o=o.listeners;e:{var f=void 0;if(t)for(var v=o.length-1;0<=v;v--){var R=o[v],N=R.instance,_=R.currentTarget;if(R=R.listener,N!==f&&c.isPropagationStopped())break e;f=R,c.currentTarget=_;try{f(c)}catch(F){vo(F)}c.currentTarget=null,f=N}else for(v=0;v<o.length;v++){if(R=o[v],N=R.instance,_=R.currentTarget,R=R.listener,N!==f&&c.isPropagationStopped())break e;f=R,c.currentTarget=_;try{f(c)}catch(F){vo(F)}c.currentTarget=null,f=N}}}}function we(e,t){var s=t[Tc];s===void 0&&(s=t[Tc]=new Set);var o=e+"__bubble";s.has(o)||(d0(t,e,2,!1),s.add(o))}function pd(e,t,s){var o=0;t&&(o|=4),d0(s,e,o,t)}var il="_reactListening"+Math.random().toString(36).slice(2);function md(e){if(!e[il]){e[il]=!0,sp.forEach(function(s){s!=="selectionchange"&&(X5.has(s)||pd(s,!1,e),pd(s,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[il]||(t[il]=!0,pd("selectionchange",!1,t))}}function d0(e,t,s,o){switch(U0(t)){case 2:var c=R3;break;case 8:c=w3;break;default:c=Cd}s=c.bind(null,t,s,e),c=void 0,!Oc||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(c=!0),o?c!==void 0?e.addEventListener(t,s,{capture:!0,passive:c}):e.addEventListener(t,s,!0):c!==void 0?e.addEventListener(t,s,{passive:c}):e.addEventListener(t,s,!1)}function gd(e,t,s,o,c){var f=o;if((t&1)===0&&(t&2)===0&&o!==null)e:for(;;){if(o===null)return;var v=o.tag;if(v===3||v===4){var R=o.stateNode.containerInfo;if(R===c)break;if(v===4)for(v=o.return;v!==null;){var N=v.tag;if((N===3||N===4)&&v.stateNode.containerInfo===c)return;v=v.return}for(;R!==null;){if(v=js(R),v===null)return;if(N=v.tag,N===5||N===6||N===26||N===27){o=f=v;continue e}R=R.parentNode}}o=o.return}gp(function(){var _=f,F=zc(s),$=[];e:{var B=Pp.get(e);if(B!==void 0){var H=go,te=e;switch(e){case"keypress":if(po(s)===0)break e;case"keydown":case"keyup":H=U2;break;case"focusin":te="focus",H=Bc;break;case"focusout":te="blur",H=Bc;break;case"beforeblur":case"afterblur":H=Bc;break;case"click":if(s.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":H=vp;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":H=E2;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":H=I2;break;case Up:case Hp:case Fp:H=k2;break;case Ip:H=Y2;break;case"scroll":case"scrollend":H=T2;break;case"wheel":H=X2;break;case"copy":case"cut":case"paste":H=z2;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":H=Rp;break;case"toggle":case"beforetoggle":H=Q2}var ce=(t&4)!==0,Ge=!ce&&(e==="scroll"||e==="scrollend"),V=ce?B!==null?B+"Capture":null:B;ce=[];for(var C=_,G;C!==null;){var P=C;if(G=P.stateNode,P=P.tag,P!==5&&P!==26&&P!==27||G===null||V===null||(P=Vi(C,V),P!=null&&ce.push(hr(C,P,G))),Ge)break;C=C.return}0<ce.length&&(B=new H(B,te,null,s,F),$.push({event:B,listeners:ce}))}}if((t&7)===0){e:{if(B=e==="mouseover"||e==="pointerover",H=e==="mouseout"||e==="pointerout",B&&s!==Dc&&(te=s.relatedTarget||s.fromElement)&&(js(te)||te[Ss]))break e;if((H||B)&&(B=F.window===F?F:(B=F.ownerDocument)?B.defaultView||B.parentWindow:window,H?(te=s.relatedTarget||s.toElement,H=_,te=te?js(te):null,te!==null&&(Ge=d(te),ce=te.tag,te!==Ge||ce!==5&&ce!==27&&ce!==6)&&(te=null)):(H=null,te=_),H!==te)){if(ce=vp,P="onMouseLeave",V="onMouseEnter",C="mouse",(e==="pointerout"||e==="pointerover")&&(ce=Rp,P="onPointerLeave",V="onPointerEnter",C="pointer"),Ge=H==null?B:zi(H),G=te==null?B:zi(te),B=new ce(P,C+"leave",H,s,F),B.target=Ge,B.relatedTarget=G,P=null,js(F)===_&&(ce=new ce(V,C+"enter",te,s,F),ce.target=G,ce.relatedTarget=Ge,P=ce),Ge=P,H&&te)t:{for(ce=$5,V=H,C=te,G=0,P=V;P;P=ce(P))G++;P=0;for(var le=C;le;le=ce(le))P++;for(;0<G-P;)V=ce(V),G--;for(;0<P-G;)C=ce(C),P--;for(;G--;){if(V===C||C!==null&&V===C.alternate){ce=V;break t}V=ce(V),C=ce(C)}ce=null}else ce=null;H!==null&&f0($,B,H,ce,!1),te!==null&&Ge!==null&&f0($,Ge,te,ce,!0)}}e:{if(B=_?zi(_):window,H=B.nodeName&&B.nodeName.toLowerCase(),H==="select"||H==="input"&&B.type==="file")var Ce=Ap;else if(Np(B))if(Cp)Ce=i5;else{Ce=a5;var ie=n5}else H=B.nodeName,!H||H.toLowerCase()!=="input"||B.type!=="checkbox"&&B.type!=="radio"?_&&kc(_.elementType)&&(Ce=Ap):Ce=s5;if(Ce&&(Ce=Ce(e,_))){Ep($,Ce,s,F);break e}ie&&ie(e,B,_),e==="focusout"&&_&&B.type==="number"&&_.memoizedProps.value!=null&&Cc(B,"number",B.value)}switch(ie=_?zi(_):window,e){case"focusin":(Np(ie)||ie.contentEditable==="true")&&(zs=ie,Yc=_,Fi=null);break;case"focusout":Fi=Yc=zs=null;break;case"mousedown":qc=!0;break;case"contextmenu":case"mouseup":case"dragend":qc=!1,_p($,s,F);break;case"selectionchange":if(o5)break;case"keydown":case"keyup":_p($,s,F)}var xe;if(Hc)e:{switch(e){case"compositionstart":var Me="onCompositionStart";break e;case"compositionend":Me="onCompositionEnd";break e;case"compositionupdate":Me="onCompositionUpdate";break e}Me=void 0}else Ds?Mp(e,s)&&(Me="onCompositionEnd"):e==="keydown"&&s.keyCode===229&&(Me="onCompositionStart");Me&&(wp&&s.locale!=="ko"&&(Ds||Me!=="onCompositionStart"?Me==="onCompositionEnd"&&Ds&&(xe=yp()):(xa=F,Lc="value"in xa?xa.value:xa.textContent,Ds=!0)),ie=rl(_,Me),0<ie.length&&(Me=new bp(Me,e,null,s,F),$.push({event:Me,listeners:ie}),xe?Me.data=xe:(xe=Tp(s),xe!==null&&(Me.data=xe)))),(xe=K2?J2(e,s):W2(e,s))&&(Me=rl(_,"onBeforeInput"),0<Me.length&&(ie=new bp("onBeforeInput","beforeinput",null,s,F),$.push({event:ie,listeners:Me}),ie.data=xe)),P5($,e,_,s,F)}u0($,t)})}function hr(e,t,s){return{instance:e,listener:t,currentTarget:s}}function rl(e,t){for(var s=t+"Capture",o=[];e!==null;){var c=e,f=c.stateNode;if(c=c.tag,c!==5&&c!==26&&c!==27||f===null||(c=Vi(e,s),c!=null&&o.unshift(hr(e,c,f)),c=Vi(e,t),c!=null&&o.push(hr(e,c,f))),e.tag===3)return o;e=e.return}return[]}function $5(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function f0(e,t,s,o,c){for(var f=t._reactName,v=[];s!==null&&s!==o;){var R=s,N=R.alternate,_=R.stateNode;if(R=R.tag,N!==null&&N===o)break;R!==5&&R!==26&&R!==27||_===null||(N=_,c?(_=Vi(s,f),_!=null&&v.unshift(hr(s,_,N))):c||(_=Vi(s,f),_!=null&&v.push(hr(s,_,N)))),s=s.return}v.length!==0&&e.push({event:t,listeners:v})}var Q5=/\r\n?/g,Z5=/\u0000|\uFFFD/g;function h0(e){return(typeof e=="string"?e:""+e).replace(Q5,`
`).replace(Z5,"")}function p0(e,t){return t=h0(t),h0(e)===t}function Le(e,t,s,o,c,f){switch(s){case"children":typeof o=="string"?t==="body"||t==="textarea"&&o===""||As(e,o):(typeof o=="number"||typeof o=="bigint")&&t!=="body"&&As(e,""+o);break;case"className":co(e,"class",o);break;case"tabIndex":co(e,"tabindex",o);break;case"dir":case"role":case"viewBox":case"width":case"height":co(e,s,o);break;case"style":pp(e,o,f);break;case"data":if(t!=="object"){co(e,"data",o);break}case"src":case"href":if(o===""&&(t!=="a"||s!=="href")){e.removeAttribute(s);break}if(o==null||typeof o=="function"||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(s);break}o=fo(""+o),e.setAttribute(s,o);break;case"action":case"formAction":if(typeof o=="function"){e.setAttribute(s,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof f=="function"&&(s==="formAction"?(t!=="input"&&Le(e,t,"name",c.name,c,null),Le(e,t,"formEncType",c.formEncType,c,null),Le(e,t,"formMethod",c.formMethod,c,null),Le(e,t,"formTarget",c.formTarget,c,null)):(Le(e,t,"encType",c.encType,c,null),Le(e,t,"method",c.method,c,null),Le(e,t,"target",c.target,c,null)));if(o==null||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(s);break}o=fo(""+o),e.setAttribute(s,o);break;case"onClick":o!=null&&(e.onclick=qn);break;case"onScroll":o!=null&&we("scroll",e);break;case"onScrollEnd":o!=null&&we("scrollend",e);break;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(r(61));if(s=o.__html,s!=null){if(c.children!=null)throw Error(r(60));e.innerHTML=s}}break;case"multiple":e.multiple=o&&typeof o!="function"&&typeof o!="symbol";break;case"muted":e.muted=o&&typeof o!="function"&&typeof o!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(o==null||typeof o=="function"||typeof o=="boolean"||typeof o=="symbol"){e.removeAttribute("xlink:href");break}s=fo(""+o),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",s);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(s,""+o):e.removeAttribute(s);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":o&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(s,""):e.removeAttribute(s);break;case"capture":case"download":o===!0?e.setAttribute(s,""):o!==!1&&o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(s,o):e.removeAttribute(s);break;case"cols":case"rows":case"size":case"span":o!=null&&typeof o!="function"&&typeof o!="symbol"&&!isNaN(o)&&1<=o?e.setAttribute(s,o):e.removeAttribute(s);break;case"rowSpan":case"start":o==null||typeof o=="function"||typeof o=="symbol"||isNaN(o)?e.removeAttribute(s):e.setAttribute(s,o);break;case"popover":we("beforetoggle",e),we("toggle",e),lo(e,"popover",o);break;case"xlinkActuate":Yn(e,"http://www.w3.org/1999/xlink","xlink:actuate",o);break;case"xlinkArcrole":Yn(e,"http://www.w3.org/1999/xlink","xlink:arcrole",o);break;case"xlinkRole":Yn(e,"http://www.w3.org/1999/xlink","xlink:role",o);break;case"xlinkShow":Yn(e,"http://www.w3.org/1999/xlink","xlink:show",o);break;case"xlinkTitle":Yn(e,"http://www.w3.org/1999/xlink","xlink:title",o);break;case"xlinkType":Yn(e,"http://www.w3.org/1999/xlink","xlink:type",o);break;case"xmlBase":Yn(e,"http://www.w3.org/XML/1998/namespace","xml:base",o);break;case"xmlLang":Yn(e,"http://www.w3.org/XML/1998/namespace","xml:lang",o);break;case"xmlSpace":Yn(e,"http://www.w3.org/XML/1998/namespace","xml:space",o);break;case"is":lo(e,"is",o);break;case"innerText":case"textContent":break;default:(!(2<s.length)||s[0]!=="o"&&s[0]!=="O"||s[1]!=="n"&&s[1]!=="N")&&(s=j2.get(s)||s,lo(e,s,o))}}function yd(e,t,s,o,c,f){switch(s){case"style":pp(e,o,f);break;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(r(61));if(s=o.__html,s!=null){if(c.children!=null)throw Error(r(60));e.innerHTML=s}}break;case"children":typeof o=="string"?As(e,o):(typeof o=="number"||typeof o=="bigint")&&As(e,""+o);break;case"onScroll":o!=null&&we("scroll",e);break;case"onScrollEnd":o!=null&&we("scrollend",e);break;case"onClick":o!=null&&(e.onclick=qn);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!ip.hasOwnProperty(s))e:{if(s[0]==="o"&&s[1]==="n"&&(c=s.endsWith("Capture"),t=s.slice(2,c?s.length-7:void 0),f=e[Ut]||null,f=f!=null?f[s]:null,typeof f=="function"&&e.removeEventListener(t,f,c),typeof o=="function")){typeof f!="function"&&f!==null&&(s in e?e[s]=null:e.hasAttribute(s)&&e.removeAttribute(s)),e.addEventListener(t,o,c);break e}s in e?e[s]=o:o===!0?e.setAttribute(s,""):lo(e,s,o)}}}function Ct(e,t,s){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":we("error",e),we("load",e);var o=!1,c=!1,f;for(f in s)if(s.hasOwnProperty(f)){var v=s[f];if(v!=null)switch(f){case"src":o=!0;break;case"srcSet":c=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(r(137,t));default:Le(e,t,f,v,s,null)}}c&&Le(e,t,"srcSet",s.srcSet,s,null),o&&Le(e,t,"src",s.src,s,null);return;case"input":we("invalid",e);var R=f=v=c=null,N=null,_=null;for(o in s)if(s.hasOwnProperty(o)){var F=s[o];if(F!=null)switch(o){case"name":c=F;break;case"type":v=F;break;case"checked":N=F;break;case"defaultChecked":_=F;break;case"value":f=F;break;case"defaultValue":R=F;break;case"children":case"dangerouslySetInnerHTML":if(F!=null)throw Error(r(137,t));break;default:Le(e,t,o,F,s,null)}}up(e,f,R,N,_,v,c,!1);return;case"select":we("invalid",e),o=v=f=null;for(c in s)if(s.hasOwnProperty(c)&&(R=s[c],R!=null))switch(c){case"value":f=R;break;case"defaultValue":v=R;break;case"multiple":o=R;default:Le(e,t,c,R,s,null)}t=f,s=v,e.multiple=!!o,t!=null?Es(e,!!o,t,!1):s!=null&&Es(e,!!o,s,!0);return;case"textarea":we("invalid",e),f=c=o=null;for(v in s)if(s.hasOwnProperty(v)&&(R=s[v],R!=null))switch(v){case"value":o=R;break;case"defaultValue":c=R;break;case"children":f=R;break;case"dangerouslySetInnerHTML":if(R!=null)throw Error(r(91));break;default:Le(e,t,v,R,s,null)}fp(e,o,c,f);return;case"option":for(N in s)s.hasOwnProperty(N)&&(o=s[N],o!=null)&&(N==="selected"?e.selected=o&&typeof o!="function"&&typeof o!="symbol":Le(e,t,N,o,s,null));return;case"dialog":we("beforetoggle",e),we("toggle",e),we("cancel",e),we("close",e);break;case"iframe":case"object":we("load",e);break;case"video":case"audio":for(o=0;o<fr.length;o++)we(fr[o],e);break;case"image":we("error",e),we("load",e);break;case"details":we("toggle",e);break;case"embed":case"source":case"link":we("error",e),we("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(_ in s)if(s.hasOwnProperty(_)&&(o=s[_],o!=null))switch(_){case"children":case"dangerouslySetInnerHTML":throw Error(r(137,t));default:Le(e,t,_,o,s,null)}return;default:if(kc(t)){for(F in s)s.hasOwnProperty(F)&&(o=s[F],o!==void 0&&yd(e,t,F,o,s,void 0));return}}for(R in s)s.hasOwnProperty(R)&&(o=s[R],o!=null&&Le(e,t,R,o,s,null))}function K5(e,t,s,o){switch(t){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var c=null,f=null,v=null,R=null,N=null,_=null,F=null;for(H in s){var $=s[H];if(s.hasOwnProperty(H)&&$!=null)switch(H){case"checked":break;case"value":break;case"defaultValue":N=$;default:o.hasOwnProperty(H)||Le(e,t,H,null,o,$)}}for(var B in o){var H=o[B];if($=s[B],o.hasOwnProperty(B)&&(H!=null||$!=null))switch(B){case"type":f=H;break;case"name":c=H;break;case"checked":_=H;break;case"defaultChecked":F=H;break;case"value":v=H;break;case"defaultValue":R=H;break;case"children":case"dangerouslySetInnerHTML":if(H!=null)throw Error(r(137,t));break;default:H!==$&&Le(e,t,B,H,o,$)}}Ac(e,v,R,N,_,F,f,c);return;case"select":H=v=R=B=null;for(f in s)if(N=s[f],s.hasOwnProperty(f)&&N!=null)switch(f){case"value":break;case"multiple":H=N;default:o.hasOwnProperty(f)||Le(e,t,f,null,o,N)}for(c in o)if(f=o[c],N=s[c],o.hasOwnProperty(c)&&(f!=null||N!=null))switch(c){case"value":B=f;break;case"defaultValue":R=f;break;case"multiple":v=f;default:f!==N&&Le(e,t,c,f,o,N)}t=R,s=v,o=H,B!=null?Es(e,!!s,B,!1):!!o!=!!s&&(t!=null?Es(e,!!s,t,!0):Es(e,!!s,s?[]:"",!1));return;case"textarea":H=B=null;for(R in s)if(c=s[R],s.hasOwnProperty(R)&&c!=null&&!o.hasOwnProperty(R))switch(R){case"value":break;case"children":break;default:Le(e,t,R,null,o,c)}for(v in o)if(c=o[v],f=s[v],o.hasOwnProperty(v)&&(c!=null||f!=null))switch(v){case"value":B=c;break;case"defaultValue":H=c;break;case"children":break;case"dangerouslySetInnerHTML":if(c!=null)throw Error(r(91));break;default:c!==f&&Le(e,t,v,c,o,f)}dp(e,B,H);return;case"option":for(var te in s)B=s[te],s.hasOwnProperty(te)&&B!=null&&!o.hasOwnProperty(te)&&(te==="selected"?e.selected=!1:Le(e,t,te,null,o,B));for(N in o)B=o[N],H=s[N],o.hasOwnProperty(N)&&B!==H&&(B!=null||H!=null)&&(N==="selected"?e.selected=B&&typeof B!="function"&&typeof B!="symbol":Le(e,t,N,B,o,H));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var ce in s)B=s[ce],s.hasOwnProperty(ce)&&B!=null&&!o.hasOwnProperty(ce)&&Le(e,t,ce,null,o,B);for(_ in o)if(B=o[_],H=s[_],o.hasOwnProperty(_)&&B!==H&&(B!=null||H!=null))switch(_){case"children":case"dangerouslySetInnerHTML":if(B!=null)throw Error(r(137,t));break;default:Le(e,t,_,B,o,H)}return;default:if(kc(t)){for(var Ge in s)B=s[Ge],s.hasOwnProperty(Ge)&&B!==void 0&&!o.hasOwnProperty(Ge)&&yd(e,t,Ge,void 0,o,B);for(F in o)B=o[F],H=s[F],!o.hasOwnProperty(F)||B===H||B===void 0&&H===void 0||yd(e,t,F,B,o,H);return}}for(var V in s)B=s[V],s.hasOwnProperty(V)&&B!=null&&!o.hasOwnProperty(V)&&Le(e,t,V,null,o,B);for($ in o)B=o[$],H=s[$],!o.hasOwnProperty($)||B===H||B==null&&H==null||Le(e,t,$,B,o,H)}function m0(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function J5(){if(typeof performance.getEntriesByType=="function"){for(var e=0,t=0,s=performance.getEntriesByType("resource"),o=0;o<s.length;o++){var c=s[o],f=c.transferSize,v=c.initiatorType,R=c.duration;if(f&&R&&m0(v)){for(v=0,R=c.responseEnd,o+=1;o<s.length;o++){var N=s[o],_=N.startTime;if(_>R)break;var F=N.transferSize,$=N.initiatorType;F&&m0($)&&(N=N.responseEnd,v+=F*(N<R?1:(R-_)/(N-_)))}if(--o,t+=8*(f+v)/(c.duration/1e3),e++,10<e)break}}if(0<e)return t/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var xd=null,vd=null;function ol(e){return e.nodeType===9?e:e.ownerDocument}function g0(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function y0(e,t){if(e===0)switch(t){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&t==="foreignObject"?0:e}function bd(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.children=="bigint"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Rd=null;function W5(){var e=window.event;return e&&e.type==="popstate"?e===Rd?!1:(Rd=e,!0):(Rd=null,!1)}var x0=typeof setTimeout=="function"?setTimeout:void 0,e3=typeof clearTimeout=="function"?clearTimeout:void 0,v0=typeof Promise=="function"?Promise:void 0,t3=typeof queueMicrotask=="function"?queueMicrotask:typeof v0<"u"?function(e){return v0.resolve(null).then(e).catch(n3)}:x0;function n3(e){setTimeout(function(){throw e})}function Oa(e){return e==="head"}function b0(e,t){var s=t,o=0;do{var c=s.nextSibling;if(e.removeChild(s),c&&c.nodeType===8)if(s=c.data,s==="/$"||s==="/&"){if(o===0){e.removeChild(c),ri(t);return}o--}else if(s==="$"||s==="$?"||s==="$~"||s==="$!"||s==="&")o++;else if(s==="html")pr(e.ownerDocument.documentElement);else if(s==="head"){s=e.ownerDocument.head,pr(s);for(var f=s.firstChild;f;){var v=f.nextSibling,R=f.nodeName;f[Di]||R==="SCRIPT"||R==="STYLE"||R==="LINK"&&f.rel.toLowerCase()==="stylesheet"||s.removeChild(f),f=v}}else s==="body"&&pr(e.ownerDocument.body);s=c}while(s);ri(t)}function R0(e,t){var s=e;e=0;do{var o=s.nextSibling;if(s.nodeType===1?t?(s._stashedDisplay=s.style.display,s.style.display="none"):(s.style.display=s._stashedDisplay||"",s.getAttribute("style")===""&&s.removeAttribute("style")):s.nodeType===3&&(t?(s._stashedText=s.nodeValue,s.nodeValue=""):s.nodeValue=s._stashedText||""),o&&o.nodeType===8)if(s=o.data,s==="/$"){if(e===0)break;e--}else s!=="$"&&s!=="$?"&&s!=="$~"&&s!=="$!"||e++;s=o}while(s)}function wd(e){var t=e.firstChild;for(t&&t.nodeType===10&&(t=t.nextSibling);t;){var s=t;switch(t=t.nextSibling,s.nodeName){case"HTML":case"HEAD":case"BODY":wd(s),Nc(s);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(s.rel.toLowerCase()==="stylesheet")continue}e.removeChild(s)}}function a3(e,t,s,o){for(;e.nodeType===1;){var c=s;if(e.nodeName.toLowerCase()!==t.toLowerCase()){if(!o&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(o){if(!e[Di])switch(t){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(f=e.getAttribute("rel"),f==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(f!==c.rel||e.getAttribute("href")!==(c.href==null||c.href===""?null:c.href)||e.getAttribute("crossorigin")!==(c.crossOrigin==null?null:c.crossOrigin)||e.getAttribute("title")!==(c.title==null?null:c.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(f=e.getAttribute("src"),(f!==(c.src==null?null:c.src)||e.getAttribute("type")!==(c.type==null?null:c.type)||e.getAttribute("crossorigin")!==(c.crossOrigin==null?null:c.crossOrigin))&&f&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(t==="input"&&e.type==="hidden"){var f=c.name==null?null:""+c.name;if(c.type==="hidden"&&e.getAttribute("name")===f)return e}else return e;if(e=gn(e.nextSibling),e===null)break}return null}function s3(e,t,s){if(t==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!s||(e=gn(e.nextSibling),e===null))return null;return e}function w0(e,t){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!t||(e=gn(e.nextSibling),e===null))return null;return e}function Sd(e){return e.data==="$?"||e.data==="$~"}function jd(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function i3(e,t){var s=e.ownerDocument;if(e.data==="$~")e._reactRetry=t;else if(e.data!=="$?"||s.readyState!=="loading")t();else{var o=function(){t(),s.removeEventListener("DOMContentLoaded",o)};s.addEventListener("DOMContentLoaded",o),e._reactRetry=o}}function gn(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"||t==="F!"||t==="F")break;if(t==="/$"||t==="/&")return null}}return e}var Md=null;function S0(e){e=e.nextSibling;for(var t=0;e;){if(e.nodeType===8){var s=e.data;if(s==="/$"||s==="/&"){if(t===0)return gn(e.nextSibling);t--}else s!=="$"&&s!=="$!"&&s!=="$?"&&s!=="$~"&&s!=="&"||t++}e=e.nextSibling}return null}function j0(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var s=e.data;if(s==="$"||s==="$!"||s==="$?"||s==="$~"||s==="&"){if(t===0)return e;t--}else s!=="/$"&&s!=="/&"||t++}e=e.previousSibling}return null}function M0(e,t,s){switch(t=ol(s),e){case"html":if(e=t.documentElement,!e)throw Error(r(452));return e;case"head":if(e=t.head,!e)throw Error(r(453));return e;case"body":if(e=t.body,!e)throw Error(r(454));return e;default:throw Error(r(451))}}function pr(e){for(var t=e.attributes;t.length;)e.removeAttributeNode(t[0]);Nc(e)}var yn=new Map,T0=new Set;function ll(e){return typeof e.getRootNode=="function"?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var la=K.d;K.d={f:r3,r:o3,D:l3,C:c3,L:u3,m:d3,X:h3,S:f3,M:p3};function r3(){var e=la.f(),t=Wo();return e||t}function o3(e){var t=Ms(e);t!==null&&t.tag===5&&t.type==="form"?Im(t):la.r(e)}var ai=typeof document>"u"?null:document;function N0(e,t,s){var o=ai;if(o&&typeof t=="string"&&t){var c=cn(t);c='link[rel="'+e+'"][href="'+c+'"]',typeof s=="string"&&(c+='[crossorigin="'+s+'"]'),T0.has(c)||(T0.add(c),e={rel:e,crossOrigin:s,href:t},o.querySelector(c)===null&&(t=o.createElement("link"),Ct(t,"link",e),bt(t),o.head.appendChild(t)))}}function l3(e){la.D(e),N0("dns-prefetch",e,null)}function c3(e,t){la.C(e,t),N0("preconnect",e,t)}function u3(e,t,s){la.L(e,t,s);var o=ai;if(o&&e&&t){var c='link[rel="preload"][as="'+cn(t)+'"]';t==="image"&&s&&s.imageSrcSet?(c+='[imagesrcset="'+cn(s.imageSrcSet)+'"]',typeof s.imageSizes=="string"&&(c+='[imagesizes="'+cn(s.imageSizes)+'"]')):c+='[href="'+cn(e)+'"]';var f=c;switch(t){case"style":f=si(e);break;case"script":f=ii(e)}yn.has(f)||(e=x({rel:"preload",href:t==="image"&&s&&s.imageSrcSet?void 0:e,as:t},s),yn.set(f,e),o.querySelector(c)!==null||t==="style"&&o.querySelector(mr(f))||t==="script"&&o.querySelector(gr(f))||(t=o.createElement("link"),Ct(t,"link",e),bt(t),o.head.appendChild(t)))}}function d3(e,t){la.m(e,t);var s=ai;if(s&&e){var o=t&&typeof t.as=="string"?t.as:"script",c='link[rel="modulepreload"][as="'+cn(o)+'"][href="'+cn(e)+'"]',f=c;switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":f=ii(e)}if(!yn.has(f)&&(e=x({rel:"modulepreload",href:e},t),yn.set(f,e),s.querySelector(c)===null)){switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(s.querySelector(gr(f)))return}o=s.createElement("link"),Ct(o,"link",e),bt(o),s.head.appendChild(o)}}}function f3(e,t,s){la.S(e,t,s);var o=ai;if(o&&e){var c=Ts(o).hoistableStyles,f=si(e);t=t||"default";var v=c.get(f);if(!v){var R={loading:0,preload:null};if(v=o.querySelector(mr(f)))R.loading=5;else{e=x({rel:"stylesheet",href:e,"data-precedence":t},s),(s=yn.get(f))&&Td(e,s);var N=v=o.createElement("link");bt(N),Ct(N,"link",e),N._p=new Promise(function(_,F){N.onload=_,N.onerror=F}),N.addEventListener("load",function(){R.loading|=1}),N.addEventListener("error",function(){R.loading|=2}),R.loading|=4,cl(v,t,o)}v={type:"stylesheet",instance:v,count:1,state:R},c.set(f,v)}}}function h3(e,t){la.X(e,t);var s=ai;if(s&&e){var o=Ts(s).hoistableScripts,c=ii(e),f=o.get(c);f||(f=s.querySelector(gr(c)),f||(e=x({src:e,async:!0},t),(t=yn.get(c))&&Nd(e,t),f=s.createElement("script"),bt(f),Ct(f,"link",e),s.head.appendChild(f)),f={type:"script",instance:f,count:1,state:null},o.set(c,f))}}function p3(e,t){la.M(e,t);var s=ai;if(s&&e){var o=Ts(s).hoistableScripts,c=ii(e),f=o.get(c);f||(f=s.querySelector(gr(c)),f||(e=x({src:e,async:!0,type:"module"},t),(t=yn.get(c))&&Nd(e,t),f=s.createElement("script"),bt(f),Ct(f,"link",e),s.head.appendChild(f)),f={type:"script",instance:f,count:1,state:null},o.set(c,f))}}function E0(e,t,s,o){var c=(c=ve.current)?ll(c):null;if(!c)throw Error(r(446));switch(e){case"meta":case"title":return null;case"style":return typeof s.precedence=="string"&&typeof s.href=="string"?(t=si(s.href),s=Ts(c).hoistableStyles,o=s.get(t),o||(o={type:"style",instance:null,count:0,state:null},s.set(t,o)),o):{type:"void",instance:null,count:0,state:null};case"link":if(s.rel==="stylesheet"&&typeof s.href=="string"&&typeof s.precedence=="string"){e=si(s.href);var f=Ts(c).hoistableStyles,v=f.get(e);if(v||(c=c.ownerDocument||c,v={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},f.set(e,v),(f=c.querySelector(mr(e)))&&!f._p&&(v.instance=f,v.state.loading=5),yn.has(e)||(s={rel:"preload",as:"style",href:s.href,crossOrigin:s.crossOrigin,integrity:s.integrity,media:s.media,hrefLang:s.hrefLang,referrerPolicy:s.referrerPolicy},yn.set(e,s),f||m3(c,e,s,v.state))),t&&o===null)throw Error(r(528,""));return v}if(t&&o!==null)throw Error(r(529,""));return null;case"script":return t=s.async,s=s.src,typeof s=="string"&&t&&typeof t!="function"&&typeof t!="symbol"?(t=ii(s),s=Ts(c).hoistableScripts,o=s.get(t),o||(o={type:"script",instance:null,count:0,state:null},s.set(t,o)),o):{type:"void",instance:null,count:0,state:null};default:throw Error(r(444,e))}}function si(e){return'href="'+cn(e)+'"'}function mr(e){return'link[rel="stylesheet"]['+e+"]"}function A0(e){return x({},e,{"data-precedence":e.precedence,precedence:null})}function m3(e,t,s,o){e.querySelector('link[rel="preload"][as="style"]['+t+"]")?o.loading=1:(t=e.createElement("link"),o.preload=t,t.addEventListener("load",function(){return o.loading|=1}),t.addEventListener("error",function(){return o.loading|=2}),Ct(t,"link",s),bt(t),e.head.appendChild(t))}function ii(e){return'[src="'+cn(e)+'"]'}function gr(e){return"script[async]"+e}function C0(e,t,s){if(t.count++,t.instance===null)switch(t.type){case"style":var o=e.querySelector('style[data-href~="'+cn(s.href)+'"]');if(o)return t.instance=o,bt(o),o;var c=x({},s,{"data-href":s.href,"data-precedence":s.precedence,href:null,precedence:null});return o=(e.ownerDocument||e).createElement("style"),bt(o),Ct(o,"style",c),cl(o,s.precedence,e),t.instance=o;case"stylesheet":c=si(s.href);var f=e.querySelector(mr(c));if(f)return t.state.loading|=4,t.instance=f,bt(f),f;o=A0(s),(c=yn.get(c))&&Td(o,c),f=(e.ownerDocument||e).createElement("link"),bt(f);var v=f;return v._p=new Promise(function(R,N){v.onload=R,v.onerror=N}),Ct(f,"link",o),t.state.loading|=4,cl(f,s.precedence,e),t.instance=f;case"script":return f=ii(s.src),(c=e.querySelector(gr(f)))?(t.instance=c,bt(c),c):(o=s,(c=yn.get(f))&&(o=x({},s),Nd(o,c)),e=e.ownerDocument||e,c=e.createElement("script"),bt(c),Ct(c,"link",o),e.head.appendChild(c),t.instance=c);case"void":return null;default:throw Error(r(443,t.type))}else t.type==="stylesheet"&&(t.state.loading&4)===0&&(o=t.instance,t.state.loading|=4,cl(o,s.precedence,e));return t.instance}function cl(e,t,s){for(var o=s.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),c=o.length?o[o.length-1]:null,f=c,v=0;v<o.length;v++){var R=o[v];if(R.dataset.precedence===t)f=R;else if(f!==c)break}f?f.parentNode.insertBefore(e,f.nextSibling):(t=s.nodeType===9?s.head:s,t.insertBefore(e,t.firstChild))}function Td(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.title==null&&(e.title=t.title)}function Nd(e,t){e.crossOrigin==null&&(e.crossOrigin=t.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=t.referrerPolicy),e.integrity==null&&(e.integrity=t.integrity)}var ul=null;function k0(e,t,s){if(ul===null){var o=new Map,c=ul=new Map;c.set(s,o)}else c=ul,o=c.get(s),o||(o=new Map,c.set(s,o));if(o.has(e))return o;for(o.set(e,null),s=s.getElementsByTagName(e),c=0;c<s.length;c++){var f=s[c];if(!(f[Di]||f[Tt]||e==="link"&&f.getAttribute("rel")==="stylesheet")&&f.namespaceURI!=="http://www.w3.org/2000/svg"){var v=f.getAttribute(t)||"";v=e+v;var R=o.get(v);R?R.push(f):o.set(v,[f])}}return o}function D0(e,t,s){e=e.ownerDocument||e,e.head.insertBefore(s,t==="title"?e.querySelector("head > title"):null)}function g3(e,t,s){if(s===1||t.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof t.precedence!="string"||typeof t.href!="string"||t.href==="")break;return!0;case"link":if(typeof t.rel!="string"||typeof t.href!="string"||t.href===""||t.onLoad||t.onError)break;return t.rel==="stylesheet"?(e=t.disabled,typeof t.precedence=="string"&&e==null):!0;case"script":if(t.async&&typeof t.async!="function"&&typeof t.async!="symbol"&&!t.onLoad&&!t.onError&&t.src&&typeof t.src=="string")return!0}return!1}function z0(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function y3(e,t,s,o){if(s.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(s.state.loading&4)===0){if(s.instance===null){var c=si(o.href),f=t.querySelector(mr(c));if(f){t=f._p,t!==null&&typeof t=="object"&&typeof t.then=="function"&&(e.count++,e=dl.bind(e),t.then(e,e)),s.state.loading|=4,s.instance=f,bt(f);return}f=t.ownerDocument||t,o=A0(o),(c=yn.get(c))&&Td(o,c),f=f.createElement("link"),bt(f);var v=f;v._p=new Promise(function(R,N){v.onload=R,v.onerror=N}),Ct(f,"link",o),s.instance=f}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(s,t),(t=s.state.preload)&&(s.state.loading&3)===0&&(e.count++,s=dl.bind(e),t.addEventListener("load",s),t.addEventListener("error",s))}}var Ed=0;function x3(e,t){return e.stylesheets&&e.count===0&&hl(e,e.stylesheets),0<e.count||0<e.imgCount?function(s){var o=setTimeout(function(){if(e.stylesheets&&hl(e,e.stylesheets),e.unsuspend){var f=e.unsuspend;e.unsuspend=null,f()}},6e4+t);0<e.imgBytes&&Ed===0&&(Ed=62500*J5());var c=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&hl(e,e.stylesheets),e.unsuspend)){var f=e.unsuspend;e.unsuspend=null,f()}},(e.imgBytes>Ed?50:800)+t);return e.unsuspend=s,function(){e.unsuspend=null,clearTimeout(o),clearTimeout(c)}}:null}function dl(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)hl(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var fl=null;function hl(e,t){e.stylesheets=null,e.unsuspend!==null&&(e.count++,fl=new Map,t.forEach(v3,e),fl=null,dl.call(e))}function v3(e,t){if(!(t.state.loading&4)){var s=fl.get(e);if(s)var o=s.get(null);else{s=new Map,fl.set(e,s);for(var c=e.querySelectorAll("link[data-precedence],style[data-precedence]"),f=0;f<c.length;f++){var v=c[f];(v.nodeName==="LINK"||v.getAttribute("media")!=="not all")&&(s.set(v.dataset.precedence,v),o=v)}o&&s.set(null,o)}c=t.instance,v=c.getAttribute("data-precedence"),f=s.get(v)||o,f===o&&s.set(null,c),s.set(v,c),this.count++,o=dl.bind(this),c.addEventListener("load",o),c.addEventListener("error",o),f?f.parentNode.insertBefore(c,f.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(c,e.firstChild)),t.state.loading|=4}}var yr={$$typeof:z,Provider:null,Consumer:null,_currentValue:Y,_currentValue2:Y,_threadCount:0};function b3(e,t,s,o,c,f,v,R,N){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Sc(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Sc(0),this.hiddenUpdates=Sc(null),this.identifierPrefix=o,this.onUncaughtError=c,this.onCaughtError=f,this.onRecoverableError=v,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=N,this.incompleteTransitions=new Map}function V0(e,t,s,o,c,f,v,R,N,_,F,$){return e=new b3(e,t,s,v,N,_,F,$,R),t=1,f===!0&&(t|=24),f=Wt(3,null,null,t),e.current=f,f.stateNode=e,t=ou(),t.refCount++,e.pooledCache=t,t.refCount++,f.memoizedState={element:o,isDehydrated:s,cache:t},du(f),e}function O0(e){return e?(e=Ls,e):Ls}function L0(e,t,s,o,c,f){c=O0(c),o.context===null?o.context=c:o.pendingContext=c,o=ja(t),o.payload={element:s},f=f===void 0?null:f,f!==null&&(o.callback=f),s=Ma(e,o,t),s!==null&&(qt(s,e,t),Qi(s,e,t))}function G0(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var s=e.retryLane;e.retryLane=s!==0&&s<t?s:t}}function Ad(e,t){G0(e,t),(e=e.alternate)&&G0(e,t)}function _0(e){if(e.tag===13||e.tag===31){var t=Wa(e,67108864);t!==null&&qt(t,e,67108864),Ad(e,67108864)}}function B0(e){if(e.tag===13||e.tag===31){var t=sn();t=jc(t);var s=Wa(e,t);s!==null&&qt(s,e,t),Ad(e,t)}}var pl=!0;function R3(e,t,s,o){var c=U.T;U.T=null;var f=K.p;try{K.p=2,Cd(e,t,s,o)}finally{K.p=f,U.T=c}}function w3(e,t,s,o){var c=U.T;U.T=null;var f=K.p;try{K.p=8,Cd(e,t,s,o)}finally{K.p=f,U.T=c}}function Cd(e,t,s,o){if(pl){var c=kd(o);if(c===null)gd(e,t,o,ml,s),H0(e,o);else if(j3(c,e,t,s,o))o.stopPropagation();else if(H0(e,o),t&4&&-1<S3.indexOf(e)){for(;c!==null;){var f=Ms(c);if(f!==null)switch(f.tag){case 3:if(f=f.stateNode,f.current.memoizedState.isDehydrated){var v=$a(f.pendingLanes);if(v!==0){var R=f;for(R.pendingLanes|=2,R.entangledLanes|=2;v;){var N=1<<31-Kt(v);R.entanglements[1]|=N,v&=~N}_n(f),(De&6)===0&&(Ko=Qt()+500,dr(0))}}break;case 31:case 13:R=Wa(f,2),R!==null&&qt(R,f,2),Wo(),Ad(f,2)}if(f=kd(o),f===null&&gd(e,t,o,ml,s),f===c)break;c=f}c!==null&&o.stopPropagation()}else gd(e,t,o,null,s)}}function kd(e){return e=zc(e),Dd(e)}var ml=null;function Dd(e){if(ml=null,e=js(e),e!==null){var t=d(e);if(t===null)e=null;else{var s=t.tag;if(s===13){if(e=h(t),e!==null)return e;e=null}else if(s===31){if(e=y(t),e!==null)return e;e=null}else if(s===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null)}}return ml=e,null}function U0(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(l2()){case $h:return 2;case Qh:return 8;case ao:case c2:return 32;case Zh:return 268435456;default:return 32}default:return 32}}var zd=!1,La=null,Ga=null,_a=null,xr=new Map,vr=new Map,Ba=[],S3="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function H0(e,t){switch(e){case"focusin":case"focusout":La=null;break;case"dragenter":case"dragleave":Ga=null;break;case"mouseover":case"mouseout":_a=null;break;case"pointerover":case"pointerout":xr.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":vr.delete(t.pointerId)}}function br(e,t,s,o,c,f){return e===null||e.nativeEvent!==f?(e={blockedOn:t,domEventName:s,eventSystemFlags:o,nativeEvent:f,targetContainers:[c]},t!==null&&(t=Ms(t),t!==null&&_0(t)),e):(e.eventSystemFlags|=o,t=e.targetContainers,c!==null&&t.indexOf(c)===-1&&t.push(c),e)}function j3(e,t,s,o,c){switch(t){case"focusin":return La=br(La,e,t,s,o,c),!0;case"dragenter":return Ga=br(Ga,e,t,s,o,c),!0;case"mouseover":return _a=br(_a,e,t,s,o,c),!0;case"pointerover":var f=c.pointerId;return xr.set(f,br(xr.get(f)||null,e,t,s,o,c)),!0;case"gotpointercapture":return f=c.pointerId,vr.set(f,br(vr.get(f)||null,e,t,s,o,c)),!0}return!1}function F0(e){var t=js(e.target);if(t!==null){var s=d(t);if(s!==null){if(t=s.tag,t===13){if(t=h(s),t!==null){e.blockedOn=t,np(e.priority,function(){B0(s)});return}}else if(t===31){if(t=y(s),t!==null){e.blockedOn=t,np(e.priority,function(){B0(s)});return}}else if(t===3&&s.stateNode.current.memoizedState.isDehydrated){e.blockedOn=s.tag===3?s.stateNode.containerInfo:null;return}}}e.blockedOn=null}function gl(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var s=kd(e.nativeEvent);if(s===null){s=e.nativeEvent;var o=new s.constructor(s.type,s);Dc=o,s.target.dispatchEvent(o),Dc=null}else return t=Ms(s),t!==null&&_0(t),e.blockedOn=s,!1;t.shift()}return!0}function I0(e,t,s){gl(e)&&s.delete(t)}function M3(){zd=!1,La!==null&&gl(La)&&(La=null),Ga!==null&&gl(Ga)&&(Ga=null),_a!==null&&gl(_a)&&(_a=null),xr.forEach(I0),vr.forEach(I0)}function yl(e,t){e.blockedOn===t&&(e.blockedOn=null,zd||(zd=!0,n.unstable_scheduleCallback(n.unstable_NormalPriority,M3)))}var xl=null;function P0(e){xl!==e&&(xl=e,n.unstable_scheduleCallback(n.unstable_NormalPriority,function(){xl===e&&(xl=null);for(var t=0;t<e.length;t+=3){var s=e[t],o=e[t+1],c=e[t+2];if(typeof o!="function"){if(Dd(o||s)===null)continue;break}var f=Ms(s);f!==null&&(e.splice(t,3),t-=3,ku(f,{pending:!0,data:c,method:s.method,action:o},o,c))}}))}function ri(e){function t(N){return yl(N,e)}La!==null&&yl(La,e),Ga!==null&&yl(Ga,e),_a!==null&&yl(_a,e),xr.forEach(t),vr.forEach(t);for(var s=0;s<Ba.length;s++){var o=Ba[s];o.blockedOn===e&&(o.blockedOn=null)}for(;0<Ba.length&&(s=Ba[0],s.blockedOn===null);)F0(s),s.blockedOn===null&&Ba.shift();if(s=(e.ownerDocument||e).$$reactFormReplay,s!=null)for(o=0;o<s.length;o+=3){var c=s[o],f=s[o+1],v=c[Ut]||null;if(typeof f=="function")v||P0(s);else if(v){var R=null;if(f&&f.hasAttribute("formAction")){if(c=f,v=f[Ut]||null)R=v.formAction;else if(Dd(c)!==null)continue}else R=v.action;typeof R=="function"?s[o+1]=R:(s.splice(o,3),o-=3),P0(s)}}}function Y0(){function e(f){f.canIntercept&&f.info==="react-transition"&&f.intercept({handler:function(){return new Promise(function(v){return c=v})},focusReset:"manual",scroll:"manual"})}function t(){c!==null&&(c(),c=null),o||setTimeout(s,20)}function s(){if(!o&&!navigation.transition){var f=navigation.currentEntry;f&&f.url!=null&&navigation.navigate(f.url,{state:f.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var o=!1,c=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",t),navigation.addEventListener("navigateerror",t),setTimeout(s,100),function(){o=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",t),navigation.removeEventListener("navigateerror",t),c!==null&&(c(),c=null)}}}function Vd(e){this._internalRoot=e}vl.prototype.render=Vd.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(r(409));var s=t.current,o=sn();L0(s,o,e,t,null,null)},vl.prototype.unmount=Vd.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;L0(e.current,2,null,e,null,null),Wo(),t[Ss]=null}};function vl(e){this._internalRoot=e}vl.prototype.unstable_scheduleHydration=function(e){if(e){var t=tp();e={blockedOn:null,target:e,priority:t};for(var s=0;s<Ba.length&&t!==0&&t<Ba[s].priority;s++);Ba.splice(s,0,e),s===0&&F0(e)}};var q0=a.version;if(q0!=="19.2.3")throw Error(r(527,q0,"19.2.3"));K.findDOMNode=function(e){var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(r(188)):(e=Object.keys(e).join(","),Error(r(268,e)));return e=m(t),e=e!==null?g(e):null,e=e===null?null:e.stateNode,e};var T3={bundleType:0,version:"19.2.3",rendererPackageName:"react-dom",currentDispatcherRef:U,reconcilerVersion:"19.2.3"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var bl=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!bl.isDisabled&&bl.supportsFiber)try{Ai=bl.inject(T3),Zt=bl}catch{}}return wr.createRoot=function(e,t){if(!l(e))throw Error(r(299));var s=!1,o="",c=Wm,f=eg,v=tg;return t!=null&&(t.unstable_strictMode===!0&&(s=!0),t.identifierPrefix!==void 0&&(o=t.identifierPrefix),t.onUncaughtError!==void 0&&(c=t.onUncaughtError),t.onCaughtError!==void 0&&(f=t.onCaughtError),t.onRecoverableError!==void 0&&(v=t.onRecoverableError)),t=V0(e,1,!1,null,null,s,o,null,c,f,v,Y0),e[Ss]=t.current,md(e),new Vd(t)},wr.hydrateRoot=function(e,t,s){if(!l(e))throw Error(r(299));var o=!1,c="",f=Wm,v=eg,R=tg,N=null;return s!=null&&(s.unstable_strictMode===!0&&(o=!0),s.identifierPrefix!==void 0&&(c=s.identifierPrefix),s.onUncaughtError!==void 0&&(f=s.onUncaughtError),s.onCaughtError!==void 0&&(v=s.onCaughtError),s.onRecoverableError!==void 0&&(R=s.onRecoverableError),s.formState!==void 0&&(N=s.formState)),t=V0(e,1,!0,t,s??null,o,c,N,f,v,R,Y0),t.context=O0(null),s=t.current,o=sn(),o=jc(o),c=ja(o),c.callback=null,Ma(s,c,o),s=o,t.current.lanes=s,ki(t,s),_n(t),e[Ss]=t.current,md(e),new vl(t)},wr.version="19.2.3",wr}var ny;function B3(){if(ny)return Gd.exports;ny=1;function n(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)}catch(a){console.error(a)}}return n(),Gd.exports=_3(),Gd.exports}var U3=B3();var Zf=/^(?:[a-z][a-z0-9+.-]*:|[\\/]{2})/i,o1=/^[\\/]{2}/;function H3(n,a){return a+n.replace(/\\/g,"/")}var ay="popstate";function sy(n){return typeof n=="object"&&n!=null&&"pathname"in n&&"search"in n&&"hash"in n&&"state"in n&&"key"in n}function F3(n={}){function a(l,d){let{pathname:h="/",search:y="",hash:p=""}=ws(l.location.hash.substring(1));return!h.startsWith("/")&&!h.startsWith(".")&&(h="/"+h),gf("",{pathname:h,search:y,hash:p},d.state&&d.state.usr||null,d.state&&d.state.key||"default")}function i(l,d){let h=l.document.querySelector("base"),y="";if(h&&h.getAttribute("href")){let p=l.location.href,m=p.indexOf("#");y=m===-1?p:p.slice(0,m)}return y+"#"+(typeof d=="string"?d:Or(d))}function r(l,d){vn(l.pathname.charAt(0)==="/",`relative pathnames are not supported in hash history.push(${JSON.stringify(d)})`)}return P3(a,i,r,n)}function Ke(n,a){if(n===!1||n===null||typeof n>"u")throw new Error(a)}function vn(n,a){if(!n){typeof console<"u"&&console.warn(a);try{throw new Error(a)}catch{}}}function I3(){return Math.random().toString(36).substring(2,10)}function iy(n,a){return{usr:n.state,key:n.key,idx:a,masked:n.mask?{pathname:n.pathname,search:n.search,hash:n.hash}:void 0}}function gf(n,a,i=null,r,l){return{pathname:typeof n=="string"?n:n.pathname,search:"",hash:"",...typeof a=="string"?ws(a):a,state:i,key:a&&a.key||r||I3(),mask:l}}function Or({pathname:n="/",search:a="",hash:i=""}){return a&&a!=="?"&&(n+=a.charAt(0)==="?"?a:"?"+a),i&&i!=="#"&&(n+=i.charAt(0)==="#"?i:"#"+i),n}function ws(n){let a={};if(n){let i=n.indexOf("#");i>=0&&(a.hash=n.substring(i),n=n.substring(0,i));let r=n.indexOf("?");r>=0&&(a.search=n.substring(r),n=n.substring(0,r)),n&&(a.pathname=n)}return a}function P3(n,a,i,r={}){let{window:l=document.defaultView,v5Compat:d=!1}=r,h=l.history,y="POP",p=null,m=g();m==null&&(m=0,h.replaceState({...h.state,idx:m},""));function g(){return(h.state||{idx:null}).idx}function x(){y="POP";let j=g(),O=j==null?null:j-m;m=j,p&&p({action:y,location:T.location,delta:O})}function b(j,O){y="PUSH";let L=sy(j)?j:gf(T.location,j,O);i&&i(L,j),m=g()+1;let z=iy(L,m),D=T.createHref(L.mask||L);try{h.pushState(z,"",D)}catch(X){if(X instanceof DOMException&&X.name==="DataCloneError")throw X;l.location.assign(D)}d&&p&&p({action:y,location:T.location,delta:1})}function M(j,O){y="REPLACE";let L=sy(j)?j:gf(T.location,j,O);i&&i(L,j),m=g();let z=iy(L,m),D=T.createHref(L.mask||L);h.replaceState(z,"",D),d&&p&&p({action:y,location:T.location,delta:0})}function S(j){return Y3(l,j)}let T={get action(){return y},get location(){return n(l,h)},listen(j){if(p)throw new Error("A history only accepts one active listener");return l.addEventListener(ay,x),p=j,()=>{l.removeEventListener(ay,x),p=null}},createHref(j){return a(l,j)},createURL:S,encodeLocation(j){let O=S(j);return{pathname:O.pathname,search:O.search,hash:O.hash}},push:b,replace:M,go(j){return h.go(j)}};return T}function Y3(n,a,i=!1){let r="http://localhost";n&&(r=n.location.origin!=="null"?n.location.origin:n.location.href),Ke(r,"No window.location.(origin|href) available to create URL");let l=typeof a=="string"?a:Or(a);return l=l.replace(/ $/,"%20"),!i&&o1.test(l)&&(l=r+l),new URL(l,r)}function l1(n,a,i="/"){return q3(n,a,i,!1)}function q3(n,a,i,r,l){let d=typeof a=="string"?ws(a):a,h=fa(d.pathname||"/",i);if(h==null)return null;let y=X3(n),p=null,m=sR(h);for(let g=0;p==null&&g<y.length;++g)p=aR(y[g],m,r);return p}function X3(n){let a=c1(n);return $3(a),a}function c1(n,a=[],i=[],r="",l=!1){let d=(h,y,p=l,m)=>{let g={relativePath:m===void 0?h.path||"":m,caseSensitive:h.caseSensitive===!0,childrenIndex:y,route:h};if(g.relativePath.startsWith("/")){if(!g.relativePath.startsWith(r)&&p)return;Ke(g.relativePath.startsWith(r),`Absolute route path "${g.relativePath}" nested under path "${r}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`),g.relativePath=g.relativePath.slice(r.length)}let x=Cn([r,g.relativePath]),b=i.concat(g);h.children&&h.children.length>0&&(Ke(h.index!==!0,`Index routes must not have child routes. Please remove all child routes from route path "${x}".`),c1(h.children,a,b,x,p)),!(h.path==null&&!h.index)&&a.push({path:x,score:tR(x,h.index),routesMeta:b.map((M,S)=>{let[T,j]=f1(M.relativePath,M.caseSensitive,S===b.length-1);return{...M,matcher:T,compiledParams:j}})})};return n.forEach((h,y)=>{if(h.path===""||!h.path?.includes("?"))d(h,y);else for(let p of u1(h.path))d(h,y,!0,p)}),a}function u1(n){let a=n.split("/");if(a.length===0)return[];let[i,...r]=a,l=i.endsWith("?"),d=i.replace(/\?$/,"");if(r.length===0)return l?[d,""]:[d];let h=u1(r.join("/")),y=[];return y.push(...h.map(p=>p===""?d:[d,p].join("/"))),l&&y.push(...h),y.map(p=>n.startsWith("/")&&p===""?"/":p)}function $3(n){n.sort((a,i)=>a.score!==i.score?i.score-a.score:nR(a.routesMeta.map(r=>r.childrenIndex),i.routesMeta.map(r=>r.childrenIndex)))}var Q3=/^:[\w-]+$/,Z3=3,K3=2,J3=1,W3=10,eR=-2,ry=n=>n==="*";function tR(n,a){let i=n.split("/"),r=i.length;return i.some(ry)&&(r+=eR),a&&(r+=K3),i.filter(l=>!ry(l)).reduce((l,d)=>l+(Q3.test(d)?Z3:d===""?J3:W3),r)}function nR(n,a){return n.length===a.length&&n.slice(0,-1).every((r,l)=>r===a[l])?n[n.length-1]-a[a.length-1]:0}function aR(n,a,i=!1){let{routesMeta:r}=n,l={},d="/",h=[];for(let y=0;y<r.length;++y){let p=r[y],m=y===r.length-1,g=d==="/"?a:a.slice(d.length)||"/",x={path:p.relativePath,caseSensitive:p.caseSensitive,end:m},b=p.matcher&&p.compiledParams?d1(x,g,p.matcher,p.compiledParams):Yl(x,g),M=p.route;if(!b&&m&&i&&!r[r.length-1].route.index&&(b=Yl({path:p.relativePath,caseSensitive:p.caseSensitive,end:!1},g)),!b)return null;Object.assign(l,b.params),h.push({params:l,pathname:Cn([d,b.pathname]),pathnameBase:oR(Cn([d,b.pathnameBase])),route:M}),b.pathnameBase!=="/"&&(d=Cn([d,b.pathnameBase]))}return h}function Yl(n,a){typeof n=="string"&&(n={path:n,caseSensitive:!1,end:!0});let[i,r]=f1(n.path,n.caseSensitive,n.end);return d1(n,a,i,r)}function d1(n,a,i,r){let l=a.match(i);if(!l)return null;let d=l[0],h=d.replace(/(.)\/+$/,"$1"),y=l.slice(1);return{params:r.reduce((m,{paramName:g,isOptional:x},b)=>{if(g==="*"){let S=y[b]||"";h=d.slice(0,d.length-S.length).replace(/(.)\/+$/,"$1")}const M=y[b];return x&&!M?m[g]=void 0:m[g]=(M||"").replace(/%2F/g,"/"),m},{}),pathname:d,pathnameBase:h,pattern:n}}function f1(n,a=!1,i=!0){vn(n==="*"||!n.endsWith("*")||n.endsWith("/*"),`Route path "${n}" will be treated as if it were "${n.replace(/\*$/,"/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${n.replace(/\*$/,"/*")}".`);let r=[],l="^"+n.replace(/\/*\*?$/,"").replace(/^\/*/,"/").replace(/[\\.*+^${}|()[\]]/g,"\\$&").replace(/\/:([\w-]+)(\?)?/g,(h,y,p,m,g)=>{if(r.push({paramName:y,isOptional:p!=null}),p){let x=g.charAt(m+h.length);return x&&x!=="/"?"/([^\\/]*)":"(?:/([^\\/]*))?"}return"/([^\\/]+)"}).replace(/\/([\w-]+)\?(\/|$)/g,"(/$1)?$2");return n.endsWith("*")?(r.push({paramName:"*"}),l+=n==="*"||n==="/*"?"(.*)$":"(?:\\/(.+)|\\/*)$"):i?l+="\\/*$":n!==""&&n!=="/"&&(l+="(?:(?=\\/|$))"),[new RegExp(l,a?void 0:"i"),r]}function sR(n){try{return n.split("/").map(a=>decodeURIComponent(a).replace(/\//g,"%2F")).join("/")}catch(a){return vn(!1,`The URL path "${n}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${a}).`),n}}function fa(n,a){if(a==="/")return n;if(!n.toLowerCase().startsWith(a.toLowerCase()))return null;let i=a.endsWith("/")?a.length-1:a.length,r=n.charAt(i);return r&&r!=="/"?null:n.slice(i)||"/"}function iR(n,a="/"){let{pathname:i,search:r="",hash:l=""}=typeof n=="string"?ws(n):n,d;return i?(i=p1(i),i.startsWith("/")?d=oy(i.substring(1),"/"):d=oy(i,a)):d=a,{pathname:d,search:lR(r),hash:cR(l)}}function oy(n,a){let i=ql(a).split("/");return n.split("/").forEach(l=>{l===".."?i.length>1&&i.pop():l!=="."&&i.push(l)}),i.length>1?i.join("/"):"/"}function Hd(n,a,i,r){return`Cannot include a '${n}' character in a manually specified \`to.${a}\` field [${JSON.stringify(r)}].  Please separate it out to the \`to.${i}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`}function rR(n){return n.filter((a,i)=>i===0||a.route.path&&a.route.path.length>0)}function h1(n){let a=rR(n);return a.map((i,r)=>r===a.length-1?i.pathname:i.pathnameBase)}function Kf(n,a,i,r=!1){let l;typeof n=="string"?l=ws(n):(l={...n},Ke(!l.pathname||!l.pathname.includes("?"),Hd("?","pathname","search",l)),Ke(!l.pathname||!l.pathname.includes("#"),Hd("#","pathname","hash",l)),Ke(!l.search||!l.search.includes("#"),Hd("#","search","hash",l)));let d=n===""||l.pathname==="",h=d?"/":l.pathname,y;if(h==null)y=i;else{let x=a.length-1;if(!r&&h.startsWith("..")){let b=h.split("/");for(;b[0]==="..";)b.shift(),x-=1;l.pathname=b.join("/")}y=x>=0?a[x]:"/"}let p=iR(l,y),m=h&&h!=="/"&&h.endsWith("/"),g=(d||h===".")&&i.endsWith("/");return!p.pathname.endsWith("/")&&(m||g)&&(p.pathname+="/"),p}var p1=n=>n.replace(/[\\/]{2,}/g,"/"),Cn=n=>p1(n.join("/")),ql=n=>n.replace(/\/+$/,""),oR=n=>ql(n).replace(/^\/*/,"/"),lR=n=>!n||n==="?"?"":n.startsWith("?")?n:"?"+n,cR=n=>!n||n==="#"?"":n.startsWith("#")?n:"#"+n,uR=class{constructor(n,a,i,r=!1){this.status=n,this.statusText=a||"",this.internal=r,i instanceof Error?(this.data=i.toString(),this.error=i):this.data=i}};function dR(n){return n!=null&&typeof n.status=="number"&&typeof n.statusText=="string"&&typeof n.internal=="boolean"&&"data"in n}function fR(n){let a=n.map(i=>i.route.path).filter(Boolean);return Cn(a)||"/"}var m1=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";function g1(n,a){let i=n;if(typeof i!="string"||!Zf.test(i))return{absoluteURL:void 0,isExternal:!1,to:i};let r=i,l=!1;if(m1)try{let d=new URL(window.location.href),h=o1.test(i)?new URL(H3(i,d.protocol)):new URL(i),y=fa(h.pathname,a);h.origin===d.origin&&y!=null?i=y+h.search+h.hash:l=!0}catch{vn(!1,`<Link to="${i}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)}return{absoluteURL:r,isExternal:l,to:i}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");var y1=["POST","PUT","PATCH","DELETE"];new Set(y1);var hR=["GET",...y1];new Set(hR);var pR=["about:","blob:","chrome:","chrome-untrusted:","content:","data:","devtools:","file:","filesystem:","javascript:"];function mR(n){try{return pR.includes(new URL(n).protocol)}catch{return!1}}var Ri=w.createContext(null);Ri.displayName="DataRouter";var lc=w.createContext(null);lc.displayName="DataRouterState";var x1=w.createContext(!1);function gR(){return w.useContext(x1)}var v1=w.createContext({isTransitioning:!1});v1.displayName="ViewTransition";var yR=w.createContext(new Map);yR.displayName="Fetchers";var xR=w.createContext(null);xR.displayName="Await";var Rn=w.createContext(null);Rn.displayName="Navigation";var Fr=w.createContext(null);Fr.displayName="Location";var In=w.createContext({outlet:null,matches:[],isDataRoute:!1});In.displayName="Route";var Jf=w.createContext(null);Jf.displayName="RouteError";var b1="REACT_ROUTER_ERROR",vR="REDIRECT",bR="ROUTE_ERROR_RESPONSE";function RR(n){if(n.startsWith(`${b1}:${vR}:{`))try{let a=JSON.parse(n.slice(28));if(typeof a=="object"&&a&&typeof a.status=="number"&&typeof a.statusText=="string"&&typeof a.location=="string"&&typeof a.reloadDocument=="boolean"&&typeof a.replace=="boolean")return a}catch{}}function wR(n){if(n.startsWith(`${b1}:${bR}:{`))try{let a=JSON.parse(n.slice(40));if(typeof a=="object"&&a&&typeof a.status=="number"&&typeof a.statusText=="string")return new uR(a.status,a.statusText,a.data)}catch{}}function SR(n,{relative:a}={}){Ke(Ir(),"useHref() may be used only in the context of a <Router> component.");let{basename:i,navigator:r}=w.useContext(Rn),{hash:l,pathname:d,search:h}=Pr(n,{relative:a}),y=d;return i!=="/"&&(y=d==="/"?i:Cn([i,d])),r.createHref({pathname:y,search:h,hash:l})}function Ir(){return w.useContext(Fr)!=null}function Pn(){return Ke(Ir(),"useLocation() may be used only in the context of a <Router> component."),w.useContext(Fr).location}var R1="You should call navigate() in a React.useEffect(), not when your component is first rendered.";function w1(n){w.useContext(Rn).static||w.useLayoutEffect(n)}function wi(){let{isDataRoute:n}=w.useContext(In);return n?GR():jR()}function jR(){Ke(Ir(),"useNavigate() may be used only in the context of a <Router> component.");let n=w.useContext(Ri),{basename:a,navigator:i}=w.useContext(Rn),{matches:r}=w.useContext(In),{pathname:l}=Pn(),d=JSON.stringify(h1(r)),h=w.useRef(!1);return w1(()=>{h.current=!0}),w.useCallback((p,m={})=>{if(vn(h.current,R1),!h.current)return;if(typeof p=="number"){i.go(p);return}let g=Kf(p,JSON.parse(d),l,m.relative==="path");n==null&&a!=="/"&&(g.pathname=g.pathname==="/"?a:Cn([a,g.pathname])),(m.replace?i.replace:i.push)(g,m.state,m)},[a,i,d,l,n])}w.createContext(null);function MR(){let{matches:n}=w.useContext(In);return n[n.length-1]?.params??{}}function Pr(n,{relative:a}={}){let{matches:i}=w.useContext(In),{pathname:r}=Pn(),l=JSON.stringify(h1(i));return w.useMemo(()=>Kf(n,JSON.parse(l),r,a==="path"),[n,l,r,a])}function TR(n,a){return S1(n,a)}function S1(n,a,i){Ke(Ir(),"useRoutes() may be used only in the context of a <Router> component.");let{navigator:r}=w.useContext(Rn),{matches:l}=w.useContext(In),d=l[l.length-1],h=d?d.params:{},y=d?d.pathname:"/",p=d?d.pathnameBase:"/",m=d&&d.route;{let j=m&&m.path||"";M1(y,!m||j.endsWith("*")||j.endsWith("*?"),`You rendered descendant <Routes> (or called \`useRoutes()\`) at "${y}" (under <Route path="${j}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${j}"> to <Route path="${j==="/"?"*":`${j}/*`}">.`)}let g=Pn(),x;if(a){let j=typeof a=="string"?ws(a):a;Ke(p==="/"||j.pathname?.startsWith(p),`When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${p}" but pathname "${j.pathname}" was given in the \`location\` prop.`),x=j}else x=g;let b=x.pathname||"/",M=b;if(p!=="/"){let j=p.replace(/^\//,"").split("/");M="/"+b.replace(/^\//,"").split("/").slice(j.length).join("/")}let S=i&&i.state.matches.length?i.state.matches.map(j=>Object.assign(j,{route:i.manifest[j.route.id]||j.route})):l1(n,{pathname:M});vn(m||S!=null,`No routes matched location "${x.pathname}${x.search}${x.hash}" `),vn(S==null||S[S.length-1].route.element!==void 0||S[S.length-1].route.Component!==void 0||S[S.length-1].route.lazy!==void 0,`Matched leaf route at location "${x.pathname}${x.search}${x.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);let T=kR(S&&S.map(j=>Object.assign({},j,{params:Object.assign({},h,j.params),pathname:Cn([p,r.encodeLocation?r.encodeLocation(j.pathname.replace(/%/g,"%25").replace(/\?/g,"%3F").replace(/#/g,"%23")).pathname:j.pathname]),pathnameBase:j.pathnameBase==="/"?p:Cn([p,r.encodeLocation?r.encodeLocation(j.pathnameBase.replace(/%/g,"%25").replace(/\?/g,"%3F").replace(/#/g,"%23")).pathname:j.pathnameBase])})),l,i);return a&&T?w.createElement(Fr.Provider,{value:{location:{pathname:"/",search:"",hash:"",state:null,key:"default",mask:void 0,...x},navigationType:"POP"}},T):T}function NR(){let n=LR(),a=dR(n)?`${n.status} ${n.statusText}`:n instanceof Error?n.message:JSON.stringify(n),i=n instanceof Error?n.stack:null,r="rgba(200,200,200, 0.5)",l={padding:"0.5rem",backgroundColor:r},d={padding:"2px 4px",backgroundColor:r},h=null;return console.error("Error handled by React Router default ErrorBoundary:",n),h=w.createElement(w.Fragment,null,w.createElement("p",null,"💿 Hey developer 👋"),w.createElement("p",null,"You can provide a way better UX than this when your app throws errors by providing your own ",w.createElement("code",{style:d},"ErrorBoundary")," or"," ",w.createElement("code",{style:d},"errorElement")," prop on your route.")),w.createElement(w.Fragment,null,w.createElement("h2",null,"Unexpected Application Error!"),w.createElement("h3",{style:{fontStyle:"italic"}},a),i?w.createElement("pre",{style:l},i):null,h)}var ER=w.createElement(NR,null),j1=class extends w.Component{constructor(n){super(n),this.state={location:n.location,revalidation:n.revalidation,error:n.error}}static getDerivedStateFromError(n){return{error:n}}static getDerivedStateFromProps(n,a){return a.location!==n.location||a.revalidation!=="idle"&&n.revalidation==="idle"?{error:n.error,location:n.location,revalidation:n.revalidation}:{error:n.error!==void 0?n.error:a.error,location:a.location,revalidation:n.revalidation||a.revalidation}}componentDidCatch(n,a){this.props.onError?this.props.onError(n,a):console.error("React Router caught the following error during render",n)}render(){let n=this.state.error;if(this.context&&typeof n=="object"&&n&&"digest"in n&&typeof n.digest=="string"){const i=wR(n.digest);i&&(n=i)}let a=n!==void 0?w.createElement(In.Provider,{value:this.props.routeContext},w.createElement(Jf.Provider,{value:n,children:this.props.component})):this.props.children;return this.context?w.createElement(AR,{error:n},a):a}};j1.contextType=x1;var Fd=new WeakMap;function AR({children:n,error:a}){let{basename:i}=w.useContext(Rn);if(typeof a=="object"&&a&&"digest"in a&&typeof a.digest=="string"){let r=RR(a.digest);if(r){let l=Fd.get(a);if(l)throw l;let d=g1(r.location,i),h=d.absoluteURL||d.to;if(mR(h))throw new Error("Invalid redirect location");if(m1&&!Fd.get(a))if(d.isExternal||r.reloadDocument)window.location.href=h;else{const y=Promise.resolve().then(()=>window.__reactRouterDataRouter.navigate(d.to,{replace:r.replace}));throw Fd.set(a,y),y}return w.createElement("meta",{httpEquiv:"refresh",content:`0;url=${h}`})}}return n}function CR({routeContext:n,match:a,children:i}){let r=w.useContext(Ri);return r&&r.static&&r.staticContext&&(a.route.errorElement||a.route.ErrorBoundary)&&(r.staticContext._deepestRenderedBoundaryId=a.route.id),w.createElement(In.Provider,{value:n},i)}function kR(n,a=[],i){let r=i?.state;if(n==null){if(!r)return null;if(r.errors)n=r.matches;else if(a.length===0&&!r.initialized&&r.matches.length>0)n=r.matches;else return null}let l=n,d=r?.errors;if(d!=null){let g=l.findIndex(x=>x.route.id&&d?.[x.route.id]!==void 0);Ke(g>=0,`Could not find a matching route for errors on route IDs: ${Object.keys(d).join(",")}`),l=l.slice(0,Math.min(l.length,g+1))}let h=!1,y=-1;if(i&&r){h=r.renderFallback;for(let g=0;g<l.length;g++){let x=l[g];if((x.route.HydrateFallback||x.route.hydrateFallbackElement)&&(y=g),x.route.id){let{loaderData:b,errors:M}=r,S=x.route.loader&&!b.hasOwnProperty(x.route.id)&&(!M||M[x.route.id]===void 0);if(x.route.lazy||S){i.isStatic&&(h=!0),y>=0?l=l.slice(0,y+1):l=[l[0]];break}}}}let p=i?.onError,m=r&&p?(g,x)=>{p(g,{location:r.location,params:r.matches?.[0]?.params??{},pattern:fR(r.matches),errorInfo:x})}:void 0;return l.reduceRight((g,x,b)=>{let M,S=!1,T=null,j=null;r&&(M=d&&x.route.id?d[x.route.id]:void 0,T=x.route.errorElement||ER,h&&(y<0&&b===0?(M1("route-fallback",!1,"No `HydrateFallback` element provided to render during initial hydration"),S=!0,j=null):y===b&&(S=!0,j=x.route.hydrateFallbackElement||null)));let O=a.concat(l.slice(0,b+1)),L=()=>{let z;return M?z=T:S?z=j:x.route.Component?z=w.createElement(x.route.Component,null):x.route.element?z=x.route.element:z=g,w.createElement(CR,{match:x,routeContext:{outlet:g,matches:O,isDataRoute:r!=null},children:z})};return r&&(x.route.ErrorBoundary||x.route.errorElement||b===0)?w.createElement(j1,{location:r.location,revalidation:r.revalidation,component:T,error:M,children:L(),routeContext:{outlet:null,matches:O,isDataRoute:!0},onError:m}):L()},null)}function Wf(n){return`${n} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function DR(n){let a=w.useContext(Ri);return Ke(a,Wf(n)),a}function zR(n){let a=w.useContext(lc);return Ke(a,Wf(n)),a}function VR(n){let a=w.useContext(In);return Ke(a,Wf(n)),a}function eh(n){let a=VR(n),i=a.matches[a.matches.length-1];return Ke(i.route.id,`${n} can only be used on routes that contain a unique "id"`),i.route.id}function OR(){return eh("useRouteId")}function LR(){let n=w.useContext(Jf),a=zR("useRouteError"),i=eh("useRouteError");return n!==void 0?n:a.errors?.[i]}function GR(){let{router:n}=DR("useNavigate"),a=eh("useNavigate"),i=w.useRef(!1);return w1(()=>{i.current=!0}),w.useCallback(async(l,d={})=>{vn(i.current,R1),i.current&&(typeof l=="number"?await n.navigate(l):await n.navigate(l,{fromRouteId:a,...d}))},[n,a])}var ly={};function M1(n,a,i){!a&&!ly[n]&&(ly[n]=!0,vn(!1,i))}w.memo(_R);function _R({routes:n,manifest:a,future:i,state:r,isStatic:l,onError:d}){return S1(n,void 0,{manifest:a,state:r,isStatic:l,onError:d})}function rn(n){Ke(!1,"A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.")}function BR({basename:n="/",children:a=null,location:i,navigationType:r="POP",navigator:l,static:d=!1,useTransitions:h}){Ke(!Ir(),"You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");let y=n.replace(/^\/*/,"/"),p=w.useMemo(()=>({basename:y,navigator:l,static:d,useTransitions:h,future:{}}),[y,l,d,h]);typeof i=="string"&&(i=ws(i));let{pathname:m="/",search:g="",hash:x="",state:b=null,key:M="default",mask:S}=i,T=w.useMemo(()=>{let j=fa(m,y);return j==null?null:{location:{pathname:j,search:g,hash:x,state:b,key:M,mask:S},navigationType:r}},[y,m,g,x,b,M,r,S]);return vn(T!=null,`<Router basename="${y}"> is not able to match the URL "${m}${g}${x}" because it does not start with the basename, so the <Router> won't render anything.`),T==null?null:w.createElement(Rn.Provider,{value:p},w.createElement(Fr.Provider,{children:a,value:T}))}function UR({children:n,location:a}){return TR(yf(n),a)}function yf(n,a=[]){let i=[];return w.Children.forEach(n,(r,l)=>{if(!w.isValidElement(r))return;let d=[...a,l];if(r.type===w.Fragment){i.push.apply(i,yf(r.props.children,d));return}Ke(r.type===rn,`[${typeof r.type=="string"?r.type:r.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`),Ke(!r.props.index||!r.props.children,"An index route cannot have child routes.");let h={id:r.props.id||d.join("-"),caseSensitive:r.props.caseSensitive,element:r.props.element,Component:r.props.Component,index:r.props.index,path:r.props.path,middleware:r.props.middleware,loader:r.props.loader,action:r.props.action,hydrateFallbackElement:r.props.hydrateFallbackElement,HydrateFallback:r.props.HydrateFallback,errorElement:r.props.errorElement,ErrorBoundary:r.props.ErrorBoundary,hasErrorBoundary:r.props.hasErrorBoundary===!0||r.props.ErrorBoundary!=null||r.props.errorElement!=null,shouldRevalidate:r.props.shouldRevalidate,handle:r.props.handle,lazy:r.props.lazy};r.props.children&&(h.children=yf(r.props.children,d)),i.push(h)}),i}var Vl="get",Ol="application/x-www-form-urlencoded";function cc(n){return typeof HTMLElement<"u"&&n instanceof HTMLElement}function HR(n){return cc(n)&&n.tagName.toLowerCase()==="button"}function FR(n){return cc(n)&&n.tagName.toLowerCase()==="form"}function IR(n){return cc(n)&&n.tagName.toLowerCase()==="input"}function PR(n){return!!(n.metaKey||n.altKey||n.ctrlKey||n.shiftKey)}function YR(n,a){return n.button===0&&(!a||a==="_self")&&!PR(n)}function xf(n=""){return new URLSearchParams(typeof n=="string"||Array.isArray(n)||n instanceof URLSearchParams?n:Object.keys(n).reduce((a,i)=>{let r=n[i];return a.concat(Array.isArray(r)?r.map(l=>[i,l]):[[i,r]])},[]))}function qR(n,a){let i=xf(n);return a&&a.forEach((r,l)=>{i.has(l)||a.getAll(l).forEach(d=>{i.append(l,d)})}),i}var Rl=null;function XR(){if(Rl===null)try{new FormData(document.createElement("form"),0),Rl=!1}catch{Rl=!0}return Rl}var $R=new Set(["application/x-www-form-urlencoded","multipart/form-data","text/plain"]);function Id(n){return n!=null&&!$R.has(n)?(vn(!1,`"${n}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${Ol}"`),null):n}function QR(n,a){let i,r,l,d,h;if(FR(n)){let y=n.getAttribute("action");r=y?fa(y,a):null,i=n.getAttribute("method")||Vl,l=Id(n.getAttribute("enctype"))||Ol,d=new FormData(n)}else if(HR(n)||IR(n)&&(n.type==="submit"||n.type==="image")){let y=n.form;if(y==null)throw new Error('Cannot submit a <button> or <input type="submit"> without a <form>');let p=n.getAttribute("formaction")||y.getAttribute("action");if(r=p?fa(p,a):null,i=n.getAttribute("formmethod")||y.getAttribute("method")||Vl,l=Id(n.getAttribute("formenctype"))||Id(y.getAttribute("enctype"))||Ol,d=new FormData(y,n),!XR()){let{name:m,type:g,value:x}=n;if(g==="image"){let b=m?`${m}.`:"";d.append(`${b}x`,"0"),d.append(`${b}y`,"0")}else m&&d.append(m,x)}}else{if(cc(n))throw new Error('Cannot submit element that is not <form>, <button>, or <input type="submit|image">');i=Vl,r=null,l=Ol,h=n}return d&&l==="text/plain"&&(h=d,d=void 0),{action:r,method:i.toLowerCase(),encType:l,formData:d,body:h}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");function th(n,a){if(n===!1||n===null||typeof n>"u")throw new Error(a)}function T1(n,a,i,r){let l=typeof n=="string"?new URL(n,typeof window>"u"?"server://singlefetch/":window.location.origin):n;return i?l.pathname.endsWith("/")?l.pathname=`${l.pathname}_.${r}`:l.pathname=`${l.pathname}.${r}`:l.pathname==="/"?l.pathname=`_root.${r}`:a&&fa(l.pathname,a)==="/"?l.pathname=`${ql(a)}/_root.${r}`:l.pathname=`${ql(l.pathname)}.${r}`,l}async function ZR(n,a){if(n.id in a)return a[n.id];try{let i=await import(n.module);return a[n.id]=i,i}catch(i){return console.error(`Error loading route module \`${n.module}\`, reloading page...`),console.error(i),window.__reactRouterContext&&window.__reactRouterContext.isSpaMode,window.location.reload(),new Promise(()=>{})}}function KR(n){return n==null?!1:n.href==null?n.rel==="preload"&&typeof n.imageSrcSet=="string"&&typeof n.imageSizes=="string":typeof n.rel=="string"&&typeof n.href=="string"}async function JR(n,a,i){let r=await Promise.all(n.map(async l=>{let d=a.routes[l.route.id];if(d){let h=await ZR(d,i);return h.links?h.links():[]}return[]}));return nw(r.flat(1).filter(KR).filter(l=>l.rel==="stylesheet"||l.rel==="preload").map(l=>l.rel==="stylesheet"?{...l,rel:"prefetch",as:"style"}:{...l,rel:"prefetch"}))}function cy(n,a,i,r,l,d){let h=(p,m)=>i[m]?p.route.id!==i[m].route.id:!0,y=(p,m)=>i[m].pathname!==p.pathname||i[m].route.path?.endsWith("*")&&i[m].params["*"]!==p.params["*"];return d==="assets"?a.filter((p,m)=>h(p,m)||y(p,m)):d==="data"?a.filter((p,m)=>{let g=r.routes[p.route.id];if(!g||!g.hasLoader)return!1;if(h(p,m)||y(p,m))return!0;if(p.route.shouldRevalidate){let x=p.route.shouldRevalidate({currentUrl:new URL(l.pathname+l.search+l.hash,window.origin),currentParams:i[0]?.params||{},nextUrl:new URL(n,window.origin),nextParams:p.params,defaultShouldRevalidate:!0});if(typeof x=="boolean")return x}return!0}):[]}function WR(n,a,{includeHydrateFallback:i}={}){return ew(n.map(r=>{let l=a.routes[r.route.id];if(!l)return[];let d=[l.module];return l.clientActionModule&&(d=d.concat(l.clientActionModule)),l.clientLoaderModule&&(d=d.concat(l.clientLoaderModule)),i&&l.hydrateFallbackModule&&(d=d.concat(l.hydrateFallbackModule)),l.imports&&(d=d.concat(l.imports)),d}).flat(1))}function ew(n){return[...new Set(n)]}function tw(n){let a={},i=Object.keys(n).sort();for(let r of i)a[r]=n[r];return a}function nw(n,a){let i=new Set;return new Set(a),n.reduce((r,l)=>{let d=JSON.stringify(tw(l));return i.has(d)||(i.add(d),r.push({key:d,link:l})),r},[])}function nh(){let n=w.useContext(Ri);return th(n,"You must render this element inside a <DataRouterContext.Provider> element"),n}function aw(){let n=w.useContext(lc);return th(n,"You must render this element inside a <DataRouterStateContext.Provider> element"),n}var ah=w.createContext(void 0);ah.displayName="FrameworkContext";function uc(){let n=w.useContext(ah);return th(n,"You must render this element inside a <HydratedRouter> element"),n}function sw(n,a){let i=w.useContext(ah),[r,l]=w.useState(!1),[d,h]=w.useState(!1),{onFocus:y,onBlur:p,onMouseEnter:m,onMouseLeave:g,onTouchStart:x}=a,b=w.useRef(null);w.useEffect(()=>{if(n==="render"&&h(!0),n==="viewport"){let T=O=>{O.forEach(L=>{h(L.isIntersecting)})},j=new IntersectionObserver(T,{threshold:.5});return b.current&&j.observe(b.current),()=>{j.disconnect()}}},[n]),w.useEffect(()=>{if(r){let T=setTimeout(()=>{h(!0)},100);return()=>{clearTimeout(T)}}},[r]);let M=()=>{l(!0)},S=()=>{l(!1),h(!1)};return i?n!=="intent"?[d,b,{}]:[d,b,{onFocus:Sr(y,M),onBlur:Sr(p,S),onMouseEnter:Sr(m,M),onMouseLeave:Sr(g,S),onTouchStart:Sr(x,M)}]:[!1,b,{}]}function Sr(n,a){return i=>{n&&n(i),i.defaultPrevented||a(i)}}function iw({page:n,...a}){let i=gR(),{nonce:r}=uc(),{router:l}=nh(),d=w.useMemo(()=>l1(l.routes,n,l.basename),[l.routes,n,l.basename]);return d?(a.nonce==null&&r&&(a={...a,nonce:r}),i?w.createElement(ow,{page:n,matches:d,...a}):w.createElement(lw,{page:n,matches:d,...a})):null}function rw(n){let{manifest:a,routeModules:i}=uc(),[r,l]=w.useState([]);return w.useEffect(()=>{let d=!1;return JR(n,a,i).then(h=>{d||l(h)}),()=>{d=!0}},[n,a,i]),r}function ow({page:n,matches:a,...i}){let r=Pn(),{future:l}=uc(),{basename:d}=nh(),h=w.useMemo(()=>{if(n===r.pathname+r.search+r.hash)return[];let y=T1(n,d,l.v8_trailingSlashAwareDataRequests,"rsc"),p=!1,m=[];for(let g of a)typeof g.route.shouldRevalidate=="function"?p=!0:m.push(g.route.id);return p&&m.length>0&&y.searchParams.set("_routes",m.join(",")),[y.pathname+y.search]},[d,l.v8_trailingSlashAwareDataRequests,n,r,a]);return w.createElement(w.Fragment,null,h.map(y=>w.createElement("link",{key:y,rel:"prefetch",as:"fetch",href:y,...i})))}function lw({page:n,matches:a,...i}){let r=Pn(),{future:l,manifest:d,routeModules:h}=uc(),{basename:y}=nh(),{loaderData:p,matches:m}=aw(),g=w.useMemo(()=>cy(n,a,m,d,r,"data"),[n,a,m,d,r]),x=w.useMemo(()=>cy(n,a,m,d,r,"assets"),[n,a,m,d,r]),b=w.useMemo(()=>{if(n===r.pathname+r.search+r.hash)return[];let T=new Set,j=!1;if(a.forEach(L=>{let z=d.routes[L.route.id];!z||!z.hasLoader||(!g.some(D=>D.route.id===L.route.id)&&L.route.id in p&&h[L.route.id]?.shouldRevalidate||z.hasClientLoader?j=!0:T.add(L.route.id))}),T.size===0)return[];let O=T1(n,y,l.v8_trailingSlashAwareDataRequests,"data");return j&&T.size>0&&O.searchParams.set("_routes",a.filter(L=>T.has(L.route.id)).map(L=>L.route.id).join(",")),[O.pathname+O.search]},[y,l.v8_trailingSlashAwareDataRequests,p,r,d,g,a,n,h]),M=w.useMemo(()=>WR(x,d),[x,d]),S=rw(x);return w.createElement(w.Fragment,null,b.map(T=>w.createElement("link",{key:T,rel:"prefetch",as:"fetch",href:T,...i})),M.map(T=>w.createElement("link",{key:T,rel:"modulepreload",href:T,...i})),S.map(({key:T,link:j})=>w.createElement("link",{key:T,nonce:i.nonce,...j,crossOrigin:j.crossOrigin??i.crossOrigin})))}function cw(...n){return a=>{n.forEach(i=>{typeof i=="function"?i(a):i!=null&&(i.current=a)})}}var uw=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";try{uw&&(window.__reactRouterVersion="7.18.1")}catch{}function dw({basename:n,children:a,useTransitions:i,window:r}){let l=w.useRef();l.current==null&&(l.current=F3({window:r,v5Compat:!0}));let d=l.current,[h,y]=w.useState({action:d.action,location:d.location}),p=w.useCallback(m=>{i===!1?y(m):w.startTransition(()=>y(m))},[i]);return w.useLayoutEffect(()=>d.listen(p),[d,p]),w.createElement(BR,{basename:n,children:a,location:h.location,navigationType:h.action,navigator:d,useTransitions:i})}var Vt=w.forwardRef(function({onClick:a,discover:i="render",prefetch:r="none",relative:l,reloadDocument:d,replace:h,mask:y,state:p,target:m,to:g,preventScrollReset:x,viewTransition:b,defaultShouldRevalidate:M,...S},T){let{basename:j,navigator:O,useTransitions:L}=w.useContext(Rn),z=typeof g=="string"&&Zf.test(g),D=g1(g,j);g=D.to;let X=SR(g,{relative:l}),J=Pn(),Q=null;if(y){let de=Kf(y,[],J.mask?J.mask.pathname:"/",!0);j!=="/"&&(de.pathname=de.pathname==="/"?j:Cn([j,de.pathname])),Q=O.createHref(de)}let[E,q,ee]=sw(r,S),oe=mw(g,{replace:h,mask:y,state:p,target:m,preventScrollReset:x,relative:l,viewTransition:b,defaultShouldRevalidate:M,useTransitions:L});function me(de){a&&a(de),de.defaultPrevented||oe(de)}let He=!(D.isExternal||d),Te=w.createElement("a",{...S,...ee,href:(He?Q:void 0)||D.absoluteURL||X,onClick:He?me:a,ref:cw(T,q),target:m,"data-discover":!z&&i==="render"?"true":void 0});return E&&!z?w.createElement(w.Fragment,null,Te,w.createElement(iw,{page:X})):Te});Vt.displayName="Link";var fw=w.forwardRef(function({"aria-current":a="page",caseSensitive:i=!1,className:r="",end:l=!1,style:d,to:h,viewTransition:y,children:p,...m},g){let x=Pr(h,{relative:m.relative}),b=Pn(),M=w.useContext(lc),{navigator:S,basename:T}=w.useContext(Rn),j=M!=null&&Rw(x)&&y===!0,O=S.encodeLocation?S.encodeLocation(x).pathname:x.pathname,L=b.pathname,z=M&&M.navigation&&M.navigation.location?M.navigation.location.pathname:null;i||(L=L.toLowerCase(),z=z?z.toLowerCase():null,O=O.toLowerCase()),z&&T&&(z=fa(z,T)||z);const D=O!=="/"&&O.endsWith("/")?O.length-1:O.length;let X=L===O||!l&&L.startsWith(O)&&L.charAt(D)==="/",J=z!=null&&(z===O||!l&&z.startsWith(O)&&z.charAt(O.length)==="/"),Q={isActive:X,isPending:J,isTransitioning:j},E=X?a:void 0,q;typeof r=="function"?q=r(Q):q=[r,X?"active":null,J?"pending":null,j?"transitioning":null].filter(Boolean).join(" ");let ee=typeof d=="function"?d(Q):d;return w.createElement(Vt,{...m,"aria-current":E,className:q,ref:g,style:ee,to:h,viewTransition:y},typeof p=="function"?p(Q):p)});fw.displayName="NavLink";var hw=w.forwardRef(({discover:n="render",fetcherKey:a,navigate:i,reloadDocument:r,replace:l,state:d,method:h=Vl,action:y,onSubmit:p,relative:m,preventScrollReset:g,viewTransition:x,defaultShouldRevalidate:b,...M},S)=>{let{useTransitions:T}=w.useContext(Rn),j=vw(),O=bw(y,{relative:m}),L=h.toLowerCase()==="get"?"get":"post",z=typeof y=="string"&&Zf.test(y),D=X=>{if(p&&p(X),X.defaultPrevented)return;X.preventDefault();let J=X.nativeEvent.submitter,Q=J?.getAttribute("formmethod")||h,E=()=>j(J||X.currentTarget,{fetcherKey:a,method:Q,navigate:i,replace:l,state:d,relative:m,preventScrollReset:g,viewTransition:x,defaultShouldRevalidate:b});T&&i!==!1?w.startTransition(()=>E()):E()};return w.createElement("form",{ref:S,method:L,action:O,onSubmit:r?p:D,...M,"data-discover":!z&&n==="render"?"true":void 0})});hw.displayName="Form";function pw(n){return`${n} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function N1(n){let a=w.useContext(Ri);return Ke(a,pw(n)),a}function mw(n,{target:a,replace:i,mask:r,state:l,preventScrollReset:d,relative:h,viewTransition:y,defaultShouldRevalidate:p,useTransitions:m}={}){let g=wi(),x=Pn(),b=Pr(n,{relative:h});return w.useCallback(M=>{if(YR(M,a)){M.preventDefault();let S=i!==void 0?i:Or(x)===Or(b),T=()=>g(n,{replace:S,mask:r,state:l,preventScrollReset:d,relative:h,viewTransition:y,defaultShouldRevalidate:p});m?w.startTransition(()=>T()):T()}},[x,g,b,i,r,l,a,n,d,h,y,p,m])}function gw(n){vn(typeof URLSearchParams<"u","You cannot use the `useSearchParams` hook in a browser that does not support the URLSearchParams API. If you need to support Internet Explorer 11, we recommend you load a polyfill such as https://github.com/ungap/url-search-params.");let a=w.useRef(xf(n)),i=w.useRef(!1),r=Pn(),l=w.useMemo(()=>qR(r.search,i.current?null:a.current),[r.search]),d=wi(),h=w.useCallback((y,p)=>{const m=xf(typeof y=="function"?y(new URLSearchParams(l)):y);i.current=!0,d("?"+m,p)},[d,l]);return[l,h]}var yw=0,xw=()=>`__${String(++yw)}__`;function vw(){let{router:n}=N1("useSubmit"),{basename:a}=w.useContext(Rn),i=OR(),r=n.fetch,l=n.navigate;return w.useCallback(async(d,h={})=>{let{action:y,method:p,encType:m,formData:g,body:x}=QR(d,a);if(h.navigate===!1){let b=h.fetcherKey||xw();await r(b,i,h.action||y,{defaultShouldRevalidate:h.defaultShouldRevalidate,preventScrollReset:h.preventScrollReset,formData:g,body:x,formMethod:h.method||p,formEncType:h.encType||m,flushSync:h.flushSync})}else await l(h.action||y,{defaultShouldRevalidate:h.defaultShouldRevalidate,preventScrollReset:h.preventScrollReset,formData:g,body:x,formMethod:h.method||p,formEncType:h.encType||m,replace:h.replace,state:h.state,fromRouteId:i,flushSync:h.flushSync,viewTransition:h.viewTransition})},[r,l,a,i])}function bw(n,{relative:a}={}){let{basename:i}=w.useContext(Rn),r=w.useContext(In);Ke(r,"useFormAction must be used inside a RouteContext");let[l]=r.matches.slice(-1),d={...Pr(n||".",{relative:a})},h=Pn();if(n==null){d.search=h.search;let y=new URLSearchParams(d.search),p=y.getAll("index");if(p.some(g=>g==="")){y.delete("index"),p.filter(x=>x).forEach(x=>y.append("index",x));let g=y.toString();d.search=g?`?${g}`:""}}return(!n||n===".")&&l.route.index&&(d.search=d.search?d.search.replace(/^\?/,"?index&"):"?index"),i!=="/"&&(d.pathname=d.pathname==="/"?i:Cn([i,d.pathname])),Or(d)}function Rw(n,{relative:a}={}){let i=w.useContext(v1);Ke(i!=null,"`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");let{basename:r}=N1("useViewTransitionState"),l=Pr(n,{relative:a});if(!i.isTransitioning)return!1;let d=fa(i.currentLocation.pathname,r)||i.currentLocation.pathname,h=fa(i.nextLocation.pathname,r)||i.nextLocation.pathname;return Yl(l.pathname,h)!=null||Yl(l.pathname,d)!=null}const ww="modulepreload",Sw=function(n,a){return new URL(n,a).href},uy={},Yr=function(a,i,r){let l=Promise.resolve();if(i&&i.length>0){let m=function(g){return Promise.all(g.map(x=>Promise.resolve(x).then(b=>({status:"fulfilled",value:b}),b=>({status:"rejected",reason:b}))))};const h=document.getElementsByTagName("link"),y=document.querySelector("meta[property=csp-nonce]"),p=y?.nonce||y?.getAttribute("nonce");l=m(i.map(g=>{if(g=Sw(g,r),g in uy)return;uy[g]=!0;const x=g.endsWith(".css"),b=x?'[rel="stylesheet"]':"";if(r)for(let S=h.length-1;S>=0;S--){const T=h[S];if(T.href===g&&(!x||T.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${g}"]${b}`))return;const M=document.createElement("link");if(M.rel=x?"stylesheet":ww,x||(M.as="script"),M.crossOrigin="",M.href=g,p&&M.setAttribute("nonce",p),document.head.appendChild(M),x)return new Promise((S,T)=>{M.addEventListener("load",S),M.addEventListener("error",()=>T(new Error(`Unable to preload CSS for ${g}`)))})}))}function d(h){const y=new Event("vite:preloadError",{cancelable:!0});if(y.payload=h,window.dispatchEvent(y),!y.defaultPrevented)throw h}return l.then(h=>{for(const y of h||[])y.status==="rejected"&&d(y.reason);return a().catch(d)})},di=new Map;function jw(n,a){return di.has(n)||di.set(n,new Set),di.get(n).add(a),()=>di.get(n).delete(a)}function E1(n){di.get(n)?.forEach(a=>a()),di.get("*")?.forEach(a=>a())}const F8=n=>`${n}_${Date.now().toString(36)}${Math.random().toString(36).slice(2,8)}`,dy="ABCDEFGHJKMNPQRSTUVWXYZ23456789",I8=()=>Array.from({length:4},()=>dy[Math.floor(Math.random()*dy.length)]).join(""),Mw=()=>`harusi-${Math.random().toString(36).slice(2,8)}`;function P8(n){const a=new Date(Date.now()+7776e6).toISOString().slice(0,10);return{ownerId:n,slug:Mw(),templateId:"blush-swan",status:"draft",groomName:"Zohan",brideName:"Rose",quoteEn:"And among His signs is that He created for you spouses from among yourselves, that you may find tranquillity in them.",quoteSw:"Na kati ya dalili zake ni kwamba Amekuundieni wake kutoka kwenu ninyi, mpate kutulia nao.",storyEn:"As we get ready to say “I do”, we feel grateful for the wonderful people in our lives. Your support means the world to us, and we would be honoured to have you with us as we begin our life together.",storySw:"Tunapoandaa kusema “Ndoa”, tunawashukuru watu wote wazuri katika maisha yetu. Msaada wenu unamaanisha mengi kwetu, na itakuwa heshima kuwa nanyi tuanze safari hii mpya pamoja.",heroImage:"",musicTrack:"ocean-strings",language:"en",whatsappNumber:"255754000000",groomFamily:"Mr. & Mrs. Abdalla",brideFamily:"Mr. & Mrs. Makame",sealText:"",events:[{name:"Nikkah Ceremony",nameSw:"Nikkah",date:a,time:"16:00",venue:"Masjid Sheikh, Stone Town, Zanzibar",mapsUrl:"https://maps.google.com/?q=Stone+Town+Zanzibar",dressCode:"",notes:""},{name:"Walimah Reception",nameSw:"Walimah",date:a,time:"18:30",venue:"Serena Hotel Gardens, Zanzibar",mapsUrl:"https://maps.google.com/?q=Zanzibar",dressCode:"",notes:""}],gifts:[{label:"M-Pesa",provider:"Vodacom M-Pesa",accountName:"Wedding Committee",accountNumber:"0754 000 000"},{label:"Tigo Pesa",provider:"Tigo Pesa",accountName:"Wedding Committee",accountNumber:"0654 000 000"}],contacts:[{label:"Wedding Planner",name:"Bi. Amina",phone:"+255754000000"}],gallery:[],createdAt:Date.now()}}let Pd=null;function A1(){return Pd||(Pd=Yr(()=>import("./firebaseBackend-AMtMKnr2.js"),[],import.meta.url).then(n=>n.createFirebaseRepo())),Pd}function Ha(n,a,i){const r=i?.enabled!==!1,[l,d]=w.useState({data:void 0,error:null,isLoading:r}),[h,y]=w.useState(0),p=w.useRef(n);p.current=n,w.useEffect(()=>jw("*",()=>y(g=>g+1)),[]),w.useEffect(()=>{if(!r){d(x=>x.isLoading?{...x,isLoading:!1}:x);return}let g=!0;return d(x=>({...x,isLoading:x.data===void 0,error:null})),A1().then(x=>p.current(x)).then(x=>{g&&d({data:x,error:null,isLoading:!1})}).catch(x=>{g&&d(b=>({data:b.data,error:x,isLoading:!1}))}),()=>{g=!1}},[r,h,a]);const m=w.useCallback(()=>y(g=>g+1),[]);return{data:l.data,error:l.error,isLoading:l.isLoading,refetch:m}}function kt(n,a){const[i,r]=w.useState(!1),[l,d]=w.useState(!1),h=w.useRef(n);h.current=n;const y=w.useRef(a);y.current=a;const p=w.useCallback(async g=>{r(!0),d(!1);try{const x=await A1(),b=await h.current(x,g);return E1("*"),await y.current?.onSuccess?.(b,g),b}catch(x){throw d(!0),y.current?.onError?.(x,g),x}finally{r(!1)}},[]);return{mutate:w.useCallback(g=>{p(g).catch(()=>{})},[p]),mutateAsync:p,isPending:i,isError:l}}const fs=()=>E1("*"),Tw={invalidate:fs,invitations:{mine:{invalidate:fs},get:{invalidate:fs},publicView:{invalidate:fs}},guests:{list:{invalidate:n=>fs()}},admin:{invitations:{invalidate:fs},hosters:{invalidate:fs},pricing:{invalidate:fs}}},da={useUtils:()=>Tw,auth:{me:{useQuery:(n,a)=>Ha(i=>i.auth.me(),"me",a)},logout:{useMutation:n=>kt(a=>a.auth.logout(),n)},login:{useMutation:n=>kt((a,i)=>a.auth.login(i.email,i.password),n)},signup:{useMutation:n=>kt((a,i)=>a.auth.signup(i.name,i.email,i.password),n)}},invitations:{mine:{useQuery:(n,a)=>Ha(i=>i.invitations.mine(),"mine",a)},get:{useQuery:(n,a)=>Ha(i=>i.invitations.get(n.id),`get:${n?.id}`,a)},publicView:{useQuery:(n,a)=>Ha(i=>i.invitations.publicView(n.slug,n.code),`pv:${n?.slug}:${n?.code??""}`,a)},create:{useMutation:n=>kt(a=>a.invitations.create(),n)},update:{useMutation:n=>kt((a,i)=>a.invitations.update(i.id,i.data),n)},remove:{useMutation:n=>kt((a,i)=>a.invitations.remove(i.id),n)}},guests:{list:{useQuery:(n,a)=>Ha(i=>i.guests.list(n.invitationId),`gl:${n?.invitationId}`,a)},add:{useMutation:n=>kt((a,i)=>a.guests.add(i),n)},remove:{useMutation:n=>kt((a,i)=>a.guests.remove(i),n)},checkIn:{useMutation:n=>kt((a,i)=>a.guests.checkIn(i),n)},rsvp:{useMutation:n=>kt((a,i)=>a.guests.rsvp(i),n)}},messages:{add:{useMutation:n=>kt((a,i)=>a.messages.add(i),n)}},admin:{bootstrap:{useMutation:n=>kt(a=>a.admin.bootstrap(),n)},stats:{useQuery:(n,a)=>Ha(i=>i.admin.stats(),"as",a)},hosters:{useQuery:(n,a)=>Ha(i=>i.admin.hosters(),"ah",a)},invitations:{useQuery:(n,a)=>Ha(i=>i.admin.invitations(),"ai",a)},getPricing:{useQuery:(n,a)=>Ha(i=>i.admin.getPricing(),"ap",a)},savePricing:{useMutation:n=>kt((a,i)=>a.admin.savePricing(i),n)},setStatus:{useMutation:n=>kt((a,i)=>a.admin.setStatus(i),n)},setRole:{useMutation:n=>kt((a,i)=>a.admin.setRole(i),n)},createHost:{useMutation:n=>kt((a,i)=>a.admin.createHost(i),n)},setUserStatus:{useMutation:n=>kt((a,i)=>a.admin.setUserStatus(i),n)},wipeHost:{useMutation:n=>kt((a,i)=>a.admin.wipeHost(i),n)}}};function Nw({children:n}){return u.jsx(u.Fragment,{children:n})}const sh=w.createContext({});function Pa(n){const a=w.useRef(null);return a.current===null&&(a.current=n()),a.current}const Ew=typeof window<"u",qr=Ew?w.useLayoutEffect:w.useEffect,dc=w.createContext(null);function ih(n,a){n.indexOf(a)===-1&&n.push(a)}function Xl(n,a){const i=n.indexOf(a);i>-1&&n.splice(i,1)}const Dn=(n,a,i)=>i>a?a:i<n?n:i;let rh=()=>{};const Ya={},C1=n=>/^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(n),k1=n=>typeof n=="object"&&n!==null,D1=n=>/^0[^.\s]+$/u.test(n);function z1(n){let a;return()=>(a===void 0&&(a=n()),a)}const $t=n=>n,Xr=(...n)=>n.reduce((a,i)=>r=>i(a(r))),xi=(n,a,i)=>{const r=a-n;return r?(i-n)/r:1};class oh{constructor(){this.subscriptions=[]}add(a){return ih(this.subscriptions,a),()=>Xl(this.subscriptions,a)}notify(a,i,r){const l=this.subscriptions.length;if(l)if(l===1)this.subscriptions[0](a,i,r);else for(let d=0;d<l;d++){const h=this.subscriptions[d];h&&h(a,i,r)}}getSize(){return this.subscriptions.length}clear(){this.subscriptions.length=0}}const on=n=>n*1e3,xn=n=>n/1e3,lh=(n,a)=>a?n*(1e3/a):0,V1=(n,a,i)=>(((1-3*i+3*a)*n+(3*i-6*a))*n+3*a)*n,Aw=1e-7,Cw=12;function kw(n,a,i,r,l){let d,h,y=0;do h=a+(i-a)/2,d=V1(h,r,l)-n,d>0?i=h:a=h;while(Math.abs(d)>Aw&&++y<Cw);return h}function $r(n,a,i,r){if(n===a&&i===r)return $t;const l=d=>kw(d,0,1,n,i);return d=>d===0||d===1?d:V1(l(d),a,r)}const O1=n=>a=>a<=.5?n(2*a)/2:(2-n(2*(1-a)))/2,L1=n=>a=>1-n(1-a),G1=$r(.33,1.53,.69,.99),ch=L1(G1),_1=O1(ch),B1=n=>n>=1?1:(n*=2)<1?.5*ch(n):.5*(2-Math.pow(2,-10*(n-1))),uh=n=>1-Math.sin(Math.acos(n)),U1=L1(uh),H1=O1(uh),Dw=$r(.42,0,1,1),zw=$r(0,0,.58,1),F1=$r(.42,0,.58,1),Vw=n=>Array.isArray(n)&&typeof n[0]!="number",I1=n=>Array.isArray(n)&&typeof n[0]=="number",Ow={linear:$t,easeIn:Dw,easeInOut:F1,easeOut:zw,circIn:uh,circInOut:H1,circOut:U1,backIn:ch,backInOut:_1,backOut:G1,anticipate:B1},Lw=n=>typeof n=="string",fy=n=>{if(I1(n)){rh(n.length===4);const[a,i,r,l]=n;return $r(a,i,r,l)}else if(Lw(n))return Ow[n];return n},wl=["setup","read","resolveKeyframes","preUpdate","update","preRender","render","postRender"];function Gw(n){let a=new Set,i=new Set,r=!1,l=!1;const d=new WeakSet;let h={delta:0,timestamp:0,isProcessing:!1};function y(m){d.has(m)&&(p.schedule(m),n()),m(h)}const p={schedule:(m,g=!1,x=!1)=>{const M=x&&r?a:i;return g&&d.add(m),M.add(m),m},cancel:m=>{i.delete(m),d.delete(m)},process:m=>{if(h=m,r){l=!0;return}r=!0;const g=a;a=i,i=g,a.forEach(y),a.clear(),r=!1,l&&(l=!1,p.process(m))}};return p}const _w=40;function P1(n,a){let i=!1,r=!0;const l={delta:0,timestamp:0,isProcessing:!1},d=()=>i=!0,h=wl.reduce((z,D)=>(z[D]=Gw(d),z),{}),{setup:y,read:p,resolveKeyframes:m,preUpdate:g,update:x,preRender:b,render:M,postRender:S}=h,T=()=>{const z=Ya.useManualTiming,D=z?l.timestamp:performance.now();i=!1,z||(l.delta=r?1e3/60:Math.max(Math.min(D-l.timestamp,_w),1)),l.timestamp=D,l.isProcessing=!0,y.process(l),p.process(l),m.process(l),g.process(l),x.process(l),b.process(l),M.process(l),S.process(l),l.isProcessing=!1,i&&a&&(r=!1,n(T))},j=()=>{i=!0,r=!0,l.isProcessing||n(T)};return{schedule:wl.reduce((z,D)=>{const X=h[D];return z[D]=(J,Q=!1,E=!1)=>(i||j(),X.schedule(J,Q,E)),z},{}),cancel:z=>{for(let D=0;D<wl.length;D++)h[wl[D]].cancel(z)},state:l,steps:h}}const{schedule:Ae,cancel:bn,state:wt,steps:Yd}=P1(typeof requestAnimationFrame<"u"?requestAnimationFrame:$t,!0);let Ll;function Bw(){Ll=void 0}const Gt={now:()=>(Ll===void 0&&Gt.set(wt.isProcessing||Ya.useManualTiming?wt.timestamp:performance.now()),Ll),set:n=>{Ll=n,queueMicrotask(Bw)}},Y1=n=>a=>typeof a=="string"&&a.startsWith(n),q1=Y1("--"),Uw=Y1("var(--"),dh=n=>Uw(n)?Hw.test(n.split("/*")[0].trim()):!1,Hw=/var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu;function hy(n){return typeof n!="string"?!1:n.split("/*")[0].includes("var(--")}const Si={test:n=>typeof n=="number",parse:parseFloat,transform:n=>n},Lr={...Si,transform:n=>Dn(0,1,n)},Sl={...Si,default:1},Ar=n=>Math.round(n*1e5)/1e5,fh=/-?(?:\d+(?:\.\d+)?|\.\d+)/gu;function Fw(n){return n==null}const Iw=/^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,hh=(n,a)=>i=>!!(typeof i=="string"&&Iw.test(i)&&i.startsWith(n)||a&&!Fw(i)&&Object.prototype.hasOwnProperty.call(i,a)),X1=(n,a,i)=>r=>{if(typeof r!="string")return r;const[l,d,h,y]=r.match(fh);return{[n]:parseFloat(l),[a]:parseFloat(d),[i]:parseFloat(h),alpha:y!==void 0?parseFloat(y):1}},Pw=n=>Dn(0,255,n),qd={...Si,transform:n=>Math.round(Pw(n))},gs={test:hh("rgb","red"),parse:X1("red","green","blue"),transform:({red:n,green:a,blue:i,alpha:r=1})=>"rgba("+qd.transform(n)+", "+qd.transform(a)+", "+qd.transform(i)+", "+Ar(Lr.transform(r))+")"};function Yw(n){let a="",i="",r="",l="";return n.length>5?(a=n.substring(1,3),i=n.substring(3,5),r=n.substring(5,7),l=n.substring(7,9)):(a=n.substring(1,2),i=n.substring(2,3),r=n.substring(3,4),l=n.substring(4,5),a+=a,i+=i,r+=r,l+=l),{red:parseInt(a,16),green:parseInt(i,16),blue:parseInt(r,16),alpha:l?parseInt(l,16)/255:1}}const vf={test:hh("#"),parse:Yw,transform:gs.transform},Qr=n=>({test:a=>typeof a=="string"&&a.endsWith(n)&&a.split(" ").length===1,parse:parseFloat,transform:a=>`${a}${n}`}),ua=Qr("deg"),Fn=Qr("%"),se=Qr("px"),qw=Qr("vh"),Xw=Qr("vw"),py={...Fn,parse:n=>Fn.parse(n)/100,transform:n=>Fn.transform(n*100)},fi={test:hh("hsl","hue"),parse:X1("hue","saturation","lightness"),transform:({hue:n,saturation:a,lightness:i,alpha:r=1})=>"hsla("+Math.round(n)+", "+Fn.transform(Ar(a))+", "+Fn.transform(Ar(i))+", "+Ar(Lr.transform(r))+")"},dt={test:n=>gs.test(n)||vf.test(n)||fi.test(n),parse:n=>gs.test(n)?gs.parse(n):fi.test(n)?fi.parse(n):vf.parse(n),transform:n=>typeof n=="string"?n:n.hasOwnProperty("red")?gs.transform(n):fi.transform(n),getAnimatableNone:n=>{const a=dt.parse(n);return a.alpha=0,dt.transform(a)}},$w=/(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;function Qw(n){return isNaN(n)&&typeof n=="string"&&(n.match(fh)?.length||0)+(n.match($w)?.length||0)>0}const $1="number",Q1="color",Zw="var",Kw="var(",my="${}",Jw=/var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;function vi(n){const a=n.toString(),i=[],r={color:[],number:[],var:[]},l=[];let d=0;const y=a.replace(Jw,p=>(dt.test(p)?(r.color.push(d),l.push(Q1),i.push(dt.parse(p))):p.startsWith(Kw)?(r.var.push(d),l.push(Zw),i.push(p)):(r.number.push(d),l.push($1),i.push(parseFloat(p))),++d,my)).split(my);return{values:i,split:y,indexes:r,types:l}}function Ww(n){return vi(n).values}function Z1({split:n,types:a}){const i=n.length;return r=>{let l="";for(let d=0;d<i;d++)if(l+=n[d],r[d]!==void 0){const h=a[d];h===$1?l+=Ar(r[d]):h===Q1?l+=dt.transform(r[d]):l+=r[d]}return l}}function eS(n){return Z1(vi(n))}const tS=n=>typeof n=="number"?0:dt.test(n)?dt.getAnimatableNone(n):n,nS=(n,a)=>typeof n=="number"?a?.trim().endsWith("/")?n:0:tS(n);function aS(n){const a=vi(n);return Z1(a)(a.values.map((r,l)=>nS(r,a.split[l])))}const kn={test:Qw,parse:Ww,createTransformer:eS,getAnimatableNone:aS};function Xd(n,a,i){return i<0&&(i+=1),i>1&&(i-=1),i<1/6?n+(a-n)*6*i:i<1/2?a:i<2/3?n+(a-n)*(2/3-i)*6:n}function sS({hue:n,saturation:a,lightness:i,alpha:r}){n/=360,a/=100,i/=100;let l=0,d=0,h=0;if(!a)l=d=h=i;else{const y=i<.5?i*(1+a):i+a-i*a,p=2*i-y;l=Xd(p,y,n+1/3),d=Xd(p,y,n),h=Xd(p,y,n-1/3)}return{red:Math.round(l*255),green:Math.round(d*255),blue:Math.round(h*255),alpha:r}}function $l(n,a){return i=>i>0?a:n}const Ue=(n,a,i)=>n+(a-n)*i,$d=(n,a,i)=>{const r=n*n,l=i*(a*a-r)+r;return l<0?0:Math.sqrt(l)},iS=[vf,gs,fi],rS=n=>iS.find(a=>a.test(n));function gy(n){const a=rS(n);if(!a)return!1;let i=a.parse(n);return a===fi&&(i=sS(i)),i}const yy=(n,a)=>{const i=gy(n),r=gy(a);if(!i||!r)return $l(n,a);const l={...i};return d=>(l.red=$d(i.red,r.red,d),l.green=$d(i.green,r.green,d),l.blue=$d(i.blue,r.blue,d),l.alpha=Ue(i.alpha,r.alpha,d),gs.transform(l))},bf=new Set(["none","hidden"]);function oS(n,a){return bf.has(n)?i=>i<=0?n:a:i=>i>=1?a:n}function lS(n,a){return i=>Ue(n,a,i)}function ph(n){return typeof n=="number"?lS:typeof n=="string"?dh(n)?$l:dt.test(n)?yy:dS:Array.isArray(n)?K1:typeof n=="object"?dt.test(n)?yy:cS:$l}function K1(n,a){const i=[...n],r=i.length,l=n.map((d,h)=>ph(d)(d,a[h]));return d=>{for(let h=0;h<r;h++)i[h]=l[h](d);return i}}function cS(n,a){const i={...n,...a},r={};for(const l in i)n[l]!==void 0&&a[l]!==void 0&&(r[l]=ph(n[l])(n[l],a[l]));return l=>{for(const d in r)i[d]=r[d](l);return i}}function uS(n,a){const i=[],r={color:0,var:0,number:0};for(let l=0;l<a.values.length;l++){const d=a.types[l],h=n.indexes[d][r[d]],y=n.values[h]??0;i[l]=y,r[d]++}return i}const dS=(n,a)=>{const i=kn.createTransformer(a),r=vi(n),l=vi(a);return r.indexes.var.length===l.indexes.var.length&&r.indexes.color.length===l.indexes.color.length&&r.indexes.number.length>=l.indexes.number.length?bf.has(n)&&!l.values.length||bf.has(a)&&!r.values.length?oS(n,a):Xr(K1(uS(r,l),l.values),i):$l(n,a)};function J1(n,a,i){return typeof n=="number"&&typeof a=="number"&&typeof i=="number"?Ue(n,a,i):ph(n)(n,a)}const fS=n=>{const a=({timestamp:i})=>n(i);return{start:(i=!0)=>Ae.update(a,i),stop:()=>bn(a),now:()=>wt.isProcessing?wt.timestamp:Gt.now()}},W1=(n,a,i=10)=>{let r="";const l=Math.max(Math.round(a/i),2);for(let d=0;d<l;d++)r+=Math.round(n(d/(l-1))*1e4)/1e4+", ";return`linear(${r.substring(0,r.length-2)})`},Ql=2e4;function mh(n){let a=0;const i=50;let r=n.next(a);for(;!r.done&&a<Ql;)a+=i,r=n.next(a);return a>=Ql?1/0:a}function hS(n,a=100,i){const r=i({...n,keyframes:[0,a]}),l=Math.min(mh(r),Ql);return{type:"keyframes",ease:d=>r.next(l*d).value/a,duration:xn(l)}}const at={stiffness:100,damping:10,mass:1,velocity:0,duration:800,bounce:.3,visualDuration:.3,restSpeed:{granular:.01,default:2},restDelta:{granular:.005,default:.5},minDuration:.01,maxDuration:10,minDamping:.05,maxDamping:1};function Rf(n,a){return n*Math.sqrt(1-a*a)}const pS=12;function mS(n,a,i){let r=i;for(let l=1;l<pS;l++)r=r-n(r)/a(r);return r}const Qd=.001;function gS({duration:n=at.duration,bounce:a=at.bounce,velocity:i=at.velocity,mass:r=at.mass}){let l,d,h=1-a;h=Dn(at.minDamping,at.maxDamping,h),n=Dn(at.minDuration,at.maxDuration,xn(n)),h<1?(l=m=>{const g=m*h,x=g*n,b=g-i,M=Rf(m,h),S=Math.exp(-x);return Qd-b/M*S},d=m=>{const x=m*h*n,b=x*i+i,M=Math.pow(h,2)*Math.pow(m,2)*n,S=Math.exp(-x),T=Rf(Math.pow(m,2),h);return(-l(m)+Qd>0?-1:1)*((b-M)*S)/T}):(l=m=>{const g=Math.exp(-m*n),x=(m-i)*n+1;return-Qd+g*x},d=m=>{const g=Math.exp(-m*n),x=(i-m)*(n*n);return g*x});const y=5/n,p=mS(l,d,y);if(n=on(n),isNaN(p))return{stiffness:at.stiffness,damping:at.damping,duration:n};{const m=Math.pow(p,2)*r;return{stiffness:m,damping:h*2*Math.sqrt(r*m),duration:n}}}const yS=["duration","bounce"],xS=["stiffness","damping","mass"];function xy(n,a){return a.some(i=>n[i]!==void 0)}function vS(n){let a={velocity:at.velocity,stiffness:at.stiffness,damping:at.damping,mass:at.mass,isResolvedFromDuration:!1,...n};if(!xy(n,xS)&&xy(n,yS))if(a.velocity=0,n.visualDuration){const i=n.visualDuration,r=2*Math.PI/(i*1.2),l=r*r,d=2*Dn(.05,1,1-(n.bounce||0))*Math.sqrt(l);a={...a,mass:at.mass,stiffness:l,damping:d}}else{const i=gS({...n,velocity:0});a={...a,...i,mass:at.mass},a.isResolvedFromDuration=!0}return a}function Zl(n=at.visualDuration,a=at.bounce){const i=typeof n!="object"?{visualDuration:n,keyframes:[0,1],bounce:a}:n;let{restSpeed:r,restDelta:l}=i;const d=i.keyframes[0],h=i.keyframes[i.keyframes.length-1],y={done:!1,value:d},{stiffness:p,damping:m,mass:g,duration:x,velocity:b,isResolvedFromDuration:M}=vS({...i,velocity:-xn(i.velocity||0)}),S=b||0,T=m/(2*Math.sqrt(p*g)),j=h-d,O=xn(Math.sqrt(p/g)),L=Math.abs(j)<5;r||(r=L?at.restSpeed.granular:at.restSpeed.default),l||(l=L?at.restDelta.granular:at.restDelta.default);let z,D,X,J,Q,E;if(T<1)X=Rf(O,T),J=(S+T*O*j)/X,z=ee=>{const oe=Math.exp(-T*O*ee);return h-oe*(J*Math.sin(X*ee)+j*Math.cos(X*ee))},Q=T*O*J+j*X,E=T*O*j-J*X,D=ee=>Math.exp(-T*O*ee)*(Q*Math.sin(X*ee)+E*Math.cos(X*ee));else if(T===1){z=oe=>h-Math.exp(-O*oe)*(j+(S+O*j)*oe);const ee=S+O*j;D=oe=>Math.exp(-O*oe)*(O*ee*oe-S)}else{const ee=O*Math.sqrt(T*T-1);z=Te=>{const de=Math.exp(-T*O*Te),U=Math.min(ee*Te,300);return h-de*((S+T*O*j)*Math.sinh(U)+ee*j*Math.cosh(U))/ee};const oe=(S+T*O*j)/ee,me=T*O*oe-j*ee,He=T*O*j-oe*ee;D=Te=>{const de=Math.exp(-T*O*Te),U=Math.min(ee*Te,300);return de*(me*Math.sinh(U)+He*Math.cosh(U))}}const q={calculatedDuration:M&&x||null,velocity:ee=>on(D(ee)),next:ee=>{if(!M&&T<1){const me=Math.exp(-T*O*ee),He=Math.sin(X*ee),Te=Math.cos(X*ee),de=h-me*(J*He+j*Te),U=on(me*(Q*He+E*Te));return y.done=Math.abs(U)<=r&&Math.abs(h-de)<=l,y.value=y.done?h:de,y}const oe=z(ee);if(M)y.done=ee>=x;else{const me=on(D(ee));y.done=Math.abs(me)<=r&&Math.abs(h-oe)<=l}return y.value=y.done?h:oe,y},toString:()=>{const ee=Math.min(mh(q),Ql),oe=W1(me=>q.next(ee*me).value,ee,30);return ee+"ms "+oe},toTransition:()=>{}};return q}Zl.applyToOptions=n=>{const a=hS(n,100,Zl);return n.ease=a.ease,n.duration=on(a.duration),n.type="keyframes",n};const bS=5;function ev(n,a,i){const r=Math.max(a-bS,0);return lh(i-n(r),a-r)}function wf({keyframes:n,velocity:a=0,power:i=.8,timeConstant:r=325,bounceDamping:l=10,bounceStiffness:d=500,modifyTarget:h,min:y,max:p,restDelta:m=.5,restSpeed:g}){const x=n[0],b={done:!1,value:x},M=E=>y!==void 0&&E<y||p!==void 0&&E>p,S=E=>y===void 0?p:p===void 0||Math.abs(y-E)<Math.abs(p-E)?y:p;let T=i*a;const j=x+T,O=h===void 0?j:h(j);O!==j&&(T=O-x);const L=E=>-T*Math.exp(-E/r),z=E=>O+L(E),D=E=>{const q=L(E),ee=z(E);b.done=Math.abs(q)<=m,b.value=b.done?O:ee};let X,J;const Q=E=>{M(b.value)&&(X=E,J=Zl({keyframes:[b.value,S(b.value)],velocity:ev(z,E,b.value),damping:l,stiffness:d,restDelta:m,restSpeed:g}))};return Q(0),{calculatedDuration:null,next:E=>{let q=!1;return!J&&X===void 0&&(q=!0,D(E),Q(E)),X!==void 0&&E>=X?J.next(E-X):(!q&&D(E),b)}}}function RS(n,a,i){const r=[],l=i||Ya.mix||J1,d=n.length-1;for(let h=0;h<d;h++){let y=l(n[h],n[h+1]);if(a){const p=Array.isArray(a)?a[h]||$t:a;y=Xr(p,y)}r.push(y)}return r}function gh(n,a,{clamp:i=!0,ease:r,mixer:l}={}){const d=n.length;if(rh(d===a.length),d===1)return()=>a[0];if(d===2&&a[0]===a[1])return()=>a[1];const h=n[0]===n[1];n[0]>n[d-1]&&(n=[...n].reverse(),a=[...a].reverse());const y=RS(a,r,l),p=y.length,m=g=>{if(h&&g<n[0])return a[0];let x=0;if(p>1)for(;x<n.length-2&&!(g<n[x+1]);x++);const b=xi(n[x],n[x+1],g);return y[x](b)};return i?g=>m(Dn(n[0],n[d-1],g)):m}function wS(n,a){const i=n[n.length-1];for(let r=1;r<=a;r++){const l=xi(0,a,r);n.push(Ue(i,1,l))}}function tv(n){const a=[0];return wS(a,n.length-1),a}function SS(n,a){return n.map(i=>i*a)}function jS(n,a){return n.map(()=>a||F1).splice(0,n.length-1)}function Cr({duration:n=300,keyframes:a,times:i,ease:r="easeInOut"}){const l=Vw(r)?r.map(fy):fy(r),d={done:!1,value:a[0]},h=SS(i&&i.length===a.length?i:tv(a),n),y=gh(h,a,{ease:Array.isArray(l)?l:jS(a,l)});return{calculatedDuration:n,next:p=>(d.value=y(p),d.done=p>=n,d)}}const MS=n=>n!==null;function fc(n,{repeat:a,repeatType:i="loop"},r,l=1){const d=n.filter(MS),y=l<0||a&&i!=="loop"&&a%2===1?0:d.length-1;return!y||r===void 0?d[y]:r}const TS={decay:wf,inertia:wf,tween:Cr,keyframes:Cr,spring:Zl};function nv(n){typeof n.type=="string"&&(n.type=TS[n.type])}class yh{constructor(){this.updateFinished()}get finished(){return this._finished}updateFinished(){this._finished=new Promise(a=>{this.resolve=a})}notifyFinished(){this.resolve()}then(a,i){return this.finished.then(a,i)}}const NS=n=>n/100;class Gr extends yh{constructor(a){super(),this.state="idle",this.startTime=null,this.isStopped=!1,this.currentTime=0,this.holdTime=null,this.playbackSpeed=1,this.delayState={done:!1,value:void 0},this.stop=()=>{const{motionValue:i}=this.options;i&&i.updatedAt!==Gt.now()&&this.tick(Gt.now()),this.isStopped=!0,this.state!=="idle"&&(this.teardown(),this.options.onStop?.())},this.options=a,this.initAnimation(),this.play(),a.autoplay===!1&&this.pause()}initAnimation(){const{options:a}=this;nv(a);const{type:i=Cr,repeat:r=0,repeatDelay:l=0,repeatType:d,velocity:h=0}=a;let{keyframes:y}=a;const p=i||Cr;p!==Cr&&typeof y[0]!="number"&&(this.mixKeyframes=Xr(NS,J1(y[0],y[1])),y=[0,100]);const m=p({...a,keyframes:y});d==="mirror"&&(this.mirroredGenerator=p({...a,keyframes:[...y].reverse(),velocity:-h})),m.calculatedDuration===null&&(m.calculatedDuration=mh(m));const{calculatedDuration:g}=m;this.calculatedDuration=g,this.resolvedDuration=g+l,this.totalDuration=this.resolvedDuration*(r+1)-l,this.generator=m}updateTime(a){const i=Math.round(a-this.startTime)*this.playbackSpeed;this.holdTime!==null?this.currentTime=this.holdTime:this.currentTime=i}tick(a,i=!1){const{generator:r,totalDuration:l,mixKeyframes:d,mirroredGenerator:h,resolvedDuration:y,calculatedDuration:p}=this;if(this.startTime===null)return r.next(0);const{delay:m=0,keyframes:g,repeat:x,repeatType:b,repeatDelay:M,type:S,onUpdate:T,finalKeyframe:j}=this.options;this.speed>0?this.startTime=Math.min(this.startTime,a):this.speed<0&&(this.startTime=Math.min(a-l/this.speed,this.startTime)),i?this.currentTime=a:this.updateTime(a);const O=this.currentTime-m*(this.playbackSpeed>=0?1:-1),L=this.playbackSpeed>=0?O<0:O>l;this.currentTime=Math.max(O,0),this.state==="finished"&&this.holdTime===null&&(this.currentTime=l);let z=this.currentTime,D=r;if(x){const E=Math.min(this.currentTime,l)/y;let q=Math.floor(E),ee=E%1;!ee&&E>=1&&(ee=1),ee===1&&q--,q=Math.min(q,x+1),q%2&&(b==="reverse"?(ee=1-ee,M&&(ee-=M/y)):b==="mirror"&&(D=h)),z=Dn(0,1,ee)*y}let X;L?(this.delayState.value=g[0],X=this.delayState):X=D.next(z),d&&!L&&(X.value=d(X.value));let{done:J}=X;!L&&p!==null&&(J=this.playbackSpeed>=0?this.currentTime>=l:this.currentTime<=0);const Q=this.holdTime===null&&(this.state==="finished"||this.state==="running"&&J);return Q&&S!==wf&&(X.value=fc(g,this.options,j,this.speed)),T&&T(X.value),Q&&this.finish(),X}then(a,i){return this.finished.then(a,i)}get duration(){return xn(this.calculatedDuration)}get iterationDuration(){const{delay:a=0}=this.options||{};return this.duration+xn(a)}get time(){return xn(this.currentTime)}set time(a){a=on(a),this.currentTime=a,this.startTime===null||this.holdTime!==null||this.playbackSpeed===0?this.holdTime=a:this.driver&&(this.startTime=this.driver.now()-a/this.playbackSpeed),this.driver?this.driver.start(!1):(this.startTime=0,this.state="paused",this.holdTime=a,this.tick(a))}getGeneratorVelocity(){const a=this.currentTime;if(a<=0)return this.options.velocity||0;if(this.generator.velocity)return this.generator.velocity(a);const i=this.generator.next(a).value;return ev(r=>this.generator.next(r).value,a,i)}get speed(){return this.playbackSpeed}set speed(a){const i=this.playbackSpeed!==a;i&&this.driver&&this.updateTime(Gt.now()),this.playbackSpeed=a,i&&this.driver&&(this.time=xn(this.currentTime))}play(){if(this.isStopped)return;const{driver:a=fS,startTime:i}=this.options;this.driver||(this.driver=a(l=>this.tick(l))),this.options.onPlay?.();const r=this.driver.now();this.state==="finished"?(this.updateFinished(),this.startTime=r):this.holdTime!==null?this.startTime=r-this.holdTime:this.startTime||(this.startTime=i??r),this.state==="finished"&&this.speed<0&&(this.startTime+=this.calculatedDuration),this.holdTime=null,this.state="running",this.driver.start()}pause(){this.state="paused",this.updateTime(Gt.now()),this.holdTime=this.currentTime}complete(){this.state!=="running"&&this.play(),this.state="finished",this.holdTime=null}finish(){this.notifyFinished(),this.teardown(),this.state="finished",this.options.onComplete?.()}cancel(){this.holdTime=null,this.startTime=0,this.tick(0),this.teardown(),this.options.onCancel?.()}teardown(){this.state="idle",this.stopDriver(),this.startTime=this.holdTime=null}stopDriver(){this.driver&&(this.driver.stop(),this.driver=void 0)}sample(a){return this.startTime=0,this.tick(a,!0)}attachTimeline(a){return this.options.allowFlatten&&(this.options.type="keyframes",this.options.ease="linear",this.initAnimation()),this.driver?.stop(),a.observe(this)}}function ES(n){for(let a=1;a<n.length;a++)n[a]??(n[a]=n[a-1])}const ys=n=>n*180/Math.PI,Sf=n=>{const a=ys(Math.atan2(n[1],n[0]));return jf(a)},AS={x:4,y:5,translateX:4,translateY:5,scaleX:0,scaleY:3,scale:n=>(Math.abs(n[0])+Math.abs(n[3]))/2,rotate:Sf,rotateZ:Sf,skewX:n=>ys(Math.atan(n[1])),skewY:n=>ys(Math.atan(n[2])),skew:n=>(Math.abs(n[1])+Math.abs(n[2]))/2},jf=n=>(n=n%360,n<0&&(n+=360),n),vy=Sf,by=n=>Math.sqrt(n[0]*n[0]+n[1]*n[1]),Ry=n=>Math.sqrt(n[4]*n[4]+n[5]*n[5]),CS={x:12,y:13,z:14,translateX:12,translateY:13,translateZ:14,scaleX:by,scaleY:Ry,scale:n=>(by(n)+Ry(n))/2,rotateX:n=>jf(ys(Math.atan2(n[6],n[5]))),rotateY:n=>jf(ys(Math.atan2(-n[2],n[0]))),rotateZ:vy,rotate:vy,skewX:n=>ys(Math.atan(n[4])),skewY:n=>ys(Math.atan(n[1])),skew:n=>(Math.abs(n[1])+Math.abs(n[4]))/2};function Mf(n){return n.includes("scale")?1:0}function Tf(n,a){if(!n||n==="none")return Mf(a);const i=n.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);let r,l;if(i)r=CS,l=i;else{const y=n.match(/^matrix\(([-\d.e\s,]+)\)$/u);r=AS,l=y}if(!l)return Mf(a);const d=r[a],h=l[1].split(",").map(DS);return typeof d=="function"?d(h):h[d]}const kS=(n,a)=>{const{transform:i="none"}=getComputedStyle(n);return Tf(i,a)};function DS(n){return parseFloat(n.trim())}const ji=["transformPerspective","x","y","z","translateX","translateY","translateZ","scale","scaleX","scaleY","rotate","rotateX","rotateY","rotateZ","skew","skewX","skewY"],Mi=new Set([...ji,"pathRotation"]),wy=n=>n===Si||n===se,zS=new Set(["x","y","z"]),VS=ji.filter(n=>!zS.has(n));function OS(n){const a=[];return VS.forEach(i=>{const r=n.getValue(i);r!==void 0&&(a.push([i,r.get()]),r.set(i.startsWith("scale")?1:0))}),a}const Ia={width:({x:n},{paddingLeft:a="0",paddingRight:i="0",boxSizing:r})=>{const l=n.max-n.min;return r==="border-box"?l:l-parseFloat(a)-parseFloat(i)},height:({y:n},{paddingTop:a="0",paddingBottom:i="0",boxSizing:r})=>{const l=n.max-n.min;return r==="border-box"?l:l-parseFloat(a)-parseFloat(i)},top:(n,{top:a})=>parseFloat(a),left:(n,{left:a})=>parseFloat(a),bottom:({y:n},{top:a})=>parseFloat(a)+(n.max-n.min),right:({x:n},{left:a})=>parseFloat(a)+(n.max-n.min),x:(n,{transform:a})=>Tf(a,"x"),y:(n,{transform:a})=>Tf(a,"y")};Ia.translateX=Ia.x;Ia.translateY=Ia.y;const vs=new Set;let Nf=!1,Ef=!1,Af=!1;function av(){if(Ef){const n=Array.from(vs).filter(r=>r.needsMeasurement),a=new Set(n.map(r=>r.element)),i=new Map;a.forEach(r=>{const l=OS(r);l.length&&(i.set(r,l),r.render())}),n.forEach(r=>r.measureInitialState()),a.forEach(r=>{r.render();const l=i.get(r);l&&l.forEach(([d,h])=>{r.getValue(d)?.set(h)})}),n.forEach(r=>r.measureEndState()),n.forEach(r=>{r.suspendedScrollY!==void 0&&window.scrollTo(0,r.suspendedScrollY)})}Ef=!1,Nf=!1,vs.forEach(n=>n.complete(Af)),vs.clear()}function sv(){vs.forEach(n=>{n.readKeyframes(),n.needsMeasurement&&(Ef=!0)})}function LS(){Af=!0,sv(),av(),Af=!1}class xh{constructor(a,i,r,l,d,h=!1){this.state="pending",this.isAsync=!1,this.needsMeasurement=!1,this.unresolvedKeyframes=[...a],this.onComplete=i,this.name=r,this.motionValue=l,this.element=d,this.isAsync=h}scheduleResolve(){this.state="scheduled",this.isAsync?(vs.add(this),Nf||(Nf=!0,Ae.read(sv),Ae.resolveKeyframes(av))):(this.readKeyframes(),this.complete())}readKeyframes(){const{unresolvedKeyframes:a,name:i,element:r,motionValue:l}=this;if(a[0]===null){const d=l?.get(),h=a[a.length-1];if(d!==void 0)a[0]=d;else if(r&&i){const y=r.readValue(i,h);y!=null&&(a[0]=y)}a[0]===void 0&&(a[0]=h),l&&d===void 0&&l.set(a[0])}ES(a)}setFinalKeyframe(){}measureInitialState(){}renderEndStyles(){}measureEndState(){}complete(a=!1){this.state="complete",this.onComplete(this.unresolvedKeyframes,this.finalKeyframe,a),vs.delete(this)}cancel(){this.state==="scheduled"&&(vs.delete(this),this.state="pending")}resume(){this.state==="pending"&&this.scheduleResolve()}}const GS=n=>n.startsWith("--");function iv(n,a,i){GS(a)?n.style.setProperty(a,i):n.style[a]=i}const _S={};function vh(n,a){const i=z1(n);return()=>_S[a]??i()}const bh=vh(()=>window.ScrollTimeline!==void 0,"scrollTimeline"),rv=vh(()=>window.ViewTimeline!==void 0,"viewTimeline"),ov=vh(()=>{try{document.createElement("div").animate({opacity:0},{easing:"linear(0, 1)"})}catch{return!1}return!0},"linearEasing"),Nr=([n,a,i,r])=>`cubic-bezier(${n}, ${a}, ${i}, ${r})`,Sy={linear:"linear",ease:"ease",easeIn:"ease-in",easeOut:"ease-out",easeInOut:"ease-in-out",circIn:Nr([0,.65,.55,1]),circOut:Nr([.55,0,1,.45]),backIn:Nr([.31,.01,.66,-.59]),backOut:Nr([.33,1.53,.69,.99])};function lv(n,a){if(n)return typeof n=="function"?ov()?W1(n,a):"ease-out":I1(n)?Nr(n):Array.isArray(n)?n.map(i=>lv(i,a)||Sy.easeOut):Sy[n]}function BS(n,a,i,{delay:r=0,duration:l=300,repeat:d=0,repeatType:h="loop",ease:y="easeOut",times:p}={},m=void 0){const g={[a]:i};p&&(g.offset=p);const x=lv(y,l);Array.isArray(x)&&(g.easing=x);const b={delay:r,duration:l,easing:Array.isArray(x)?"linear":x,fill:"both",iterations:d+1,direction:h==="reverse"?"alternate":"normal"};return m&&(b.pseudoElement=m),n.animate(g,b)}function cv(n){return typeof n=="function"&&"applyToOptions"in n}function US({type:n,...a}){return cv(n)&&ov()?n.applyToOptions(a):(a.duration??(a.duration=300),a.ease??(a.ease="easeOut"),a)}class uv extends yh{constructor(a){if(super(),this.finishedTime=null,this.isStopped=!1,this.manualStartTime=null,!a)return;const{element:i,name:r,keyframes:l,pseudoElement:d,allowFlatten:h=!1,finalKeyframe:y,onComplete:p}=a;this.isPseudoElement=!!d,this.allowFlatten=h,this.options=a,rh(typeof a.type!="string");const m=US(a);this.animation=BS(i,r,l,m,d),m.autoplay===!1&&this.animation.pause(),this.animation.onfinish=()=>{if(this.finishedTime=this.time,!d){const g=fc(l,this.options,y,this.speed);this.updateMotionValue&&this.updateMotionValue(g),iv(i,r,g),this.animation.cancel()}p?.(),this.notifyFinished()}}play(){this.isStopped||(this.manualStartTime=null,this.animation.play(),this.state==="finished"&&this.updateFinished())}pause(){this.animation.pause()}complete(){this.animation.finish?.()}cancel(){try{this.animation.cancel()}catch{}}stop(){if(this.isStopped)return;this.isStopped=!0;const{state:a}=this;a==="idle"||a==="finished"||(this.updateMotionValue?this.updateMotionValue():this.commitStyles(),this.isPseudoElement||this.cancel())}commitStyles(){const a=this.options?.element;!this.isPseudoElement&&a?.isConnected&&this.animation.commitStyles?.()}get duration(){const a=this.animation.effect?.getComputedTiming?.().duration||0;return xn(Number(a))}get iterationDuration(){const{delay:a=0}=this.options||{};return this.duration+xn(a)}get time(){return xn(Number(this.animation.currentTime)||0)}set time(a){const i=this.finishedTime!==null;this.manualStartTime=null,this.finishedTime=null,this.animation.currentTime=on(a),i&&this.animation.pause()}get speed(){return this.animation.playbackRate}set speed(a){a<0&&(this.finishedTime=null),this.animation.playbackRate=a}get state(){return this.finishedTime!==null?"finished":this.animation.playState}get startTime(){return this.manualStartTime??Number(this.animation.startTime)}set startTime(a){this.manualStartTime=this.animation.startTime=a}attachTimeline({timeline:a,rangeStart:i,rangeEnd:r,observe:l}){return this.allowFlatten&&this.animation.effect?.updateTiming({easing:"linear"}),this.animation.onfinish=null,a&&bh()?(this.animation.timeline=a,i&&(this.animation.rangeStart=i),r&&(this.animation.rangeEnd=r),$t):l(this)}}const dv={anticipate:B1,backInOut:_1,circInOut:H1};function HS(n){return n in dv}function FS(n){typeof n.ease=="string"&&HS(n.ease)&&(n.ease=dv[n.ease])}const Zd=10;class IS extends uv{constructor(a){FS(a),nv(a),super(a),a.startTime!==void 0&&a.autoplay!==!1&&(this.startTime=a.startTime),this.options=a}updateMotionValue(a){const{motionValue:i,onUpdate:r,onComplete:l,element:d,...h}=this.options;if(!i)return;if(a!==void 0){i.set(a);return}const y=new Gr({...h,autoplay:!1}),p=Math.max(Zd,Gt.now()-this.startTime),m=Dn(0,Zd,p-Zd),g=y.sample(p).value,{name:x}=this.options;d&&x&&iv(d,x,g),i.setWithVelocity(y.sample(Math.max(0,p-m)).value,g,m),y.stop()}}const jy=(n,a)=>a==="zIndex"?!1:!!(typeof n=="number"||Array.isArray(n)||typeof n=="string"&&(kn.test(n)||n==="0")&&!n.startsWith("url("));function PS(n){const a=n[0];if(n.length===1)return!0;for(let i=0;i<n.length;i++)if(n[i]!==a)return!0}function YS(n,a,i,r){const l=n[0];if(l===null)return!1;if(a==="display"||a==="visibility")return!0;const d=n[n.length-1],h=jy(l,a),y=jy(d,a);return!h||!y?!1:PS(n)||(i==="spring"||cv(i))&&r}function Cf(n){n.duration=0,n.type="keyframes"}const fv=new Set(["opacity","clipPath","filter","transform"]),qS=/^(?:oklch|oklab|lab|lch|color|color-mix|light-dark)\(/;function XS(n){for(let a=0;a<n.length;a++)if(typeof n[a]=="string"&&qS.test(n[a]))return!0;return!1}const $S=new Set(["color","backgroundColor","outlineColor","fill","stroke","borderColor","borderTopColor","borderRightColor","borderBottomColor","borderLeftColor"]),QS=z1(()=>Object.hasOwnProperty.call(Element.prototype,"animate"));function ZS(n){const{motionValue:a,name:i,repeatDelay:r,repeatType:l,damping:d,type:h,keyframes:y}=n;if(!(a?.owner?.current instanceof HTMLElement))return!1;const{onUpdate:m,transformTemplate:g}=a.owner.getProps();return QS()&&i&&(fv.has(i)||$S.has(i)&&XS(y))&&(i!=="transform"||!g)&&!m&&!r&&l!=="mirror"&&d!==0&&h!=="inertia"}const KS=40;class JS extends yh{constructor({autoplay:a=!0,delay:i=0,type:r="keyframes",repeat:l=0,repeatDelay:d=0,repeatType:h="loop",keyframes:y,name:p,motionValue:m,element:g,...x}){super(),this.stop=()=>{this._animation&&(this._animation.stop(),this.stopTimeline?.()),this.keyframeResolver?.cancel()},this.createdAt=Gt.now();const b={autoplay:a,delay:i,type:r,repeat:l,repeatDelay:d,repeatType:h,name:p,motionValue:m,element:g,...x},M=g?.KeyframeResolver||xh;this.keyframeResolver=new M(y,(S,T,j)=>this.onKeyframesResolved(S,T,b,!j),p,m,g),this.keyframeResolver?.scheduleResolve()}onKeyframesResolved(a,i,r,l){this.keyframeResolver=void 0;const{name:d,type:h,velocity:y,delay:p,isHandoff:m,onUpdate:g}=r;this.resolvedAt=Gt.now();let x=!0;YS(a,d,h,y)||(x=!1,(Ya.instantAnimations||!p)&&g?.(fc(a,r,i)),a[0]=a[a.length-1],Cf(r),r.repeat=0);const M={startTime:l?this.resolvedAt?this.resolvedAt-this.createdAt>KS?this.resolvedAt:this.createdAt:this.createdAt:void 0,finalKeyframe:i,...r,keyframes:a},S=x&&!m&&ZS(M),T=M.motionValue?.owner?.current;let j;if(S)try{j=new IS({...M,element:T})}catch{j=new Gr(M)}else j=new Gr(M);j.finished.then(()=>{this.notifyFinished()}).catch($t),this.pendingTimeline&&(this.stopTimeline=j.attachTimeline(this.pendingTimeline),this.pendingTimeline=void 0),this._animation=j}get finished(){return this._animation?this.animation.finished:this._finished}then(a,i){return this.finished.finally(a).then(()=>{})}get animation(){return this._animation||(this.keyframeResolver?.resume(),LS()),this._animation}get duration(){return this.animation.duration}get iterationDuration(){return this.animation.iterationDuration}get time(){return this.animation.time}set time(a){this.animation.time=a}get speed(){return this.animation.speed}get state(){return this.animation.state}set speed(a){this.animation.speed=a}get startTime(){return this.animation.startTime}attachTimeline(a){return this._animation?this.stopTimeline=this.animation.attachTimeline(a):this.pendingTimeline=a,()=>this.stop()}play(){this.animation.play()}pause(){this.animation.pause()}complete(){this.animation.complete()}cancel(){this._animation&&this.animation.cancel(),this.keyframeResolver?.cancel()}}function hv(n,a,i,r=0,l=1){const d=Array.from(n).sort((m,g)=>m.sortNodePosition(g)).indexOf(a),h=n.size,y=(h-1)*r;return typeof i=="function"?i(d,h):l===1?d*r:y-d*r}const My=30,WS=n=>!isNaN(parseFloat(n)),kr={current:void 0};class e4{constructor(a,i={}){this.canTrackVelocity=null,this.events={},this.updateAndNotify=r=>{const l=Gt.now();if(this.updatedAt!==l&&this.setPrevFrameValue(),this.prev=this.current,this.setCurrent(r),this.current!==this.prev&&(this.events.change?.notify(this.current),this.dependents))for(const d of this.dependents)d.dirty()},this.hasAnimated=!1,this.setCurrent(a),this.owner=i.owner}setCurrent(a){this.current=a,this.updatedAt=Gt.now(),this.canTrackVelocity===null&&a!==void 0&&(this.canTrackVelocity=WS(this.current))}setPrevFrameValue(a=this.current){this.prevFrameValue=a,this.prevUpdatedAt=this.updatedAt}onChange(a){return this.on("change",a)}on(a,i){this.events[a]||(this.events[a]=new oh);const r=this.events[a].add(i);return a==="change"?()=>{r(),Ae.read(()=>{this.events.change.getSize()||this.stop()})}:r}clearListeners(){for(const a in this.events)this.events[a].clear()}attach(a,i){this.passiveEffect=a,this.stopPassiveEffect=i}set(a){this.passiveEffect?this.passiveEffect(a,this.updateAndNotify):this.updateAndNotify(a)}setWithVelocity(a,i,r){this.set(i),this.prev=void 0,this.prevFrameValue=a,this.prevUpdatedAt=this.updatedAt-r}jump(a,i=!0){this.updateAndNotify(a),this.prev=a,this.prevUpdatedAt=this.prevFrameValue=void 0,i&&this.stop(),this.stopPassiveEffect&&this.stopPassiveEffect()}dirty(){this.events.change?.notify(this.current)}addDependent(a){this.dependents||(this.dependents=new Set),this.dependents.add(a)}removeDependent(a){this.dependents&&this.dependents.delete(a)}get(){return kr.current&&kr.current.push(this),this.current}getPrevious(){return this.prev}getVelocity(){const a=Gt.now();if(!this.canTrackVelocity||this.prevFrameValue===void 0||a-this.updatedAt>My)return 0;const i=Math.min(this.updatedAt-this.prevUpdatedAt,My);return lh(parseFloat(this.current)-parseFloat(this.prevFrameValue),i)}start(a){return this.stop(),new Promise(i=>{this.hasAnimated=!0,this.animation=a(i),this.events.animationStart&&this.events.animationStart.notify()}).then(()=>{this.events.animationComplete&&this.events.animationComplete.notify(),this.clearAnimation()})}stop(){this.animation&&(this.animation.stop(),this.events.animationCancel&&this.events.animationCancel.notify()),this.clearAnimation()}isAnimating(){return!!this.animation}clearAnimation(){delete this.animation}destroy(){this.dependents?.clear(),this.events.destroy?.notify(),this.clearListeners(),this.stop(),this.stopPassiveEffect&&this.stopPassiveEffect()}}function An(n,a){return new e4(n,a)}function pv(n,a){if(n?.inherit&&a){const{inherit:i,...r}=n;return{...a,...r}}return n}function Rh(n,a){const i=n?.[a]??n?.default??n;return i!==n?pv(i,n):i}const t4={type:"spring",stiffness:500,damping:25,restSpeed:10},n4=n=>({type:"spring",stiffness:550,damping:n===0?2*Math.sqrt(550):30,restSpeed:10}),a4={type:"keyframes",duration:.8},s4={type:"keyframes",ease:[.25,.1,.35,1],duration:.3},i4=(n,{keyframes:a})=>a.length>2?a4:Mi.has(n)?n.startsWith("scale")?n4(a[1]):t4:s4,r4=new Set(["when","delay","delayChildren","staggerChildren","staggerDirection","repeat","repeatType","repeatDelay","from","elapsed"]);function o4(n){for(const a in n)if(!r4.has(a))return!0;return!1}const wh=(n,a,i,r={},l,d)=>h=>{const y=Rh(r,n)||{},p=y.delay||r.delay||0;let{elapsed:m=0}=r;m=m-on(p);const g={keyframes:Array.isArray(i)?i:[null,i],ease:"easeOut",velocity:a.getVelocity(),...y,delay:-m,onUpdate:b=>{a.set(b),y.onUpdate&&y.onUpdate(b)},onComplete:()=>{h(),y.onComplete&&y.onComplete()},name:n,motionValue:a,element:d?void 0:l};o4(y)||Object.assign(g,i4(n,g)),g.duration&&(g.duration=on(g.duration)),g.repeatDelay&&(g.repeatDelay=on(g.repeatDelay)),g.from!==void 0&&(g.keyframes[0]=g.from);let x=!1;if((g.type===!1||g.duration===0&&!g.repeatDelay)&&(Cf(g),g.delay===0&&(x=!0)),(Ya.instantAnimations||Ya.skipAnimations||l?.shouldSkipAnimations||y.skipAnimations)&&(x=!0,Cf(g),g.delay=0),g.allowFlatten=!y.type&&!y.ease,x&&!d&&a.get()!==void 0){const b=fc(g.keyframes,y);if(b!==void 0){Ae.update(()=>{g.onUpdate(b),g.onComplete()});return}}return y.isSync?new Gr(g):new JS(g)},l4=/^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;function c4(n){const a=l4.exec(n);if(!a)return[,];const[,i,r,l]=a;return[`--${i??r}`,l]}function mv(n,a,i=1){const[r,l]=c4(n);if(!r)return;const d=window.getComputedStyle(a).getPropertyValue(r);if(d){const h=d.trim();return C1(h)?parseFloat(h):h}return dh(l)?mv(l,a,i+1):l}function Ty(n){const a=[{},{}];return n?.values.forEach((i,r)=>{a[0][r]=i.get(),a[1][r]=i.getVelocity()}),a}function Sh(n,a,i,r){if(typeof a=="function"){const[l,d]=Ty(r);a=a(i!==void 0?i:n.custom,l,d)}if(typeof a=="string"&&(a=n.variants&&n.variants[a]),typeof a=="function"){const[l,d]=Ty(r);a=a(i!==void 0?i:n.custom,l,d)}return a}function bs(n,a,i){const r=n.getProps();return Sh(r,a,i!==void 0?i:r.custom,n)}const gv=new Set(["width","height","top","left","right","bottom",...ji]),kf=n=>Array.isArray(n);function u4(n,a,i){n.hasValue(a)?n.getValue(a).set(i):n.addValue(a,An(i))}function d4(n){return kf(n)?n[n.length-1]||0:n}function f4(n,a){const i=bs(n,a);let{transitionEnd:r={},transition:l={},...d}=i||{};d={...d,...r};for(const h in d){const y=d4(d[h]);u4(n,h,y)}}const yt=n=>!!(n&&n.getVelocity);function h4(n){return!!(yt(n)&&n.add)}function Df(n,a){const i=n.getValue("willChange");if(h4(i))return i.add(a);if(!i&&Ya.WillChange){const r=new Ya.WillChange("auto");n.addValue("willChange",r),r.add(a)}}function jh(n){return n.replace(/([A-Z])/g,a=>`-${a.toLowerCase()}`)}const p4="framerAppearId",yv="data-"+jh(p4);function xv(n){return n.props[yv]}function m4({protectedKeys:n,needsAnimating:a},i){const r=n.hasOwnProperty(i)&&a[i]!==!0;return a[i]=!1,r}function vv(n,a,{delay:i=0,transitionOverride:r,type:l}={}){let{transition:d,transitionEnd:h,...y}=a;const p=n.getDefaultTransition();d=d?pv(d,p):p;const m=d?.reduceMotion,g=d?.skipAnimations;r&&(d=r);const x=[],b=l&&n.animationState&&n.animationState.getState()[l],M=d?.path;M&&M.animateVisualElement(n,y,d,i,x);for(const S in y){const T=n.getValue(S,n.latestValues[S]??null),j=y[S];if(j===void 0||b&&m4(b,S))continue;const O={delay:i,...Rh(d||{},S)};g&&(O.skipAnimations=!0);const L=T.get();if(L!==void 0&&!T.isAnimating()&&!Array.isArray(j)&&j===L&&!O.velocity){Ae.update(()=>T.set(j));continue}let z=!1;if(window.MotionHandoffAnimation){const J=xv(n);if(J){const Q=window.MotionHandoffAnimation(J,S,Ae);Q!==null&&(O.startTime=Q,z=!0)}}Df(n,S);const D=m??n.shouldReduceMotion;T.start(wh(S,T,j,D&&gv.has(S)?{type:!1}:O,n,z));const X=T.animation;X&&x.push(X)}if(h){const S=()=>Ae.update(()=>{h&&f4(n,h)});x.length?Promise.all(x).then(S):S()}return x}function zf(n,a,i={}){const r=bs(n,a,i.type==="exit"?n.presenceContext?.custom:void 0);let{transition:l=n.getDefaultTransition()||{}}=r||{};i.transitionOverride&&(l=i.transitionOverride);const d=r?()=>Promise.all(vv(n,r,i)):()=>Promise.resolve(),h=n.variantChildren&&n.variantChildren.size?(p=0)=>{const{delayChildren:m=0,staggerChildren:g,staggerDirection:x}=l;return g4(n,a,p,m,g,x,i)}:()=>Promise.resolve(),{when:y}=l;if(y){const[p,m]=y==="beforeChildren"?[d,h]:[h,d];return p().then(()=>m())}else return Promise.all([d(),h(i.delay)])}function g4(n,a,i=0,r=0,l=0,d=1,h){const y=[];for(const p of n.variantChildren)p.notify("AnimationStart",a),y.push(zf(p,a,{...h,delay:i+(typeof r=="function"?0:r)+hv(n.variantChildren,p,r,l,d)}).then(()=>p.notify("AnimationComplete",a)));return Promise.all(y)}function y4(n,a,i={}){n.notify("AnimationStart",a);let r;if(Array.isArray(a)){const l=a.map(d=>zf(n,d,i));r=Promise.all(l)}else if(typeof a=="string")r=zf(n,a,i);else{const l=typeof a=="function"?bs(n,a,i.custom):a;r=Promise.all(vv(n,l,i))}return r.then(()=>{n.notify("AnimationComplete",a)})}const x4={test:n=>n==="auto",parse:n=>n},bv=n=>a=>a.test(n),Rv=[Si,se,Fn,ua,Xw,qw,x4],Ny=n=>Rv.find(bv(n));function v4(n){return typeof n=="number"?n===0:n!==null?n==="none"||n==="0"||D1(n):!0}const b4=new Set(["brightness","contrast","saturate","opacity"]);function R4(n){const[a,i]=n.slice(0,-1).split("(");if(a==="drop-shadow")return n;const[r]=i.match(fh)||[];if(!r)return n;const l=i.replace(r,"");let d=b4.has(a)?1:0;return r!==i&&(d*=100),a+"("+d+l+")"}const w4=/\b([a-z-]*)\(.*?\)/gu,Vf={...kn,getAnimatableNone:n=>{const a=n.match(w4);return a?a.map(R4).join(" "):n}},Of={...kn,getAnimatableNone:n=>{const a=kn.parse(n);return kn.createTransformer(n)(a.map(r=>typeof r=="number"?0:typeof r=="object"?{...r,alpha:1}:r))}},Ey={...Si,transform:Math.round},S4={rotate:ua,pathRotation:ua,rotateX:ua,rotateY:ua,rotateZ:ua,scale:Sl,scaleX:Sl,scaleY:Sl,scaleZ:Sl,skew:ua,skewX:ua,skewY:ua,distance:se,translateX:se,translateY:se,translateZ:se,x:se,y:se,z:se,perspective:se,transformPerspective:se,opacity:Lr,originX:py,originY:py,originZ:se},Kl={borderWidth:se,borderTopWidth:se,borderRightWidth:se,borderBottomWidth:se,borderLeftWidth:se,borderRadius:se,borderTopLeftRadius:se,borderTopRightRadius:se,borderBottomRightRadius:se,borderBottomLeftRadius:se,width:se,maxWidth:se,height:se,maxHeight:se,top:se,right:se,bottom:se,left:se,inset:se,insetBlock:se,insetBlockStart:se,insetBlockEnd:se,insetInline:se,insetInlineStart:se,insetInlineEnd:se,padding:se,paddingTop:se,paddingRight:se,paddingBottom:se,paddingLeft:se,paddingBlock:se,paddingBlockStart:se,paddingBlockEnd:se,paddingInline:se,paddingInlineStart:se,paddingInlineEnd:se,margin:se,marginTop:se,marginRight:se,marginBottom:se,marginLeft:se,marginBlock:se,marginBlockStart:se,marginBlockEnd:se,marginInline:se,marginInlineStart:se,marginInlineEnd:se,fontSize:se,backgroundPositionX:se,backgroundPositionY:se,...S4,zIndex:Ey,fillOpacity:Lr,strokeOpacity:Lr,numOctaves:Ey},j4={...Kl,color:dt,backgroundColor:dt,outlineColor:dt,fill:dt,stroke:dt,borderColor:dt,borderTopColor:dt,borderRightColor:dt,borderBottomColor:dt,borderLeftColor:dt,filter:Vf,WebkitFilter:Vf,mask:Of,WebkitMask:Of},wv=n=>j4[n],M4=new Set([Vf,Of]);function Sv(n,a){let i=wv(n);return M4.has(i)||(i=kn),i.getAnimatableNone?i.getAnimatableNone(a):void 0}const T4=new Set(["auto","none","0"]);function N4(n,a,i){let r=0,l;for(;r<n.length&&!l;){const d=n[r];typeof d=="string"&&!T4.has(d)&&vi(d).values.length&&(l=n[r]),r++}if(l&&i)for(const d of a)n[d]=Sv(i,l)}class E4 extends xh{constructor(a,i,r,l,d){super(a,i,r,l,d,!0)}readKeyframes(){const{unresolvedKeyframes:a,element:i,name:r}=this;if(!i||!i.current)return;super.readKeyframes();for(let g=0;g<a.length;g++){let x=a[g];if(typeof x=="string"&&(x=x.trim(),dh(x))){const b=mv(x,i.current);b!==void 0&&(a[g]=b),g===a.length-1&&(this.finalKeyframe=x)}}if(this.resolveNoneKeyframes(),!gv.has(r)||a.length!==2)return;const[l,d]=a,h=Ny(l),y=Ny(d),p=hy(l),m=hy(d);if(p!==m&&Ia[r]){this.needsMeasurement=!0;return}if(h!==y)if(wy(h)&&wy(y))for(let g=0;g<a.length;g++){const x=a[g];typeof x=="string"&&(a[g]=parseFloat(x))}else Ia[r]&&(this.needsMeasurement=!0)}resolveNoneKeyframes(){const{unresolvedKeyframes:a,name:i}=this,r=[];for(let l=0;l<a.length;l++)(a[l]===null||v4(a[l]))&&r.push(l);r.length&&N4(a,r,i)}measureInitialState(){const{element:a,unresolvedKeyframes:i,name:r}=this;if(!a||!a.current)return;r==="height"&&(this.suspendedScrollY=window.pageYOffset),this.measuredOrigin=Ia[r](a.measureViewportBox(),window.getComputedStyle(a.current)),i[0]=this.measuredOrigin;const l=i[i.length-1];l!==void 0&&a.getValue(r,l).jump(l,!1)}measureEndState(){const{element:a,name:i,unresolvedKeyframes:r}=this;if(!a||!a.current)return;const l=a.getValue(i);l&&l.jump(this.measuredOrigin,!1);const d=r.length-1,h=r[d];r[d]=Ia[i](a.measureViewportBox(),window.getComputedStyle(a.current)),h!==null&&this.finalKeyframe===void 0&&(this.finalKeyframe=h),this.removedTransforms?.length&&this.removedTransforms.forEach(([y,p])=>{a.getValue(y).set(p)}),this.resolveNoneKeyframes()}}const Mh=["borderTopLeftRadius","borderTopRightRadius","borderBottomRightRadius","borderBottomLeftRadius"];function jv(n,a,i){if(n==null)return[];if(n instanceof EventTarget)return[n];if(typeof n=="string"){const l=document.querySelectorAll(n);return l?Array.from(l):[]}return Array.from(n).filter(r=>r!=null)}const Lf=(n,a)=>a&&typeof n=="number"?a.transform(n):n;function Dr(n){return k1(n)&&"offsetHeight"in n&&!("ownerSVGElement"in n)}const{schedule:bi,cancel:Mv}=P1(queueMicrotask,!1),Tn={x:!1,y:!1};function Tv(){return Tn.x||Tn.y}function A4(n){return n==="x"||n==="y"?Tn[n]?null:(Tn[n]=!0,()=>{Tn[n]=!1}):Tn.x||Tn.y?null:(Tn.x=Tn.y=!0,()=>{Tn.x=Tn.y=!1})}function Nv(n,a){const i=jv(n),r=new AbortController,l={passive:!0,...a,signal:r.signal};return[i,l,()=>r.abort()]}function C4(n){return!(n.pointerType==="touch"||Tv())}function k4(n,a,i={}){const[r,l,d]=Nv(n,i);return r.forEach(h=>{let y=!1,p=!1,m;const g=()=>{h.removeEventListener("pointerleave",S)},x=j=>{m&&(m(j),m=void 0),g()},b=j=>{y=!1,window.removeEventListener("pointerup",b),window.removeEventListener("pointercancel",b),p&&(p=!1,x(j))},M=()=>{y=!0,window.addEventListener("pointerup",b,l),window.addEventListener("pointercancel",b,l)},S=j=>{if(j.pointerType!=="touch"){if(y){p=!0;return}x(j)}},T=j=>{if(!C4(j))return;p=!1;const O=a(h,j);typeof O=="function"&&(m=O,h.addEventListener("pointerleave",S,l))};h.addEventListener("pointerenter",T,l),h.addEventListener("pointerdown",M,l)}),d}const Ev=(n,a)=>a?n===a?!0:Ev(n,a.parentElement):!1,Th=n=>n.pointerType==="mouse"?typeof n.button!="number"||n.button<=0:n.isPrimary!==!1,D4=new Set(["BUTTON","INPUT","SELECT","TEXTAREA","A"]);function z4(n){return D4.has(n.tagName)||n.isContentEditable===!0}const V4=new Set(["INPUT","SELECT","TEXTAREA"]);function O4(n){return V4.has(n.tagName)||n.isContentEditable===!0}const Gl=new WeakSet;function Ay(n){return a=>{a.key==="Enter"&&n(a)}}function Kd(n,a){n.dispatchEvent(new PointerEvent("pointer"+a,{isPrimary:!0,bubbles:!0}))}const L4=(n,a)=>{const i=n.currentTarget;if(!i)return;const r=Ay(()=>{if(Gl.has(i))return;Kd(i,"down");const l=Ay(()=>{Kd(i,"up")}),d=()=>Kd(i,"cancel");i.addEventListener("keyup",l,a),i.addEventListener("blur",d,a)});i.addEventListener("keydown",r,a),i.addEventListener("blur",()=>i.removeEventListener("keydown",r),a)};function Cy(n){return Th(n)&&!Tv()}const ky=new WeakSet;function G4(n,a,i={}){const[r,l,d]=Nv(n,i),h=y=>{const p=y.currentTarget;if(!Cy(y)||ky.has(y))return;Gl.add(p),i.stopPropagation&&ky.add(y);const m=a(p,y),g={...l,capture:!0},x=(S,T)=>{window.removeEventListener("pointerup",b,g),window.removeEventListener("pointercancel",M,g),Gl.has(p)&&Gl.delete(p),Cy(S)&&typeof m=="function"&&m(S,{success:T})},b=S=>{x(S,p===window||p===document||i.useGlobalTarget||Ev(p,S.target))},M=S=>{x(S,!1)};window.addEventListener("pointerup",b,g),window.addEventListener("pointercancel",M,g)};return r.forEach(y=>{(i.useGlobalTarget?window:y).addEventListener("pointerdown",h,l),Dr(y)&&(y.addEventListener("focus",m=>L4(m,l)),!z4(y)&&!y.hasAttribute("tabindex")&&(y.tabIndex=0))}),d}function Nh(n){return k1(n)&&"ownerSVGElement"in n}const _l=new WeakMap;let Bl;const Av=(n,a,i)=>(r,l)=>l&&l[0]?l[0][n+"Size"]:Nh(r)&&"getBBox"in r?r.getBBox()[a]:r[i],_4=Av("inline","width","offsetWidth"),B4=Av("block","height","offsetHeight");function U4({target:n,borderBoxSize:a}){_l.get(n)?.forEach(i=>{i(n,{get width(){return _4(n,a)},get height(){return B4(n,a)}})})}function H4(n){n.forEach(U4)}function F4(){typeof ResizeObserver>"u"||(Bl=new ResizeObserver(H4))}function I4(n,a){Bl||F4();const i=jv(n);return i.forEach(r=>{let l=_l.get(r);l||(l=new Set,_l.set(r,l)),l.add(a),Bl?.observe(r)}),()=>{i.forEach(r=>{const l=_l.get(r);l?.delete(a),l?.size||Bl?.unobserve(r)})}}const Ul=new Set;let hi;function P4(){hi=()=>{const n={get width(){return window.innerWidth},get height(){return window.innerHeight}};Ul.forEach(a=>a(n))},window.addEventListener("resize",hi)}function Y4(n){return Ul.add(n),hi||P4(),()=>{Ul.delete(n),!Ul.size&&typeof hi=="function"&&(window.removeEventListener("resize",hi),hi=void 0)}}function Gf(n,a){return typeof n=="function"?Y4(n):I4(n,a)}function Cv(n,a){let i;const r=()=>{const{currentTime:l}=a,h=(l===null?0:l.value)/100;i!==h&&n(h),i=h};return Ae.preUpdate(r,!0),()=>bn(r)}function q4(n){return Nh(n)&&n.tagName==="svg"}function X4(...n){const a=!Array.isArray(n[0]),i=a?0:-1,r=n[0+i],l=n[1+i],d=n[2+i],h=n[3+i],y=gh(l,d,h);return a?y(r):y}function $4(n,a,i={}){const r=n.get();let l=null,d=r,h;const y=typeof r=="string"?r.replace(/[\d.-]/g,""):void 0,p=()=>{l&&(l.stop(),l=null),n.animation=void 0},m=()=>{const x=Dy(n.get()),b=Dy(d);if(x===b){p();return}const M=l?l.getGeneratorVelocity():n.getVelocity();p(),l=new Gr({keyframes:[x,b],velocity:M,type:"spring",restDelta:.001,restSpeed:.01,...i,onUpdate:h})},g=()=>{m(),n.animation=l??void 0,n.events.animationStart?.notify(),l?.then(()=>{n.animation=void 0,n.events.animationComplete?.notify()})};if(n.attach((x,b)=>{d=x,h=M=>b(Jd(M,y)),Ae.postRender(g)},p),yt(a)){let x=i.skipInitialAnimation===!0;const b=a.on("change",S=>{x?(x=!1,n.jump(Jd(S,y),!1)):n.set(Jd(S,y))}),M=n.on("destroy",b);return()=>{b(),M()}}return p}function Jd(n,a){return a?n+a:n}function Dy(n){return typeof n=="number"?n:parseFloat(n)}const Q4=[...Rv,dt,kn],Z4=n=>Q4.find(bv(n)),zy=()=>({translate:0,scale:1,origin:0,originPoint:0}),pi=()=>({x:zy(),y:zy()}),Vy=()=>({min:0,max:0}),mt=()=>({x:Vy(),y:Vy()}),K4=new WeakMap;function hc(n){return n!==null&&typeof n=="object"&&typeof n.start=="function"}function _r(n){return typeof n=="string"||Array.isArray(n)}const Eh=["animate","whileInView","whileFocus","whileHover","whileTap","whileDrag","exit"],Ah=["initial",...Eh];function pc(n){return hc(n.animate)||Ah.some(a=>_r(n[a]))}function kv(n){return!!(pc(n)||n.variants)}function J4(n,a,i){for(const r in a){const l=a[r],d=i[r];if(yt(l))n.addValue(r,l);else if(yt(d))n.addValue(r,An(l,{owner:n}));else if(d!==l)if(n.hasValue(r)){const h=n.getValue(r);h.liveStyle===!0?h.jump(l):h.hasAnimated||h.set(l)}else{const h=n.getStaticValue(r);n.addValue(r,An(h!==void 0?h:l,{owner:n}))}}for(const r in i)a[r]===void 0&&n.removeValue(r);return a}const _f={current:null},Dv={current:!1},W4=typeof window<"u";function e6(){if(Dv.current=!0,!!W4)if(window.matchMedia){const n=window.matchMedia("(prefers-reduced-motion)"),a=()=>_f.current=n.matches;n.addEventListener("change",a),a()}else _f.current=!1}const Oy=["AnimationStart","AnimationComplete","Update","BeforeLayoutMeasure","LayoutMeasure","LayoutAnimationStart","LayoutAnimationComplete"];let Jl={};function zv(n){Jl=n}function t6(){return Jl}class n6{scrapeMotionValuesFromProps(a,i,r){return{}}constructor({parent:a,props:i,presenceContext:r,reducedMotionConfig:l,skipAnimations:d,blockInitialAnimation:h,visualState:y},p={}){this.current=null,this.children=new Set,this.isVariantNode=!1,this.isControllingVariants=!1,this.shouldReduceMotion=null,this.shouldSkipAnimations=!1,this.values=new Map,this.KeyframeResolver=xh,this.features={},this.valueSubscriptions=new Map,this.prevMotionValues={},this.hasBeenMounted=!1,this.events={},this.propEventSubscriptions={},this.notifyUpdate=()=>this.notify("Update",this.latestValues),this.render=()=>{this.current&&(this.triggerBuild(),this.renderInstance(this.current,this.renderState,this.props.style,this.projection))},this.renderScheduledAt=0,this.scheduleRender=()=>{const M=Gt.now();this.renderScheduledAt<M&&(this.renderScheduledAt=M,Ae.render(this.render,!1,!0))};const{latestValues:m,renderState:g}=y;this.latestValues=m,this.baseTarget={...m},this.initialValues=i.initial?{...m}:{},this.renderState=g,this.parent=a,this.props=i,this.presenceContext=r,this.depth=a?a.depth+1:0,this.reducedMotionConfig=l,this.skipAnimationsConfig=d,this.options=p,this.blockInitialAnimation=!!h,this.isControllingVariants=pc(i),this.isVariantNode=kv(i),this.isVariantNode&&(this.variantChildren=new Set),this.manuallyAnimateOnMount=!!(a&&a.current);const{willChange:x,...b}=this.scrapeMotionValuesFromProps(i,{},this);for(const M in b){const S=b[M];m[M]!==void 0&&yt(S)&&S.set(m[M])}}mount(a){if(this.hasBeenMounted)for(const i in this.initialValues)this.values.get(i)?.jump(this.initialValues[i]),this.latestValues[i]=this.initialValues[i];this.current=a,K4.set(a,this),this.projection&&!this.projection.instance&&this.projection.mount(a),this.parent&&this.isVariantNode&&!this.isControllingVariants&&(this.removeFromVariantTree=this.parent.addVariantChild(this)),this.values.forEach((i,r)=>this.bindToMotionValue(r,i)),this.reducedMotionConfig==="never"?this.shouldReduceMotion=!1:this.reducedMotionConfig==="always"?this.shouldReduceMotion=!0:(Dv.current||e6(),this.shouldReduceMotion=_f.current),this.shouldSkipAnimations=this.skipAnimationsConfig??!1,this.parent?.addChild(this),this.update(this.props,this.presenceContext),this.hasBeenMounted=!0}unmount(){this.projection&&this.projection.unmount(),bn(this.notifyUpdate),bn(this.render),this.valueSubscriptions.forEach(a=>a()),this.valueSubscriptions.clear(),this.removeFromVariantTree&&this.removeFromVariantTree(),this.parent?.removeChild(this);for(const a in this.events)this.events[a].clear();for(const a in this.features){const i=this.features[a];i&&(i.unmount(),i.isMounted=!1)}this.current=null}addChild(a){this.children.add(a),this.enteringChildren??(this.enteringChildren=new Set),this.enteringChildren.add(a)}removeChild(a){this.children.delete(a),this.enteringChildren&&this.enteringChildren.delete(a)}bindToMotionValue(a,i){if(this.valueSubscriptions.has(a)&&this.valueSubscriptions.get(a)(),i.accelerate&&fv.has(a)&&this.current instanceof HTMLElement){const{factory:h,keyframes:y,times:p,ease:m,duration:g}=i.accelerate,x=new uv({element:this.current,name:a,keyframes:y,times:p,ease:m,duration:on(g)}),b=h(x);this.valueSubscriptions.set(a,()=>{b(),x.cancel()});return}const r=Mi.has(a);r&&this.onBindTransform&&this.onBindTransform();const l=i.on("change",h=>{this.latestValues[a]=h,this.props.onUpdate&&Ae.preRender(this.notifyUpdate),r&&this.projection&&(this.projection.isTransformDirty=!0),this.scheduleRender()});let d;typeof window<"u"&&window.MotionCheckAppearSync&&(d=window.MotionCheckAppearSync(this,a,i)),this.valueSubscriptions.set(a,()=>{l(),d&&d()})}sortNodePosition(a){return!this.current||!this.sortInstanceNodePosition||this.type!==a.type?0:this.sortInstanceNodePosition(this.current,a.current)}updateFeatures(){let a="animation";for(a in Jl){const i=Jl[a];if(!i)continue;const{isEnabled:r,Feature:l}=i;if(!this.features[a]&&l&&r(this.props)&&(this.features[a]=new l(this)),this.features[a]){const d=this.features[a];d.isMounted?d.update():(d.mount(),d.isMounted=!0)}}}triggerBuild(){this.build(this.renderState,this.latestValues,this.props)}measureViewportBox(){return this.current?this.measureInstanceViewportBox(this.current,this.props):mt()}getStaticValue(a){return this.latestValues[a]}setStaticValue(a,i){this.latestValues[a]=i}update(a,i){(a.transformTemplate||this.props.transformTemplate)&&this.scheduleRender(),this.prevProps=this.props,this.props=a,this.prevPresenceContext=this.presenceContext,this.presenceContext=i;for(let r=0;r<Oy.length;r++){const l=Oy[r];this.propEventSubscriptions[l]&&(this.propEventSubscriptions[l](),delete this.propEventSubscriptions[l]);const d="on"+l,h=a[d];h&&(this.propEventSubscriptions[l]=this.on(l,h))}this.prevMotionValues=J4(this,this.scrapeMotionValuesFromProps(a,this.prevProps||{},this),this.prevMotionValues),this.handleChildMotionValue&&this.handleChildMotionValue()}getProps(){return this.props}getVariant(a){return this.props.variants?this.props.variants[a]:void 0}getDefaultTransition(){return this.props.transition}getTransformPagePoint(){return this.props.transformPagePoint}getClosestVariantNode(){return this.isVariantNode?this:this.parent?this.parent.getClosestVariantNode():void 0}addVariantChild(a){const i=this.getClosestVariantNode();if(i)return i.variantChildren&&i.variantChildren.add(a),()=>i.variantChildren.delete(a)}addValue(a,i){const r=this.values.get(a);i!==r&&(r&&this.removeValue(a),this.bindToMotionValue(a,i),this.values.set(a,i),this.latestValues[a]=i.get())}removeValue(a){this.values.delete(a);const i=this.valueSubscriptions.get(a);i&&(i(),this.valueSubscriptions.delete(a)),delete this.latestValues[a],this.removeValueFromRenderState(a,this.renderState)}hasValue(a){return this.values.has(a)}getValue(a,i){if(this.props.values&&this.props.values[a])return this.props.values[a];let r=this.values.get(a);return r===void 0&&i!==void 0&&(r=An(i===null?void 0:i,{owner:this}),this.addValue(a,r)),r}readValue(a,i){let r=this.latestValues[a]!==void 0||!this.current?this.latestValues[a]:this.getBaseTargetFromProps(this.props,a)??this.readValueFromInstance(this.current,a,this.options);return r!=null&&(typeof r=="string"&&(C1(r)||D1(r))?r=parseFloat(r):!Z4(r)&&kn.test(i)&&(r=Sv(a,i)),this.setBaseTarget(a,yt(r)?r.get():r)),yt(r)?r.get():r}setBaseTarget(a,i){this.baseTarget[a]=i}getBaseTarget(a){const{initial:i}=this.props;let r;if(typeof i=="string"||typeof i=="object"){const d=Sh(this.props,i,this.presenceContext?.custom);d&&(r=d[a])}if(i&&r!==void 0)return r;const l=this.getBaseTargetFromProps(this.props,a);return l!==void 0&&!yt(l)?l:this.initialValues[a]!==void 0&&r===void 0?void 0:this.baseTarget[a]}on(a,i){return this.events[a]||(this.events[a]=new oh),this.events[a].add(i)}notify(a,...i){this.events[a]&&this.events[a].notify(...i)}scheduleRenderMicrotask(){bi.render(this.render)}}class Vv extends n6{constructor(){super(...arguments),this.KeyframeResolver=E4}sortInstanceNodePosition(a,i){return a.compareDocumentPosition(i)&2?1:-1}getBaseTargetFromProps(a,i){const r=a.style;return r?r[i]:void 0}removeValueFromRenderState(a,{vars:i,style:r}){delete i[a],delete r[a]}handleChildMotionValue(){this.childSubscription&&(this.childSubscription(),delete this.childSubscription);const{children:a}=this.props;yt(a)&&(this.childSubscription=a.on("change",i=>{this.current&&(this.current.textContent=`${i}`)}))}}class qa{constructor(a){this.isMounted=!1,this.node=a}update(){}}function Ov({top:n,left:a,right:i,bottom:r}){return{x:{min:a,max:i},y:{min:n,max:r}}}function a6({x:n,y:a}){return{top:a.min,right:n.max,bottom:a.max,left:n.min}}function s6(n,a){if(!a)return n;const i=a({x:n.left,y:n.top}),r=a({x:n.right,y:n.bottom});return{top:i.y,left:i.x,bottom:r.y,right:r.x}}function Wd(n){return n===void 0||n===1}function Bf({scale:n,scaleX:a,scaleY:i}){return!Wd(n)||!Wd(a)||!Wd(i)}function ms(n){return Bf(n)||Lv(n)||n.z||n.rotate||n.rotateX||n.rotateY||n.skewX||n.skewY}function Lv(n){return Ly(n.x)||Ly(n.y)}function Ly(n){return n&&n!=="0%"}function Wl(n,a,i){const r=n-i,l=a*r;return i+l}function Gy(n,a,i,r,l){return l!==void 0&&(n=Wl(n,l,r)),Wl(n,i,r)+a}function Uf(n,a=0,i=1,r,l){n.min=Gy(n.min,a,i,r,l),n.max=Gy(n.max,a,i,r,l)}function Gv(n,{x:a,y:i}){Uf(n.x,a.translate,a.scale,a.originPoint),Uf(n.y,i.translate,i.scale,i.originPoint)}const _y=.999999999999,By=1.0000000000001;function i6(n,a,i,r=!1){const l=i.length;if(!l)return;a.x=a.y=1;let d,h;for(let y=0;y<l;y++){d=i[y],h=d.projectionDelta;const{visualElement:p}=d.options;p&&p.props.style&&p.props.style.display==="contents"||(r&&d.options.layoutScroll&&d.scroll&&d!==d.root&&(Un(n.x,-d.scroll.offset.x),Un(n.y,-d.scroll.offset.y)),h&&(a.x*=h.x.scale,a.y*=h.y.scale,Gv(n,h)),r&&ms(d.latestValues)&&Hl(n,d.latestValues,d.layout?.layoutBox))}a.x<By&&a.x>_y&&(a.x=1),a.y<By&&a.y>_y&&(a.y=1)}function Un(n,a){n.min+=a,n.max+=a}function Uy(n,a,i,r,l=.5){const d=Ue(n.min,n.max,l);Uf(n,a,i,d,r)}function Hy(n,a){return typeof n=="string"?parseFloat(n)/100*(a.max-a.min):n}function Hl(n,a,i){const r=i??n;Uy(n.x,Hy(a.x,r.x),a.scaleX,a.scale,a.originX),Uy(n.y,Hy(a.y,r.y),a.scaleY,a.scale,a.originY)}function _v(n,a){return Ov(s6(n.getBoundingClientRect(),a))}function r6(n,a,i){const r=_v(n,i),{scroll:l}=a;return l&&(Un(r.x,l.offset.x),Un(r.y,l.offset.y)),r}const o6={x:"translateX",y:"translateY",z:"translateZ",transformPerspective:"perspective"},l6=ji.length;function c6(n,a,i){let r="",l=!0;for(let h=0;h<l6;h++){const y=ji[h],p=n[y];if(p===void 0)continue;let m=!0;if(typeof p=="number")m=p===(y.startsWith("scale")?1:0);else{const g=parseFloat(p);m=y.startsWith("scale")?g===1:g===0}if(!m||i){const g=Lf(p,Kl[y]);if(!m){l=!1;const x=o6[y]||y;r+=`${x}(${g}) `}i&&(a[y]=g)}}const d=n.pathRotation;return d&&(l=!1,r+=`rotate(${Lf(d,Kl.pathRotation)}) `),r=r.trim(),i?r=i(a,l?"":r):l&&(r="none"),r}function Ch(n,a,i){const{style:r,vars:l,transformOrigin:d}=n;let h=!1,y=!1;for(const p in a){const m=a[p];if(Mi.has(p)){h=!0;continue}else if(q1(p)){l[p]=m;continue}else{const g=Lf(m,Kl[p]);p.startsWith("origin")?(y=!0,d[p]=g):r[p]=g}}if(a.transform||(h||i?r.transform=c6(a,n.transform,i):r.transform&&(r.transform="none")),y){const{originX:p="50%",originY:m="50%",originZ:g=0}=d;r.transformOrigin=`${p} ${m} ${g}`}}function Bv(n,{style:a,vars:i},r,l){const d=n.style;let h;for(h in a)d[h]=a[h];l?.applyProjectionStyles(d,r);for(h in i)d.setProperty(h,i[h])}function Fy(n,a){return a.max===a.min?0:n/(a.max-a.min)*100}const jr={correct:(n,a)=>{if(!a.target)return n;if(typeof n=="string")if(se.test(n))n=parseFloat(n);else return n;const i=Fy(n,a.target.x),r=Fy(n,a.target.y);return`${i}% ${r}%`}},u6={correct:(n,{treeScale:a,projectionDelta:i})=>{const r=n,l=kn.parse(n);if(l.length>5)return r;const d=kn.createTransformer(n),h=typeof l[0]!="number"?1:0,y=i.x.scale*a.x,p=i.y.scale*a.y;l[0+h]/=y,l[1+h]/=p;const m=Ue(y,p,.5);return typeof l[2+h]=="number"&&(l[2+h]/=m),typeof l[3+h]=="number"&&(l[3+h]/=m),d(l)}},Hf={borderRadius:{...jr,applyTo:[...Mh]},borderTopLeftRadius:jr,borderTopRightRadius:jr,borderBottomLeftRadius:jr,borderBottomRightRadius:jr,boxShadow:u6};function Uv(n,{layout:a,layoutId:i}){return Mi.has(n)||n.startsWith("origin")||(a||i!==void 0)&&(!!Hf[n]||n==="opacity")}function kh(n,a,i){const r=n.style,l=a?.style,d={};if(!r)return d;for(const h in r)(yt(r[h])||l&&yt(l[h])||Uv(h,n)||i?.getValue(h)?.liveStyle!==void 0)&&(d[h]=r[h]);return d}function d6(n){return window.getComputedStyle(n)}class f6 extends Vv{constructor(){super(...arguments),this.type="html",this.renderInstance=Bv}readValueFromInstance(a,i){if(Mi.has(i))return this.projection?.isProjecting?Mf(i):kS(a,i);{const r=d6(a),l=(q1(i)?r.getPropertyValue(i):r[i])||0;return typeof l=="string"?l.trim():l}}measureInstanceViewportBox(a,{transformPagePoint:i}){return _v(a,i)}build(a,i,r){Ch(a,i,r.transformTemplate)}scrapeMotionValuesFromProps(a,i,r){return kh(a,i,r)}}const h6={offset:"stroke-dashoffset",array:"stroke-dasharray"},p6={offset:"strokeDashoffset",array:"strokeDasharray"};function m6(n,a,i=1,r=0,l=!0){n.pathLength=1;const d=l?h6:p6;n[d.offset]=`${-r}`,n[d.array]=`${a} ${i}`}const g6=["offsetDistance","offsetPath","offsetRotate","offsetAnchor"];function Hv(n,{attrX:a,attrY:i,attrScale:r,pathLength:l,pathSpacing:d=1,pathOffset:h=0,...y},p,m,g){if(Ch(n,y,m),p){n.style.viewBox&&(n.attrs.viewBox=n.style.viewBox);return}n.attrs=n.style,n.style={};const{attrs:x,style:b}=n;x.transform&&(b.transform=x.transform,delete x.transform),(b.transform||x.transformOrigin)&&(b.transformOrigin=x.transformOrigin??"50% 50%",delete x.transformOrigin),b.transform&&(b.transformBox=g?.transformBox??"fill-box",delete x.transformBox);for(const M of g6)x[M]!==void 0&&(b[M]=x[M],delete x[M]);a!==void 0&&(x.x=a),i!==void 0&&(x.y=i),r!==void 0&&(x.scale=r),l!==void 0&&m6(x,l,d,h,!1)}const Fv=new Set(["baseFrequency","diffuseConstant","kernelMatrix","kernelUnitLength","keySplines","keyTimes","limitingConeAngle","markerHeight","markerWidth","numOctaves","targetX","targetY","surfaceScale","specularConstant","specularExponent","stdDeviation","tableValues","viewBox","gradientTransform","pathLength","startOffset","textLength","lengthAdjust"]),Iv=n=>typeof n=="string"&&n.toLowerCase()==="svg";function y6(n,a,i,r){Bv(n,a,void 0,r);for(const l in a.attrs)n.setAttribute(Fv.has(l)?l:jh(l),a.attrs[l])}function Pv(n,a,i){const r=kh(n,a,i);for(const l in n)if(yt(n[l])||yt(a[l])){const d=ji.indexOf(l)!==-1?"attr"+l.charAt(0).toUpperCase()+l.substring(1):l;r[d]=n[l]}return r}class x6 extends Vv{constructor(){super(...arguments),this.type="svg",this.isSVGTag=!1,this.measureInstanceViewportBox=mt}getBaseTargetFromProps(a,i){return a[i]}readValueFromInstance(a,i){if(Mi.has(i)){const r=wv(i);return r&&r.default||0}return i=Fv.has(i)?i:jh(i),a.getAttribute(i)}scrapeMotionValuesFromProps(a,i,r){return Pv(a,i,r)}build(a,i,r){Hv(a,i,this.isSVGTag,r.transformTemplate,r.style)}renderInstance(a,i,r,l){y6(a,i,r,l)}mount(a){this.isSVGTag=Iv(a.tagName),super.mount(a)}}const v6=Ah.length;function Yv(n){if(!n)return;if(!n.isControllingVariants){const i=n.parent?Yv(n.parent)||{}:{};return n.props.initial!==void 0&&(i.initial=n.props.initial),i}const a={};for(let i=0;i<v6;i++){const r=Ah[i],l=n.props[r];(_r(l)||l===!1)&&(a[r]=l)}return a}function qv(n,a){if(!Array.isArray(a))return!1;const i=a.length;if(i!==n.length)return!1;for(let r=0;r<i;r++)if(a[r]!==n[r])return!1;return!0}const b6=[...Eh].reverse(),R6=Eh.length;function w6(n){return a=>Promise.all(a.map(({animation:i,options:r})=>y4(n,i,r)))}function S6(n){let a=w6(n),i=Iy(),r=!0,l=!1;const d=m=>(g,x)=>{const b=bs(n,x,m==="exit"?n.presenceContext?.custom:void 0);if(b){const{transition:M,transitionEnd:S,...T}=b;g={...g,...T,...S}}return g};function h(m){a=m(n)}function y(m){const{props:g}=n,x=Yv(n.parent)||{},b=[],M=new Set;let S={},T=1/0;for(let O=0;O<R6;O++){const L=b6[O],z=i[L],D=g[L]!==void 0?g[L]:x[L],X=_r(D),J=L===m?z.isActive:null;J===!1&&(T=O);let Q=D===x[L]&&D!==g[L]&&X;if(Q&&(r||l)&&n.manuallyAnimateOnMount&&(Q=!1),z.protectedKeys={...S},!z.isActive&&J===null||!D&&!z.prevProp||hc(D)||typeof D=="boolean")continue;if(L==="exit"&&z.isActive&&J!==!0){z.prevResolvedValues&&(S={...S,...z.prevResolvedValues});continue}const E=j6(z.prevProp,D);let q=E||L===m&&z.isActive&&!Q&&X||O>T&&X,ee=!1;const oe=Array.isArray(D)?D:[D];let me=oe.reduce(d(L),{});J===!1&&(me={});const{prevResolvedValues:He={}}=z,Te={...He,...me},de=Y=>{q=!0,M.has(Y)&&(ee=!0,M.delete(Y)),z.needsAnimating[Y]=!0;const fe=n.getValue(Y);fe&&(fe.liveStyle=!1)};for(const Y in Te){const fe=me[Y],ye=He[Y];if(S.hasOwnProperty(Y))continue;let A=!1;kf(fe)&&kf(ye)?A=!qv(fe,ye)||E:A=fe!==ye,A?fe!=null?de(Y):M.add(Y):fe!==void 0&&M.has(Y)?de(Y):z.protectedKeys[Y]=!0}z.prevProp=D,z.prevResolvedValues=me,z.isActive&&(S={...S,...me}),(r||l)&&n.blockInitialAnimation&&(q=!1);const U=Q&&E;q&&(!U||ee)&&b.push(...oe.map(Y=>{const fe={type:L};if(typeof Y=="string"&&(r||l)&&!U&&n.manuallyAnimateOnMount&&n.parent){const{parent:ye}=n,A=bs(ye,Y);if(ye.enteringChildren&&A){const{delayChildren:I}=A.transition||{};fe.delay=hv(ye.enteringChildren,n,I)}}return{animation:Y,options:fe}}))}if(M.size){const O={};if(typeof g.initial!="boolean"){const L=bs(n,Array.isArray(g.initial)?g.initial[0]:g.initial);L&&L.transition&&(O.transition=L.transition)}M.forEach(L=>{const z=n.getBaseTarget(L),D=n.getValue(L);D&&(D.liveStyle=!0),O[L]=z??null}),b.push({animation:O})}let j=!!b.length;return r&&(g.initial===!1||g.initial===g.animate)&&!n.manuallyAnimateOnMount&&(j=!1),r=!1,l=!1,j?a(b):Promise.resolve()}function p(m,g){if(i[m].isActive===g)return Promise.resolve();n.variantChildren?.forEach(b=>b.animationState?.setActive(m,g)),i[m].isActive=g;const x=y(m);for(const b in i)i[b].protectedKeys={};return x}return{animateChanges:y,setActive:p,setAnimateFunction:h,getState:()=>i,reset:()=>{i=Iy(),l=!0}}}function j6(n,a){return typeof a=="string"?a!==n:Array.isArray(a)?!qv(a,n):!1}function hs(n=!1){return{isActive:n,protectedKeys:{},needsAnimating:{},prevResolvedValues:{}}}function Iy(){return{animate:hs(!0),whileInView:hs(),whileHover:hs(),whileTap:hs(),whileDrag:hs(),whileFocus:hs(),exit:hs()}}function Ff(n,a){n.min=a.min,n.max=a.max}function Mn(n,a){Ff(n.x,a.x),Ff(n.y,a.y)}function Py(n,a){n.translate=a.translate,n.scale=a.scale,n.originPoint=a.originPoint,n.origin=a.origin}const Xv=1e-4,M6=1-Xv,T6=1+Xv,$v=.01,N6=0-$v,E6=0+$v;function _t(n){return n.max-n.min}function A6(n,a,i){return Math.abs(n-a)<=i}function Yy(n,a,i,r=.5){n.origin=r,n.originPoint=Ue(a.min,a.max,n.origin),n.scale=_t(i)/_t(a),n.translate=Ue(i.min,i.max,n.origin)-n.originPoint,(n.scale>=M6&&n.scale<=T6||isNaN(n.scale))&&(n.scale=1),(n.translate>=N6&&n.translate<=E6||isNaN(n.translate))&&(n.translate=0)}function zr(n,a,i,r){Yy(n.x,a.x,i.x,r?r.originX:void 0),Yy(n.y,a.y,i.y,r?r.originY:void 0)}function qy(n,a,i,r=0){const l=r?Ue(i.min,i.max,r):i.min;n.min=l+a.min,n.max=n.min+_t(a)}function C6(n,a,i,r){qy(n.x,a.x,i.x,r?.x),qy(n.y,a.y,i.y,r?.y)}function Xy(n,a,i,r=0){const l=r?Ue(i.min,i.max,r):i.min;n.min=a.min-l,n.max=n.min+_t(a)}function ec(n,a,i,r){Xy(n.x,a.x,i.x,r?.x),Xy(n.y,a.y,i.y,r?.y)}function $y(n,a,i,r,l){return n-=a,n=Wl(n,1/i,r),l!==void 0&&(n=Wl(n,1/l,r)),n}function k6(n,a=0,i=1,r=.5,l,d=n,h=n){if(Fn.test(a)&&(a=parseFloat(a),a=Ue(h.min,h.max,a/100)-h.min),typeof a!="number")return;let y=Ue(d.min,d.max,r);n===d&&(y-=a),n.min=$y(n.min,a,i,y,l),n.max=$y(n.max,a,i,y,l)}function Qy(n,a,[i,r,l],d,h){k6(n,a[i],a[r],a[l],a.scale,d,h)}const D6=["x","scaleX","originX"],z6=["y","scaleY","originY"];function Zy(n,a,i,r){Qy(n.x,a,D6,i?i.x:void 0,r?r.x:void 0),Qy(n.y,a,z6,i?i.y:void 0,r?r.y:void 0)}function Ky(n){return n.translate===0&&n.scale===1}function Qv(n){return Ky(n.x)&&Ky(n.y)}function Jy(n,a){return n.min===a.min&&n.max===a.max}function V6(n,a){return Jy(n.x,a.x)&&Jy(n.y,a.y)}function Wy(n,a){return Math.round(n.min)===Math.round(a.min)&&Math.round(n.max)===Math.round(a.max)}function Zv(n,a){return Wy(n.x,a.x)&&Wy(n.y,a.y)}function ex(n){return _t(n.x)/_t(n.y)}function tx(n,a){return n.translate===a.translate&&n.scale===a.scale&&n.originPoint===a.originPoint}function Bn(n){return[n("x"),n("y")]}function O6(n,a,i){let r="";const l=n.x.translate/a.x,d=n.y.translate/a.y,h=i?.z||0;if((l||d||h)&&(r=`translate3d(${l}px, ${d}px, ${h}px) `),(a.x!==1||a.y!==1)&&(r+=`scale(${1/a.x}, ${1/a.y}) `),i){const{transformPerspective:m,rotate:g,pathRotation:x,rotateX:b,rotateY:M,skewX:S,skewY:T}=i;m&&(r=`perspective(${m}px) ${r}`),g&&(r+=`rotate(${g}deg) `),x&&(r+=`rotate(${x}deg) `),b&&(r+=`rotateX(${b}deg) `),M&&(r+=`rotateY(${M}deg) `),S&&(r+=`skewX(${S}deg) `),T&&(r+=`skewY(${T}deg) `)}const y=n.x.scale*a.x,p=n.y.scale*a.y;return(y!==1||p!==1)&&(r+=`scale(${y}, ${p})`),r||"none"}const L6=Mh.length,nx=n=>typeof n=="string"?parseFloat(n):n,ax=n=>typeof n=="number"||se.test(n);function G6(n,a,i,r,l,d){l?(n.opacity=Ue(0,i.opacity??1,_6(r)),n.opacityExit=Ue(a.opacity??1,0,B6(r))):d&&(n.opacity=Ue(a.opacity??1,i.opacity??1,r));for(let h=0;h<L6;h++){const y=Mh[h];let p=sx(a,y),m=sx(i,y);if(p===void 0&&m===void 0)continue;p||(p=0),m||(m=0),p===0||m===0||ax(p)===ax(m)?(n[y]=Math.max(Ue(nx(p),nx(m),r),0),(Fn.test(m)||Fn.test(p))&&(n[y]+="%")):n[y]=m}(a.rotate||i.rotate)&&(n.rotate=Ue(a.rotate||0,i.rotate||0,r))}function sx(n,a){return n[a]!==void 0?n[a]:n.borderRadius}const _6=Kv(0,.5,U1),B6=Kv(.5,.95,$t);function Kv(n,a,i){return r=>r<n?0:r>a?1:i(xi(n,a,r))}function U6(n,a,i){const r=yt(n)?n:An(n);return r.start(wh("",r,a,i)),r.animation}function Br(n,a,i,r={passive:!0}){return n.addEventListener(a,i,r),()=>n.removeEventListener(a,i,r)}const H6=(n,a)=>n.depth-a.depth;class F6{constructor(){this.children=[],this.isDirty=!1}add(a){ih(this.children,a),this.isDirty=!0}remove(a){Xl(this.children,a),this.isDirty=!0}forEach(a){this.isDirty&&this.children.sort(H6),this.isDirty=!1,this.children.forEach(a)}}function I6(n,a){const i=Gt.now(),r=({timestamp:l})=>{const d=l-i;d>=a&&(bn(r),n(d-a))};return Ae.setup(r,!0),()=>bn(r)}function Fl(n){return yt(n)?n.get():n}class P6{constructor(){this.members=[]}add(a){ih(this.members,a);for(let i=this.members.length-1;i>=0;i--){const r=this.members[i];if(r===a||r===this.lead||r===this.prevLead)continue;const l=r.instance;(!l||l.isConnected===!1)&&!r.snapshot&&(Xl(this.members,r),r.unmount())}a.scheduleRender()}remove(a){if(Xl(this.members,a),a===this.prevLead&&(this.prevLead=void 0),a===this.lead){const i=this.members[this.members.length-1];i&&this.promote(i)}}relegate(a){for(let i=this.members.indexOf(a)-1;i>=0;i--){const r=this.members[i];if(r.isPresent!==!1&&r.instance?.isConnected!==!1)return this.promote(r),!0}return!1}promote(a,i){const r=this.lead;if(a!==r&&(this.prevLead=r,this.lead=a,a.show(),r)){r.updateSnapshot(),a.scheduleRender();const{layoutDependency:l}=r.options,{layoutDependency:d}=a.options;(l===void 0||l!==d)&&(a.resumeFrom=r,i&&(r.preserveOpacity=!0),r.snapshot&&(a.snapshot=r.snapshot,a.snapshot.latestValues=r.animationValues||r.latestValues),a.root?.isUpdating&&(a.isLayoutDirty=!0)),a.options.crossfade===!1&&r.hide()}}exitAnimationComplete(){this.members.forEach(a=>{a.options.onExitComplete?.(),a.resumingFrom?.options.onExitComplete?.()})}scheduleRender(){this.members.forEach(a=>a.instance&&a.scheduleRender(!1))}removeLeadSnapshot(){this.lead?.snapshot&&(this.lead.snapshot=void 0)}}const Il={hasAnimatedSinceResize:!0,hasEverUpdated:!1},ef=["","X","Y","Z"],Y6=1e3;let q6=0;function tf(n,a,i,r){const{latestValues:l}=a;l[n]&&(i[n]=l[n],a.setStaticValue(n,0),r&&(r[n]=0))}function Jv(n){if(n.hasCheckedOptimisedAppear=!0,n.root===n)return;const{visualElement:a}=n.options;if(!a)return;const i=xv(a);if(window.MotionHasOptimisedAnimation(i,"transform")){const{layout:l,layoutId:d}=n.options;window.MotionCancelOptimisedAnimation(i,"transform",Ae,!(l||d))}const{parent:r}=n;r&&!r.hasCheckedOptimisedAppear&&Jv(r)}function Wv({attachResizeListener:n,defaultParent:a,measureScroll:i,checkIsScrollRoot:r,resetTransform:l}){return class{constructor(h={},y=a?.()){this.id=q6++,this.animationId=0,this.animationCommitId=0,this.children=new Set,this.options={},this.isTreeAnimating=!1,this.isAnimationBlocked=!1,this.isLayoutDirty=!1,this.isProjectionDirty=!1,this.isSharedProjectionDirty=!1,this.isTransformDirty=!1,this.updateManuallyBlocked=!1,this.updateBlockedByResize=!1,this.isUpdating=!1,this.isSVG=!1,this.needsReset=!1,this.shouldResetTransform=!1,this.hasCheckedOptimisedAppear=!1,this.treeScale={x:1,y:1},this.eventHandlers=new Map,this.hasTreeAnimated=!1,this.layoutVersion=0,this.updateScheduled=!1,this.scheduleUpdate=()=>this.update(),this.projectionUpdateScheduled=!1,this.checkUpdateFailed=()=>{this.isUpdating&&(this.isUpdating=!1,this.clearAllSnapshots())},this.updateProjection=()=>{this.projectionUpdateScheduled=!1,this.nodes.forEach(Q6),this.nodes.forEach(tj),this.nodes.forEach(nj),this.nodes.forEach(Z6)},this.resolvedRelativeTargetAt=0,this.linkedParentVersion=0,this.hasProjected=!1,this.isVisible=!0,this.animationProgress=0,this.sharedNodes=new Map,this.latestValues=h,this.root=y?y.root||y:this,this.path=y?[...y.path,y]:[],this.parent=y,this.depth=y?y.depth+1:0;for(let p=0;p<this.path.length;p++)this.path[p].shouldResetTransform=!0;this.root===this&&(this.nodes=new F6)}addEventListener(h,y){return this.eventHandlers.has(h)||this.eventHandlers.set(h,new oh),this.eventHandlers.get(h).add(y)}notifyListeners(h,...y){const p=this.eventHandlers.get(h);p&&p.notify(...y)}hasListeners(h){return this.eventHandlers.has(h)}mount(h){if(this.instance)return;this.isSVG=Nh(h)&&!q4(h),this.instance=h;const{layoutId:y,layout:p,visualElement:m}=this.options;if(m&&!m.current&&m.mount(h),this.root.nodes.add(this),this.parent&&this.parent.children.add(this),this.root.hasTreeAnimated&&(p||y)&&(this.isLayoutDirty=!0),n){let g,x=0;const b=()=>this.root.updateBlockedByResize=!1;Ae.read(()=>{x=window.innerWidth}),n(h,()=>{const M=window.innerWidth;M!==x&&(x=M,this.root.updateBlockedByResize=!0,g&&g(),g=I6(b,250),Il.hasAnimatedSinceResize&&(Il.hasAnimatedSinceResize=!1,this.nodes.forEach(ox)))})}y&&this.root.registerSharedNode(y,this),this.options.animate!==!1&&m&&(y||p)&&this.addEventListener("didUpdate",({delta:g,hasLayoutChanged:x,hasRelativeLayoutChanged:b,layout:M})=>{if(this.isTreeAnimationBlocked()){this.target=void 0,this.relativeTarget=void 0;return}const S=this.options.transition||m.getDefaultTransition()||oj,{onLayoutAnimationStart:T,onLayoutAnimationComplete:j}=m.getProps(),O=!this.targetLayout||!Zv(this.targetLayout,M),L=!x&&b;if(this.options.layoutRoot||this.resumeFrom||L||x&&(O||!this.currentAnimation)){this.resumeFrom&&(this.resumingFrom=this.resumeFrom,this.resumingFrom.resumingFrom=void 0);const z={...Rh(S,"layout"),onPlay:T,onComplete:j};(m.shouldReduceMotion||this.options.layoutRoot)&&(z.delay=0,z.type=!1),this.startAnimation(z),this.setAnimationOrigin(g,L,z.path)}else x||ox(this),this.isLead()&&this.options.onExitComplete&&this.options.onExitComplete();this.targetLayout=M})}unmount(){this.options.layoutId&&this.willUpdate(),this.root.nodes.remove(this);const h=this.getStack();h&&h.remove(this),this.parent&&this.parent.children.delete(this),this.instance=void 0,this.eventHandlers.clear(),bn(this.updateProjection)}blockUpdate(){this.updateManuallyBlocked=!0}unblockUpdate(){this.updateManuallyBlocked=!1}isUpdateBlocked(){return this.updateManuallyBlocked||this.updateBlockedByResize}isTreeAnimationBlocked(){return this.isAnimationBlocked||this.parent&&this.parent.isTreeAnimationBlocked()||!1}startUpdate(){this.isUpdateBlocked()||(this.isUpdating=!0,this.nodes&&this.nodes.forEach(aj),this.animationId++)}getTransformTemplate(){const{visualElement:h}=this.options;return h&&h.getProps().transformTemplate}willUpdate(h=!0){if(this.root.hasTreeAnimated=!0,this.root.isUpdateBlocked()){this.options.onExitComplete&&this.options.onExitComplete();return}if(window.MotionCancelOptimisedAnimation&&!this.hasCheckedOptimisedAppear&&Jv(this),!this.root.isUpdating&&this.root.startUpdate(),this.isLayoutDirty)return;this.isLayoutDirty=!0;for(let g=0;g<this.path.length;g++){const x=this.path[g];x.shouldResetTransform=!0,(typeof x.latestValues.x=="string"||typeof x.latestValues.y=="string")&&(x.isLayoutDirty=!0),x.updateScroll("snapshot"),x.options.layoutRoot&&x.willUpdate(!1)}const{layoutId:y,layout:p}=this.options;if(y===void 0&&!p)return;const m=this.getTransformTemplate();this.prevTransformTemplateValue=m?m(this.latestValues,""):void 0,this.updateSnapshot(),h&&this.notifyListeners("willUpdate")}update(){if(this.updateScheduled=!1,this.isUpdateBlocked()){const p=this.updateBlockedByResize;this.unblockUpdate(),this.updateBlockedByResize=!1,this.clearAllSnapshots(),p&&this.nodes.forEach(J6),this.nodes.forEach(ix);return}if(this.animationId<=this.animationCommitId){this.nodes.forEach(rx);return}this.animationCommitId=this.animationId,this.isUpdating?(this.isUpdating=!1,this.nodes.forEach(W6),this.nodes.forEach(ej),this.nodes.forEach(X6),this.nodes.forEach($6)):this.nodes.forEach(rx),this.clearAllSnapshots();const y=Gt.now();wt.delta=Dn(0,1e3/60,y-wt.timestamp),wt.timestamp=y,wt.isProcessing=!0,Yd.update.process(wt),Yd.preRender.process(wt),Yd.render.process(wt),wt.isProcessing=!1}didUpdate(){this.updateScheduled||(this.updateScheduled=!0,bi.read(this.scheduleUpdate))}clearAllSnapshots(){this.nodes.forEach(K6),this.sharedNodes.forEach(sj)}scheduleUpdateProjection(){this.projectionUpdateScheduled||(this.projectionUpdateScheduled=!0,Ae.preRender(this.updateProjection,!1,!0))}scheduleCheckAfterUnmount(){Ae.postRender(()=>{this.isLayoutDirty?this.root.didUpdate():this.root.checkUpdateFailed()})}updateSnapshot(){this.snapshot||!this.instance||(this.snapshot=this.measure(),this.snapshot&&!_t(this.snapshot.measuredBox.x)&&!_t(this.snapshot.measuredBox.y)&&(this.snapshot=void 0))}updateLayout(){if(!this.instance||(this.updateScroll(),!(this.options.alwaysMeasureLayout&&this.isLead())&&!this.isLayoutDirty))return;if(this.resumeFrom&&!this.resumeFrom.instance)for(let p=0;p<this.path.length;p++)this.path[p].updateScroll();const h=this.layout;this.layout=this.measure(!1),this.layoutVersion++,this.layoutCorrected||(this.layoutCorrected=mt()),this.isLayoutDirty=!1,this.projectionDelta=void 0,this.notifyListeners("measure",this.layout.layoutBox);const{visualElement:y}=this.options;y&&y.notify("LayoutMeasure",this.layout.layoutBox,h?h.layoutBox:void 0)}updateScroll(h="measure"){let y=!!(this.options.layoutScroll&&this.instance);if(this.scroll&&this.scroll.animationId===this.root.animationId&&this.scroll.phase===h&&(y=!1),y&&this.instance){const p=r(this.instance);this.scroll={animationId:this.root.animationId,phase:h,isRoot:p,offset:i(this.instance),wasRoot:this.scroll?this.scroll.isRoot:p}}}resetTransform(){if(!l)return;const h=this.isLayoutDirty||this.shouldResetTransform||this.options.alwaysMeasureLayout,y=this.projectionDelta&&!Qv(this.projectionDelta),p=this.getTransformTemplate(),m=p?p(this.latestValues,""):void 0,g=m!==this.prevTransformTemplateValue;h&&this.instance&&(y||ms(this.latestValues)||g)&&(l(this.instance,m),this.shouldResetTransform=!1,this.scheduleRender())}measure(h=!0){const y=this.measurePageBox();let p=this.removeElementScroll(y);return h&&(p=this.removeTransform(p)),lj(p),{animationId:this.root.animationId,measuredBox:y,layoutBox:p,latestValues:{},source:this.id}}measurePageBox(){const{visualElement:h}=this.options;if(!h)return mt();const y=h.measureViewportBox();if(!(this.scroll?.wasRoot||this.path.some(cj))){const{scroll:m}=this.root;m&&(Un(y.x,m.offset.x),Un(y.y,m.offset.y))}return y}removeElementScroll(h){const y=mt();if(Mn(y,h),this.scroll?.wasRoot)return y;for(let p=0;p<this.path.length;p++){const m=this.path[p],{scroll:g,options:x}=m;m!==this.root&&g&&x.layoutScroll&&(g.wasRoot&&Mn(y,h),Un(y.x,g.offset.x),Un(y.y,g.offset.y))}return y}applyTransform(h,y=!1,p){const m=p||mt();Mn(m,h);for(let g=0;g<this.path.length;g++){const x=this.path[g];!y&&x.options.layoutScroll&&x.scroll&&x!==x.root&&(Un(m.x,-x.scroll.offset.x),Un(m.y,-x.scroll.offset.y)),ms(x.latestValues)&&Hl(m,x.latestValues,x.layout?.layoutBox)}return ms(this.latestValues)&&Hl(m,this.latestValues,this.layout?.layoutBox),m}removeTransform(h){const y=mt();Mn(y,h);for(let p=0;p<this.path.length;p++){const m=this.path[p];if(!ms(m.latestValues))continue;let g;m.instance&&(Bf(m.latestValues)&&m.updateSnapshot(),g=mt(),Mn(g,m.measurePageBox())),Zy(y,m.latestValues,m.snapshot?.layoutBox,g)}return ms(this.latestValues)&&Zy(y,this.latestValues),y}setTargetDelta(h){this.targetDelta=h,this.root.scheduleUpdateProjection(),this.isProjectionDirty=!0}setOptions(h){this.options={...this.options,...h,crossfade:h.crossfade!==void 0?h.crossfade:!0}}clearMeasurements(){this.scroll=void 0,this.layout=void 0,this.snapshot=void 0,this.prevTransformTemplateValue=void 0,this.targetDelta=void 0,this.target=void 0,this.isLayoutDirty=!1}forceRelativeParentToResolveTarget(){this.relativeParent&&this.relativeParent.resolvedRelativeTargetAt!==wt.timestamp&&this.relativeParent.resolveTargetDelta(!0)}resolveTargetDelta(h=!1){const y=this.getLead();this.isProjectionDirty||(this.isProjectionDirty=y.isProjectionDirty),this.isTransformDirty||(this.isTransformDirty=y.isTransformDirty),this.isSharedProjectionDirty||(this.isSharedProjectionDirty=y.isSharedProjectionDirty);const p=!!this.resumingFrom||this!==y;if(!(h||p&&this.isSharedProjectionDirty||this.isProjectionDirty||this.parent?.isProjectionDirty||this.attemptToResolveRelativeTarget||this.root.updateBlockedByResize))return;const{layout:g,layoutId:x}=this.options;if(!this.layout||!(g||x))return;this.resolvedRelativeTargetAt=wt.timestamp;const b=this.getClosestProjectingParent();b&&this.linkedParentVersion!==b.layoutVersion&&!b.options.layoutRoot&&this.removeRelativeTarget(),!this.targetDelta&&!this.relativeTarget&&(this.options.layoutAnchor!==!1&&b&&b.layout?this.createRelativeTarget(b,this.layout.layoutBox,b.layout.layoutBox):this.removeRelativeTarget()),!(!this.relativeTarget&&!this.targetDelta)&&(this.target||(this.target=mt(),this.targetWithTransforms=mt()),this.relativeTarget&&this.relativeTargetOrigin&&this.relativeParent&&this.relativeParent.target?(this.forceRelativeParentToResolveTarget(),C6(this.target,this.relativeTarget,this.relativeParent.target,this.options.layoutAnchor||void 0)):this.targetDelta?(this.resumingFrom?this.applyTransform(this.layout.layoutBox,!1,this.target):Mn(this.target,this.layout.layoutBox),Gv(this.target,this.targetDelta)):Mn(this.target,this.layout.layoutBox),this.attemptToResolveRelativeTarget&&(this.attemptToResolveRelativeTarget=!1,this.options.layoutAnchor!==!1&&b&&!!b.resumingFrom==!!this.resumingFrom&&!b.options.layoutScroll&&b.target&&this.animationProgress!==1?this.createRelativeTarget(b,this.target,b.target):this.relativeParent=this.relativeTarget=void 0))}getClosestProjectingParent(){if(!(!this.parent||Bf(this.parent.latestValues)||Lv(this.parent.latestValues)))return this.parent.isProjecting()?this.parent:this.parent.getClosestProjectingParent()}isProjecting(){return!!((this.relativeTarget||this.targetDelta||this.options.layoutRoot)&&this.layout)}createRelativeTarget(h,y,p){this.relativeParent=h,this.linkedParentVersion=h.layoutVersion,this.forceRelativeParentToResolveTarget(),this.relativeTarget=mt(),this.relativeTargetOrigin=mt(),ec(this.relativeTargetOrigin,y,p,this.options.layoutAnchor||void 0),Mn(this.relativeTarget,this.relativeTargetOrigin)}removeRelativeTarget(){this.relativeParent=this.relativeTarget=void 0}calcProjection(){const h=this.getLead(),y=!!this.resumingFrom||this!==h;let p=!0;if((this.isProjectionDirty||this.parent?.isProjectionDirty)&&(p=!1),y&&(this.isSharedProjectionDirty||this.isTransformDirty)&&(p=!1),this.resolvedRelativeTargetAt===wt.timestamp&&(p=!1),p)return;const{layout:m,layoutId:g}=this.options;if(this.isTreeAnimating=!!(this.parent&&this.parent.isTreeAnimating||this.currentAnimation||this.pendingAnimation),this.isTreeAnimating||(this.targetDelta=this.relativeTarget=void 0),!this.layout||!(m||g))return;Mn(this.layoutCorrected,this.layout.layoutBox);const x=this.treeScale.x,b=this.treeScale.y;i6(this.layoutCorrected,this.treeScale,this.path,y),h.layout&&!h.target&&(this.treeScale.x!==1||this.treeScale.y!==1)&&(h.target=h.layout.layoutBox,h.targetWithTransforms=mt());const{target:M}=h;if(!M){this.prevProjectionDelta&&(this.createProjectionDeltas(),this.scheduleRender());return}!this.projectionDelta||!this.prevProjectionDelta?this.createProjectionDeltas():(Py(this.prevProjectionDelta.x,this.projectionDelta.x),Py(this.prevProjectionDelta.y,this.projectionDelta.y)),zr(this.projectionDelta,this.layoutCorrected,M,this.latestValues),(this.treeScale.x!==x||this.treeScale.y!==b||!tx(this.projectionDelta.x,this.prevProjectionDelta.x)||!tx(this.projectionDelta.y,this.prevProjectionDelta.y))&&(this.hasProjected=!0,this.scheduleRender(),this.notifyListeners("projectionUpdate",M))}hide(){this.isVisible=!1}show(){this.isVisible=!0}scheduleRender(h=!0){if(this.options.visualElement?.scheduleRender(),h){const y=this.getStack();y&&y.scheduleRender()}this.resumingFrom&&!this.resumingFrom.instance&&(this.resumingFrom=void 0)}createProjectionDeltas(){this.prevProjectionDelta=pi(),this.projectionDelta=pi(),this.projectionDeltaWithTransform=pi()}setAnimationOrigin(h,y=!1,p){const m=this.snapshot,g=m?m.latestValues:{},x={...this.latestValues},b=pi();(!this.relativeParent||!this.relativeParent.options.layoutRoot)&&(this.relativeTarget=this.relativeTargetOrigin=void 0),this.attemptToResolveRelativeTarget=!y;const M=mt(),S=m?m.source:void 0,T=this.layout?this.layout.source:void 0,j=S!==T,O=this.getStack(),L=!O||O.members.length<=1,z=!!(j&&!L&&this.options.crossfade===!0&&!this.path.some(rj));this.animationProgress=0;let D;const X=p?.interpolateProjection(h);this.mixTargetDelta=J=>{const Q=J/1e3,E=X?.(Q);E?(b.x.translate=E.x,b.x.scale=Ue(h.x.scale,1,Q),b.x.origin=h.x.origin,b.x.originPoint=h.x.originPoint,b.y.translate=E.y,b.y.scale=Ue(h.y.scale,1,Q),b.y.origin=h.y.origin,b.y.originPoint=h.y.originPoint):(lx(b.x,h.x,Q),lx(b.y,h.y,Q)),this.setTargetDelta(b),this.relativeTarget&&this.relativeTargetOrigin&&this.layout&&this.relativeParent&&this.relativeParent.layout&&(ec(M,this.layout.layoutBox,this.relativeParent.layout.layoutBox,this.options.layoutAnchor||void 0),ij(this.relativeTarget,this.relativeTargetOrigin,M,Q),D&&V6(this.relativeTarget,D)&&(this.isProjectionDirty=!1),D||(D=mt()),Mn(D,this.relativeTarget)),j&&(this.animationValues=x,G6(x,g,this.latestValues,Q,z,L)),E&&E.rotate!==void 0&&(this.animationValues||(this.animationValues=x),this.animationValues.pathRotation=E.rotate),this.root.scheduleUpdateProjection(),this.scheduleRender(),this.animationProgress=Q},this.mixTargetDelta(this.options.layoutRoot?1e3:0)}startAnimation(h){this.notifyListeners("animationStart"),this.currentAnimation?.stop(),this.resumingFrom?.currentAnimation?.stop(),this.pendingAnimation&&(bn(this.pendingAnimation),this.pendingAnimation=void 0),this.pendingAnimation=Ae.update(()=>{Il.hasAnimatedSinceResize=!0,this.motionValue||(this.motionValue=An(0)),this.motionValue.jump(0,!1),this.currentAnimation=U6(this.motionValue,[0,1e3],{...h,velocity:0,isSync:!0,onUpdate:y=>{this.mixTargetDelta(y),h.onUpdate&&h.onUpdate(y)},onComplete:()=>{h.onComplete&&h.onComplete(),this.completeAnimation()}}),this.resumingFrom&&(this.resumingFrom.currentAnimation=this.currentAnimation),this.pendingAnimation=void 0})}completeAnimation(){this.resumingFrom&&(this.resumingFrom.currentAnimation=void 0,this.resumingFrom.preserveOpacity=void 0);const h=this.getStack();h&&h.exitAnimationComplete(),this.resumingFrom=this.currentAnimation=this.animationValues=void 0,this.notifyListeners("animationComplete")}finishAnimation(){this.currentAnimation&&(this.mixTargetDelta&&this.mixTargetDelta(Y6),this.currentAnimation.stop()),this.completeAnimation()}applyTransformsToTarget(){const h=this.getLead();let{targetWithTransforms:y,target:p,layout:m,latestValues:g}=h;if(!(!y||!p||!m)){if(this!==h&&this.layout&&m&&eb(this.options.animationType,this.layout.layoutBox,m.layoutBox)){p=this.target||mt();const x=_t(this.layout.layoutBox.x);p.x.min=h.target.x.min,p.x.max=p.x.min+x;const b=_t(this.layout.layoutBox.y);p.y.min=h.target.y.min,p.y.max=p.y.min+b}Mn(y,p),Hl(y,g),zr(this.projectionDeltaWithTransform,this.layoutCorrected,y,g)}}registerSharedNode(h,y){this.sharedNodes.has(h)||this.sharedNodes.set(h,new P6),this.sharedNodes.get(h).add(y);const m=y.options.initialPromotionConfig;y.promote({transition:m?m.transition:void 0,preserveFollowOpacity:m&&m.shouldPreserveFollowOpacity?m.shouldPreserveFollowOpacity(y):void 0})}isLead(){const h=this.getStack();return h?h.lead===this:!0}getLead(){const{layoutId:h}=this.options;return h?this.getStack()?.lead||this:this}getPrevLead(){const{layoutId:h}=this.options;return h?this.getStack()?.prevLead:void 0}getStack(){const{layoutId:h}=this.options;if(h)return this.root.sharedNodes.get(h)}promote({needsReset:h,transition:y,preserveFollowOpacity:p}={}){const m=this.getStack();m&&m.promote(this,p),h&&(this.projectionDelta=void 0,this.needsReset=!0),y&&this.setOptions({transition:y})}relegate(){const h=this.getStack();return h?h.relegate(this):!1}resetSkewAndRotation(){const{visualElement:h}=this.options;if(!h)return;let y=!1;const{latestValues:p}=h;if((p.z||p.rotate||p.rotateX||p.rotateY||p.rotateZ||p.skewX||p.skewY)&&(y=!0),!y)return;const m={};p.z&&tf("z",h,m,this.animationValues);for(let g=0;g<ef.length;g++)tf(`rotate${ef[g]}`,h,m,this.animationValues),tf(`skew${ef[g]}`,h,m,this.animationValues);h.render();for(const g in m)h.setStaticValue(g,m[g]),this.animationValues&&(this.animationValues[g]=m[g]);h.scheduleRender()}applyProjectionStyles(h,y){if(!this.instance||this.isSVG)return;if(!this.isVisible){h.visibility="hidden";return}const p=this.getTransformTemplate();if(this.needsReset){this.needsReset=!1,h.visibility="",h.opacity="",h.pointerEvents=Fl(y?.pointerEvents)||"",h.transform=p?p(this.latestValues,""):"none";return}const m=this.getLead();if(!this.projectionDelta||!this.layout||!m.target){this.options.layoutId&&(h.opacity=this.latestValues.opacity!==void 0?this.latestValues.opacity:1,h.pointerEvents=Fl(y?.pointerEvents)||""),this.hasProjected&&!ms(this.latestValues)&&(h.transform=p?p({},""):"none",this.hasProjected=!1);return}h.visibility="";const g=m.animationValues||m.latestValues;this.applyTransformsToTarget();let x=O6(this.projectionDeltaWithTransform,this.treeScale,g);p&&(x=p(g,x)),h.transform=x;const{x:b,y:M}=this.projectionDelta;h.transformOrigin=`${b.origin*100}% ${M.origin*100}% 0`,m.animationValues?h.opacity=m===this?g.opacity??this.latestValues.opacity??1:this.preserveOpacity?this.latestValues.opacity:g.opacityExit:h.opacity=m===this?g.opacity!==void 0?g.opacity:"":g.opacityExit!==void 0?g.opacityExit:0;for(const S in Hf){if(g[S]===void 0)continue;const{correct:T,applyTo:j,isCSSVariable:O}=Hf[S],L=x==="none"?g[S]:T(g[S],m);if(j){const z=j.length;for(let D=0;D<z;D++)h[j[D]]=L}else O?this.options.visualElement.renderState.vars[S]=L:h[S]=L}this.options.layoutId&&(h.pointerEvents=m===this?Fl(y?.pointerEvents)||"":"none")}clearSnapshot(){this.resumeFrom=this.snapshot=void 0}resetTree(){this.root.nodes.forEach(h=>h.currentAnimation?.stop()),this.root.nodes.forEach(ix),this.root.sharedNodes.clear()}}}function X6(n){n.updateLayout()}function $6(n){const a=n.resumeFrom?.snapshot||n.snapshot;if(n.isLead()&&n.layout&&a&&n.hasListeners("didUpdate")){const{layoutBox:i,measuredBox:r}=n.layout,{animationType:l}=n.options,d=a.source!==n.layout.source;if(l==="size")Bn(g=>{const x=d?a.measuredBox[g]:a.layoutBox[g],b=_t(x);x.min=i[g].min,x.max=x.min+b});else if(l==="x"||l==="y"){const g=l==="x"?"y":"x";Ff(d?a.measuredBox[g]:a.layoutBox[g],i[g])}else eb(l,a.layoutBox,i)&&Bn(g=>{const x=d?a.measuredBox[g]:a.layoutBox[g],b=_t(i[g]);x.max=x.min+b,n.relativeTarget&&!n.currentAnimation&&(n.isProjectionDirty=!0,n.relativeTarget[g].max=n.relativeTarget[g].min+b)});const h=pi();zr(h,i,a.layoutBox);const y=pi();d?zr(y,n.applyTransform(r,!0),a.measuredBox):zr(y,i,a.layoutBox);const p=!Qv(h);let m=!1;if(!n.resumeFrom){const g=n.getClosestProjectingParent();if(g&&!g.resumeFrom){const{snapshot:x,layout:b}=g;if(x&&b){const M=n.options.layoutAnchor||void 0,S=mt();ec(S,a.layoutBox,x.layoutBox,M);const T=mt();ec(T,i,b.layoutBox,M),Zv(S,T)||(m=!0),g.options.layoutRoot&&(n.relativeTarget=T,n.relativeTargetOrigin=S,n.relativeParent=g)}}}n.notifyListeners("didUpdate",{layout:i,snapshot:a,delta:y,layoutDelta:h,hasLayoutChanged:p,hasRelativeLayoutChanged:m})}else if(n.isLead()){const{onExitComplete:i}=n.options;i&&i()}n.options.transition=void 0}function Q6(n){n.parent&&(n.isProjecting()||(n.isProjectionDirty=n.parent.isProjectionDirty),n.isSharedProjectionDirty||(n.isSharedProjectionDirty=!!(n.isProjectionDirty||n.parent.isProjectionDirty||n.parent.isSharedProjectionDirty)),n.isTransformDirty||(n.isTransformDirty=n.parent.isTransformDirty))}function Z6(n){n.isProjectionDirty=n.isSharedProjectionDirty=n.isTransformDirty=!1}function K6(n){n.clearSnapshot()}function ix(n){n.clearMeasurements()}function J6(n){n.isLayoutDirty=!0,n.updateLayout()}function rx(n){n.isLayoutDirty=!1}function W6(n){n.isAnimationBlocked&&n.layout&&!n.isLayoutDirty&&(n.snapshot=n.layout,n.isLayoutDirty=!0)}function ej(n){const{visualElement:a}=n.options;a&&a.getProps().onBeforeLayoutMeasure&&a.notify("BeforeLayoutMeasure"),n.resetTransform()}function ox(n){n.finishAnimation(),n.targetDelta=n.relativeTarget=n.target=void 0,n.isProjectionDirty=!0}function tj(n){n.resolveTargetDelta()}function nj(n){n.calcProjection()}function aj(n){n.resetSkewAndRotation()}function sj(n){n.removeLeadSnapshot()}function lx(n,a,i){n.translate=Ue(a.translate,0,i),n.scale=Ue(a.scale,1,i),n.origin=a.origin,n.originPoint=a.originPoint}function cx(n,a,i,r){n.min=Ue(a.min,i.min,r),n.max=Ue(a.max,i.max,r)}function ij(n,a,i,r){cx(n.x,a.x,i.x,r),cx(n.y,a.y,i.y,r)}function rj(n){return n.animationValues&&n.animationValues.opacityExit!==void 0}const oj={duration:.45,ease:[.4,0,.1,1]},ux=n=>typeof navigator<"u"&&navigator.userAgent&&navigator.userAgent.toLowerCase().includes(n),dx=ux("applewebkit/")&&!ux("chrome/")?Math.round:$t;function fx(n){n.min=dx(n.min),n.max=dx(n.max)}function lj(n){fx(n.x),fx(n.y)}function eb(n,a,i){return n==="position"||n==="preserve-aspect"&&!A6(ex(a),ex(i),.2)}function cj(n){return n!==n.root&&n.scroll?.wasRoot}const uj=Wv({attachResizeListener:(n,a)=>Br(n,"resize",a),measureScroll:()=>({x:document.documentElement.scrollLeft||document.body?.scrollLeft||0,y:document.documentElement.scrollTop||document.body?.scrollTop||0}),checkIsScrollRoot:()=>!0}),nf={current:void 0},tb=Wv({measureScroll:n=>({x:n.scrollLeft,y:n.scrollTop}),defaultParent:()=>{if(!nf.current){const n=new uj({});n.mount(window),n.setOptions({layoutScroll:!0}),nf.current=n}return nf.current},resetTransform:(n,a)=>{n.style.transform=a!==void 0?a:"none"},checkIsScrollRoot:n=>window.getComputedStyle(n).position==="fixed"}),Zr=w.createContext({transformPagePoint:n=>n,isStatic:!1,reducedMotion:"never"});function hx(n,a){if(typeof n=="function")return n(a);n!=null&&(n.current=a)}function dj(...n){return a=>{let i=!1;const r=n.map(l=>{const d=hx(l,a);return!i&&typeof d=="function"&&(i=!0),d});if(i)return()=>{for(let l=0;l<r.length;l++){const d=r[l];typeof d=="function"?d():hx(n[l],null)}}}}function fj(...n){return w.useCallback(dj(...n),n)}class hj extends w.Component{getSnapshotBeforeUpdate(a){const i=this.props.childRef.current;if(Dr(i)&&a.isPresent&&!this.props.isPresent&&this.props.pop!==!1){const r=i.offsetParent,l=Dr(r)&&r.offsetWidth||0,d=Dr(r)&&r.offsetHeight||0,h=getComputedStyle(i),y=this.props.sizeRef.current;y.height=parseFloat(h.height),y.width=parseFloat(h.width),y.top=i.offsetTop,y.left=i.offsetLeft,y.right=l-y.width-y.left,y.bottom=d-y.height-y.top,y.direction=h.direction}return null}componentDidUpdate(){}render(){return this.props.children}}function pj({children:n,isPresent:a,anchorX:i,anchorY:r,root:l,pop:d}){const h=w.useId(),y=w.useRef(null),p=w.useRef({width:0,height:0,top:0,left:0,right:0,bottom:0,direction:"ltr"}),{nonce:m}=w.useContext(Zr),g=n.props?.ref??n?.ref,x=fj(y,g);return w.useInsertionEffect(()=>{const{width:b,height:M,top:S,left:T,right:j,bottom:O,direction:L}=p.current;if(a||d===!1||!y.current||!b||!M)return;const z=L==="rtl",D=i==="left"?z?`right: ${j}`:`left: ${T}`:z?`left: ${T}`:`right: ${j}`,X=r==="bottom"?`bottom: ${O}`:`top: ${S}`;y.current.dataset.motionPopId=h;const J=document.createElement("style");m&&(J.nonce=m);const Q=l??document.head;return Q.appendChild(J),J.sheet&&J.sheet.insertRule(`
          [data-motion-pop-id="${h}"] {
            position: absolute !important;
            width: ${b}px !important;
            height: ${M}px !important;
            ${D}px !important;
            ${X}px !important;
          }
        `),()=>{y.current?.removeAttribute("data-motion-pop-id"),Q.contains(J)&&Q.removeChild(J)}},[a]),u.jsx(hj,{isPresent:a,childRef:y,sizeRef:p,pop:d,children:d===!1?n:w.cloneElement(n,{ref:x})})}const mj=({children:n,initial:a,isPresent:i,onExitComplete:r,custom:l,presenceAffectsLayout:d,mode:h,anchorX:y,anchorY:p,root:m})=>{const g=Pa(gj),x=w.useId(),b=w.useRef(i),M=w.useRef(r);qr(()=>{b.current=i,M.current=r});let S=!0,T=w.useMemo(()=>(S=!1,{id:x,initial:a,isPresent:i,custom:l,onExitComplete:j=>{g.set(j,!0);for(const O of g.values())if(!O)return;r&&r()},register:j=>(g.set(j,!1),()=>{g.delete(j),!b.current&&!g.size&&M.current?.()})}),[i,g,r]);return d&&S&&(T={...T}),w.useMemo(()=>{g.forEach((j,O)=>g.set(O,!1))},[i]),w.useEffect(()=>{!i&&!g.size&&r&&r()},[i]),n=u.jsx(pj,{pop:h==="popLayout",isPresent:i,anchorX:y,anchorY:p,root:m,children:n}),u.jsx(dc.Provider,{value:T,children:n})};function gj(){return new Map}function nb(n=!0){const a=w.useContext(dc);if(a===null)return[!0,null];const{isPresent:i,onExitComplete:r,register:l}=a,d=w.useId();w.useEffect(()=>{if(n)return l(d)},[n]);const h=w.useCallback(()=>n&&r&&r(d),[d,r,n]);return!i&&r?[!1,h]:[!0]}const jl=n=>n.key||"";function px(n){const a=[];return w.Children.forEach(n,i=>{w.isValidElement(i)&&a.push(i)}),a}const Ti=({children:n,custom:a,initial:i=!0,onExitComplete:r,presenceAffectsLayout:l=!0,mode:d="sync",propagate:h=!1,anchorX:y="left",anchorY:p="top",root:m})=>{const[g,x]=nb(h),b=w.useMemo(()=>px(n),[n]),M=h&&!g?[]:b.map(jl),S=w.useRef(!0),T=w.useRef(b),j=Pa(()=>new Map),O=w.useRef(new Set),[L,z]=w.useState(b),[D,X]=w.useState(b);qr(()=>{S.current=!1,T.current=b;for(let E=0;E<D.length;E++){const q=jl(D[E]);M.includes(q)?(j.delete(q),O.current.delete(q)):j.get(q)!==!0&&j.set(q,!1)}},[D,M.length,M.join("-")]);const J=[];if(b!==L){let E=[...b];for(let q=0;q<D.length;q++){const ee=D[q],oe=jl(ee);M.includes(oe)||(E.splice(q,0,ee),J.push(ee))}return d==="wait"&&J.length&&(E=J),X(px(E)),z(b),null}const{forceRender:Q}=w.useContext(sh);return u.jsx(u.Fragment,{children:D.map(E=>{const q=jl(E),ee=h&&!g?!1:b===D||M.includes(q),oe=()=>{if(O.current.has(q))return;if(j.has(q))O.current.add(q),j.set(q,!0);else return;let me=!0;j.forEach(He=>{He||(me=!1)}),me&&(Q?.(),X(T.current),h&&x?.(),r&&r())};return u.jsx(mj,{isPresent:ee,initial:!S.current||i?void 0:!1,custom:a,presenceAffectsLayout:l,mode:d,root:m,onExitComplete:ee?void 0:oe,anchorX:y,anchorY:p,children:E},q)})})},ab=w.createContext({strict:!1}),mx={animation:["animate","variants","whileHover","whileTap","exit","whileInView","whileFocus","whileDrag"],exit:["exit"],drag:["drag","dragControls"],focus:["whileFocus"],hover:["whileHover","onHoverStart","onHoverEnd"],tap:["whileTap","onTap","onTapStart","onTapCancel"],pan:["onPan","onPanStart","onPanSessionStart","onPanEnd"],inView:["whileInView","onViewportEnter","onViewportLeave"],layout:["layout","layoutId"]};let gx=!1;function yj(){if(gx)return;const n={};for(const a in mx)n[a]={isEnabled:i=>mx[a].some(r=>!!i[r])};zv(n),gx=!0}function sb(){return yj(),t6()}function xj(n){const a=sb();for(const i in n)a[i]={...a[i],...n[i]};zv(a)}const vj=new Set(["animate","exit","variants","initial","style","values","variants","transition","transformTemplate","custom","inherit","onBeforeLayoutMeasure","onAnimationStart","onAnimationComplete","onUpdate","onDragStart","onDrag","onDragEnd","onMeasureDragConstraints","onDirectionLock","onDragTransitionEnd","_dragX","_dragY","onHoverStart","onHoverEnd","onViewportEnter","onViewportLeave","globalTapTarget","propagate","ignoreStrict","viewport"]);function tc(n){return n.startsWith("while")||n.startsWith("drag")&&n!=="draggable"||n.startsWith("layout")||n.startsWith("onTap")||n.startsWith("onPan")||n.startsWith("onLayout")||vj.has(n)}let ib=n=>!tc(n);function bj(n){typeof n=="function"&&(ib=a=>a.startsWith("on")?!tc(a):n(a))}try{bj(require("@emotion/is-prop-valid").default)}catch{}function Rj(n,a,i){const r={};for(const l in n)l==="values"&&typeof n.values=="object"||yt(n[l])||(ib(l)||i===!0&&tc(l)||!a&&!tc(l)||n.draggable&&l.startsWith("onDrag"))&&(r[l]=n[l]);return r}const mc=w.createContext({});function wj(n,a){if(pc(n)){const{initial:i,animate:r}=n;return{initial:i===!1||_r(i)?i:void 0,animate:_r(r)?r:void 0}}return n.inherit!==!1?a:{}}function Sj(n){const{initial:a,animate:i}=wj(n,w.useContext(mc));return w.useMemo(()=>({initial:a,animate:i}),[yx(a),yx(i)])}function yx(n){return Array.isArray(n)?n.join(" "):n}const Dh=()=>({style:{},transform:{},transformOrigin:{},vars:{}});function rb(n,a,i){for(const r in a)!yt(a[r])&&!Uv(r,i)&&(n[r]=a[r])}function jj({transformTemplate:n},a){return w.useMemo(()=>{const i=Dh();return Ch(i,a,n),Object.assign({},i.vars,i.style)},[a])}function Mj(n,a){const i=n.style||{},r={};return rb(r,i,n),Object.assign(r,jj(n,a)),r}function Tj(n,a){const i={},r=Mj(n,a);return n.drag&&n.dragListener!==!1&&(i.draggable=!1,r.userSelect=r.WebkitUserSelect=r.WebkitTouchCallout="none",r.touchAction=n.drag===!0?"none":`pan-${n.drag==="x"?"y":"x"}`),n.tabIndex===void 0&&(n.onTap||n.onTapStart||n.whileTap)&&(i.tabIndex=0),i.style=r,i}const ob=()=>({...Dh(),attrs:{}});function Nj(n,a,i,r){const l=w.useMemo(()=>{const d=ob();return Hv(d,a,Iv(r),n.transformTemplate,n.style),{...d.attrs,style:{...d.style}}},[a]);if(n.style){const d={};rb(d,n.style,n),l.style={...d,...l.style}}return l}const Ej=["animate","circle","defs","desc","ellipse","g","image","line","filter","marker","mask","metadata","path","pattern","polygon","polyline","rect","stop","switch","symbol","svg","text","tspan","use","view"];function zh(n){return typeof n!="string"||n.includes("-")?!1:!!(Ej.indexOf(n)>-1||/[A-Z]/u.test(n))}function Aj(n,a,i,{latestValues:r},l,d=!1,h){const p=(h??zh(n)?Nj:Tj)(a,r,l,n),m=Rj(a,typeof n=="string",d),g=n!==w.Fragment?{...m,...p,ref:i}:{},{children:x}=a,b=w.useMemo(()=>yt(x)?x.get():x,[x]);return w.createElement(n,{...g,children:b})}function Cj({scrapeMotionValuesFromProps:n,createRenderState:a},i,r,l){return{latestValues:kj(i,r,l,n),renderState:a()}}function kj(n,a,i,r){const l={},d=r(n,{});for(const b in d)l[b]=Fl(d[b]);let{initial:h,animate:y}=n;const p=pc(n),m=kv(n);a&&m&&!p&&n.inherit!==!1&&(h===void 0&&(h=a.initial),y===void 0&&(y=a.animate));let g=i?i.initial===!1:!1;g=g||h===!1;const x=g?y:h;if(x&&typeof x!="boolean"&&!hc(x)){const b=Array.isArray(x)?x:[x];for(let M=0;M<b.length;M++){const S=Sh(n,b[M]);if(S){const{transitionEnd:T,transition:j,...O}=S;for(const L in O){let z=O[L];if(Array.isArray(z)){const D=g?z.length-1:0;z=z[D]}z!==null&&(l[L]=z)}for(const L in T)l[L]=T[L]}}}return l}const lb=n=>(a,i)=>{const r=w.useContext(mc),l=w.useContext(dc),d=()=>Cj(n,a,r,l);return i?d():Pa(d)},Dj=lb({scrapeMotionValuesFromProps:kh,createRenderState:Dh}),zj=lb({scrapeMotionValuesFromProps:Pv,createRenderState:ob}),Vj=Symbol.for("motionComponentSymbol");function Oj(n,a,i){const r=w.useRef(i);w.useInsertionEffect(()=>{r.current=i});const l=w.useRef(null);return w.useCallback(d=>{d&&n.onMount?.(d),a&&(d?a.mount(d):a.unmount());const h=r.current;if(typeof h=="function")if(d){const y=h(d);typeof y=="function"&&(l.current=y)}else l.current?(l.current(),l.current=null):h(d);else h&&(h.current=d)},[a])}const cb=w.createContext({});function ui(n){return n&&typeof n=="object"&&Object.prototype.hasOwnProperty.call(n,"current")}function Lj(n,a,i,r,l,d){const{visualElement:h}=w.useContext(mc),y=w.useContext(ab),p=w.useContext(dc),m=w.useContext(Zr),g=m.reducedMotion,x=m.skipAnimations,b=w.useRef(null),M=w.useRef(!1);r=r||y.renderer,!b.current&&r&&(b.current=r(n,{visualState:a,parent:h,props:i,presenceContext:p,blockInitialAnimation:p?p.initial===!1:!1,reducedMotionConfig:g,skipAnimations:x,isSVG:d}),M.current&&b.current&&(b.current.manuallyAnimateOnMount=!0));const S=b.current,T=w.useContext(cb);S&&!S.projection&&l&&(S.type==="html"||S.type==="svg")&&Gj(b.current,i,l,T);const j=w.useRef(!1);w.useInsertionEffect(()=>{S&&j.current&&S.update(i,p)});const O=i[yv],L=w.useRef(!!O&&typeof window<"u"&&!window.MotionHandoffIsComplete?.(O)&&window.MotionHasOptimisedAnimation?.(O));return qr(()=>{M.current=!0,S&&(j.current=!0,window.MotionIsMounted=!0,S.updateFeatures(),S.scheduleRenderMicrotask(),L.current&&S.animationState&&S.animationState.animateChanges())}),w.useEffect(()=>{S&&(!L.current&&S.animationState&&S.animationState.animateChanges(),L.current&&(queueMicrotask(()=>{window.MotionHandoffMarkAsComplete?.(O)}),L.current=!1),S.enteringChildren=void 0)}),S}function Gj(n,a,i,r){const{layoutId:l,layout:d,drag:h,dragConstraints:y,layoutScroll:p,layoutRoot:m,layoutAnchor:g,layoutCrossfade:x}=a;n.projection=new i(n.latestValues,a["data-framer-portal-id"]?void 0:ub(n.parent)),n.projection.setOptions({layoutId:l,layout:d,alwaysMeasureLayout:!!h||y&&ui(y),visualElement:n,animationType:typeof d=="string"?d:"both",initialPromotionConfig:r,crossfade:x,layoutScroll:p,layoutRoot:m,layoutAnchor:g})}function ub(n){if(n)return n.options.allowProjection!==!1?n.projection:ub(n.parent)}function af(n,{forwardMotionProps:a=!1,type:i}={},r,l){r&&xj(r);const d=i?i==="svg":zh(n),h=d?zj:Dj;function y(m,g){let x;const b={...w.useContext(Zr),...m,layoutId:_j(m)},{isStatic:M}=b,S=Sj(m),T=h(m,M);if(!M&&typeof window<"u"){Bj();const j=Uj(b);x=j.MeasureLayout,S.visualElement=Lj(n,T,b,l,j.ProjectionNode,d)}return u.jsxs(mc.Provider,{value:S,children:[x&&S.visualElement?u.jsx(x,{visualElement:S.visualElement,...b}):null,Aj(n,m,Oj(T,S.visualElement,g),T,M,a,d)]})}y.displayName=`motion.${typeof n=="string"?n:`create(${n.displayName??n.name??""})`}`;const p=w.forwardRef(y);return p[Vj]=n,p}function _j({layoutId:n}){const a=w.useContext(sh).id;return a&&n!==void 0?a+"-"+n:n}function Bj(n,a){w.useContext(ab).strict}function Uj(n){const a=sb(),{drag:i,layout:r}=a;if(!i&&!r)return{};const l={...i,...r};return{MeasureLayout:i?.isEnabled(n)||r?.isEnabled(n)?l.MeasureLayout:void 0,ProjectionNode:l.ProjectionNode}}function Hj(n,a){if(typeof Proxy>"u")return af;const i=new Map,r=(d,h)=>af(d,h,n,a),l=(d,h)=>r(d,h);return new Proxy(l,{get:(d,h)=>h==="create"?r:(i.has(h)||i.set(h,af(h,void 0,n,a)),i.get(h))})}const Fj=(n,a)=>a.isSVG??zh(n)?new x6(a):new f6(a,{allowProjection:n!==w.Fragment});class Ij extends qa{constructor(a){super(a),a.animationState||(a.animationState=S6(a))}updateAnimationControlsSubscription(){const{animate:a}=this.node.getProps();hc(a)&&(this.unmountControls=a.subscribe(this.node))}mount(){this.updateAnimationControlsSubscription()}update(){const{animate:a}=this.node.getProps(),{animate:i}=this.node.prevProps||{};a!==i&&this.updateAnimationControlsSubscription()}unmount(){this.node.animationState.reset(),this.unmountControls?.()}}let Pj=0;class Yj extends qa{constructor(){super(...arguments),this.id=Pj++,this.isExitComplete=!1}update(){if(!this.node.presenceContext)return;const{isPresent:a,onExitComplete:i}=this.node.presenceContext,{isPresent:r}=this.node.prevPresenceContext||{};if(!this.node.animationState||a===r)return;if(a&&r===!1){if(this.isExitComplete){const{initial:d,custom:h}=this.node.getProps();if(typeof d=="string"||typeof d=="object"&&d!==null&&!Array.isArray(d)){const y=bs(this.node,d,h);if(y){const{transition:p,transitionEnd:m,...g}=y;for(const x in g)this.node.getValue(x)?.jump(g[x])}}this.node.animationState.reset(),this.node.animationState.animateChanges()}else this.node.animationState.setActive("exit",!1);this.isExitComplete=!1;return}const l=this.node.animationState.setActive("exit",!a);i&&!a&&l.then(()=>{this.isExitComplete=!0,i(this.id)})}mount(){const{register:a,onExitComplete:i}=this.node.presenceContext||{};i&&i(this.id),a&&(this.unmount=a(this.id))}unmount(){}}const qj={animation:{Feature:Ij},exit:{Feature:Yj}};function Kr(n){return{point:{x:n.pageX,y:n.pageY}}}const Xj=n=>a=>Th(a)&&n(a,Kr(a));function Vr(n,a,i,r){return Br(n,a,Xj(i),r)}const db=({current:n})=>n?n.ownerDocument.defaultView:null,xx=(n,a)=>Math.abs(n-a);function $j(n,a){const i=xx(n.x,a.x),r=xx(n.y,a.y);return Math.sqrt(i**2+r**2)}const vx=new Set(["auto","scroll"]);class fb{constructor(a,i,{transformPagePoint:r,contextWindow:l=window,dragSnapToOrigin:d=!1,distanceThreshold:h=3,element:y}={}){if(this.startEvent=null,this.lastMoveEvent=null,this.lastMoveEventInfo=null,this.lastRawMoveEventInfo=null,this.handlers={},this.contextWindow=window,this.scrollPositions=new Map,this.removeScrollListeners=null,this.onElementScroll=S=>{this.handleScroll(S.target)},this.onWindowScroll=()=>{this.handleScroll(window)},this.updatePoint=()=>{if(!(this.lastMoveEvent&&this.lastMoveEventInfo))return;this.lastRawMoveEventInfo&&(this.lastMoveEventInfo=Ml(this.lastRawMoveEventInfo,this.transformPagePoint));const S=sf(this.lastMoveEventInfo,this.history),T=this.startEvent!==null,j=$j(S.offset,{x:0,y:0})>=this.distanceThreshold;if(!T&&!j)return;const{point:O}=S,{timestamp:L}=wt;this.history.push({...O,timestamp:L});const{onStart:z,onMove:D}=this.handlers;T||(z&&z(this.lastMoveEvent,S),this.startEvent=this.lastMoveEvent),D&&D(this.lastMoveEvent,S)},this.handlePointerMove=(S,T)=>{this.lastMoveEvent=S,this.lastRawMoveEventInfo=T,this.lastMoveEventInfo=Ml(T,this.transformPagePoint),Ae.update(this.updatePoint,!0)},this.handlePointerUp=(S,T)=>{this.end();const{onEnd:j,onSessionEnd:O,resumeAnimation:L}=this.handlers;if((this.dragSnapToOrigin||!this.startEvent)&&L&&L(),!(this.lastMoveEvent&&this.lastMoveEventInfo))return;const z=sf(S.type==="pointercancel"?this.lastMoveEventInfo:Ml(T,this.transformPagePoint),this.history);this.startEvent&&j&&j(S,z),O&&O(S,z)},!Th(a))return;this.dragSnapToOrigin=d,this.handlers=i,this.transformPagePoint=r,this.distanceThreshold=h,this.contextWindow=l||window;const p=Kr(a),m=Ml(p,this.transformPagePoint),{point:g}=m,{timestamp:x}=wt;this.history=[{...g,timestamp:x}];const{onSessionStart:b}=i;b&&b(a,sf(m,this.history));const M={passive:!0,capture:!0};this.removeListeners=Xr(Vr(this.contextWindow,"pointermove",this.handlePointerMove,M),Vr(this.contextWindow,"pointerup",this.handlePointerUp,M),Vr(this.contextWindow,"pointercancel",this.handlePointerUp,M)),y&&this.startScrollTracking(y)}startScrollTracking(a){let i=a.parentElement;for(;i;){const r=getComputedStyle(i);(vx.has(r.overflowX)||vx.has(r.overflowY))&&this.scrollPositions.set(i,{x:i.scrollLeft,y:i.scrollTop}),i=i.parentElement}this.scrollPositions.set(window,{x:window.scrollX,y:window.scrollY}),window.addEventListener("scroll",this.onElementScroll,{capture:!0}),window.addEventListener("scroll",this.onWindowScroll),this.removeScrollListeners=()=>{window.removeEventListener("scroll",this.onElementScroll,{capture:!0}),window.removeEventListener("scroll",this.onWindowScroll)}}handleScroll(a){const i=this.scrollPositions.get(a);if(!i)return;const r=a===window,l=r?{x:window.scrollX,y:window.scrollY}:{x:a.scrollLeft,y:a.scrollTop},d={x:l.x-i.x,y:l.y-i.y};d.x===0&&d.y===0||(r?this.lastMoveEventInfo&&(this.lastMoveEventInfo.point.x+=d.x,this.lastMoveEventInfo.point.y+=d.y):this.history.length>0&&(this.history[0].x-=d.x,this.history[0].y-=d.y),this.scrollPositions.set(a,l),Ae.update(this.updatePoint,!0))}updateHandlers(a){this.handlers=a}end(){this.removeListeners&&this.removeListeners(),this.removeScrollListeners&&this.removeScrollListeners(),this.scrollPositions.clear(),bn(this.updatePoint)}}function Ml(n,a){return a?{point:a(n.point)}:n}function bx(n,a){return{x:n.x-a.x,y:n.y-a.y}}function sf({point:n},a){return{point:n,delta:bx(n,hb(a)),offset:bx(n,Qj(a)),velocity:Zj(a,.1)}}function Qj(n){return n[0]}function hb(n){return n[n.length-1]}function Zj(n,a){if(n.length<2)return{x:0,y:0};let i=n.length-1,r=null;const l=hb(n);for(;i>=0&&(r=n[i],!(l.timestamp-r.timestamp>on(a)));)i--;if(!r)return{x:0,y:0};r===n[0]&&n.length>2&&l.timestamp-r.timestamp>on(a)*2&&(r=n[1]);const d=xn(l.timestamp-r.timestamp);if(d===0)return{x:0,y:0};const h={x:(l.x-r.x)/d,y:(l.y-r.y)/d};return h.x===1/0&&(h.x=0),h.y===1/0&&(h.y=0),h}function Kj(n,{min:a,max:i},r){return a!==void 0&&n<a?n=r?Ue(a,n,r.min):Math.max(n,a):i!==void 0&&n>i&&(n=r?Ue(i,n,r.max):Math.min(n,i)),n}function Rx(n,a,i){return{min:a!==void 0?n.min+a:void 0,max:i!==void 0?n.max+i-(n.max-n.min):void 0}}function Jj(n,{top:a,left:i,bottom:r,right:l}){return{x:Rx(n.x,i,l),y:Rx(n.y,a,r)}}function wx(n,a){let i=a.min-n.min,r=a.max-n.max;return a.max-a.min<n.max-n.min&&([i,r]=[r,i]),{min:i,max:r}}function Wj(n,a){return{x:wx(n.x,a.x),y:wx(n.y,a.y)}}function eM(n,a){let i=.5;const r=_t(n),l=_t(a);return l>r?i=xi(a.min,a.max-r,n.min):r>l&&(i=xi(n.min,n.max-l,a.min)),Dn(0,1,i)}function tM(n,a){const i={};return a.min!==void 0&&(i.min=a.min-n.min),a.max!==void 0&&(i.max=a.max-n.min),i}const If=.35;function nM(n=If){return n===!1?n=0:n===!0&&(n=If),{x:Sx(n,"left","right"),y:Sx(n,"top","bottom")}}function Sx(n,a,i){return{min:jx(n,a),max:jx(n,i)}}function jx(n,a){return typeof n=="number"?n:n[a]||0}const aM=new WeakMap;class sM{constructor(a){this.openDragLock=null,this.isDragging=!1,this.currentDirection=null,this.originPoint={x:0,y:0},this.constraints=!1,this.hasMutatedConstraints=!1,this.elastic=mt(),this.latestPointerEvent=null,this.latestPanInfo=null,this.visualElement=a}start(a,{snapToCursor:i=!1,distanceThreshold:r}={}){const{presenceContext:l}=this.visualElement;if(l&&l.isPresent===!1)return;const d=x=>{i&&this.snapToCursor(Kr(x).point),this.stopAnimation()},h=(x,b)=>{const{drag:M,dragPropagation:S,onDragStart:T}=this.getProps();if(M&&!S&&(this.openDragLock&&this.openDragLock(),this.openDragLock=A4(M),!this.openDragLock))return;this.latestPointerEvent=x,this.latestPanInfo=b,this.isDragging=!0,this.currentDirection=null,this.resolveConstraints(),this.visualElement.projection&&(this.visualElement.projection.isAnimationBlocked=!0,this.visualElement.projection.target=void 0),Bn(O=>{let L=this.getAxisMotionValue(O).get()||0;if(Fn.test(L)){const{projection:z}=this.visualElement;if(z&&z.layout){const D=z.layout.layoutBox[O];D&&(L=_t(D)*(parseFloat(L)/100))}}this.originPoint[O]=L}),T&&Ae.update(()=>T(x,b),!1,!0),Df(this.visualElement,"transform");const{animationState:j}=this.visualElement;j&&j.setActive("whileDrag",!0)},y=(x,b)=>{this.latestPointerEvent=x,this.latestPanInfo=b;const{dragPropagation:M,dragDirectionLock:S,onDirectionLock:T,onDrag:j}=this.getProps();if(!M&&!this.openDragLock)return;const{offset:O}=b;if(S&&this.currentDirection===null){this.currentDirection=rM(O),this.currentDirection!==null&&T&&T(this.currentDirection);return}this.updateAxis("x",b.point,O),this.updateAxis("y",b.point,O),this.visualElement.render(),j&&Ae.update(()=>j(x,b),!1,!0)},p=(x,b)=>{this.latestPointerEvent=x,this.latestPanInfo=b,this.stop(x,b),this.latestPointerEvent=null,this.latestPanInfo=null},m=()=>{const{dragSnapToOrigin:x}=this.getProps();(x||this.constraints)&&this.startAnimation({x:0,y:0})},{dragSnapToOrigin:g}=this.getProps();this.panSession=new fb(a,{onSessionStart:d,onStart:h,onMove:y,onSessionEnd:p,resumeAnimation:m},{transformPagePoint:this.visualElement.getTransformPagePoint(),dragSnapToOrigin:g,distanceThreshold:r,contextWindow:db(this.visualElement),element:this.visualElement.current})}stop(a,i){const r=a||this.latestPointerEvent,l=i||this.latestPanInfo,d=this.isDragging;if(this.cancel(),!d||!l||!r)return;const{velocity:h}=l;this.startAnimation(h);const{onDragEnd:y}=this.getProps();y&&Ae.postRender(()=>y(r,l))}cancel(){this.isDragging=!1;const{projection:a,animationState:i}=this.visualElement;a&&(a.isAnimationBlocked=!1),this.endPanSession();const{dragPropagation:r}=this.getProps();!r&&this.openDragLock&&(this.openDragLock(),this.openDragLock=null),i&&i.setActive("whileDrag",!1)}endPanSession(){this.panSession&&this.panSession.end(),this.panSession=void 0}updateAxis(a,i,r){const{drag:l}=this.getProps();if(!r||!Tl(a,l,this.currentDirection))return;const d=this.getAxisMotionValue(a);let h=this.originPoint[a]+r[a];this.constraints&&this.constraints[a]&&(h=Kj(h,this.constraints[a],this.elastic[a])),d.set(h)}resolveConstraints(){const{dragConstraints:a,dragElastic:i}=this.getProps(),r=this.visualElement.projection&&!this.visualElement.projection.layout?this.visualElement.projection.measure(!1):this.visualElement.projection?.layout,l=this.constraints;a&&ui(a)?this.constraints||(this.constraints=this.resolveRefConstraints()):a&&r?this.constraints=Jj(r.layoutBox,a):this.constraints=!1,this.elastic=nM(i),l!==this.constraints&&!ui(a)&&r&&this.constraints&&!this.hasMutatedConstraints&&Bn(d=>{this.constraints!==!1&&this.getAxisMotionValue(d)&&(this.constraints[d]=tM(r.layoutBox[d],this.constraints[d]))})}resolveRefConstraints(){const{dragConstraints:a,onMeasureDragConstraints:i}=this.getProps();if(!a||!ui(a))return!1;const r=a.current,{projection:l}=this.visualElement;if(!l||!l.layout)return!1;l.root&&(l.root.scroll=void 0,l.root.updateScroll());const d=r6(r,l.root,this.visualElement.getTransformPagePoint());let h=Wj(l.layout.layoutBox,d);if(i){const y=i(a6(h));this.hasMutatedConstraints=!!y,y&&(h=Ov(y))}return h}startAnimation(a){const{drag:i,dragMomentum:r,dragElastic:l,dragTransition:d,dragSnapToOrigin:h,onDragTransitionEnd:y}=this.getProps(),p=this.constraints||{},m=Bn(g=>{if(!Tl(g,i,this.currentDirection))return;let x=p&&p[g]||{};(h===!0||h===g)&&(x={min:0,max:0});const b=l?200:1e6,M=l?40:1e7,S={type:"inertia",velocity:r?a[g]:0,bounceStiffness:b,bounceDamping:M,timeConstant:750,restDelta:1,restSpeed:10,...d,...x};return this.startAxisValueAnimation(g,S)});return Promise.all(m).then(y)}startAxisValueAnimation(a,i){const r=this.getAxisMotionValue(a);return Df(this.visualElement,a),r.start(wh(a,r,0,i,this.visualElement,!1))}stopAnimation(){Bn(a=>this.getAxisMotionValue(a).stop())}getAxisMotionValue(a){const i=`_drag${a.toUpperCase()}`,l=this.visualElement.getProps()[i];return l||this.visualElement.getValue(a,this.visualElement.latestValues[a]??0)}snapToCursor(a){Bn(i=>{const{drag:r}=this.getProps();if(!Tl(i,r,this.currentDirection))return;const{projection:l}=this.visualElement,d=this.getAxisMotionValue(i);if(l&&l.layout){const{min:h,max:y}=l.layout.layoutBox[i],p=d.get()||0;d.set(a[i]-Ue(h,y,.5)+p)}})}scalePositionWithinConstraints(){if(!this.visualElement.current)return;const{drag:a,dragConstraints:i}=this.getProps(),{projection:r}=this.visualElement;if(!ui(i)||!r||!this.constraints)return;this.stopAnimation();const l={x:0,y:0};Bn(h=>{const y=this.getAxisMotionValue(h);if(y&&this.constraints!==!1){const p=y.get();l[h]=eM({min:p,max:p},this.constraints[h])}});const{transformTemplate:d}=this.visualElement.getProps();this.visualElement.current.style.transform=d?d({},""):"none",r.root&&r.root.updateScroll(),r.updateLayout(),this.constraints=!1,this.resolveConstraints(),Bn(h=>{if(!Tl(h,a,null))return;const y=this.getAxisMotionValue(h),{min:p,max:m}=this.constraints[h];y.set(Ue(p,m,l[h]))}),this.visualElement.render()}addListeners(){if(!this.visualElement.current)return;aM.set(this.visualElement,this);const a=this.visualElement.current,i=Vr(a,"pointerdown",m=>{const{drag:g,dragListener:x=!0}=this.getProps(),b=m.target,M=b!==a&&O4(b);g&&x&&!M&&this.start(m)});let r;const l=()=>{const{dragConstraints:m}=this.getProps();ui(m)&&m.current&&(this.constraints=this.resolveRefConstraints(),r||(r=iM(a,m.current,()=>this.scalePositionWithinConstraints())))},{projection:d}=this.visualElement,h=d.addEventListener("measure",l);d&&!d.layout&&(d.root&&d.root.updateScroll(),d.updateLayout()),Ae.read(l);const y=Br(window,"resize",()=>this.scalePositionWithinConstraints()),p=d.addEventListener("didUpdate",(({delta:m,hasLayoutChanged:g})=>{this.isDragging&&g&&(Bn(x=>{const b=this.getAxisMotionValue(x);b&&(this.originPoint[x]+=m[x].translate,b.set(b.get()+m[x].translate))}),this.visualElement.render())}));return()=>{y(),i(),h(),p&&p(),r&&r()}}getProps(){const a=this.visualElement.getProps(),{drag:i=!1,dragDirectionLock:r=!1,dragPropagation:l=!1,dragConstraints:d=!1,dragElastic:h=If,dragMomentum:y=!0}=a;return{...a,drag:i,dragDirectionLock:r,dragPropagation:l,dragConstraints:d,dragElastic:h,dragMomentum:y}}}function Mx(n){let a=!0;return()=>{if(a){a=!1;return}n()}}function iM(n,a,i){const r=Gf(n,Mx(i)),l=Gf(a,Mx(i));return()=>{r(),l()}}function Tl(n,a,i){return(a===!0||a===n)&&(i===null||i===n)}function rM(n,a=10){let i=null;return Math.abs(n.y)>a?i="y":Math.abs(n.x)>a&&(i="x"),i}class oM extends qa{constructor(a){super(a),this.removeGroupControls=$t,this.removeListeners=$t,this.controls=new sM(a)}mount(){const{dragControls:a}=this.node.getProps();a&&(this.removeGroupControls=a.subscribe(this.controls)),this.removeListeners=this.controls.addListeners()||$t}update(){const{dragControls:a}=this.node.getProps(),{dragControls:i}=this.node.prevProps||{};a!==i&&(this.removeGroupControls(),a&&(this.removeGroupControls=a.subscribe(this.controls)))}unmount(){this.removeGroupControls(),this.removeListeners(),this.controls.isDragging||this.controls.endPanSession()}}const rf=n=>(a,i)=>{n&&Ae.update(()=>n(a,i),!1,!0)};class lM extends qa{constructor(){super(...arguments),this.removePointerDownListener=$t}onPointerDown(a){this.session=new fb(a,this.createPanHandlers(),{transformPagePoint:this.node.getTransformPagePoint(),contextWindow:db(this.node)})}createPanHandlers(){const{onPanSessionStart:a,onPanStart:i,onPan:r,onPanEnd:l}=this.node.getProps();return{onSessionStart:rf(a),onStart:rf(i),onMove:rf(r),onEnd:(d,h)=>{delete this.session,l&&Ae.postRender(()=>l(d,h))}}}mount(){this.removePointerDownListener=Vr(this.node.current,"pointerdown",a=>this.onPointerDown(a))}update(){this.session&&this.session.updateHandlers(this.createPanHandlers())}unmount(){this.removePointerDownListener(),this.session&&this.session.end()}}let of=!1;class cM extends w.Component{componentDidMount(){const{visualElement:a,layoutGroup:i,switchLayoutGroup:r,layoutId:l}=this.props,{projection:d}=a;d&&(i.group&&i.group.add(d),r&&r.register&&l&&r.register(d),of&&d.root.didUpdate(),d.addEventListener("animationComplete",()=>{this.safeToRemove()}),d.setOptions({...d.options,layoutDependency:this.props.layoutDependency,onExitComplete:()=>this.safeToRemove()})),Il.hasEverUpdated=!0}getSnapshotBeforeUpdate(a){const{layoutDependency:i,visualElement:r,drag:l,isPresent:d}=this.props,{projection:h}=r;return h&&(h.isPresent=d,a.layoutDependency!==i&&h.setOptions({...h.options,layoutDependency:i}),of=!0,l||a.layoutDependency!==i||i===void 0||a.isPresent!==d?h.willUpdate():this.safeToRemove(),a.isPresent!==d&&(d?h.promote():h.relegate()||Ae.postRender(()=>{const y=h.getStack();(!y||!y.members.length)&&this.safeToRemove()}))),null}componentDidUpdate(){const{visualElement:a,layoutAnchor:i}=this.props,{projection:r}=a;r&&(r.options.layoutAnchor=i,r.root.didUpdate(),bi.postRender(()=>{!r.currentAnimation&&r.isLead()&&this.safeToRemove()}))}componentWillUnmount(){const{visualElement:a,layoutGroup:i,switchLayoutGroup:r}=this.props,{projection:l}=a;of=!0,l&&(l.scheduleCheckAfterUnmount(),i&&i.group&&i.group.remove(l),r&&r.deregister&&r.deregister(l))}safeToRemove(){const{safeToRemove:a}=this.props;a&&a()}render(){return null}}function pb(n){const[a,i]=nb(),r=w.useContext(sh);return u.jsx(cM,{...n,layoutGroup:r,switchLayoutGroup:w.useContext(cb),isPresent:a,safeToRemove:i})}const uM={pan:{Feature:lM},drag:{Feature:oM,ProjectionNode:tb,MeasureLayout:pb}};function Tx(n,a,i){const{props:r}=n;n.animationState&&r.whileHover&&n.animationState.setActive("whileHover",i==="Start");const l="onHover"+i,d=r[l];d&&Ae.postRender(()=>d(a,Kr(a)))}class dM extends qa{mount(){const{current:a}=this.node;a&&(this.unmount=k4(a,(i,r)=>(Tx(this.node,r,"Start"),l=>Tx(this.node,l,"End"))))}unmount(){}}class fM extends qa{constructor(){super(...arguments),this.isActive=!1}onFocus(){let a=!1;try{a=this.node.current.matches(":focus-visible")}catch{a=!0}!a||!this.node.animationState||(this.node.animationState.setActive("whileFocus",!0),this.isActive=!0)}onBlur(){!this.isActive||!this.node.animationState||(this.node.animationState.setActive("whileFocus",!1),this.isActive=!1)}mount(){this.unmount=Xr(Br(this.node.current,"focus",()=>this.onFocus()),Br(this.node.current,"blur",()=>this.onBlur()))}unmount(){}}function Nx(n,a,i){const{props:r}=n;if(n.current instanceof HTMLButtonElement&&n.current.disabled)return;n.animationState&&r.whileTap&&n.animationState.setActive("whileTap",i==="Start");const l="onTap"+(i==="End"?"":i),d=r[l];d&&Ae.postRender(()=>d(a,Kr(a)))}class hM extends qa{mount(){const{current:a}=this.node;if(!a)return;const{globalTapTarget:i,propagate:r}=this.node.props;this.unmount=G4(a,(l,d)=>(Nx(this.node,d,"Start"),(h,{success:y})=>Nx(this.node,h,y?"End":"Cancel")),{useGlobalTarget:i,stopPropagation:r?.tap===!1})}unmount(){}}const Pf=new WeakMap,lf=new WeakMap,pM=n=>{const a=Pf.get(n.target);a&&a(n)},mM=n=>{n.forEach(pM)};function gM({root:n,...a}){const i=n||document;lf.has(i)||lf.set(i,{});const r=lf.get(i),l=JSON.stringify(a);return r[l]||(r[l]=new IntersectionObserver(mM,{root:n,...a})),r[l]}function yM(n,a,i){const r=gM(a);return Pf.set(n,i),r.observe(n),()=>{Pf.delete(n),r.unobserve(n)}}const xM={some:0,all:1};class vM extends qa{constructor(){super(...arguments),this.hasEnteredView=!1,this.isInView=!1}startObserver(){this.stopObserver?.();const{viewport:a={}}=this.node.getProps(),{root:i,margin:r,amount:l="some",once:d}=a,h={root:i?i.current:void 0,rootMargin:r,threshold:typeof l=="number"?l:xM[l]},y=p=>{const{isIntersecting:m}=p;if(this.isInView===m||(this.isInView=m,d&&!m&&this.hasEnteredView))return;m&&(this.hasEnteredView=!0),this.node.animationState&&this.node.animationState.setActive("whileInView",m);const{onViewportEnter:g,onViewportLeave:x}=this.node.getProps(),b=m?g:x;b&&b(p)};this.stopObserver=yM(this.node.current,h,y)}mount(){this.startObserver()}update(){if(typeof IntersectionObserver>"u")return;const{props:a,prevProps:i}=this.node;["amount","margin","root"].some(bM(a,i))&&this.startObserver()}unmount(){this.stopObserver?.(),this.hasEnteredView=!1,this.isInView=!1}}function bM({viewport:n={}},{viewport:a={}}={}){return i=>n[i]!==a[i]}const RM={inView:{Feature:vM},tap:{Feature:hM},focus:{Feature:fM},hover:{Feature:dM}},wM={layout:{ProjectionNode:tb,MeasureLayout:pb}},SM={...qj,...RM,...uM,...wM},k=Hj(SM,Fj);function nc(n){return typeof window>"u"?!1:n?rv():bh()}const jM=50,Ex=()=>({current:0,offset:[],progress:0,scrollLength:0,targetOffset:0,targetLength:0,containerLength:0,velocity:0}),MM=()=>({time:0,x:Ex(),y:Ex()}),TM={x:{length:"Width",position:"Left"},y:{length:"Height",position:"Top"}};function Ax(n,a,i,r){const l=i[a],{length:d,position:h}=TM[a],y=l.current,p=i.time;l.current=Math.abs(n[`scroll${h}`]),l.scrollLength=n[`scroll${d}`]-n[`client${d}`],l.offset.length=0,l.offset[0]=0,l.offset[1]=l.scrollLength,l.progress=xi(0,l.scrollLength,l.current);const m=r-p;l.velocity=m>jM?0:lh(l.current-y,m)}function NM(n,a,i){Ax(n,"x",a,i),Ax(n,"y",a,i),a.time=i}function EM(n,a){const i={x:0,y:0};let r=n;for(;r&&r!==a;)if(Dr(r))i.x+=r.offsetLeft,i.y+=r.offsetTop,r=r.offsetParent;else if(r.tagName==="svg"){const l=r.getBoundingClientRect();r=r.parentElement;const d=r.getBoundingClientRect();i.x+=l.left-d.left,i.y+=l.top-d.top}else if(r instanceof SVGGraphicsElement){const{x:l,y:d}=r.getBBox();i.x+=l,i.y+=d;let h=null,y=r.parentNode;for(;!h;)y.tagName==="svg"&&(h=y),y=r.parentNode;r=h}else break;return i}const Yf={start:0,center:.5,end:1};function Cx(n,a,i=0){let r=0;if(n in Yf&&(n=Yf[n]),typeof n=="string"){const l=parseFloat(n);n.endsWith("px")?r=l:n.endsWith("%")?n=l/100:n.endsWith("vw")?r=l/100*document.documentElement.clientWidth:n.endsWith("vh")?r=l/100*document.documentElement.clientHeight:n=l}return typeof n=="number"&&(r=a*n),i+r}const AM=[0,0];function CM(n,a,i,r){let l=Array.isArray(n)?n:AM,d=0,h=0;return typeof n=="number"?l=[n,n]:typeof n=="string"&&(n=n.trim(),n.includes(" ")?l=n.split(" "):l=[n,Yf[n]?n:"0"]),d=Cx(l[0],i,r),h=Cx(l[1],a),d-h}const Er={Enter:[[0,1],[1,1]],Exit:[[0,0],[1,0]],Any:[[1,0],[0,1]],All:[[0,0],[1,1]]},kM={x:0,y:0};function DM(n){return"getBBox"in n&&n.tagName!=="svg"?n.getBBox():{width:n.clientWidth,height:n.clientHeight}}function zM(n,a,i){const{offset:r=Er.All}=i,{target:l=n,axis:d="y"}=i,h=d==="y"?"height":"width",y=l!==n?EM(l,n):kM,p=l===n?{width:n.scrollWidth,height:n.scrollHeight}:DM(l),m={width:n.clientWidth,height:n.clientHeight};a[d].offset.length=0;let g=!a[d].interpolate;const x=r.length;for(let b=0;b<x;b++){const M=CM(r[b],m[h],p[h],y[d]);!g&&M!==a[d].interpolatorOffsets[b]&&(g=!0),a[d].offset[b]=M}g&&(a[d].interpolate=gh(a[d].offset,tv(r),{clamp:!1}),a[d].interpolatorOffsets=[...a[d].offset]),a[d].progress=Dn(0,1,a[d].interpolate(a[d].current))}function VM(n,a=n,i){if(i.x.targetOffset=0,i.y.targetOffset=0,a!==n){let r=a;for(;r&&r!==n;)i.x.targetOffset+=r.offsetLeft,i.y.targetOffset+=r.offsetTop,r=r.offsetParent}i.x.targetLength=a===n?a.scrollWidth:a.clientWidth,i.y.targetLength=a===n?a.scrollHeight:a.clientHeight,i.x.containerLength=n.clientWidth,i.y.containerLength=n.clientHeight}function OM(n,a,i,r={}){return{measure:l=>{VM(n,r.target,i),NM(n,i,l),(r.offset||r.target)&&zM(n,i,r)},notify:()=>a(i)}}const oi=new WeakMap,kx=new WeakMap,cf=new WeakMap,Dx=new WeakMap,Nl=new WeakMap,zx=n=>n===document.scrollingElement?window:n;function mb(n,{container:a=document.scrollingElement,trackContentSize:i=!1,...r}={}){if(!a)return $t;let l=cf.get(a);l||(l=new Set,cf.set(a,l));const d=MM(),h=OM(a,n,d,r);if(l.add(h),!oi.has(a)){const p=()=>{for(const b of l)b.measure(wt.timestamp);Ae.preUpdate(m)},m=()=>{for(const b of l)b.notify()},g=()=>Ae.read(p);oi.set(a,g);const x=zx(a);window.addEventListener("resize",g),a!==document.documentElement&&kx.set(a,Gf(a,g)),x.addEventListener("scroll",g),g()}if(i&&!Nl.has(a)){const p=oi.get(a),m={width:a.scrollWidth,height:a.scrollHeight};Dx.set(a,m);const g=()=>{const b=a.scrollWidth,M=a.scrollHeight;(m.width!==b||m.height!==M)&&(p(),m.width=b,m.height=M)},x=Ae.read(g,!0);Nl.set(a,x)}const y=oi.get(a);return Ae.read(y,!1,!0),()=>{bn(y);const p=cf.get(a);if(!p||(p.delete(h),p.size))return;const m=oi.get(a);oi.delete(a),m&&(zx(a).removeEventListener("scroll",m),kx.get(a)?.(),window.removeEventListener("resize",m));const g=Nl.get(a);g&&(bn(g),Nl.delete(a)),Dx.delete(a)}}const LM=[[Er.Enter,"entry"],[Er.Exit,"exit"],[Er.Any,"cover"],[Er.All,"contain"]],Vx={start:0,end:1};function GM(n){const a=n.trim().split(/\s+/);if(a.length!==2)return;const i=Vx[a[0]],r=Vx[a[1]];if(!(i===void 0||r===void 0))return[i,r]}function _M(n){if(n.length!==2)return;const a=[];for(const i of n)if(Array.isArray(i))a.push(i);else if(typeof i=="string"){const r=GM(i);if(!r)return;a.push(r)}else return;return a}function BM(n,a){const i=_M(n);if(!i)return!1;for(let r=0;r<2;r++){const l=i[r],d=a[r];if(l[0]!==d[0]||l[1]!==d[1])return!1}return!0}function Vh(n){if(!n)return{rangeStart:"contain 0%",rangeEnd:"contain 100%"};for(const[a,i]of LM)if(BM(n,a))return{rangeStart:`${i} 0%`,rangeEnd:`${i} 100%`}}const Ox=new Map;function Lx(n){const a={value:0},i=mb(r=>{a.value=r[n.axis].progress*100},n);return{currentTime:a,cancel:i}}function gb({source:n,container:a,...i}){const{axis:r}=i;n&&(a=n);let l=Ox.get(a);l||(l=new Map,Ox.set(a,l));const d=i.target??"self";let h=l.get(d);h||(h={},l.set(d,h));const y=r+(i.offset??[]).join(",");return h[y]||(i.target&&nc(i.target)?Vh(i.offset)?h[y]=new ViewTimeline({subject:i.target,axis:r}):h[y]=Lx({container:a,...i}):nc()?h[y]=new ScrollTimeline({source:a,axis:r}):h[y]=Lx({container:a,...i})),h[y]}function UM(n,a){const i=gb(a),r=a.target?Vh(a.offset):void 0,l=a.target?nc(a.target)&&!!r:nc();return n.attachTimeline({timeline:l?i:void 0,...r&&l&&{rangeStart:r.rangeStart,rangeEnd:r.rangeEnd},observe:d=>(d.pause(),Cv(h=>{d.time=d.iterationDuration*h},i))})}function HM(n){return n&&(n.target||n.offset)}function FM(n){return n.length===2}function IM(n,a){return FM(n)||HM(a)?mb(i=>{n(i[a.axis].progress,i)},a):Cv(n,gb(a))}function yb(n,{axis:a="y",container:i=document.scrollingElement,...r}={}){if(!i)return $t;const l={axis:a,container:i,...r};return typeof n=="function"?IM(n,l):UM(n,l)}const PM=()=>({scrollX:An(0),scrollY:An(0),scrollXProgress:An(0),scrollYProgress:An(0)}),mi=n=>n?!n.current:!1;function Gx(n,a,i,r){return{factory:l=>{let d;const h=()=>{if(mi(i)||mi(r)){bi.read(h);return}d=yb(l,{...a,axis:n,container:i?.current||void 0,target:r?.current||void 0})};return bi.read(h),()=>{Mv(h),d?.()}},times:[0,1],keyframes:[0,1],ease:l=>l,duration:1}}function YM(n,a){return typeof window>"u"?!1:n?rv()&&!!Vh(a):bh()}function Jr({container:n,target:a,...i}={}){const r=Pa(PM);YM(a,i.offset)&&(r.scrollXProgress.accelerate=Gx("x",i,n,a),r.scrollYProgress.accelerate=Gx("y",i,n,a));const l=w.useRef(null),d=w.useRef(!1),h=w.useCallback(()=>(l.current=yb((y,{x:p,y:m})=>{r.scrollX.set(p.current),r.scrollXProgress.set(p.progress),r.scrollY.set(m.current),r.scrollYProgress.set(m.progress)},{...i,container:n?.current||void 0,target:a?.current||void 0}),()=>{l.current?.()}),[n,a,JSON.stringify(i.offset)]);return qr(()=>{if(d.current=!1,mi(n)||mi(a)){d.current=!0;return}else return h()},[h]),w.useEffect(()=>{if(!d.current)return;let y;const p=()=>{const m=mi(n),g=mi(a);!m&&!g&&(y=h())};return bi.read(p),()=>{Mv(p),y?.()}},[h]),r}function ac(n){const a=Pa(()=>An(n)),{isStatic:i}=w.useContext(Zr);if(i){const[,r]=w.useState(n);w.useEffect(()=>a.on("change",r),[])}return a}function xb(n,a){const i=ac(a()),r=()=>i.set(a());return r(),qr(()=>{const l=()=>Ae.preRender(r,!1,!0),d=n.map(h=>h.on("change",l));return()=>{d.forEach(h=>h()),bn(r)}}),i}function qM(n){kr.current=[],n();const a=xb(kr.current,n);return kr.current=void 0,a}function St(n,a,i,r){if(typeof n=="function")return qM(n);if(i!==void 0&&!Array.isArray(i)&&typeof a!="function")return XM(n,a,i,r);const h=typeof a=="function"?a:X4(a,i,r),y=Array.isArray(n)?_x(n,h):_x([n],([m])=>h(m)),p=Array.isArray(n)?void 0:n.accelerate;return p&&!p.isTransformed&&typeof a!="function"&&Array.isArray(i)&&r?.clamp!==!1&&(y.accelerate={...p,times:a,keyframes:i,isTransformed:!0}),y}function _x(n,a){const i=Pa(()=>[]);return xb(n,()=>{i.length=0;const r=n.length;for(let l=0;l<r;l++)i[l]=n[l].get();return a(i)})}function XM(n,a,i,r){const l=Pa(()=>Object.keys(i)),d=Pa(()=>({}));for(const h of l)d[h]=St(n,a,i[h],r);return d}function $M(n,a={}){const{isStatic:i}=w.useContext(Zr),r=()=>yt(n)?n.get():n;if(i)return St(r);const l=ac(r());return w.useInsertionEffect(()=>$4(l,n,a),[l,JSON.stringify(a)]),l}function Bx(n,a={}){return $M(n,{type:"spring",...a})}const QM=n=>n.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),ZM=n=>n.replace(/^([A-Z])|[\s-_]+(\w)/g,(a,i,r)=>r?r.toUpperCase():i.toLowerCase()),Ux=n=>{const a=ZM(n);return a.charAt(0).toUpperCase()+a.slice(1)},vb=(...n)=>n.filter((a,i,r)=>!!a&&a.trim()!==""&&r.indexOf(a)===i).join(" ").trim(),KM=n=>{for(const a in n)if(a.startsWith("aria-")||a==="role"||a==="title")return!0};var JM={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};const WM=w.forwardRef(({color:n="currentColor",size:a=24,strokeWidth:i=2,absoluteStrokeWidth:r,className:l="",children:d,iconNode:h,...y},p)=>w.createElement("svg",{ref:p,...JM,width:a,height:a,stroke:n,strokeWidth:r?Number(i)*24/Number(a):i,className:vb("lucide",l),...!d&&!KM(y)&&{"aria-hidden":"true"},...y},[...h.map(([m,g])=>w.createElement(m,g)),...Array.isArray(d)?d:[d]]));const Mt=(n,a)=>{const i=w.forwardRef(({className:r,...l},d)=>w.createElement(WM,{ref:d,iconNode:a,className:vb(`lucide-${QM(Ux(n))}`,`lucide-${n}`,r),...l}));return i.displayName=Ux(n),i};const eT=[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]],Oh=Mt("arrow-left",eT);const tT=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],nT=Mt("arrow-right",tT);const aT=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],Ur=Mt("check",aT);const sT=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],Lh=Mt("chevron-down",sT);const iT=[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]],Gh=Mt("copy",iT);const rT=[["path",{d:"M21.54 15H17a2 2 0 0 0-2 2v4.54",key:"1djwo0"}],["path",{d:"M7 3.34V5a3 3 0 0 0 3 3a2 2 0 0 1 2 2c0 1.1.9 2 2 2a2 2 0 0 0 2-2c0-1.1.9-2 2-2h3.17",key:"1tzkfa"}],["path",{d:"M11 21.95V18a2 2 0 0 0-2-2a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05",key:"14pb5j"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],oT=Mt("earth",rT);const lT=[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],cT=Mt("eye",lT);const uT=[["path",{d:"M10.5 3 8 9l4 13 4-13-2.5-6",key:"b3dvk1"}],["path",{d:"M17 3a2 2 0 0 1 1.6.8l3 4a2 2 0 0 1 .013 2.382l-7.99 10.986a2 2 0 0 1-3.247 0l-7.99-10.986A2 2 0 0 1 2.4 7.8l2.998-3.997A2 2 0 0 1 7 3z",key:"7w4byz"}],["path",{d:"M2 9h20",key:"16fsjt"}]],Hr=Mt("gem",uT);const dT=[["rect",{width:"18",height:"7",x:"3",y:"3",rx:"1",key:"f1a2em"}],["rect",{width:"9",height:"7",x:"3",y:"14",rx:"1",key:"jqznyg"}],["rect",{width:"5",height:"7",x:"16",y:"14",rx:"1",key:"q5h2i8"}]],fT=Mt("layout-template",dT);const hT=[["path",{d:"m10 17 5-5-5-5",key:"1bsop3"}],["path",{d:"M15 12H3",key:"6jk70r"}],["path",{d:"M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",key:"u53s6r"}]],pT=Mt("log-in",hT);const mT=[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]],_h=Mt("map-pin",mT);const gT=[["path",{d:"M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",key:"1sd12s"}]],gc=Mt("message-circle",gT);const yT=[["path",{d:"M9 18V5l12-2v13",key:"1jmyc2"}],["circle",{cx:"6",cy:"18",r:"3",key:"fqmcym"}],["circle",{cx:"18",cy:"16",r:"3",key:"1hluhg"}]],xT=Mt("music",yT);const vT=[["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",key:"9njp5v"}]],bT=Mt("phone",vT);const RT=[["rect",{width:"5",height:"5",x:"3",y:"3",rx:"1",key:"1tu5fj"}],["rect",{width:"5",height:"5",x:"16",y:"3",rx:"1",key:"1v8r4q"}],["rect",{width:"5",height:"5",x:"3",y:"16",rx:"1",key:"1x03jg"}],["path",{d:"M21 16h-3a2 2 0 0 0-2 2v3",key:"177gqh"}],["path",{d:"M21 21v.01",key:"ents32"}],["path",{d:"M12 7v3a2 2 0 0 1-2 2H7",key:"8crl2c"}],["path",{d:"M3 12h.01",key:"nlz23k"}],["path",{d:"M12 3h.01",key:"n36tog"}],["path",{d:"M12 16v.01",key:"133mhm"}],["path",{d:"M16 12h1",key:"1slzba"}],["path",{d:"M21 12v.01",key:"1lwtk9"}],["path",{d:"M12 21v-1",key:"1880an"}]],wT=Mt("qr-code",RT);const ST=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],bb=Mt("shield-check",ST);const jT=[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]],MT=Mt("sparkles",jT);const TT=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Bh=Mt("x",TT),Uh=[{id:"royal-noor",name:"Royal Noor",tagline:"A deep-navy royal envelope, golden wax seal and a cinematic 3D unsealing under falling golden leaves",taglineSw:"Bahasha ya kifalme ya bluu, muhuri wa dhahabu na ufunguzi wa 3D ukivuna majani ya dhahabu",description:"The crown jewel. A navy damask envelope sealed with golden monogrammed wax cracks open with real 3D physics — the flap falls away, your card rises through a bloom of golden light into a hero framed by baroque gold corners, a medallion of light and slowly falling golden leaves. Stacked calligraphy names, a travelling-gem events timeline with map links, a ringed countdown, a wax-sealed RSVP.",palette:["#070d22","#0e1a3d","#c9a24a","#f0d98c"],previewImage:"./royal-noor/art/noor-preview.jpg",accent:"#9A7420"},{id:"kasri-dhahabu",name:"Kasri la Dhahabu",tagline:"A bottle-green envelope, a blush wax seal and a ring of golden fire that gilds it open",taglineSw:"Bahasha ya kijani, muhuri wa waridi na pete ya moto wa dhahabu inayoifungua",description:"Our golden palace. Tap the monogrammed wax seal and a ring of golden fire sweeps across a bottle-green envelope, lighting its damask and medallions in gold, before it melts like glass into a Zanzibar palace at golden hour, framed by silk curtains and a crystal chandelier. One mihrab card carries the Basmala, the families and your letter, then a live countdown with add-to-calendar, a travelling-rosette programme, a gold-framed live map, dress code with colour palette, a sealed RSVP card and each guest's entrance QR.",palette:["#16201A","#C9A27E","#F2DFD4","#5E6B3F"],previewImage:"./kasri-dhahabu/art/preview.jpg",accent:"#8A6A3F"},{id:"blush-swan",name:"Blush Swan",tagline:"A monogrammed wax seal, golden light and two swans on a misty lake",taglineSw:"Muhuri wa shaba, mwanga wa dhahabu na Bata-maji wawili ziwanı",description:"Our flagship fairytale. A blush-pink embossed envelope sealed with your gold monogram parts with golden light to reveal a gilded mihrab arch, real rose garlands, drifting petals and two swans forming a heart — with a travelling rose-bud timeline, sketched venue art and a wax-sealed RSVP.",palette:["#f6e3e1","#e8b4b8","#6d1a2d","#c9a227"],previewImage:"./art/blush-hero-swans.jpg",accent:"#6d1a2d"},{id:"villa-rosa",name:"Villa Rosa",tagline:"A pearl-white seal, a Mediterranean courtyard, doves and deep red roses",taglineSw:"Muhuri mweupe, ua wa Mediterania, njiwa na mawaridi mekundu",description:"La dolce vita. A white embossed envelope sealed with pearl wax opens onto a sunlit villa courtyard — a stone fountain beneath an azure sky, white doves drifting overhead and lush crimson-and-ivory roses, with crimson letter, timeline, dress-code gallery and a wax-sealed RSVP.",palette:["#eef4fa","#79aede","#8a1c2e","#c9a24a"],previewImage:"./art/villa-hero.jpg",accent:"#8a1c2e"},{id:"midnight-garden",name:"Midnight Garden",tagline:"Palace doors swing open into a glowing ballroom of chandeliers and hanging gardens",taglineSw:"Milango ya kifalme inafunguka kwenye ukumbi wa taa na bustani zinazong'aa",description:"The grand reveal. Ornate palace doors part into warm golden light as crystal chandeliers ignite one by one above cascading white florals — then an illuminated arch materialises and your names bloom in gold calligraphy. A living scene: swaying chandeliers, candle flicker, drifting gold dust, parallax depth, a lantern countdown, a golden-aisle timeline, and the venue itself framed like a painting.",palette:["#0b0908","#2f3a2a","#d4af6a","#e58aa8"],previewImage:"./art/midnight-garden-hero.jpg",accent:"#A07D3B"},{id:"rose-cascade",name:"Rose Cascade",tagline:"An ivory embossed envelope, golden sparkles and a blush-pink ballroom in bloom",taglineSw:"Bahasha ya pembe za ndovu yenye muhuri wa dhahabu, miale inayong'aa na ukumbi wa maua",description:"The grand ballroom. A cream envelope embossed with white-on-white florals parts in a burst of golden light and sparkles to reveal a cascading rose wall in full bloom — ken-burns hero, letter-by-letter calligraphy names, a spinning monogram ring, live countdown, alternating golden timeline, framed gallery with cinematic lightbox, dress-code palette swatches and a wax-gold RSVP.",palette:["#faf5ee","#e8c4c0","#8a5452","#b98a2f"],previewImage:"./art/rose2-hero.jpg",accent:"#8a5452"},{id:"emerald-arch",name:"Emerald Arch",tagline:"A sealed emerald envelope, golden leaves and a Moorish arch in full bloom",taglineSw:"Bahasha ya kijani yenye muhuri, majani ya dhahabu na taji la Kiislamu",description:"The palace garden. A deep-emerald envelope with a gold wax seal opens in true 3D — the flap lifts, golden light spills, and your card rises into a Moorish arch of ivory and filigree: falling gold leaves with real physics, swaying white roses, a scroll-driven golden timeline, venue arch portrait, illustrated dress code and a wax-sealed RSVP.",palette:["#0e3b2c","#f6efdd","#c9a24a","#082a1f"],previewImage:"./art/em-hero-preview.jpg",accent:"#0e3b2c"}],q8=[{name:"Nikkah Ceremony",nameSw:"Ndoa / Nikkah",date:"",time:"10:00",venue:"Masjid, Stone Town",mapsUrl:"",dressCode:"Modest attire",notes:""},{name:"Henna Night",nameSw:"Usiku wa Henna",date:"",time:"19:00",venue:"",mapsUrl:"",dressCode:"",notes:""},{name:"Walima Reception",nameSw:"Walima / Karamu",date:"",time:"18:00",venue:"",mapsUrl:"",dressCode:"",notes:""}],X8=[{label:"M-Pesa",provider:"Vodacom M-Pesa",accountName:"",accountNumber:""},{label:"Tigo Pesa",provider:"Tigo Pesa",accountName:"",accountNumber:""},{label:"Bank (NMB)",provider:"NMB Bank",accountName:"",accountNumber:""}],NT="/login";function Rb(n){const{redirectOnUnauthenticated:a=!1,redirectPath:i=NT}=n??{},r=wi(),l=da.useUtils(),{data:d,isLoading:h,error:y,refetch:p}=da.auth.me.useQuery(void 0,{staleTime:1e3*60*5,retry:!1}),m=da.auth.logout.useMutation({onSuccess:async()=>{await l.invalidate(),r(i)}}),g=w.useCallback(()=>m.mutate(),[m]);return w.useEffect(()=>{a&&!h&&!d&&window.location.pathname!==i&&r(i)},[a,h,d,r,i]),w.useMemo(()=>({user:d??null,isAuthenticated:!!d,isLoading:h||m.isPending,error:y,logout:g,refresh:p}),[d,h,m.isPending,y,g,p])}const uf="#C6A45E",Hx="w-full rounded-xl px-4 py-3 bg-transparent outline-none text-base transition-shadow",Fx={border:"1px solid rgba(198,164,94,0.35)",color:"#F2E9D8",fontFamily:"'Cormorant Garamond', serif"};function wb({onSuccess:n}){const[a,i]=w.useState(""),[r,l]=w.useState(""),[d,h]=w.useState(null),y=wi(),p=da.auth.login.useMutation({onSuccess:g=>n?n():y(g.role==="admin"?"/admin":"/dashboard"),onError:g=>h(g.message)}),m=g=>{g.preventDefault(),h(null),p.mutate({email:a.trim(),password:r})};return u.jsxs(k.div,{"code-path":"src/components/AuthCard.tsx:38:5",initial:{opacity:0,y:26},animate:{opacity:1,y:0},transition:{duration:.7,ease:[.22,1,.36,1]},className:"w-full max-w-md rounded-[1.8rem] p-7 md:p-8 relative",style:{background:"linear-gradient(160deg, #2A2214 0%, #1C1610 60%, #14100A 100%)",border:"1px solid rgba(198,164,94,0.45)",boxShadow:"0 34px 90px rgba(30,26,18,0.35), 0 0 0 6px rgba(198,164,94,0.07)"},children:[u.jsx("span",{"code-path":"src/components/AuthCard.tsx:50:7",className:"absolute top-3 left-4 text-lg",style:{color:"rgba(198,164,94,0.55)",fontFamily:"'Amiri', serif"},children:"۝"}),u.jsx("span",{"code-path":"src/components/AuthCard.tsx:51:7",className:"absolute top-3 right-4 text-lg",style:{color:"rgba(198,164,94,0.55)",fontFamily:"'Amiri', serif"},children:"۝"}),u.jsxs("div",{"code-path":"src/components/AuthCard.tsx:53:7",className:"text-center mb-7",children:[u.jsx(Hr,{"code-path":"src/components/AuthCard.tsx:54:9",size:22,className:"mx-auto",style:{color:uf}}),u.jsx("p",{"code-path":"src/components/AuthCard.tsx:55:9",className:"mt-2 text-3xl",style:{fontFamily:"'Marcellus', serif",color:uf,letterSpacing:"0.04em"},children:"Harusi"}),u.jsx("p",{"code-path":"src/components/AuthCard.tsx:56:9",className:"text-[10px] uppercase tracking-[0.35em] opacity-60 mt-1",style:{fontFamily:"'Jost', sans-serif"},children:"Hosts Sign In"})]}),u.jsxs("form",{"code-path":"src/components/AuthCard.tsx:61:7",onSubmit:m,className:"space-y-4",children:[u.jsxs("label",{"code-path":"src/components/AuthCard.tsx:62:9",className:"block",children:[u.jsx("span",{"code-path":"src/components/AuthCard.tsx:63:11",className:"block text-[10px] uppercase tracking-[0.25em] mb-1.5 opacity-60",style:{fontFamily:"'Jost', sans-serif"},children:"Email"}),u.jsx("input",{"code-path":"src/components/AuthCard.tsx:66:11",type:"email",required:!0,className:Hx,style:Fx,value:a,onChange:g=>i(g.target.value),placeholder:"you@example.com",autoComplete:"email"})]}),u.jsxs("label",{"code-path":"src/components/AuthCard.tsx:71:9",className:"block",children:[u.jsx("span",{"code-path":"src/components/AuthCard.tsx:72:11",className:"block text-[10px] uppercase tracking-[0.25em] mb-1.5 opacity-60",style:{fontFamily:"'Jost', sans-serif"},children:"Password"}),u.jsx("input",{"code-path":"src/components/AuthCard.tsx:75:11",type:"password",required:!0,minLength:6,className:Hx,style:Fx,value:r,onChange:g=>l(g.target.value),placeholder:"••••••••",autoComplete:"current-password"})]}),d&&u.jsx("p",{"code-path":"src/components/AuthCard.tsx:83:11",className:"text-sm rounded-lg px-3 py-2",style:{background:"rgba(224,112,112,0.12)",color:"#f0a0a0",fontFamily:"'Jost', sans-serif"},children:d}),u.jsxs("button",{"code-path":"src/components/AuthCard.tsx:88:9",type:"submit",disabled:p.isPending,className:"w-full flex items-center justify-center gap-2 py-3.5 rounded-full text-sm uppercase tracking-[0.25em] font-bold cursor-pointer disabled:opacity-50 transition-transform active:scale-[0.98]",style:{background:uf,color:"#1E1A12",fontFamily:"'Jost', sans-serif"},children:[u.jsx(pT,{"code-path":"src/components/AuthCard.tsx:94:11",size:16}),p.isPending?"One moment…":"Enter Your Atelier"]})]}),u.jsxs("p",{"code-path":"src/components/AuthCard.tsx:99:7",className:"mt-6 text-center text-xs opacity-50 leading-relaxed",style:{fontFamily:"'Jost', sans-serif"},children:["Access is personal — text the Harusi admin to get your login.",u.jsx("br",{"code-path":"src/components/AuthCard.tsx:101:9"}),"Guests never need an account."]})]})}const Ze="#c9a227",El="#06281f",li="#04160f",ET=[{icon:fT,title:"Royal Template Library",desc:"Cinematic animated invitations, each a hand-crafted world of its own — a wax-sealed opening ceremony, real floral art, drifting petals and interactive moments."},{icon:gc,title:"WhatsApp Guest Links",desc:"Every guest gets a personal invitation link with their name on it. Send via WhatsApp in one tap — they RSVP without installing anything."},{icon:wT,title:"Scan-to-Confirm Codes",desc:"Each guest carries a unique code and QR. At the door, you scan or type it to confirm arrival — no more gate-crashers, no paper lists."},{icon:xT,title:"Music, Motion & Wax Seals",desc:"Taarab-inspired instrumentals, falling gold dust, frangipani petals, lantern light — every invitation opens like a ceremony."},{icon:oT,title:"English & Kiswahili",desc:"One tap switches the whole invitation between English and Kiswahili, so bibi na babu read it as comfortably as your cousins abroad."},{icon:bb,title:"RSVP, Handled Beautifully",desc:"Attendance, plus-ones and dietary needs per guest — all in one link."}];const AT=(()=>{const J8a=u.jsx,J8b=u.jsxs,J8c=u.Fragment;
const R = w, M = k, Link = Vt, useAuth = Rb, TPLS = Uh, mkIcon = Mt;
const PAPER = "#FBF8F2", PAPER2 = "#F4EFE3", CARD = "#FFFDF8", INK = "#1E1A12", INK62 = "rgba(30,26,18,0.62)", INK42 = "rgba(30,26,18,0.42)", LINE = "rgba(30,26,18,0.14)", GOLD = "#A07D3B", GOLD2 = "#C6A45E", GOLDT = "rgba(160,125,59,0.16)";
const FM = "'Marcellus', serif", FC = "'Cormorant Garamond', serif", FJ = "'Jost', sans-serif", FA = "'Amiri', serif";
const RM = typeof window !== "undefined" && window.matchMedia ? window.matchMedia("(prefers-reduced-motion: reduce)").matches : false;
const FINE = typeof window !== "undefined" && window.matchMedia ? window.matchMedia("(pointer: fine)").matches : false;
const ICheck = Ur, IArrow = nT, ISpark = MT, ITpl = fT, IChat = gc, IQr = wT, IGlobe = oT, IShield = bb;
const ICrown = mkIcon("crown", [["path", { d: "m2 4 3 12h14l3-12-6 7-4-7-4 7-6-7zm3 16h14", key: "hzc1" }]]);
const IMinus = mkIcon("minus", [["path", { d: "M5 12h14", key: "hzm1" }]]);
const IPlus = mkIcon("plus", [["path", { d: "M5 12h14", key: "hzp1" }], ["path", { d: "M12 5v14", key: "hzp2" }]]);
const IPen = mkIcon("pen-tool", [["path", { d: "M15.707 21.293a1 1 0 0 1-1.414 0l-1.586-1.586a1 1 0 0 1 0-1.414l5.586-5.586a1 1 0 0 1 1.414 0l1.586 1.586a1 1 0 0 1 0 1.414z", key: "hzt1" }], ["path", { d: "m18 13-1.375-6.874a1 1 0 0 0-.746-.776L3.235 2.028a1 1 0 0 0-1.207 1.207L5.35 15.879a1 1 0 0 0 .776.746L13 18", key: "hzt2" }], ["path", { d: "m2.3 2.3 7.286 7.286", key: "hzt3" }], ["circle", { cx: "11", cy: "11", r: "2", key: "hzt4" }]]);
const IUsers = mkIcon("users", [["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "hzu1" }], ["circle", { cx: "9", cy: "7", r: "4", key: "hzu2" }], ["path", { d: "M22 21v-2a4 4 0 0 0-3-3.87", key: "hzu3" }], ["path", { d: "M16 3.13a4 4 0 0 1 0 7.75", key: "hzu4" }]]);
const DEF_CFG = { perGuestRate: 1200, extraGuestRate: 1400, customTemplateFee: 1e5 };
let cfgCache = null;
function fetchPricing() {
  if (cfgCache) return Promise.resolve(cfgCache);
  const url = "https://firestore.googleapis.com/v1/projects/harusi-2e14f/databases/(default)/documents/config/pricing?key=AIzaSyDFmlxW4ZkRHUr5vFcttAbRX-Ct441-R9w";
  return fetch(url).then((r) => r.ok ? r.json() : null).then((d) => {
    if (!d || !d.fields) return DEF_CFG;
    const g = (k) => {
      const v = d.fields[k];
      return v ? Number(v.integerValue != null ? v.integerValue : v.doubleValue) || 0 : 0;
    };
    cfgCache = {
      perGuestRate: g("perGuestRate") || DEF_CFG.perGuestRate,
      extraGuestRate: g("extraGuestRate") || DEF_CFG.extraGuestRate,
      customTemplateFee: g("customTemplateFee") || DEF_CFG.customTemplateFee
    };
    return cfgCache;
  }).catch(() => DEF_CFG);
}
function usePricing() {
  const [cfg, setCfg] = R.useState(cfgCache || DEF_CFG);
  R.useEffect(() => {
    let live = true;
    fetchPricing().then((c) => {
      if (live) setCfg(c);
    });
    return () => {
      live = false;
    };
  }, []);
  return cfg;
}
const fmt = (n) => Math.round(n).toLocaleString("en-US");
const go = (id) => {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: RM ? "auto" : "smooth", block: "start" });
};
function tiltMove(e) {
  if (!FINE || RM) return;
  const el = e.currentTarget, r = el.getBoundingClientRect();
  const px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
  el.style.transition = "transform .08s linear";
  el.style.transform = `perspective(950px) rotateX(${(0.5 - py) * 6.5}deg) rotateY(${(px - 0.5) * 7.5}deg) translateY(-4px)`;
  el.style.setProperty("--gx", px * 100 + "%");
  el.style.setProperty("--gy", py * 100 + "%");
}
function tiltOut(e) {
  const el = e.currentTarget;
  el.style.transition = "transform .55s cubic-bezier(.22,1.4,.36,1)";
  el.style.transform = "perspective(950px) rotateX(0deg) rotateY(0deg) translateY(0)";
}
function spotMove(e) {
  if (!FINE) return;
  const el = e.currentTarget, r = el.getBoundingClientRect();
  el.style.setProperty("--sx", e.clientX - r.left + "px");
  el.style.setProperty("--sy", e.clientY - r.top + "px");
}
function magMove(e) {
  if (!FINE || RM) return;
  const el = e.currentTarget, r = el.getBoundingClientRect();
  el.style.transition = "transform .18s ease-out";
  el.style.transform = `translate(${(e.clientX - r.left - r.width / 2) * 0.16}px, ${(e.clientY - r.top - r.height / 2) * 0.2}px)`;
}
function magOut(e) {
  const el = e.currentTarget;
  el.style.transition = "transform .5s cubic-bezier(.3,1.6,.4,1)";
  el.style.transform = "translate(0,0)";
}
const SPRING = [0.3, 1.35, 0.4, 1];
function Kicker({ children, light }) {
  return /* @__PURE__ */ J8b("p", { className: "flex items-center gap-3", style: { fontFamily: FJ, fontSize: 11, letterSpacing: "0.34em", textTransform: "uppercase", color: GOLD, fontWeight: 500 }, children: [
    /* @__PURE__ */ J8a("span", { style: { display: "inline-block", width: 34, height: 1, background: GOLD } }),
    children
  ] });
}
function Nav({ authed }) {
  const [sc, setSc] = R.useState(false);
  R.useEffect(() => {
    const f = () => setSc((window.scrollY || 0) > 28);
    f();
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);
  const link = "nx-u";
  return /* @__PURE__ */ J8a("nav", { style: {
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    zIndex: 40,
    background: sc ? "rgba(251,248,242,0.92)" : "rgba(251,248,242,0.72)",
    backdropFilter: "blur(14px)",
    WebkitBackdropFilter: "blur(14px)",
    borderBottom: `1px solid ${sc ? LINE : "transparent"}`,
    boxShadow: sc ? "0 10px 40px rgba(60,44,16,0.08)" : "none",
    transition: "background .35s ease, border-color .35s ease, box-shadow .35s ease"
  }, children: /* @__PURE__ */ J8b("div", { style: { maxWidth: 1240, margin: "0 auto", padding: "16px 24px", display: "flex", alignItems: "center", justifyContent: "space-between" }, children: [
    /* @__PURE__ */ J8b(Link, { to: "/", style: { display: "flex", alignItems: "center", gap: 10, textDecoration: "none" }, children: [
      /* @__PURE__ */ J8a("span", { className: "nx-gem", "aria-hidden": "true" }),
      /* @__PURE__ */ J8a("span", { style: { fontFamily: FM, fontSize: 24, color: INK, letterSpacing: "0.02em" }, children: "Harusi" }),
      /* @__PURE__ */ J8a("span", { style: { fontFamily: FJ, fontSize: 9, letterSpacing: "0.32em", textTransform: "uppercase", color: GOLD, marginTop: 4 }, className: "hidden sm:inline", children: "Zanzibar" })
    ] }),
    /* @__PURE__ */ J8b("div", { style: { display: "flex", alignItems: "center", gap: "clamp(14px,3vw,34px)", fontFamily: FJ }, children: [
      /* @__PURE__ */ J8a(Link, { to: "/templates", className: link, style: { fontSize: 13, letterSpacing: "0.06em", color: INK62, textDecoration: "none" }, children: "Templates" }),
      /* @__PURE__ */ J8a("button", { onClick: () => go("pricing"), className: link, style: { fontSize: 13, letterSpacing: "0.06em", color: INK62, background: "none", border: "none", cursor: "pointer", fontFamily: FJ }, children: "Pricing" }),
      /* @__PURE__ */ J8a(Link, { to: "/demo", className: link, style: { fontSize: 13, letterSpacing: "0.06em", color: INK62, textDecoration: "none" }, children: "Live demo" }),
      authed ? /* @__PURE__ */ J8a(Link, { to: "/dashboard", onPointerMove: magMove, onPointerLeave: magOut, className: "nx-btn-ink", style: { fontSize: 12, letterSpacing: "0.14em", textTransform: "uppercase", padding: "11px 22px", textDecoration: "none" }, children: "Dashboard" }) : /* @__PURE__ */ J8a(Link, { to: "/login", onPointerMove: magMove, onPointerLeave: magOut, className: "nx-btn-ink", style: { fontSize: 12, letterSpacing: "0.14em", textTransform: "uppercase", padding: "11px 22px", textDecoration: "none" }, children: "Sign in" })
    ] })
  ] }) });
}
function Hero({ authed }) {
  return /* @__PURE__ */ J8b("section", { style: { position: "relative", minHeight: "100dvh", display: "flex", alignItems: "center", padding: "130px 24px 90px", overflow: "hidden" }, children: [
    /* @__PURE__ */ J8a("div", { "aria-hidden": "true", style: { position: "absolute", inset: 0, background: `radial-gradient(90% 60% at 82% 8%, ${GOLDT}, transparent 60%), radial-gradient(60% 50% at 4% 92%, rgba(160,125,59,0.10), transparent 65%)` } }),
    /* @__PURE__ */ J8a("div", { "aria-hidden": "true", className: "nx-outline", style: { position: "absolute", right: "-2vw", top: "6%", fontFamily: FM, fontSize: "17vw", lineHeight: 1, userSelect: "none" }, children: "Harusi" }),
    /* @__PURE__ */ J8b("div", { style: { position: "relative", maxWidth: 1240, margin: "0 auto", width: "100%", display: "grid", gridTemplateColumns: "repeat(12, 1fr)", gap: 32, alignItems: "center" }, className: "nx-hero-grid", children: [
      /* @__PURE__ */ J8b("div", { className: "nx-hero-copy", style: { gridColumn: "span 7" }, children: [
        /* @__PURE__ */ J8a(
          M.p,
          {
            initial: { opacity: 0 },
            animate: { opacity: 1 },
            transition: { duration: 1.2 },
            style: { fontFamily: FA, fontSize: 21, color: GOLD, marginBottom: 26 },
            children: "\u0628\u0650\u0633\u0652\u0645\u0650 \u0627\u0644\u0644\u064E\u0651\u0647\u0650 \u0627\u0644\u0631\u064E\u0651\u062D\u0652\u0645\u064E\u0670\u0646\u0650 \u0627\u0644\u0631\u064E\u0651\u062D\u0650\u064A\u0645\u0650"
          }
        ),
        /* @__PURE__ */ J8a(M.div, { initial: { opacity: 0, y: 14 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.7, delay: 0.1 }, children: /* @__PURE__ */ J8a(Kicker, { children: "Zanzibar \xB7 Digital invitation atelier" }) }),
        /* @__PURE__ */ J8b(
          M.h1,
          {
            initial: { opacity: 0, y: 18 },
            animate: { opacity: 1, y: 0 },
            transition: { duration: 0.8, delay: 0.18 },
            style: { fontFamily: FM, fontWeight: 400, fontSize: "clamp(42px, 5.4vw, 78px)", lineHeight: 1.06, letterSpacing: "-0.01em", color: INK, marginTop: 24, textWrap: "balance" },
            children: [
              "Your wedding invitation,",
              /* @__PURE__ */ J8a("br", {}),
              /* @__PURE__ */ J8a("span", { style: { fontFamily: FC, fontStyle: "italic", color: GOLD, fontSize: "1.08em" }, children: "alive" }),
              " in every",
              /* @__PURE__ */ J8a("br", {}),
              "guest's hand."
            ]
          }
        ),
        /* @__PURE__ */ J8a(
          M.p,
          {
            initial: { opacity: 0, y: 14 },
            animate: { opacity: 1, y: 0 },
            transition: { duration: 0.7, delay: 0.3 },
            style: { fontFamily: FC, fontSize: 21, lineHeight: 1.55, color: INK62, maxWidth: "46ch", marginTop: 26 },
            children: "Animated royal cards, personal WhatsApp links, RSVP tracking and door check-in codes \u2014 from Nikkah to Walima."
          }
        ),
        /* @__PURE__ */ J8b(
          M.div,
          {
            initial: { opacity: 0, y: 14 },
            animate: { opacity: 1, y: 0 },
            transition: { duration: 0.7, delay: 0.42 },
            style: { display: "flex", alignItems: "center", gap: 26, marginTop: 38, flexWrap: "wrap" },
            children: [
              /* @__PURE__ */ J8b(
                Link,
                {
                  to: authed ? "/dashboard" : "/login",
                  onPointerMove: magMove,
                  onPointerLeave: magOut,
                  className: "nx-btn-ink",
                  style: { display: "inline-flex", alignItems: "center", gap: 10, padding: "17px 34px", fontSize: 13, letterSpacing: "0.18em", textTransform: "uppercase", textDecoration: "none", fontWeight: 600 },
                  children: [
                    "Begin your invitation ",
                    /* @__PURE__ */ J8a(IArrow, { size: 15 })
                  ]
                }
              ),
              /* @__PURE__ */ J8a("button", { onClick: () => go("collection"), className: "nx-u", style: { background: "none", border: "none", cursor: "pointer", fontFamily: FJ, fontSize: 13, letterSpacing: "0.14em", textTransform: "uppercase", color: INK, padding: 0 }, children: "See the collection" })
            ]
          }
        ),
        /* @__PURE__ */ J8a(
          M.div,
          {
            initial: { opacity: 0 },
            animate: { opacity: 1 },
            transition: { duration: 0.9, delay: 0.55 },
            style: { display: "flex", gap: 22, flexWrap: "wrap", marginTop: 44, fontFamily: FJ, fontSize: 12, letterSpacing: "0.1em", color: INK42, textTransform: "uppercase" },
            children: ["No app to install", "English \xB7 Kiswahili", "Ready in minutes"].map((t) => /* @__PURE__ */ J8b("span", { style: { display: "flex", alignItems: "center", gap: 8 }, children: [
              /* @__PURE__ */ J8a(ICheck, { size: 13, style: { color: GOLD } }),
              t
            ] }, t))
          }
        )
      ] }),
      /* @__PURE__ */ J8a("div", { className: "nx-hero-art", style: { gridColumn: "span 5", position: "relative", display: "flex", justifyContent: "center" }, children: /* @__PURE__ */ J8b(M.div, { initial: { opacity: 0, y: 26 }, animate: { opacity: 1, y: 0 }, transition: { duration: 1, delay: 0.35 }, style: { position: "relative" }, children: [
        /* @__PURE__ */ J8b("div", { className: "nx-tilt nx-archwrap", onPointerMove: tiltMove, onPointerLeave: tiltOut, style: { position: "relative" }, children: [
          /* @__PURE__ */ J8a("div", { "aria-hidden": "true", style: { position: "absolute", inset: -14, border: `1px solid rgba(160,125,59,0.4)`, borderRadius: "240px 240px 26px 26px" } }),
          /* @__PURE__ */ J8a(
            "img",
            {
              src: "./art/hero-ivory.jpg",
              alt: "Ivory and gold-foil wedding invitation on linen with orchids",
              style: { display: "block", width: "min(400px, 78vw)", height: "auto", aspectRatio: "3/4.1", objectFit: "cover", borderRadius: "220px 220px 22px 22px", boxShadow: "0 50px 100px rgba(74,58,26,0.22), 0 8px 24px rgba(74,58,26,0.12)" }
            }
          ),
          /* @__PURE__ */ J8a("div", { className: "nx-glare", "aria-hidden": "true" })
        ] }),
        /* @__PURE__ */ J8b("div", { className: "nx-float1", style: { position: "absolute", top: "16%", right: -26, background: "rgba(255,253,248,0.92)", backdropFilter: "blur(8px)", border: `1px solid ${LINE}`, borderRadius: 16, padding: "12px 16px", display: "flex", alignItems: "center", gap: 10, boxShadow: "0 18px 44px rgba(74,58,26,0.16)" }, children: [
          /* @__PURE__ */ J8a("span", { style: { width: 26, height: 26, borderRadius: "50%", border: `1px solid ${GOLD}`, display: "flex", alignItems: "center", justifyContent: "center" }, children: /* @__PURE__ */ J8a(ICheck, { size: 13, style: { color: GOLD } }) }),
          /* @__PURE__ */ J8b("span", { style: { fontFamily: FJ, fontSize: 12, color: INK, letterSpacing: "0.04em" }, children: [
            "Fatma Juma \xB7 ",
            /* @__PURE__ */ J8a("b", { style: { color: GOLD }, children: "Attending" })
          ] })
        ] }),
        /* @__PURE__ */ J8b("div", { className: "nx-float2", style: { position: "absolute", bottom: "12%", left: -34, background: "rgba(255,253,248,0.92)", backdropFilter: "blur(8px)", border: `1px solid ${LINE}`, borderRadius: 16, padding: "12px 16px", display: "flex", alignItems: "center", gap: 10, boxShadow: "0 18px 44px rgba(74,58,26,0.16)" }, children: [
          /* @__PURE__ */ J8a("span", { style: { width: 26, height: 26, borderRadius: "50%", border: `1px solid ${GOLD}`, display: "flex", alignItems: "center", justifyContent: "center" }, children: /* @__PURE__ */ J8a(IQr, { size: 13, style: { color: GOLD } }) }),
          /* @__PURE__ */ J8b("span", { style: { fontFamily: FJ, fontSize: 12, color: INK, letterSpacing: "0.04em" }, children: [
            "Door code \xB7 ",
            /* @__PURE__ */ J8a("b", { style: { color: GOLD }, children: "checked in" })
          ] })
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ J8b("div", { "aria-hidden": "true", style: { position: "absolute", bottom: 26, left: "50%", transform: "translateX(-50%)", display: "flex", flexDirection: "column", alignItems: "center", gap: 10, opacity: 0.55 }, children: [
      /* @__PURE__ */ J8a("span", { style: { fontFamily: FJ, fontSize: 10, letterSpacing: "0.32em", textTransform: "uppercase", color: INK62 }, children: "Scroll" }),
      /* @__PURE__ */ J8a("span", { className: RM ? "" : "nx-cue", style: { display: "block", width: 1, height: 34, background: GOLD } })
    ] })
  ] });
}
function Strip() {
  const items = ["Nikkah", "Henna", "Sendema", "Engagement", "Walima", "Reception"];
  return /* @__PURE__ */ J8a("div", { style: { borderTop: `1px solid ${LINE}`, borderBottom: `1px solid ${LINE}`, background: PAPER2 }, children: /* @__PURE__ */ J8a("div", { style: { maxWidth: 1240, margin: "0 auto", padding: "20px 24px", display: "flex", justifyContent: "center", gap: "clamp(14px, 3.4vw, 44px)", flexWrap: "wrap" }, children: items.map((w, i) => /* @__PURE__ */ J8b("span", { style: { display: "flex", alignItems: "center", gap: "clamp(14px, 3.4vw, 44px)" }, children: [
    /* @__PURE__ */ J8a("span", { style: { fontFamily: FC, fontStyle: "italic", fontSize: 19, color: INK62 }, children: w }),
    i < items.length - 1 && /* @__PURE__ */ J8a("span", { "aria-hidden": "true", style: { width: 5, height: 5, background: GOLD, transform: "rotate(45deg)", display: "inline-block" } })
  ] }, w)) }) });
}
function Collection() {
  const [first, ...rest] = TPLS;
  return /* @__PURE__ */ J8a("section", { id: "collection", style: { padding: "120px 24px 110px", scrollMarginTop: 70 }, children: /* @__PURE__ */ J8b("div", { style: { maxWidth: 1240, margin: "0 auto" }, children: [
    /* @__PURE__ */ J8b("div", { className: "nx-col-head", style: { display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 30, flexWrap: "wrap", marginBottom: 64 }, children: [
      /* @__PURE__ */ J8b("div", { children: [
        /* @__PURE__ */ J8a(Kicker, { children: "The collection" }),
        /* @__PURE__ */ J8b("h2", { style: { fontFamily: FM, fontWeight: 400, fontSize: "clamp(34px, 4vw, 56px)", lineHeight: 1.1, color: INK, marginTop: 20, letterSpacing: "-0.01em", textWrap: "balance" }, children: [
          "Templates that open",
          /* @__PURE__ */ J8a("br", {}),
          "like ",
          /* @__PURE__ */ J8a("span", { style: { fontFamily: FC, fontStyle: "italic", color: GOLD }, children: "ceremonies" })
        ] })
      ] }),
      /* @__PURE__ */ J8a("p", { style: { fontFamily: FC, fontStyle: "italic", fontSize: 19, color: INK62, maxWidth: "32ch", lineHeight: 1.5, paddingBottom: 6 }, children: "Each one a hand-crafted world \u2014 choose the door your guests will walk through." })
    ] }),
    /* @__PURE__ */ J8b("div", { className: "nx-col-grid", style: { display: "grid", gridTemplateColumns: "repeat(12, 1fr)", gap: 28 }, children: [
      /* @__PURE__ */ J8a(
        M.article,
        {
          initial: { opacity: 0, y: 24 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, margin: "-60px" },
          transition: { duration: 0.7 },
          className: "nx-feat",
          style: { gridColumn: "span 7" },
          children: /* @__PURE__ */ J8b(
            "div",
            {
              className: "nx-tilt nx-spot",
              onPointerMove: (e) => {
                tiltMove(e);
                spotMove(e);
              },
              onPointerLeave: tiltOut,
              style: { position: "relative", borderRadius: 26, overflow: "hidden", border: `1px solid ${LINE}`, background: CARD, boxShadow: "0 30px 70px rgba(74,58,26,0.12)" },
              children: [
                /* @__PURE__ */ J8b("div", { style: { position: "relative", height: 420, overflow: "hidden" }, children: [
                  /* @__PURE__ */ J8a("img", { src: first.previewImage, alt: first.name, style: { width: "100%", height: "100%", objectFit: "cover" } }),
                  /* @__PURE__ */ J8a("div", { style: { position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(20,16,8,0.55), transparent 45%)" } }),
                  /* @__PURE__ */ J8b("div", { style: { position: "absolute", top: 20, left: 20, display: "flex", alignItems: "center", gap: 8, background: "rgba(251,248,242,0.92)", backdropFilter: "blur(6px)", padding: "8px 14px", borderRadius: 4, fontFamily: FJ, fontSize: 10, letterSpacing: "0.26em", textTransform: "uppercase", color: GOLD }, children: [
                    /* @__PURE__ */ J8a(ICrown, { size: 12 }),
                    " Crown jewel"
                  ] }),
                  /* @__PURE__ */ J8a("div", { style: { position: "absolute", bottom: 20, left: 24, display: "flex", gap: 7 }, children: first.palette.map((c) => /* @__PURE__ */ J8a("span", { style: { width: 18, height: 18, borderRadius: "50%", background: c, border: "1px solid rgba(255,255,255,0.5)" } }, c)) })
                ] }),
                /* @__PURE__ */ J8b("div", { style: { padding: "30px 32px 34px" }, children: [
                  /* @__PURE__ */ J8a("h3", { style: { fontFamily: FM, fontSize: 32, fontWeight: 400, color: INK }, children: first.name }),
                  /* @__PURE__ */ J8a("p", { style: { fontFamily: FC, fontStyle: "italic", fontSize: 18, color: GOLD, marginTop: 6 }, children: first.tagline }),
                  /* @__PURE__ */ J8a("p", { style: { fontFamily: FC, fontSize: 18, lineHeight: 1.6, color: INK62, marginTop: 14, maxWidth: "58ch" }, children: first.description }),
                  /* @__PURE__ */ J8b(Link, { to: `/demo?template=${first.id}`, className: "nx-arrow", style: { display: "inline-flex", alignItems: "center", gap: 10, marginTop: 22, fontFamily: FJ, fontSize: 12, letterSpacing: "0.2em", textTransform: "uppercase", color: INK, textDecoration: "none" }, children: [
                    "Preview live ",
                    /* @__PURE__ */ J8a(IArrow, { size: 14, className: "nx-arrow-i", style: { color: GOLD } })
                  ] })
                ] })
              ]
            }
          )
        }
      ),
      /* @__PURE__ */ J8a("div", { className: "nx-col-rest", style: { gridColumn: "span 5", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 28 }, children: rest.map((t, i) => /* @__PURE__ */ J8b(
        M.article,
        {
          initial: { opacity: 0, y: 24 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, margin: "-40px" },
          transition: { duration: 0.6, delay: i * 0.08 },
          className: "nx-tilt nx-spot",
          onPointerMove: (e) => {
            tiltMove(e);
            spotMove(e);
          },
          onPointerLeave: tiltOut,
          style: { borderRadius: 22, overflow: "hidden", border: `1px solid ${LINE}`, background: CARD, display: "flex", flexDirection: "column", boxShadow: "0 18px 44px rgba(74,58,26,0.08)" },
          children: [
            /* @__PURE__ */ J8a("div", { style: { position: "relative", height: 190, overflow: "hidden" }, children: /* @__PURE__ */ J8a("img", { src: t.previewImage, alt: t.name, loading: "lazy", style: { width: "100%", height: "100%", objectFit: "cover" } }) }),
            /* @__PURE__ */ J8b("div", { style: { padding: "20px 20px 22px", display: "flex", flexDirection: "column", flex: 1 }, children: [
              /* @__PURE__ */ J8b("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" }, children: [
                /* @__PURE__ */ J8a("h3", { style: { fontFamily: FM, fontSize: 21, fontWeight: 400, color: INK }, children: t.name }),
                /* @__PURE__ */ J8a("div", { style: { display: "flex", gap: 4 }, children: t.palette.map((c) => /* @__PURE__ */ J8a("span", { style: { width: 12, height: 12, borderRadius: "50%", background: c, border: "1px solid rgba(30,26,18,0.15)" } }, c)) })
              ] }),
              /* @__PURE__ */ J8a("p", { style: { fontFamily: FC, fontStyle: "italic", fontSize: 15.5, color: INK62, marginTop: 6, lineHeight: 1.45, flex: 1 }, children: t.tagline }),
              /* @__PURE__ */ J8b(Link, { to: `/demo?template=${t.id}`, className: "nx-arrow", style: { display: "inline-flex", alignItems: "center", gap: 8, marginTop: 16, fontFamily: FJ, fontSize: 11, letterSpacing: "0.18em", textTransform: "uppercase", color: INK, textDecoration: "none" }, children: [
                "Preview ",
                /* @__PURE__ */ J8a(IArrow, { size: 12, className: "nx-arrow-i", style: { color: GOLD } })
              ] })
            ] })
          ]
        },
        t.id
      )) })
    ] })
  ] }) });
}
const STEPS = [
  { n: "01", t: "Design your card", d: "Pick a royal template, add your names, events (Nikkah, Henna, Walima), photos and personal touches \u2014 and watch it come alive in the live preview." },
  { n: "02", t: "Add your guests", d: "Enter each guest's name once. We create a personal link and a unique entrance code for everyone \u2014 ready to paste into WhatsApp." },
  { n: "03", t: "Track & welcome", d: "See RSVPs roll in live. On the big day, scan each guest's code at the door to confirm them \u2014 elegant and effortless." }
];
function How() {
  return /* @__PURE__ */ J8a("section", { style: { background: PAPER2, padding: "110px 24px", borderTop: `1px solid ${LINE}`, borderBottom: `1px solid ${LINE}` }, children: /* @__PURE__ */ J8b("div", { style: { maxWidth: 1240, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(12, 1fr)", gap: 32 }, className: "nx-how-grid", children: [
    /* @__PURE__ */ J8b("div", { style: { gridColumn: "span 4" }, className: "nx-how-head", children: [
      /* @__PURE__ */ J8a(Kicker, { children: "How it works" }),
      /* @__PURE__ */ J8b("h2", { style: { fontFamily: FM, fontWeight: 400, fontSize: "clamp(30px, 3.4vw, 46px)", lineHeight: 1.12, color: INK, marginTop: 20, textWrap: "balance" }, children: [
        "Three movements,",
        /* @__PURE__ */ J8a("br", {}),
        "from ",
        /* @__PURE__ */ J8a("span", { style: { fontFamily: FC, fontStyle: "italic", color: GOLD }, children: "\u201Cyes\u201D" }),
        " to karibu"
      ] })
    ] }),
    /* @__PURE__ */ J8b("div", { style: { gridColumn: "span 8" }, className: "nx-how-rows", children: [
      STEPS.map((s, i) => /* @__PURE__ */ J8b(
        M.div,
        {
          initial: { opacity: 0, y: 16 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, margin: "-40px" },
          transition: { duration: 0.55, delay: i * 0.07 },
          className: "nx-row",
          style: { display: "grid", gridTemplateColumns: "110px 1fr", gap: 24, padding: "30px 6px", borderTop: `1px solid ${LINE}`, alignItems: "baseline" },
          children: [
            /* @__PURE__ */ J8a("span", { style: { fontFamily: FM, fontSize: 44, color: GOLD, lineHeight: 1 }, children: s.n }),
            /* @__PURE__ */ J8b("div", { children: [
              /* @__PURE__ */ J8a("h3", { style: { fontFamily: FM, fontSize: 25, fontWeight: 400, color: INK }, children: s.t }),
              /* @__PURE__ */ J8a("p", { style: { fontFamily: FC, fontSize: 18.5, lineHeight: 1.55, color: INK62, marginTop: 8, maxWidth: "62ch" }, children: s.d })
            ] })
          ]
        },
        s.n
      )),
      /* @__PURE__ */ J8a("div", { style: { borderTop: `1px solid ${LINE}` } })
    ] })
  ] }) });
}
const FEATURES = [
  { icon: ITpl, title: "Royal template library", desc: "Cinematic animated invitations, each a hand-crafted world of its own." },
  { icon: IChat, title: "WhatsApp guest links", desc: "Every guest gets a personal link with their name \u2014 RSVP without installing anything." },
  { icon: IQr, title: "Scan-to-confirm codes", desc: "Unique entrance codes and QRs \u2014 no gate-crashers, no paper lists." },
  { icon: ISpark, title: "Motion, wax & wonder", desc: "Wax seals that crack open, falling leaves, lantern glow, drifting petals." },
  { icon: IGlobe, title: "English & Kiswahili", desc: "One tap switches the whole invitation \u2014 bibi na babu read as comfortably as cousins abroad." },
  { icon: IShield, title: "RSVP built in", desc: "Attendance, plus-ones and dietary notes per guest." }
];
function Included() {
  return /* @__PURE__ */ J8a("section", { style: { padding: "120px 24px" }, children: /* @__PURE__ */ J8b("div", { style: { maxWidth: 1240, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(12, 1fr)", gap: 40 }, className: "nx-inc-grid", children: [
    /* @__PURE__ */ J8b("div", { style: { gridColumn: "span 5" }, className: "nx-inc-head", children: [
      /* @__PURE__ */ J8a(Kicker, { children: "Everything included" }),
      /* @__PURE__ */ J8b("h2", { style: { fontFamily: FM, fontWeight: 400, fontSize: "clamp(30px, 3.4vw, 46px)", lineHeight: 1.12, color: INK, marginTop: 20, textWrap: "balance" }, children: [
        "One link carries the ",
        /* @__PURE__ */ J8a("span", { style: { fontFamily: FC, fontStyle: "italic", color: GOLD }, children: "whole celebration" })
      ] }),
      /* @__PURE__ */ J8a(
        M.div,
        {
          initial: { opacity: 0, y: 20 },
          whileInView: { opacity: 1, y: 0 },
          viewport: { once: true, margin: "-40px" },
          transition: { duration: 0.7 },
          className: "nx-tilt",
          onPointerMove: tiltMove,
          onPointerLeave: tiltOut,
          style: { marginTop: 44 },
          children: /* @__PURE__ */ J8a(
            "img",
            {
              src: "./art/seal-ivory.jpg",
              alt: "Cream envelopes sealed with a gold wax seal",
              style: { display: "block", width: "100%", height: 300, objectFit: "cover", borderRadius: 20, border: `1px solid ${LINE}`, boxShadow: "0 30px 70px rgba(74,58,26,0.14)" },
              loading: "lazy"
            }
          )
        }
      )
    ] }),
    /* @__PURE__ */ J8a("div", { style: { gridColumn: "span 7" }, className: "nx-inc-rows", children: FEATURES.map((f, i) => /* @__PURE__ */ J8b(
      M.div,
      {
        initial: { opacity: 0, y: 14 },
        whileInView: { opacity: 1, y: 0 },
        viewport: { once: true, margin: "-30px" },
        transition: { duration: 0.5, delay: i * 0.05 },
        className: "nx-row",
        style: { display: "flex", gap: 22, alignItems: "flex-start", padding: "22px 6px", borderTop: i === 0 ? "none" : `1px solid ${LINE}` },
        children: [
          /* @__PURE__ */ J8a("span", { style: { width: 46, height: 46, borderRadius: "50%", border: `1px solid rgba(160,125,59,0.45)`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, background: "rgba(160,125,59,0.07)" }, children: /* @__PURE__ */ J8a(f.icon, { size: 19, style: { color: GOLD } }) }),
          /* @__PURE__ */ J8b("div", { children: [
            /* @__PURE__ */ J8a("h3", { style: { fontFamily: FM, fontSize: 21, fontWeight: 400, color: INK }, children: f.title }),
            /* @__PURE__ */ J8a("p", { style: { fontFamily: FC, fontSize: 18, lineHeight: 1.5, color: INK62, marginTop: 5 }, children: f.desc })
          ] })
        ]
      },
      f.title
    )) })
  ] }) });
}
const QUICK = [200, 300, 500];
function Pricing({ authed }) {
  const cfg = usePricing();
  const [guests, setGuests] = R.useState(200);
  const price = guests * cfg.perGuestRate;
  const clamp = (v) => Math.max(100, Math.min(1e3, v));
  const tick = (d) => setGuests((g) => clamp(Math.round((g + d) / 10) * 10));
  const included = [
    "Every royal template, including new releases",
    "Personal WhatsApp link + entrance QR per guest",
    "RSVP with plus-ones & dietary notes",
    "Live dashboard with attendance stats",
    "Door scanner with check-in codes",
    "English / Kiswahili toggle"
  ];
  return /* @__PURE__ */ J8a("section", { id: "pricing", style: { background: PAPER2, borderTop: `1px solid ${LINE}`, borderBottom: `1px solid ${LINE}`, padding: "110px 24px", scrollMarginTop: 60 }, children: /* @__PURE__ */ J8b("div", { style: { maxWidth: 1120, margin: "0 auto" }, children: [
    /* @__PURE__ */ J8b("div", { style: { textAlign: "center", marginBottom: 56 }, children: [
      /* @__PURE__ */ J8a("div", { style: { display: "inline-flex" }, children: /* @__PURE__ */ J8a(Kicker, { children: "Honest pricing" }) }),
      /* @__PURE__ */ J8b("h2", { style: { fontFamily: FM, fontWeight: 400, fontSize: "clamp(32px, 3.8vw, 52px)", lineHeight: 1.1, color: INK, marginTop: 20, textWrap: "balance" }, children: [
        "Priced by your guest list.",
        /* @__PURE__ */ J8a("br", {}),
        /* @__PURE__ */ J8a("span", { style: { fontFamily: FC, fontStyle: "italic", color: GOLD }, children: "Nothing more." })
      ] })
    ] }),
    /* @__PURE__ */ J8b(
      M.div,
      {
        initial: { opacity: 0, y: 24 },
        whileInView: { opacity: 1, y: 0 },
        viewport: { once: true, margin: "-60px" },
        transition: { duration: 0.7 },
        className: "nx-price-grid",
        style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 0, background: CARD, border: `1px solid ${LINE}`, borderRadius: 28, overflow: "hidden", boxShadow: "0 40px 100px rgba(74,58,26,0.13)" },
        children: [
          /* @__PURE__ */ J8b("div", { style: { padding: "clamp(28px, 4vw, 52px)", borderRight: `1px solid ${LINE}` }, className: "nx-price-left", children: [
            /* @__PURE__ */ J8b("p", { style: { fontFamily: FJ, fontSize: 11, letterSpacing: "0.3em", textTransform: "uppercase", color: INK42, display: "flex", alignItems: "center", gap: 10 }, children: [
              /* @__PURE__ */ J8a(IUsers, { size: 14, style: { color: GOLD } }),
              " How many guests?"
            ] }),
            /* @__PURE__ */ J8b("div", { style: { display: "flex", alignItems: "center", justifyContent: "center", gap: 26, marginTop: 34 }, children: [
              /* @__PURE__ */ J8a(
                "button",
                {
                  onClick: () => tick(-10),
                  "aria-label": "Fewer guests",
                  className: "nx-step",
                  style: { width: 46, height: 46, borderRadius: "50%", border: `1px solid ${LINE}`, background: "none", color: INK, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" },
                  children: /* @__PURE__ */ J8a(IMinus, { size: 17 })
                }
              ),
              /* @__PURE__ */ J8b("div", { style: { textAlign: "center", minWidth: 132 }, children: [
                /* @__PURE__ */ J8a(
                  M.span,
                  {
                    initial: { opacity: 0.25, y: 8 },
                    animate: { opacity: 1, y: 0 },
                    transition: { duration: 0.25 },
                    style: { display: "block", fontFamily: FM, fontSize: 64, lineHeight: 1, color: INK },
                    children: guests
                  },
                  guests
                ),
                /* @__PURE__ */ J8a("span", { style: { display: "block", marginTop: 8, fontFamily: FJ, fontSize: 10, letterSpacing: "0.28em", textTransform: "uppercase", color: INK42 }, children: "guests" })
              ] }),
              /* @__PURE__ */ J8a(
                "button",
                {
                  onClick: () => tick(10),
                  "aria-label": "More guests",
                  className: "nx-step",
                  style: { width: 46, height: 46, borderRadius: "50%", border: `1px solid ${LINE}`, background: "none", color: INK, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" },
                  children: /* @__PURE__ */ J8a(IPlus, { size: 17 })
                }
              )
            ] }),
            /* @__PURE__ */ J8a(
              "input",
              {
                type: "range",
                min: 100,
                max: 1e3,
                step: 10,
                value: guests,
                onChange: (e) => setGuests(Number(e.target.value)),
                className: "nx-range",
                style: { "--fill": `${(guests - 100) / 900 * 100}%`, width: "100%", marginTop: 34 },
                "aria-label": "Guest count"
              }
            ),
            /* @__PURE__ */ J8a("div", { style: { display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap", marginTop: 22 }, children: QUICK.map((q) => /* @__PURE__ */ J8b(
              "button",
              {
                onClick: () => setGuests(q),
                className: "nx-chip2",
                style: {
                  fontFamily: FJ,
                  fontSize: 11,
                  letterSpacing: "0.16em",
                  textTransform: "uppercase",
                  padding: "9px 18px",
                  borderRadius: 999,
                  cursor: "pointer",
                  border: `1px solid ${guests === q ? INK : LINE}`,
                  background: guests === q ? INK : "transparent",
                  color: guests === q ? PAPER : INK62
                },
                children: [
                  q,
                  " guests"
                ]
              },
              q
            )) }),
            /* @__PURE__ */ J8b("p", { style: { marginTop: 26, textAlign: "center", fontFamily: FC, fontSize: 16.5, color: INK62, lineHeight: 1.5 }, children: [
              "Expecting more later? Extra guests beyond your bundle \u2014 ",
              /* @__PURE__ */ J8b("span", { style: { color: GOLD, fontWeight: 600 }, children: [
                fmt(cfg.extraGuestRate),
                " TZS"
              ] }),
              " each."
            ] })
          ] }),
          /* @__PURE__ */ J8b("div", { style: { padding: "clamp(28px, 4vw, 52px)", background: PAPER, display: "flex", flexDirection: "column" }, children: [
            /* @__PURE__ */ J8a("p", { style: { fontFamily: FJ, fontSize: 11, letterSpacing: "0.3em", textTransform: "uppercase", color: INK42 }, children: "Your package" }),
            /* @__PURE__ */ J8b(
              M.p,
              {
                initial: { opacity: 0.3, scale: 0.98 },
                animate: { opacity: 1, scale: 1 },
                transition: { duration: 0.28 },
                style: { fontFamily: FM, fontSize: "clamp(44px, 4.6vw, 62px)", lineHeight: 1.02, color: INK, marginTop: 18 },
                children: [
                  fmt(price),
                  " ",
                  /* @__PURE__ */ J8a("span", { style: { fontFamily: FJ, fontSize: 18, color: GOLD, letterSpacing: "0.08em" }, children: "TZS" })
                ]
              },
              price
            ),
            /* @__PURE__ */ J8a("p", { style: { fontFamily: FC, fontStyle: "italic", fontSize: 17, color: INK62, marginTop: 6 }, children: "one wedding \xB7 every template included" }),
            /* @__PURE__ */ J8a("ul", { style: { marginTop: 26, display: "flex", flexDirection: "column", gap: 11, flex: 1 }, children: included.map((t) => /* @__PURE__ */ J8b("li", { style: { display: "flex", gap: 12, alignItems: "flex-start", fontFamily: FC, fontSize: 17.5, color: INK }, children: [
              /* @__PURE__ */ J8a(ICheck, { size: 15, style: { color: GOLD, marginTop: 4, flexShrink: 0 } }),
              /* @__PURE__ */ J8a("span", { style: { color: INK62 }, children: t })
            ] }, t)) }),
            /* @__PURE__ */ J8b(
              Link,
              {
                to: authed ? "/dashboard" : "/login",
                onPointerMove: magMove,
                onPointerLeave: magOut,
                className: "nx-btn-ink",
                style: { marginTop: 30, display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 10, padding: "16px 30px", fontSize: 12, letterSpacing: "0.2em", textTransform: "uppercase", fontWeight: 600, textDecoration: "none", alignSelf: "flex-start" },
                children: [
                  "Begin your invitation ",
                  /* @__PURE__ */ J8a(IArrow, { size: 14 })
                ]
              }
            )
          ] })
        ]
      }
    ),
    /* @__PURE__ */ J8b(
      M.div,
      {
        initial: { opacity: 0, y: 18 },
        whileInView: { opacity: 1, y: 0 },
        viewport: { once: true },
        transition: { duration: 0.6 },
        style: { marginTop: 26, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 22, flexWrap: "wrap", padding: "24px 30px", border: `1px solid ${LINE}`, borderRadius: 20, background: CARD },
        children: [
          /* @__PURE__ */ J8b("div", { style: { display: "flex", alignItems: "center", gap: 16 }, children: [
            /* @__PURE__ */ J8a("span", { style: { width: 44, height: 44, borderRadius: 14, border: `1px solid rgba(160,125,59,0.4)`, background: "rgba(160,125,59,0.07)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }, children: /* @__PURE__ */ J8a(IPen, { size: 19, style: { color: GOLD } }) }),
            /* @__PURE__ */ J8b("div", { children: [
              /* @__PURE__ */ J8a("p", { style: { fontFamily: FM, fontSize: 19, color: INK }, children: "A template designed only for you" }),
              /* @__PURE__ */ J8a("p", { style: { fontFamily: FC, fontSize: 16.5, color: INK62, marginTop: 2 }, children: "Bespoke artwork, your palette, your story \u2014 crafted with our artists." })
            ] })
          ] }),
          /* @__PURE__ */ J8b("p", { style: { fontFamily: FM, fontSize: 28, color: INK, whiteSpace: "nowrap" }, children: [
            fmt(cfg.customTemplateFee),
            " ",
            /* @__PURE__ */ J8a("span", { style: { fontFamily: FJ, fontSize: 13, color: GOLD }, children: "TZS \xB7 one-time" })
          ] })
        ]
      }
    )
  ] }) });
}
function Final({ authed }) {
  return /* @__PURE__ */ J8b(J8c, { children: [
    /* @__PURE__ */ J8b("section", { style: { position: "relative", padding: "140px 24px 150px", overflow: "hidden", textAlign: "center" }, children: [
      /* @__PURE__ */ J8a("div", { "aria-hidden": "true", className: "nx-outline", style: { position: "absolute", left: "50%", top: "50%", transform: "translate(-50%,-50%)", fontFamily: FM, fontSize: "24vw", lineHeight: 1, userSelect: "none", whiteSpace: "nowrap" }, children: "Karibu" }),
      /* @__PURE__ */ J8b("div", { style: { position: "relative", maxWidth: 760, margin: "0 auto" }, children: [
        /* @__PURE__ */ J8a(
          M.p,
          {
            initial: { opacity: 0 },
            whileInView: { opacity: 1 },
            viewport: { once: true },
            transition: { duration: 1.1 },
            style: { fontFamily: FA, fontSize: 24, color: GOLD },
            children: "\u0628\u064E\u0627\u0631\u064E\u0643\u064E \u0627\u0644\u0644\u064E\u0651\u0647\u064F \u0644\u064E\u0643\u064F\u0645\u064E\u0627 \u0648\u064E\u062C\u064E\u0645\u064E\u0639\u064E \u0628\u064E\u064A\u0652\u0646\u064E\u0643\u064F\u0645\u064E\u0627 \u0641\u0650\u064A \u062E\u064E\u064A\u0652\u0631\u064D"
          }
        ),
        /* @__PURE__ */ J8b(
          M.h2,
          {
            initial: { opacity: 0, y: 18 },
            whileInView: { opacity: 1, y: 0 },
            viewport: { once: true },
            transition: { duration: 0.75, delay: 0.12 },
            style: { fontFamily: FM, fontWeight: 400, fontSize: "clamp(36px, 4.6vw, 64px)", lineHeight: 1.1, color: INK, marginTop: 28, textWrap: "balance" },
            children: [
              "May your union be",
              /* @__PURE__ */ J8a("br", {}),
              /* @__PURE__ */ J8a("span", { style: { fontFamily: FC, fontStyle: "italic", color: GOLD }, children: "written in light" })
            ]
          }
        ),
        /* @__PURE__ */ J8b(M.div, { initial: { opacity: 0, y: 14 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.6, delay: 0.24 }, children: [
          /* @__PURE__ */ J8b(
            Link,
            {
              to: authed ? "/dashboard" : "/login",
              onPointerMove: magMove,
              onPointerLeave: magOut,
              className: "nx-btn-ink",
              style: { display: "inline-flex", alignItems: "center", gap: 10, marginTop: 44, padding: "18px 40px", fontSize: 13, letterSpacing: "0.2em", textTransform: "uppercase", fontWeight: 600, textDecoration: "none" },
              children: [
                "Begin your invitation ",
                /* @__PURE__ */ J8a(IArrow, { size: 15 })
              ]
            }
          ),
          /* @__PURE__ */ J8a("p", { style: { marginTop: 22, fontFamily: FC, fontStyle: "italic", fontSize: 17, color: INK42 }, children: "Karibu \u2014 your guests will remember how it opened." })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ J8b("footer", { style: { borderTop: `1px solid ${LINE}`, background: PAPER2, padding: "56px 24px 46px" }, children: [
      /* @__PURE__ */ J8b("div", { style: { maxWidth: 1240, margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 26, flexWrap: "wrap" }, children: [
        /* @__PURE__ */ J8b("div", { style: { display: "flex", alignItems: "center", gap: 10 }, children: [
          /* @__PURE__ */ J8a("span", { className: "nx-gem", "aria-hidden": "true" }),
          /* @__PURE__ */ J8a("span", { style: { fontFamily: FM, fontSize: 22, color: INK }, children: "Harusi" })
        ] }),
        /* @__PURE__ */ J8b("div", { style: { display: "flex", gap: 26, flexWrap: "wrap", fontFamily: FJ, fontSize: 12, letterSpacing: "0.12em", textTransform: "uppercase" }, children: [
          /* @__PURE__ */ J8a(Link, { to: "/templates", className: "nx-u", style: { color: INK62, textDecoration: "none" }, children: "Templates" }),
          /* @__PURE__ */ J8a(Link, { to: "/demo", className: "nx-u", style: { color: INK62, textDecoration: "none" }, children: "Live demo" }),
          /* @__PURE__ */ J8a(Link, { to: "/login", className: "nx-u", style: { color: INK62, textDecoration: "none" }, children: "Host sign in" }),
          /* @__PURE__ */ J8a(Link, { to: "/admin", className: "nx-u", style: { color: INK62, textDecoration: "none" }, children: "Admin" })
        ] }),
        /* @__PURE__ */ J8a("p", { style: { fontFamily: FC, fontSize: 15.5, color: INK42 }, children: "Made with love in Zanzibar \xB7 Stone Town" })
      ] }),
      /* @__PURE__ */ J8b("p", { style: { textAlign: "center", marginTop: 34, fontFamily: FJ, fontSize: 11, letterSpacing: "0.1em", color: INK42 }, children: [
        "\xA9 ",
        (/* @__PURE__ */ new Date()).getFullYear(),
        " Harusi \u2014 Digital wedding invitations"
      ] })
    ] })
  ] });
}
function AT() {
  const { isAuthenticated } = useAuth();
  return /* @__PURE__ */ J8b("div", { className: "nx-root", style: { background: PAPER, color: INK, fontFamily: FC, minHeight: "100vh", overflowX: "clip" }, children: [
    /* @__PURE__ */ J8a("div", { className: "nx-grain", "aria-hidden": "true" }),
    /* @__PURE__ */ J8a(Nav, { authed: isAuthenticated }),
    /* @__PURE__ */ J8a(Hero, { authed: isAuthenticated }),
    /* @__PURE__ */ J8a(Strip, {}),
    /* @__PURE__ */ J8a(Collection, {}),
    /* @__PURE__ */ J8a(How, {}),
    /* @__PURE__ */ J8a(Included, {}),
    /* @__PURE__ */ J8a(Pricing, { authed: isAuthenticated }),
    /* @__PURE__ */ J8a(Final, { authed: isAuthenticated })
  ] });
}

return AT;})();function kT(){const n=wi(),{isAuthenticated:a}=Rb();return u.jsx("div",{"code-path":"src/pages/Templates.tsx:12:5",className:"min-h-screen py-20 px-6",style:{background:"#FBF8F2",color:"#1E1A12",fontFamily:"'Cormorant Garamond', serif"},children:u.jsxs("div",{"code-path":"src/pages/Templates.tsx:13:7",className:"max-w-6xl mx-auto",children:[u.jsxs("button",{"code-path":"src/pages/Templates.tsx:14:9",onClick:()=>n(-1),className:"flex items-center gap-2 text-sm opacity-70 hover:opacity-100 cursor-pointer",style:{fontFamily:"'Jost', sans-serif"},children:[u.jsx(Oh,{"code-path":"src/pages/Templates.tsx:15:11",size:15})," Back"]}),u.jsxs("div",{"code-path":"src/pages/Templates.tsx:17:9",className:"text-center mt-8 mb-14",children:[u.jsx("p",{"code-path":"src/pages/Templates.tsx:18:11",className:"text-xs uppercase tracking-[0.4em]",style:{color:"#A07D3B",fontFamily:"'Jost', sans-serif"},children:"The Template Library"}),u.jsx("h1",{"code-path":"src/pages/Templates.tsx:21:11",className:"mt-4 text-5xl",style:{fontWeight:600},children:"Choose your ceremony's face"}),u.jsx("p",{"code-path":"src/pages/Templates.tsx:22:11",className:"mt-3 opacity-70 italic max-w-xl mx-auto",children:"Every template is a complete experience — opening animation, particles and typography — ready for your names."})]}),u.jsx("div",{"code-path":"src/pages/Templates.tsx:27:9",className:"grid md:grid-cols-2 lg:grid-cols-4 gap-8",children:Uh.map((i,r)=>u.jsxs(k.div,{"code-path":"src/pages/Templates.tsx:29:13",initial:{opacity:0,y:40},animate:{opacity:1,y:0},transition:{delay:r*.15},className:"rounded-3xl overflow-hidden group",style:{border:"1px solid rgba(30,26,18,0.14)",background:"#FFFFFF",boxShadow:"0 18px 44px rgba(30,26,18,0.08)"},children:[u.jsxs("div",{"code-path":"src/pages/Templates.tsx:37:15",className:"relative h-80 overflow-hidden",children:[u.jsx("img",{"code-path":"src/pages/Templates.tsx:38:17",src:i.previewImage,alt:i.name,className:"w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"}),u.jsx("div",{"code-path":"src/pages/Templates.tsx:39:17",className:"absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity",style:{background:"rgba(30,26,18,0.45)"},children:u.jsxs(Vt,{"code-path":"src/pages/Templates.tsx:40:19",to:`/demo?template=${i.id}`,className:"flex items-center gap-2 px-6 py-3 rounded-full text-sm uppercase tracking-[0.2em]",style:{background:"#1E1A12",color:"#FBF8F2",fontFamily:"'Jost', sans-serif",fontWeight:600},children:[u.jsx(cT,{"code-path":"src/pages/Templates.tsx:45:21",size:15})," Open Live Preview"]})})]}),u.jsxs("div",{"code-path":"src/pages/Templates.tsx:49:15",className:"p-6",children:[u.jsxs("div",{"code-path":"src/pages/Templates.tsx:50:17",className:"flex items-center justify-between",children:[u.jsx("h3",{"code-path":"src/pages/Templates.tsx:51:19",className:"text-2xl",style:{fontWeight:600},children:i.name}),u.jsx("div",{"code-path":"src/pages/Templates.tsx:52:19",className:"flex gap-1",children:i.palette.map(l=>u.jsx("span",{"code-path":"src/pages/Templates.tsx:54:23",className:"w-4 h-4 rounded-full border border-white/25",style:{background:l}},l))})]}),u.jsx("p",{"code-path":"src/pages/Templates.tsx:58:17",className:"mt-1 text-sm italic opacity-70",children:i.taglineSw}),u.jsx("p",{"code-path":"src/pages/Templates.tsx:59:17",className:"mt-3 text-sm opacity-75 leading-relaxed",children:i.description}),u.jsxs(Vt,{"code-path":"src/pages/Templates.tsx:60:17",to:a?"/dashboard":"/login",className:"mt-5 inline-flex items-center gap-2 text-xs uppercase tracking-[0.25em]",style:{color:i.accent,fontFamily:"'Jost', sans-serif"},children:[u.jsx(Hr,{"code-path":"src/pages/Templates.tsx:65:19",size:13})," Use this template"]})]})]},i.id))})]})})}var DT=Object.defineProperty,sc=Object.getOwnPropertySymbols,Sb=Object.prototype.hasOwnProperty,jb=Object.prototype.propertyIsEnumerable,Ix=(n,a,i)=>a in n?DT(n,a,{enumerable:!0,configurable:!0,writable:!0,value:i}):n[a]=i,qf=(n,a)=>{for(var i in a||(a={}))Sb.call(a,i)&&Ix(n,i,a[i]);if(sc)for(var i of sc(a))jb.call(a,i)&&Ix(n,i,a[i]);return n},Xf=(n,a)=>{var i={};for(var r in n)Sb.call(n,r)&&a.indexOf(r)<0&&(i[r]=n[r]);if(n!=null&&sc)for(var r of sc(n))a.indexOf(r)<0&&jb.call(n,r)&&(i[r]=n[r]);return i};var Rs;(n=>{const a=class Se{constructor(p,m,g,x){if(this.version=p,this.errorCorrectionLevel=m,this.modules=[],this.isFunction=[],p<Se.MIN_VERSION||p>Se.MAX_VERSION)throw new RangeError("Version value out of range");if(x<-1||x>7)throw new RangeError("Mask value out of range");this.size=p*4+17;let b=[];for(let S=0;S<this.size;S++)b.push(!1);for(let S=0;S<this.size;S++)this.modules.push(b.slice()),this.isFunction.push(b.slice());this.drawFunctionPatterns();const M=this.addEccAndInterleave(g);if(this.drawCodewords(M),x==-1){let S=1e9;for(let T=0;T<8;T++){this.applyMask(T),this.drawFormatBits(T);const j=this.getPenaltyScore();j<S&&(x=T,S=j),this.applyMask(T)}}l(0<=x&&x<=7),this.mask=x,this.applyMask(x),this.drawFormatBits(x),this.isFunction=[]}static encodeText(p,m){const g=n.QrSegment.makeSegments(p);return Se.encodeSegments(g,m)}static encodeBinary(p,m){const g=n.QrSegment.makeBytes(p);return Se.encodeSegments([g],m)}static encodeSegments(p,m,g=1,x=40,b=-1,M=!0){if(!(Se.MIN_VERSION<=g&&g<=x&&x<=Se.MAX_VERSION)||b<-1||b>7)throw new RangeError("Invalid value");let S,T;for(S=g;;S++){const z=Se.getNumDataCodewords(S,m)*8,D=h.getTotalBits(p,S);if(D<=z){T=D;break}if(S>=x)throw new RangeError("Data too long")}for(const z of[Se.Ecc.MEDIUM,Se.Ecc.QUARTILE,Se.Ecc.HIGH])M&&T<=Se.getNumDataCodewords(S,z)*8&&(m=z);let j=[];for(const z of p){i(z.mode.modeBits,4,j),i(z.numChars,z.mode.numCharCountBits(S),j);for(const D of z.getData())j.push(D)}l(j.length==T);const O=Se.getNumDataCodewords(S,m)*8;l(j.length<=O),i(0,Math.min(4,O-j.length),j),i(0,(8-j.length%8)%8,j),l(j.length%8==0);for(let z=236;j.length<O;z^=253)i(z,8,j);let L=[];for(;L.length*8<j.length;)L.push(0);return j.forEach((z,D)=>L[D>>>3]|=z<<7-(D&7)),new Se(S,m,L,b)}getModule(p,m){return 0<=p&&p<this.size&&0<=m&&m<this.size&&this.modules[m][p]}getModules(){return this.modules}drawFunctionPatterns(){for(let g=0;g<this.size;g++)this.setFunctionModule(6,g,g%2==0),this.setFunctionModule(g,6,g%2==0);this.drawFinderPattern(3,3),this.drawFinderPattern(this.size-4,3),this.drawFinderPattern(3,this.size-4);const p=this.getAlignmentPatternPositions(),m=p.length;for(let g=0;g<m;g++)for(let x=0;x<m;x++)g==0&&x==0||g==0&&x==m-1||g==m-1&&x==0||this.drawAlignmentPattern(p[g],p[x]);this.drawFormatBits(0),this.drawVersion()}drawFormatBits(p){const m=this.errorCorrectionLevel.formatBits<<3|p;let g=m;for(let b=0;b<10;b++)g=g<<1^(g>>>9)*1335;const x=(m<<10|g)^21522;l(x>>>15==0);for(let b=0;b<=5;b++)this.setFunctionModule(8,b,r(x,b));this.setFunctionModule(8,7,r(x,6)),this.setFunctionModule(8,8,r(x,7)),this.setFunctionModule(7,8,r(x,8));for(let b=9;b<15;b++)this.setFunctionModule(14-b,8,r(x,b));for(let b=0;b<8;b++)this.setFunctionModule(this.size-1-b,8,r(x,b));for(let b=8;b<15;b++)this.setFunctionModule(8,this.size-15+b,r(x,b));this.setFunctionModule(8,this.size-8,!0)}drawVersion(){if(this.version<7)return;let p=this.version;for(let g=0;g<12;g++)p=p<<1^(p>>>11)*7973;const m=this.version<<12|p;l(m>>>18==0);for(let g=0;g<18;g++){const x=r(m,g),b=this.size-11+g%3,M=Math.floor(g/3);this.setFunctionModule(b,M,x),this.setFunctionModule(M,b,x)}}drawFinderPattern(p,m){for(let g=-4;g<=4;g++)for(let x=-4;x<=4;x++){const b=Math.max(Math.abs(x),Math.abs(g)),M=p+x,S=m+g;0<=M&&M<this.size&&0<=S&&S<this.size&&this.setFunctionModule(M,S,b!=2&&b!=4)}}drawAlignmentPattern(p,m){for(let g=-2;g<=2;g++)for(let x=-2;x<=2;x++)this.setFunctionModule(p+x,m+g,Math.max(Math.abs(x),Math.abs(g))!=1)}setFunctionModule(p,m,g){this.modules[m][p]=g,this.isFunction[m][p]=!0}addEccAndInterleave(p){const m=this.version,g=this.errorCorrectionLevel;if(p.length!=Se.getNumDataCodewords(m,g))throw new RangeError("Invalid argument");const x=Se.NUM_ERROR_CORRECTION_BLOCKS[g.ordinal][m],b=Se.ECC_CODEWORDS_PER_BLOCK[g.ordinal][m],M=Math.floor(Se.getNumRawDataModules(m)/8),S=x-M%x,T=Math.floor(M/x);let j=[];const O=Se.reedSolomonComputeDivisor(b);for(let z=0,D=0;z<x;z++){let X=p.slice(D,D+T-b+(z<S?0:1));D+=X.length;const J=Se.reedSolomonComputeRemainder(X,O);z<S&&X.push(0),j.push(X.concat(J))}let L=[];for(let z=0;z<j[0].length;z++)j.forEach((D,X)=>{(z!=T-b||X>=S)&&L.push(D[z])});return l(L.length==M),L}drawCodewords(p){if(p.length!=Math.floor(Se.getNumRawDataModules(this.version)/8))throw new RangeError("Invalid argument");let m=0;for(let g=this.size-1;g>=1;g-=2){g==6&&(g=5);for(let x=0;x<this.size;x++)for(let b=0;b<2;b++){const M=g-b,T=(g+1&2)==0?this.size-1-x:x;!this.isFunction[T][M]&&m<p.length*8&&(this.modules[T][M]=r(p[m>>>3],7-(m&7)),m++)}}l(m==p.length*8)}applyMask(p){if(p<0||p>7)throw new RangeError("Mask value out of range");for(let m=0;m<this.size;m++)for(let g=0;g<this.size;g++){let x;switch(p){case 0:x=(g+m)%2==0;break;case 1:x=m%2==0;break;case 2:x=g%3==0;break;case 3:x=(g+m)%3==0;break;case 4:x=(Math.floor(g/3)+Math.floor(m/2))%2==0;break;case 5:x=g*m%2+g*m%3==0;break;case 6:x=(g*m%2+g*m%3)%2==0;break;case 7:x=((g+m)%2+g*m%3)%2==0;break;default:throw new Error("Unreachable")}!this.isFunction[m][g]&&x&&(this.modules[m][g]=!this.modules[m][g])}}getPenaltyScore(){let p=0;for(let b=0;b<this.size;b++){let M=!1,S=0,T=[0,0,0,0,0,0,0];for(let j=0;j<this.size;j++)this.modules[b][j]==M?(S++,S==5?p+=Se.PENALTY_N1:S>5&&p++):(this.finderPenaltyAddHistory(S,T),M||(p+=this.finderPenaltyCountPatterns(T)*Se.PENALTY_N3),M=this.modules[b][j],S=1);p+=this.finderPenaltyTerminateAndCount(M,S,T)*Se.PENALTY_N3}for(let b=0;b<this.size;b++){let M=!1,S=0,T=[0,0,0,0,0,0,0];for(let j=0;j<this.size;j++)this.modules[j][b]==M?(S++,S==5?p+=Se.PENALTY_N1:S>5&&p++):(this.finderPenaltyAddHistory(S,T),M||(p+=this.finderPenaltyCountPatterns(T)*Se.PENALTY_N3),M=this.modules[j][b],S=1);p+=this.finderPenaltyTerminateAndCount(M,S,T)*Se.PENALTY_N3}for(let b=0;b<this.size-1;b++)for(let M=0;M<this.size-1;M++){const S=this.modules[b][M];S==this.modules[b][M+1]&&S==this.modules[b+1][M]&&S==this.modules[b+1][M+1]&&(p+=Se.PENALTY_N2)}let m=0;for(const b of this.modules)m=b.reduce((M,S)=>M+(S?1:0),m);const g=this.size*this.size,x=Math.ceil(Math.abs(m*20-g*10)/g)-1;return l(0<=x&&x<=9),p+=x*Se.PENALTY_N4,l(0<=p&&p<=2568888),p}getAlignmentPatternPositions(){if(this.version==1)return[];{const p=Math.floor(this.version/7)+2,m=this.version==32?26:Math.ceil((this.version*4+4)/(p*2-2))*2;let g=[6];for(let x=this.size-7;g.length<p;x-=m)g.splice(1,0,x);return g}}static getNumRawDataModules(p){if(p<Se.MIN_VERSION||p>Se.MAX_VERSION)throw new RangeError("Version number out of range");let m=(16*p+128)*p+64;if(p>=2){const g=Math.floor(p/7)+2;m-=(25*g-10)*g-55,p>=7&&(m-=36)}return l(208<=m&&m<=29648),m}static getNumDataCodewords(p,m){return Math.floor(Se.getNumRawDataModules(p)/8)-Se.ECC_CODEWORDS_PER_BLOCK[m.ordinal][p]*Se.NUM_ERROR_CORRECTION_BLOCKS[m.ordinal][p]}static reedSolomonComputeDivisor(p){if(p<1||p>255)throw new RangeError("Degree out of range");let m=[];for(let x=0;x<p-1;x++)m.push(0);m.push(1);let g=1;for(let x=0;x<p;x++){for(let b=0;b<m.length;b++)m[b]=Se.reedSolomonMultiply(m[b],g),b+1<m.length&&(m[b]^=m[b+1]);g=Se.reedSolomonMultiply(g,2)}return m}static reedSolomonComputeRemainder(p,m){let g=m.map(x=>0);for(const x of p){const b=x^g.shift();g.push(0),m.forEach((M,S)=>g[S]^=Se.reedSolomonMultiply(M,b))}return g}static reedSolomonMultiply(p,m){if(p>>>8||m>>>8)throw new RangeError("Byte out of range");let g=0;for(let x=7;x>=0;x--)g=g<<1^(g>>>7)*285,g^=(m>>>x&1)*p;return l(g>>>8==0),g}finderPenaltyCountPatterns(p){const m=p[1];l(m<=this.size*3);const g=m>0&&p[2]==m&&p[3]==m*3&&p[4]==m&&p[5]==m;return(g&&p[0]>=m*4&&p[6]>=m?1:0)+(g&&p[6]>=m*4&&p[0]>=m?1:0)}finderPenaltyTerminateAndCount(p,m,g){return p&&(this.finderPenaltyAddHistory(m,g),m=0),m+=this.size,this.finderPenaltyAddHistory(m,g),this.finderPenaltyCountPatterns(g)}finderPenaltyAddHistory(p,m){m[0]==0&&(p+=this.size),m.pop(),m.unshift(p)}};a.MIN_VERSION=1,a.MAX_VERSION=40,a.PENALTY_N1=3,a.PENALTY_N2=3,a.PENALTY_N3=40,a.PENALTY_N4=10,a.ECC_CODEWORDS_PER_BLOCK=[[-1,7,10,15,20,26,18,20,24,30,18,20,24,26,30,22,24,28,30,28,28,28,28,30,30,26,28,30,30,30,30,30,30,30,30,30,30,30,30,30,30],[-1,10,16,26,18,24,16,18,22,22,26,30,22,22,24,24,28,28,26,26,26,26,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28,28],[-1,13,22,18,26,18,24,18,22,20,24,28,26,24,20,30,24,28,28,26,30,28,30,30,30,30,28,30,30,30,30,30,30,30,30,30,30,30,30,30,30],[-1,17,28,22,16,22,28,26,26,24,28,24,28,22,24,24,30,28,28,26,28,30,24,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30,30]],a.NUM_ERROR_CORRECTION_BLOCKS=[[-1,1,1,1,1,1,2,2,2,2,4,4,4,4,4,6,6,6,6,7,8,8,9,9,10,12,12,12,13,14,15,16,17,18,19,19,20,21,22,24,25],[-1,1,1,1,2,2,4,4,4,5,5,5,8,9,9,10,10,11,13,14,16,17,17,18,20,21,23,25,26,28,29,31,33,35,37,38,40,43,45,47,49],[-1,1,1,2,2,4,4,6,6,8,8,8,10,12,16,12,17,16,18,21,20,23,23,25,27,29,34,34,35,38,40,43,45,48,51,53,56,59,62,65,68],[-1,1,1,2,4,4,4,5,6,8,8,11,11,16,16,18,16,19,21,25,25,25,34,30,32,35,37,40,42,45,48,51,54,57,60,63,66,70,74,77,81]],n.QrCode=a;function i(y,p,m){if(p<0||p>31||y>>>p)throw new RangeError("Value out of range");for(let g=p-1;g>=0;g--)m.push(y>>>g&1)}function r(y,p){return(y>>>p&1)!=0}function l(y){if(!y)throw new Error("Assertion error")}const d=class et{constructor(p,m,g){if(this.mode=p,this.numChars=m,this.bitData=g,m<0)throw new RangeError("Invalid argument");this.bitData=g.slice()}static makeBytes(p){let m=[];for(const g of p)i(g,8,m);return new et(et.Mode.BYTE,p.length,m)}static makeNumeric(p){if(!et.isNumeric(p))throw new RangeError("String contains non-numeric characters");let m=[];for(let g=0;g<p.length;){const x=Math.min(p.length-g,3);i(parseInt(p.substring(g,g+x),10),x*3+1,m),g+=x}return new et(et.Mode.NUMERIC,p.length,m)}static makeAlphanumeric(p){if(!et.isAlphanumeric(p))throw new RangeError("String contains unencodable characters in alphanumeric mode");let m=[],g;for(g=0;g+2<=p.length;g+=2){let x=et.ALPHANUMERIC_CHARSET.indexOf(p.charAt(g))*45;x+=et.ALPHANUMERIC_CHARSET.indexOf(p.charAt(g+1)),i(x,11,m)}return g<p.length&&i(et.ALPHANUMERIC_CHARSET.indexOf(p.charAt(g)),6,m),new et(et.Mode.ALPHANUMERIC,p.length,m)}static makeSegments(p){return p==""?[]:et.isNumeric(p)?[et.makeNumeric(p)]:et.isAlphanumeric(p)?[et.makeAlphanumeric(p)]:[et.makeBytes(et.toUtf8ByteArray(p))]}static makeEci(p){let m=[];if(p<0)throw new RangeError("ECI assignment value out of range");if(p<128)i(p,8,m);else if(p<16384)i(2,2,m),i(p,14,m);else if(p<1e6)i(6,3,m),i(p,21,m);else throw new RangeError("ECI assignment value out of range");return new et(et.Mode.ECI,0,m)}static isNumeric(p){return et.NUMERIC_REGEX.test(p)}static isAlphanumeric(p){return et.ALPHANUMERIC_REGEX.test(p)}getData(){return this.bitData.slice()}static getTotalBits(p,m){let g=0;for(const x of p){const b=x.mode.numCharCountBits(m);if(x.numChars>=1<<b)return 1/0;g+=4+b+x.bitData.length}return g}static toUtf8ByteArray(p){p=encodeURI(p);let m=[];for(let g=0;g<p.length;g++)p.charAt(g)!="%"?m.push(p.charCodeAt(g)):(m.push(parseInt(p.substring(g+1,g+3),16)),g+=2);return m}};d.NUMERIC_REGEX=/^[0-9]*$/,d.ALPHANUMERIC_REGEX=/^[A-Z0-9 $%*+.\/:-]*$/,d.ALPHANUMERIC_CHARSET="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:";let h=d;n.QrSegment=d})(Rs||(Rs={}));(n=>{(a=>{const i=class{constructor(l,d){this.ordinal=l,this.formatBits=d}};i.LOW=new i(0,1),i.MEDIUM=new i(1,0),i.QUARTILE=new i(2,3),i.HIGH=new i(3,2),a.Ecc=i})(n.QrCode||(n.QrCode={}))})(Rs||(Rs={}));(n=>{(a=>{const i=class{constructor(l,d){this.modeBits=l,this.numBitsCharCount=d}numCharCountBits(l){return this.numBitsCharCount[Math.floor((l+7)/17)]}};i.NUMERIC=new i(1,[10,12,14]),i.ALPHANUMERIC=new i(2,[9,11,13]),i.BYTE=new i(4,[8,16,16]),i.KANJI=new i(8,[8,10,12]),i.ECI=new i(7,[0,0,0]),a.Mode=i})(n.QrSegment||(n.QrSegment={}))})(Rs||(Rs={}));var gi=Rs;var zT={L:gi.QrCode.Ecc.LOW,M:gi.QrCode.Ecc.MEDIUM,Q:gi.QrCode.Ecc.QUARTILE,H:gi.QrCode.Ecc.HIGH},Mb=128,Tb="L",Nb="#FFFFFF",Eb="#000000",Ab=!1,Cb=1,VT=4,OT=0,LT=.1;function kb(n,a=0){const i=[];return n.forEach(function(r,l){let d=null;r.forEach(function(h,y){if(!h&&d!==null){i.push(`M${d+a} ${l+a}h${y-d}v1H${d+a}z`),d=null;return}if(y===r.length-1){if(!h)return;d===null?i.push(`M${y+a},${l+a} h1v1H${y+a}z`):i.push(`M${d+a},${l+a} h${y+1-d}v1H${d+a}z`);return}h&&d===null&&(d=y)})}),i.join("")}function Db(n,a){return n.slice().map((i,r)=>r<a.y||r>=a.y+a.h?i:i.map((l,d)=>d<a.x||d>=a.x+a.w?l:!1))}function GT(n,a,i,r){if(r==null)return null;const l=n.length+i*2,d=Math.floor(a*LT),h=l/a,y=(r.width||d)*h,p=(r.height||d)*h,m=r.x==null?n.length/2-y/2:r.x*h,g=r.y==null?n.length/2-p/2:r.y*h,x=r.opacity==null?1:r.opacity;let b=null;if(r.excavate){let S=Math.floor(m),T=Math.floor(g),j=Math.ceil(y+m-S),O=Math.ceil(p+g-T);b={x:S,y:T,w:j,h:O}}const M=r.crossOrigin;return{x:m,y:g,h:p,w:y,excavation:b,opacity:x,crossOrigin:M}}function _T(n,a){return a!=null?Math.max(Math.floor(a),0):n?VT:OT}function zb({value:n,level:a,minVersion:i,includeMargin:r,marginSize:l,imageSettings:d,size:h,boostLevel:y}){let p=ut.useMemo(()=>{const S=(Array.isArray(n)?n:[n]).reduce((T,j)=>(T.push(...gi.QrSegment.makeSegments(j)),T),[]);return gi.QrCode.encodeSegments(S,zT[a],i,void 0,void 0,y)},[n,a,i,y]);const{cells:m,margin:g,numCells:x,calculatedImageSettings:b}=ut.useMemo(()=>{let M=p.getModules();const S=_T(r,l),T=M.length+S*2,j=GT(M,h,S,d);return{cells:M,margin:S,numCells:T,calculatedImageSettings:j}},[p,h,d,r,l]);return{qrcode:p,margin:g,cells:m,numCells:x,calculatedImageSettings:b}}var BT=(function(){try{new Path2D().addPath(new Path2D)}catch{return!1}return!0})(),yc=ut.forwardRef(function(a,i){const r=a,{value:l,size:d=Mb,level:h=Tb,bgColor:y=Nb,fgColor:p=Eb,includeMargin:m=Ab,minVersion:g=Cb,boostLevel:x,marginSize:b,imageSettings:M}=r,T=Xf(r,["value","size","level","bgColor","fgColor","includeMargin","minVersion","boostLevel","marginSize","imageSettings"]),{style:j}=T,O=Xf(T,["style"]),L=M?.src,z=ut.useRef(null),D=ut.useRef(null),X=ut.useCallback(Te=>{z.current=Te,typeof i=="function"?i(Te):i&&(i.current=Te)},[i]),[J,Q]=ut.useState(!1),{margin:E,cells:q,numCells:ee,calculatedImageSettings:oe}=zb({value:l,level:h,minVersion:g,boostLevel:x,includeMargin:m,marginSize:b,imageSettings:M,size:d});ut.useEffect(()=>{if(z.current!=null){const Te=z.current,de=Te.getContext("2d");if(!de)return;let U=q;const K=D.current,Y=oe!=null&&K!==null&&K.complete&&K.naturalHeight!==0&&K.naturalWidth!==0;Y&&oe.excavation!=null&&(U=Db(q,oe.excavation));const fe=window.devicePixelRatio||1;Te.height=Te.width=d*fe;const ye=d/ee*fe;de.scale(ye,ye),de.fillStyle=y,de.fillRect(0,0,ee,ee),de.fillStyle=p,BT?de.fill(new Path2D(kb(U,E))):q.forEach(function(A,I){A.forEach(function(Z,W){Z&&de.fillRect(W+E,I+E,1,1)})}),oe&&(de.globalAlpha=oe.opacity),Y&&de.drawImage(K,oe.x+E,oe.y+E,oe.w,oe.h)}}),ut.useEffect(()=>{Q(!1)},[L]);const me=qf({height:d,width:d},j);let He=null;return L!=null&&(He=ut.createElement("img",{src:L,key:L,style:{display:"none"},onLoad:()=>{Q(!0)},ref:D,crossOrigin:oe?.crossOrigin})),ut.createElement(ut.Fragment,null,ut.createElement("canvas",qf({style:me,height:d,width:d,ref:X,role:"img"},O)),He)});yc.displayName="QRCodeCanvas";var UT=ut.forwardRef(function(a,i){const r=a,{value:l,size:d=Mb,level:h=Tb,bgColor:y=Nb,fgColor:p=Eb,includeMargin:m=Ab,minVersion:g=Cb,boostLevel:x,title:b,marginSize:M,imageSettings:S}=r,T=Xf(r,["value","size","level","bgColor","fgColor","includeMargin","minVersion","boostLevel","title","marginSize","imageSettings"]),{margin:j,cells:O,numCells:L,calculatedImageSettings:z}=zb({value:l,level:h,minVersion:g,boostLevel:x,includeMargin:m,marginSize:M,imageSettings:S,size:d});let D=O,X=null;S!=null&&z!=null&&(z.excavation!=null&&(D=Db(O,z.excavation)),X=ut.createElement("image",{href:S.src,height:z.h,width:z.w,x:z.x+j,y:z.y+j,preserveAspectRatio:"none",opacity:z.opacity,crossOrigin:z.crossOrigin}));const J=kb(D,j);return ut.createElement("svg",qf({height:d,width:d,viewBox:`0 0 ${L} ${L}`,ref:i,role:"img"},T),!!b&&ut.createElement("title",null,b),ut.createElement("path",{fill:y,d:`M0,0 h${L}v${L}H0z`,shapeRendering:"crispEdges"}),ut.createElement("path",{fill:p,d:J,shapeRendering:"crispEdges"}),X)});UT.displayName="QRCodeSVG";const Px=[.72,0,.24,1];function Vb({hint:n,onOpenStart:a,onOpened:i,paperUrl:r="./art/blush-envelope-texture.jpg",sealUrl:l="./art/blush-wax-seal.png",bg:d="#f6e3e1",accent:h="#6d1a2d",sealText:y="",sealInk:p="#f3dcd2"}){const[m,g]=w.useState("idle");w.useEffect(()=>{"scrollRestoration"in history&&(history.scrollRestoration="manual"),window.scrollTo(0,0);const S=document.body.style.overflow;return document.body.style.overflow="hidden",()=>{document.body.style.overflow=S}},[]),w.useEffect(()=>{if(m==="seal"){const S=setTimeout(()=>g("part"),340);return()=>clearTimeout(S)}if(m==="part"){const S=setTimeout(()=>g("fade"),1380);return()=>clearTimeout(S)}if(m==="fade"){const S=setTimeout(i,240);return()=>clearTimeout(S)}},[m,i]);const x=()=>{m==="idle"&&(window.scrollTo(0,0),a(),g("seal"))},b=m==="part"||m==="fade",M={backgroundImage:`url(${r})`,backgroundSize:"cover",backgroundPosition:"center"};return u.jsxs(k.div,{"code-path":"src/components/invite/EnvelopeOverlay.tsx:82:5",className:"fixed inset-0 z-[70] overflow-hidden select-none",style:{background:b?"transparent":d},animate:{opacity:m==="fade"?0:1},transition:{duration:.24,ease:"easeOut"},role:"button","aria-label":n,onClick:x,children:[u.jsxs(k.div,{"code-path":"src/components/invite/EnvelopeOverlay.tsx:92:7",className:"absolute inset-0",style:{clipPath:"polygon(-2% 102%, 102% 102%, 102% -2%, 50% 50.6%, -2% -2%)",willChange:"transform"},animate:b?{y:"112%"}:{y:"0%"},transition:{duration:1,delay:b?.22:0,ease:Px},children:[u.jsx("div",{"code-path":"src/components/invite/EnvelopeOverlay.tsx:98:9",className:"absolute inset-0",style:M}),u.jsx("div",{"code-path":"src/components/invite/EnvelopeOverlay.tsx:100:9",className:"absolute inset-0",style:{background:"linear-gradient(to bottom, rgba(74,26,35,0.12) 46%, transparent 72%)"}}),u.jsx("div",{"code-path":"src/components/invite/EnvelopeOverlay.tsx:101:9",className:"absolute inset-0",style:{background:"linear-gradient(to top, rgba(255,255,255,0.20) 0%, transparent 26%)"}})]}),u.jsxs(k.div,{"code-path":"src/components/invite/EnvelopeOverlay.tsx:105:7",className:"absolute inset-0",style:{clipPath:"polygon(-2% -2%, 102% -2%, 50% 51%)",willChange:"transform"},animate:b?{y:"-110%"}:{y:"0%"},transition:{duration:1.05,ease:Px},children:[u.jsx("div",{"code-path":"src/components/invite/EnvelopeOverlay.tsx:111:9",className:"absolute inset-0",style:M}),u.jsx("div",{"code-path":"src/components/invite/EnvelopeOverlay.tsx:113:9",className:"absolute inset-0",style:{background:"linear-gradient(to bottom, rgba(255,255,255,0.34) 0%, transparent 30%)"}}),u.jsx("div",{"code-path":"src/components/invite/EnvelopeOverlay.tsx:114:9",className:"absolute inset-0",style:{background:"linear-gradient(to bottom, transparent 18%, rgba(74,26,35,0.10) 50%)"}})]}),u.jsx(k.svg,{"code-path":"src/components/invite/EnvelopeOverlay.tsx:118:7",className:"absolute inset-0 h-full w-full pointer-events-none",viewBox:"0 0 100 100",preserveAspectRatio:"none","aria-hidden":!0,animate:{opacity:b?0:1},transition:{duration:.3},children:["M0,0 L50,50","M100,0 L50,50","M0,100 L50,50","M100,100 L50,50"].map(S=>u.jsxs("g",{"code-path":"src/components/invite/EnvelopeOverlay.tsx:127:11",children:[u.jsx("path",{"code-path":"src/components/invite/EnvelopeOverlay.tsx:128:13",d:S,fill:"none",stroke:"rgba(255,255,255,0.6)",strokeWidth:"1.6",vectorEffect:"non-scaling-stroke",transform:"translate(0.35,0.35)"}),u.jsx("path",{"code-path":"src/components/invite/EnvelopeOverlay.tsx:129:13",d:S,fill:"none",stroke:"rgba(74,26,35,0.13)",strokeWidth:"1.1",vectorEffect:"non-scaling-stroke"})]},S))}),u.jsx("div",{"code-path":"src/components/invite/EnvelopeOverlay.tsx:135:7",className:"absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none",children:u.jsxs(k.div,{"code-path":"src/components/invite/EnvelopeOverlay.tsx:136:9",className:"relative",style:{width:168,height:168},initial:{scale:0,rotate:-24,opacity:0,filter:"brightness(1) drop-shadow(0 14px 30px rgba(74,26,35,0.5))"},animate:m==="idle"?{scale:[1,1.03,1],rotate:0,opacity:1,y:0,filter:"brightness(1) drop-shadow(0 14px 30px rgba(74,26,35,0.5))"}:m==="seal"?{scale:[1.05,.72],rotate:0,opacity:[1,0],y:6,filter:"brightness(1.3) drop-shadow(0 8px 20px rgba(74,26,35,0.4))"}:{scale:.72,rotate:0,opacity:0,y:6,filter:"brightness(1.3) drop-shadow(0 8px 20px rgba(74,26,35,0.4))"},transition:m==="idle"?{scale:{duration:3,repeat:1/0,ease:"easeInOut"},rotate:{duration:.9},opacity:{duration:.8,delay:.25}}:{duration:.34,ease:"easeIn",times:[0,1]},children:[u.jsx("img",{"code-path":"src/components/invite/EnvelopeOverlay.tsx:153:11",src:l,alt:"wax seal",draggable:!1,className:"w-full h-full"}),y.trim()!==""&&u.jsx("span",{"code-path":"src/components/invite/EnvelopeOverlay.tsx:155:13",className:"absolute inset-0 flex items-center justify-center",style:{fontFamily:"'Great Vibes', cursive",fontSize:y.length>5?20:y.length>3?27:34,color:p,textShadow:"0 1px 1px rgba(255,255,255,0.22), 0 -1px 2px rgba(0,0,0,0.4)",transform:"translateY(-3px)",letterSpacing:"0.04em"},children:y})]})}),u.jsx(Ti,{"code-path":"src/components/invite/EnvelopeOverlay.tsx:173:7",children:m==="idle"&&u.jsxs(k.div,{"code-path":"src/components/invite/EnvelopeOverlay.tsx:175:11",className:"absolute bottom-[8vh] left-0 right-0 flex flex-col items-center gap-2 pointer-events-none",initial:{opacity:0},animate:{opacity:1,transition:{delay:.9,duration:.8}},exit:{opacity:0,transition:{duration:.25}},children:[u.jsx(k.span,{"code-path":"src/components/invite/EnvelopeOverlay.tsx:181:13",className:"text-[11px] tracking-[0.38em] uppercase",style:{color:h,fontFamily:"'Jost', sans-serif"},animate:{opacity:[.45,1,.45]},transition:{duration:2.2,repeat:1/0,ease:"easeInOut"},children:n}),u.jsx(k.svg,{"code-path":"src/components/invite/EnvelopeOverlay.tsx:189:13",width:"16",height:"10",viewBox:"0 0 16 10",animate:{y:[0,5,0]},transition:{duration:2.2,repeat:1/0,ease:"easeInOut"},children:u.jsx("path",{"code-path":"src/components/invite/EnvelopeOverlay.tsx:194:15",d:"M2 2 L8 8 L14 2",stroke:"#b98a2f",strokeWidth:"1.6",fill:"none",strokeLinecap:"round"})})]})})]})}const Ot=[.22,.8,.35,1];function Wr({density:n=14,src:a="./art/blush-petal.png",sources:i,className:r=""}){const l=w.useRef(null);return w.useEffect(()=>{const d=l.current;if(!d)return;const h=d.getContext("2d");if(!h)return;const y=Math.min(window.devicePixelRatio||1,2);let p=0,m=0,g=0,x=[];const b=new Image;let M=!1;b.onload=()=>{M=!0},b.src=a;const S=i&&i.length>0?i:[[0,1]],T=D=>{const X=S[Math.floor(Math.random()*S.length)];return{x:(X[0]+Math.random()*(X[1]-X[0]))*p,y:D?Math.random()*m:-40-Math.random()*60,s:14+Math.random()*22,r:Math.random()*Math.PI*2,vr:(Math.random()-.5)*.02,vy:.35+Math.random()*.65,sway:18+Math.random()*26,phase:Math.random()*Math.PI*2,speed:.4+Math.random()*.5,alpha:.55+Math.random()*.45,flip:Math.random()>.5?1:-1}},j=()=>{const D=d.getBoundingClientRect();p=D.width,m=D.height,d.width=Math.max(1,p*y),d.height=Math.max(1,m*y),h.setTransform(y,0,0,y,0,0),x=Array.from({length:n},()=>T(!0))};j();const O=new ResizeObserver(j);O.observe(d);let L=0;const z=()=>{if(L+=.016,h.clearRect(0,0,p,m),M)for(const D of x)D.y+=D.vy,D.r+=D.vr,D.x+=Math.sin(L*D.speed+D.phase)*.6,D.y>m+50&&Object.assign(D,T(!1)),h.save(),h.translate(D.x,D.y),h.rotate(D.r+Math.sin(L*D.speed+D.phase)*.35),h.scale(D.flip,1),h.globalAlpha=D.alpha,h.drawImage(b,-D.s/2,-D.s/2,D.s,D.s),h.restore();g=requestAnimationFrame(z)};return g=requestAnimationFrame(z),()=>{cancelAnimationFrame(g),O.disconnect()}},[n,a,i]),u.jsx("canvas",{"code-path":"src/components/invite/fx.tsx:100:5",ref:l,className:`pointer-events-none absolute inset-0 h-full w-full ${r}`,"aria-hidden":!0})}function Ob({fire:n}){if(!n)return null;const a=Array.from({length:26});return u.jsx("div",{"code-path":"src/components/invite/fx.tsx:115:5",className:"pointer-events-none absolute inset-0 overflow-hidden","aria-hidden":!0,children:a.map((i,r)=>{const l=r/a.length*Math.PI*2+Math.random()*.4,d=120+Math.random()*260,h=16+Math.random()*22;return u.jsx(k.img,{"code-path":"src/components/invite/fx.tsx:121:11",src:"./art/blush-petal.png",initial:{x:0,y:0,opacity:1,rotate:0,scale:.4},animate:{x:Math.cos(l)*d,y:Math.sin(l)*d+240,opacity:[1,1,0],rotate:(Math.random()-.5)*540,scale:1},transition:{duration:2.2+Math.random(),ease:[.15,.6,.45,1]},style:{position:"absolute",left:"50%",top:"42%",width:h,height:h},alt:""},r)})})}function Bt({color:n="#b98a2f",width:a=220}){return u.jsxs("svg",{"code-path":"src/components/invite/fx.tsx:147:5",width:a,height:"26",viewBox:"0 0 220 26",fill:"none","aria-hidden":!0,children:[u.jsxs("g",{"code-path":"src/components/invite/fx.tsx:148:7",stroke:n,strokeWidth:"1.1",strokeLinecap:"round",children:[u.jsx("path",{"code-path":"src/components/invite/fx.tsx:149:9",d:"M4 13 H86",opacity:"0.7"}),u.jsx("path",{"code-path":"src/components/invite/fx.tsx:150:9",d:"M134 13 H216",opacity:"0.7"}),u.jsx("path",{"code-path":"src/components/invite/fx.tsx:151:9",d:"M88 13 C 96 13, 98 6, 104 6 C 107 6, 107 10, 104.5 10.5"}),u.jsx("path",{"code-path":"src/components/invite/fx.tsx:152:9",d:"M132 13 C 124 13, 122 20, 116 20 C 113 20, 113 16, 115.5 15.5"}),u.jsx("path",{"code-path":"src/components/invite/fx.tsx:153:9",d:"M20 13 C 20 8, 28 8, 28 12 C 28 15, 23 15.5, 21.5 13.5",opacity:"0.85"}),u.jsx("path",{"code-path":"src/components/invite/fx.tsx:154:9",d:"M200 13 C 200 18, 192 18, 192 14 C 192 11, 197 10.5, 198.5 12.5",opacity:"0.85"})]}),u.jsx("path",{"code-path":"src/components/invite/fx.tsx:156:7",d:"M110 6 L117 13 L110 20 L103 13 Z",stroke:n,strokeWidth:"1.1",fill:"none"}),u.jsx("circle",{"code-path":"src/components/invite/fx.tsx:157:7",cx:"110",cy:"13",r:"1.8",fill:n}),u.jsx("circle",{"code-path":"src/components/invite/fx.tsx:158:7",cx:"4",cy:"13",r:"1.6",fill:n}),u.jsx("circle",{"code-path":"src/components/invite/fx.tsx:159:7",cx:"216",cy:"13",r:"1.6",fill:n})]})}function $e({eyebrow:n,title:a,color:i="#6d1a2d",gold:r="#b98a2f",script:l=!1}){return u.jsxs(k.div,{"code-path":"src/components/invite/fx.tsx:181:5",initial:{opacity:0,y:26},whileInView:{opacity:1,y:0},viewport:{once:!0,margin:"-60px"},transition:{duration:.9,ease:Ot},className:"flex flex-col items-center gap-2 text-center",children:[n&&u.jsx("span",{"code-path":"src/components/invite/fx.tsx:189:9",className:"text-[11px] tracking-[0.42em] uppercase",style:{color:r,fontFamily:"'Jost', sans-serif"},children:n}),u.jsx("h2",{"code-path":"src/components/invite/fx.tsx:196:7",className:l?"text-5xl leading-tight":"text-3xl sm:text-4xl",style:{color:i,fontFamily:l?"'Great Vibes', cursive":"'Cormorant Garamond', serif",fontWeight:l?400:600,letterSpacing:l?0:"0.04em"},children:a}),u.jsx(Bt,{"code-path":"src/components/invite/fx.tsx:207:7",color:r})]})}function Lb({size:n=132,onClick:a,glow:i=!0,src:r="./art/blush-wax-seal.png"}){return u.jsxs(k.button,{"code-path":"src/components/invite/fx.tsx:227:5",onClick:a,whileTap:{scale:.92},whileHover:{scale:1.05},className:"relative rounded-full focus:outline-none",style:{width:n,height:n,WebkitTapHighlightColor:"transparent"},"aria-label":"wax seal",children:[i&&u.jsx(k.span,{"code-path":"src/components/invite/fx.tsx:236:9",className:"absolute inset-0 rounded-full",style:{background:"radial-gradient(circle, rgba(233,190,110,0.75) 0%, rgba(233,190,110,0.25) 45%, transparent 70%)",filter:"blur(6px)"},animate:{scale:[1,1.28,1],opacity:[.55,.95,.55]},transition:{duration:2.6,repeat:1/0,ease:"easeInOut"}}),u.jsx(k.img,{"code-path":"src/components/invite/fx.tsx:246:7",src:r,alt:"wax seal",className:"relative w-full h-full object-contain",style:{filter:"drop-shadow(0 10px 22px rgba(74,26,35,0.45))"},animate:i?{scale:[1,1.035,1]}:void 0,transition:{duration:2.6,repeat:1/0,ease:"easeInOut"},draggable:!1})]})}function Yx({side:n,width:a="min(55vw, 420px)",delay:i=0,opened:r=!0}){return u.jsx(k.div,{"code-path":"src/components/invite/fx.tsx:329:5",className:"pointer-events-none absolute select-none z-20",style:{top:"-3%",[n]:"-5%",width:a,transformOrigin:n==="left"?"top left":"top right"},initial:!1,animate:r?{opacity:1,y:0,scale:1,rotate:[0,n==="left"?1.6:-1.6,0]}:{opacity:0,y:-46,scale:.72,rotate:n==="left"?-9:9},transition:r?{opacity:{duration:.9,delay:i},y:{type:"spring",stiffness:100,damping:14,delay:i},scale:{type:"spring",stiffness:100,damping:14,delay:i},rotate:{duration:8,repeat:1/0,ease:"easeInOut",delay:i+1.1}}:{duration:.3},children:u.jsx("img",{"code-path":"src/components/invite/fx.tsx:354:7",src:"./art/blush-bouquet-top.png",alt:"","aria-hidden":!0,draggable:!1,className:"w-full block",style:{transform:n==="right"?"scaleX(-1)":void 0,filter:"drop-shadow(0 8px 22px rgba(74,26,35,0.2))"}})})}function qx({children:n,className:a="",style:i={}}){return u.jsx("span",{"code-path":"src/components/invite/fx.tsx:420:5",className:a,style:{background:"linear-gradient(100deg, #8a641c 0%, #d9b45c 28%, #f3dc9a 50%, #d9b45c 72%, #8a641c 100%)",backgroundSize:"200% auto",WebkitBackgroundClip:"text",backgroundClip:"text",color:"transparent",animation:"goldshine 6s linear infinite",...i},children:n})}function Gb(){const{origin:n,pathname:a}=window.location,i=a.endsWith("/")?a:a.slice(0,a.lastIndexOf("/")+1);return n+i}const Hh={en:{tapSeal:"Tap the seal to open",invited:"You're cordially invited",weddingDay:"Wedding Day",scrollDown:"Scroll down",bismillah:"بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",twoSouls:"Two Souls",oneDestiny:"One destiny",lifetime:"A Lifetime written by Allah",dearFriends:"Dear Friends and Family,",beginsIn:"The Celebration Begins In",days:"Days",hours:"Hours",minutes:"Minutes",seconds:"Seconds",schedule:"Schedule of Events",location:"Location",openInMaps:"Open in Maps",dressTitle:"Dress Code",dressText:"We kindly invite you to dress in elegant attire that reflects the style and spirit of our special day.",dressGents:"Gentlemen — well-tailored suits with classic dress shoes are preferred.",dressLadies:"Ladies — formal dresses in elegant, polished styles are encouraged.",giftTitle:"Gift Preference",familyPre:"The families of",familyAnd:"and",familyPost:"request the honour of your presence at the marriage of their beloved children",addToCalendar:"Add to Calendar",contactsTitle:"Mawasiliano",contactsSub:"For any inquiries, kindly reach us:",callNow:"Call",detailsTitle:"Details",transportTitle:"Transport & Parking",transportText:"Complimentary valet parking is available at the main gate. Shuttle service runs from the parking area to the courtyard every 15 minutes.",stayTitle:"Where to Stay",stayText:"For our guests travelling in, we recommend the nearby beach resorts of Nungwi and Kendwa — kindly book early for the season.",noBoxed:"Kindly, no boxed gifts please.",giftsNote:"Your presence is the greatest gift. Should you wish to honour us with a contribution:",confirmTitle:"Confirm Your Attendance",confirmSub:"To help us prepare for a joyful celebration, kindly confirm below.",clickToOpen:"Click to open",rsvpBefore:"Please RSVP before August 09",yourName:"Your name",attendQ:"Will you be attending?",accept:"Accepts with pleasure",decline:"Declines with regret",guestsAttending:"Number of Guests Attending",songLabel:"A Song That Gets You Dancing",childrenLabel:"Children Attending (names and ages)",dietary:"Dietary needs (optional)",submit:"Submit",rsvpDone:"Thank you — your response has been received!",rsvpWhats:"RSVP via WhatsApp",gallery:"Moments",guestbook:"Leave a Blessing",guestbookPh:"Write your dua or message…",guestbookName:"Your name",guestbookSend:"Send Blessing",guestbookThanks:"Shukran! Your blessing has been added.",copy:"Copy",copied:"Copied!",footer:"Made with love in Zanzibar",scanHint:"Show this code at the entrance",yourCode:"Your guest code",checkedInBadge:"Checked in ✓",attendingBadge:"Attending ✓",declinedBadge:"Regrets sent",loading:"Unsealing your invitation…",hopeToSee:"Hope to see you there!"},sw:{tapSeal:"Gusa muhuri kufungua",invited:"Umealikwa kwa heshima kubwa",weddingDay:"Siku ya Harusi",scrollDown:"Sogeza chini",bismillah:"بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",twoSouls:"Roho Mbili",oneDestiny:"Hatima moja",lifetime:"Maisha yaliyoandikwa na Allah",dearFriends:"Wapendwa Marafiki na Familia,",beginsIn:"Sherehe Inaanza Baada Ya",days:"Siku",hours:"Saa",minutes:"Dakika",seconds:"Sekunde",schedule:"Ratiba ya Sherehe",location:"Mahali",openInMaps:"Fungua Ramani",dressTitle:"Mavazi",dressText:"Tunakualika kuvaa mavazi rasmi yanayooana na mvuto na roho ya siku yetu maalum.",dressGents:"Wanaume — suti zilizoshonwa vizuri na viatu vya kiume vinavyopendeza.",dressLadies:"Wanawake — nguo rasmi za kifahari na za kupendeza zinapendekezwa.",giftTitle:"Zawadi",familyPre:"Familia za",familyAnd:"na",familyPost:"zinakualika kwa heshima kubwa katika harusi ya watoto wao",addToCalendar:"Weka Kalendari",contactsTitle:"Mawasiliano",contactsSub:"Kwa maswali yoyote, tupigie:",callNow:"Piga",detailsTitle:"Maelezo",transportTitle:"Usafiri na Maegesho",transportText:"Maegesho ya bure yanapatikana lango kuu. Gari la kubeba wageni linapita kila dakika 15 kutoka egesho hadi uaoni.",stayTitle:"Malazi",stayText:"Kwa wageni wanaotoka mbali, tunapendekeza hoteli za ufukweni za Nungwi na Kendwa — tafadhali weka nafasi mapema.",noBoxed:"Tafadhali, hakuna zawadi za viboksi.",giftsNote:"Kuja kwako ndio zawadi kubwa. Ukipenda kutuchangia:",confirmTitle:"Thibitisha Kuja Kwako",confirmSub:"Ili tuandae sherehe ya furaha, tafadhali thibitisha hapa chini.",clickToOpen:"Gusa kufungua",rsvpBefore:"Tafadhali jibu kabla ya Agosti 09",yourName:"Jina lako",attendQ:"Je, utahudhuria?",accept:"Nitahudhuria kwa furaha",decline:"Siwezi kuhudhuria",guestsAttending:"Idadi ya Wageni",songLabel:"Wimbo Unaokufanya Ucheze",childrenLabel:"Watoto Wanaohudhuria (majina na umri)",dietary:"Mahitaji ya chakula (hiari)",submit:"Tuma",rsvpDone:"Asante — jibu lako limepokelewa!",rsvpWhats:"Jibu kwa WhatsApp",gallery:"Kumbukumbu",guestbook:"Acha Dua au Salamu",guestbookPh:"Andika dua yako hapa…",guestbookName:"Jina lako",guestbookSend:"Tuma Dua",guestbookThanks:"Shukran! Dua yako imeongezwa.",copy:"Nakili",copied:"Imenakiliwa!",footer:"Imetengenezwa kwa upendo Zanzibar",scanHint:"Onyesha msimbo huu mlangoni",yourCode:"Msimbo wako",checkedInBadge:"Amethibitishwa ✓",attendingBadge:"Atahudhuria ✓",declinedBadge:"Amekataa",loading:"Tunafungua mwaliko wako…",hopeToSee:"Tunakutania — karibu sana!"}},Xx={"royal-noor":{id:"royal-noor",art:"./royal-noor/art/noor-preview.jpg",bg:"#0a1330",bgDeep:"#070d22",ink:"#f5ecd7",inkSoft:"#a8b0c8",accent:"#c9a24a",gold:"#c9a24a",card:"rgba(201,162,74,0.06)",cardBorder:"rgba(201,162,74,0.4)",fontDisplay:"'Great Vibes', cursive",fontBody:"'Cormorant Garamond', serif",dark:!0,paper:"#0e1a3d",seal:"#f5ecd7"},"kasri-dhahabu":{id:"kasri-dhahabu",art:"./kasri-dhahabu/art/preview.jpg",bg:"#F2DFD4",bgDeep:"#16201A",ink:"#5A4535",inkSoft:"#8C7466",accent:"#B08A52",gold:"#C9A27E",card:"rgba(176,138,82,0.06)",cardBorder:"rgba(176,138,82,0.45)",fontDisplay:"'Pinyon Script', cursive",fontBody:"'Cormorant Garamond', serif",dark:!1,paper:"#F6E9E0",seal:"#B47F6D"},"blush-swan":{id:"blush-swan",art:"./art/blush-arch-gold.png",bg:"#fdf6f4",bgDeep:"#f6e3e1",ink:"#4a1a23",inkSoft:"#96757a",accent:"#6d1a2d",gold:"#b98a2f",card:"rgba(109,26,45,0.045)",cardBorder:"rgba(185,138,47,0.4)",fontDisplay:"'Great Vibes', cursive",fontBody:"'Cormorant Garamond', serif",dark:!1,paper:"#f6e3e1",seal:"#6d1a2d"},"villa-rosa":{id:"villa-rosa",art:"./art/villa-hero.jpg",bg:"#eef4fa",bgDeep:"#8a1c2e",ink:"#2f4156",inkSoft:"#7186a0",accent:"#8a1c2e",gold:"#c9a24a",card:"rgba(138,28,46,0.05)",cardBorder:"rgba(201,162,74,0.45)",fontDisplay:"'Great Vibes', cursive",fontBody:"'Cormorant Garamond', serif",dark:!1,paper:"#e9eef4",seal:"#f4f6f8"},"emerald-arch":{id:"emerald-arch",art:"./art/em-hero-preview.jpg",bg:"#f6efdd",bgDeep:"#0e3b2c",ink:"#26332a",inkSoft:"#6f7460",accent:"#0e3b2c",gold:"#c9a24a",card:"rgba(14,59,44,0.05)",cardBorder:"rgba(201,162,74,0.45)",fontDisplay:"'Pinyon Script', cursive",fontBody:"'Cormorant Garamond', serif",dark:!1,paper:"#efe4c8",seal:"#c9a24a"}};function _b(n){return Xx[n]??Xx["blush-swan"]}const Mr="2026-09-27",HT={slug:"demo",templateId:"blush-swan",groomName:"Zohan",brideName:"Rose",quoteEn:"And among His signs is that He created for you spouses from among yourselves, that you may find tranquillity in them.",quoteSw:"Na kati ya dalili zake ni kwamba Amekuundieni wake kutoka kwenu ninyi, mpate kutulia nao.",storyEn:"With the grace of Allah, two families become one. It is with hearts full of joy that we invite you to share in the baraka of our wedding day — a day written for us long before we ever knew.",storySw:"Kwa neema ya Allah, familia mbili zinakuwa moja. Kwa mioyo iliyojaa furaha tunakualika kushiriki baraka za siku yetu ya harusi — siku iliyoandikwa kwa ajili yetu.",heroImage:"",musicTrack:"oud-dreams",language:"en",events:[{name:"Guest Arrival",nameSw:"Wageni Wanawasili",date:Mr,time:"16:00",venue:"Verde Grand Gardens, Zanzibar",mapsUrl:"https://maps.google.com/?q=Zanzibar",dressCode:"",notes:""},{name:"Nikkah Ceremony",nameSw:"Nikkah",date:Mr,time:"16:30",venue:"Verde Grand Gardens, Zanzibar",mapsUrl:"https://maps.google.com/?q=Zanzibar",dressCode:"",notes:""},{name:"Mocktail Hour",nameSw:"Vinywaji Baridi",date:Mr,time:"18:00",venue:"Verde Grand Gardens, Zanzibar",mapsUrl:"https://maps.google.com/?q=Zanzibar",dressCode:"",notes:""},{name:"Dinner",nameSw:"Chakula cha Jioni",date:Mr,time:"19:00",venue:"Verde Grand Gardens, Zanzibar",mapsUrl:"https://maps.google.com/?q=Zanzibar",dressCode:"",notes:""},{name:"Dance",nameSw:"Ngoma na Burudani",date:Mr,time:"20:30",venue:"Verde Grand Gardens, Zanzibar",mapsUrl:"https://maps.google.com/?q=Zanzibar",dressCode:"",notes:""}],gifts:[{label:"M-Pesa",provider:"Vodacom M-Pesa",accountName:"Z. & R. Harusi",accountNumber:"0754 123 456"},{label:"Tigo Pesa",provider:"Tigo Pesa",accountName:"Z. & R. Harusi",accountNumber:"0654 987 654"},{label:"Selcom",provider:"Selcom Pay",accountName:"Z. & R. Harusi",accountNumber:"0788 555 210"}],gallery:[],whatsappNumber:"255754123456",groomFamily:"Mr. & Mrs. Rashid Abdalla",brideFamily:"Mr. & Mrs. Juma Makame",contacts:[{label:"Msimamizi wa Harusi",name:"Bi Khadija Rashid",phone:"+255754111222"},{label:"Mwalimu wa Karamu",name:"Bw Salim Juma",phone:"+255655333444"}]},Cl="2027-07-05",FT={slug:"demo-villa",templateId:"villa-rosa",groomName:"Viktor",brideName:"Paola",quoteEn:"And among His signs is that He created for you spouses from among yourselves, that you may find tranquillity in them.",quoteSw:"Na kati ya dalili zake ni kwamba Amekuundieni wake kutoka kwenu ninyi, mpate kutulia nao.",storyEn:"As we get ready to say “I do”, we feel grateful for the wonderful people in our lives. Your support means the world to us, and we would be honoured to have you with us as we begin our life together.",storySw:"Tunapoandaa kusema “Ndoa”, tunawashukuru watu wote wazuri katika maisha yetu. Msaada wenu unamaanisha mengi kwetu, na itakuwa heshima kuwa nanyi tuanze safari hii mpya pamoja.",heroImage:"",musicTrack:"ocean-strings",language:"en",events:[{name:"Wedding Ceremony",nameSw:"Nikkah / Ndoa",date:Cl,time:"16:00",venue:"Château del Lago, Zanzibar",mapsUrl:"https://maps.google.com/?q=Zanzibar",dressCode:"",notes:""},{name:"Cocktail Hour",nameSw:"Vinywaji Baridi",date:Cl,time:"17:00",venue:"Château del Lago, Zanzibar",mapsUrl:"https://maps.google.com/?q=Zanzibar",dressCode:"",notes:""},{name:"Dinner",nameSw:"Chakula cha Jioni",date:Cl,time:"19:00",venue:"Château del Lago, Zanzibar",mapsUrl:"https://maps.google.com/?q=Zanzibar",dressCode:"",notes:""},{name:"Party",nameSw:"Ngoma na Burudani",date:Cl,time:"20:00",venue:"Château del Lago, Zanzibar",mapsUrl:"https://maps.google.com/?q=Zanzibar",dressCode:"",notes:""}],gifts:[{label:"M-Pesa",provider:"Vodacom M-Pesa",accountName:"V. & P. Wedding",accountNumber:"0754 123 456"},{label:"Tigo Pesa",provider:"Tigo Pesa",accountName:"V. & P. Wedding",accountNumber:"0654 987 654"}],gallery:[],whatsappNumber:"255754123456",groomFamily:"Mr. & Mrs. Alessandro Ricci",brideFamily:"Mr. & Mrs. Marco Bianchi",contacts:[{label:"Wedding Planner",name:"Signora Elena",phone:"+255754111222"},{label:"Best Man",name:"Mr. Luca",phone:"+255655333444"}]},IT={name:"Fatma Juma",code:"DEMO01",rsvpStatus:"pending",companions:0,maxCompanions:2,dietary:"",checkedIn:!1};function Fh(n,a){return`https://wa.me/${n.replace(/[^0-9]/g,"")}?text=${encodeURIComponent(a)}`}const yi="#fdf9f5",Pe="#6d1a2d",gt="#b98a2f",Lt="#4a1a23",nt="#96757a",tt={initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0,margin:"-50px"},transition:{duration:.9,ease:Ot}};function Pl(){return u.jsxs("svg",{"code-path":"src/components/invite/InvitationRenderer.tsx:28:5",className:"absolute top-0 left-0 w-full z-[1] pointer-events-none",viewBox:"0 0 1440 64",preserveAspectRatio:"none",style:{height:44,display:"block"},"aria-hidden":!0,children:[u.jsx("path",{"code-path":"src/components/invite/InvitationRenderer.tsx:35:7",d:"M0,0 L1440,0 L1440,22 C1352,40 1272,20 1176,34 C1080,48 996,24 900,38 C804,52 726,26 624,38 C522,50 444,28 348,40 C252,52 168,30 84,42 C44,48 16,42 0,46 Z",fill:"#fdf9f5"}),u.jsx("path",{"code-path":"src/components/invite/InvitationRenderer.tsx:39:7",d:"M0,0 L1440,0 L1440,12 C1340,26 1260,10 1168,22 C1076,34 1000,16 912,26 C824,36 740,16 648,26 C556,36 470,18 380,28 C290,38 200,20 110,30 C56,36 20,30 0,34 Z",fill:"rgba(232,180,184,0.35)"})]})}function $x(n){const a=new Date(n+"T00:00:00");return isNaN(a.getTime())?n:`${String(a.getDate()).padStart(2,"0")} · ${String(a.getMonth()+1).padStart(2,"0")} · ${a.getFullYear()}`}function Bb(n){if(!n)return"";const[a,i]=n.split(":").map(Number);if(isNaN(a))return n;const r=a>=12?"PM":"AM";return`${a%12===0?12:a%12}:${String(i??0).padStart(2,"0")} ${r}`}function PT({data:n,guest:a,demo:i=!1,autoOpen:r=!1,onRsvp:l,onGuestbook:d,guestbookMessages:h=[],inviteUrl:y}){const p=_b(n.templateId),[m,g]=w.useState(n.language??"en"),x=Hh[m],[b,M]=w.useState(r),[S,T]=w.useState(r),j=n.events[0],O=j?$x(j.date):"",L=m==="sw"&&n.storySw||n.storyEn,z=m==="sw"&&n.quoteSw||n.quoteEn;return u.jsxs("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:96:5",className:"relative min-h-screen",style:{background:p.bg,color:p.ink,fontFamily:p.fontBody},children:[!S&&u.jsx(Vb,{"code-path":"src/components/invite/InvitationRenderer.tsx:99:9",hint:x.tapSeal,onOpenStart:()=>{M(!0)},onOpened:()=>T(!0),sealText:n.sealText??""}),S&&u.jsx(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:109:9",className:"fixed top-4 right-4 z-40 flex rounded-full overflow-hidden text-[11px] tracking-widest",style:{border:"1px solid rgba(185,138,47,0.5)",background:"rgba(253,249,245,0.85)",backdropFilter:"blur(8px)",fontFamily:"'Jost', sans-serif"},initial:{opacity:0,y:-12},animate:{opacity:1,y:0},transition:{delay:.9},children:["en","sw"].map(D=>u.jsx("button",{"code-path":"src/components/invite/InvitationRenderer.tsx:117:13",onClick:()=>g(D),className:"px-3 py-1.5 uppercase transition-colors",style:{background:m===D?Pe:"transparent",color:m===D?"#f3dc9a":nt},children:D},D))}),S&&a&&u.jsx(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:130:9",className:"fixed top-4 left-4 z-40 px-3 py-1.5 rounded-full text-[10px] tracking-[0.2em] uppercase",style:{border:"1px solid rgba(185,138,47,0.5)",background:"rgba(253,249,245,0.85)",backdropFilter:"blur(8px)",color:nt,fontFamily:"'Jost', sans-serif"},initial:{opacity:0,y:-12},animate:{opacity:1,y:0},transition:{delay:.9},children:a.name}),u.jsx(YT,{"code-path":"src/components/invite/InvitationRenderer.tsx:142:7",data:n,t:x,dateLabel:O,opened:b||S}),u.jsxs("section",{"code-path":"src/components/invite/InvitationRenderer.tsx:145:7",className:"relative px-7 py-20 text-center",style:{background:yi},children:[u.jsx(k.p,{"code-path":"src/components/invite/InvitationRenderer.tsx:146:9",...tt,style:{fontFamily:"'Amiri', serif",color:gt},className:"text-2xl leading-relaxed",children:x.bismillah}),u.jsxs(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:149:9",...tt,transition:{...tt.transition,delay:.12},className:"mt-9 flex flex-col items-center",children:[u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:150:11",className:"text-5xl leading-tight",style:{fontFamily:"'Great Vibes', cursive",color:Pe},children:x.twoSouls}),u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:153:11",className:"text-xl mt-1 tracking-[0.14em] uppercase",style:{color:gt,fontFamily:"'Cormorant Garamond', serif"},children:x.oneDestiny}),u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:156:11",className:"text-lg mt-3 italic",style:{color:nt},children:x.lifetime}),u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:159:11",className:"mt-6",children:u.jsx(Bt,{"code-path":"src/components/invite/InvitationRenderer.tsx:159:33",color:gt})})]}),(n.groomFamily||n.brideFamily)&&u.jsxs(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:162:11",...tt,transition:{...tt.transition,delay:.16},className:"mt-10 max-w-md mx-auto",children:[u.jsxs("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:163:13",className:"text-[15px] leading-relaxed",style:{color:gt,fontFamily:"'Cormorant Garamond', serif",letterSpacing:"0.06em"},children:[x.familyPre," ",u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:164:29",style:{color:Pe,fontWeight:600},children:n.groomFamily})," ",x.familyAnd," ",u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:165:15",style:{color:Pe,fontWeight:600},children:n.brideFamily})]}),u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:167:13",className:"mt-2 text-[16px] italic leading-relaxed",style:{color:Lt},children:x.familyPost}),u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:168:13",className:"mt-6 flex justify-center",children:u.jsx(Bt,{"code-path":"src/components/invite/InvitationRenderer.tsx:168:55",color:gt,width:170})})]}),u.jsxs(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:171:9",...tt,transition:{...tt.transition,delay:.2},className:"mt-10 max-w-md mx-auto",children:[u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:172:11",className:"text-xl",style:{color:Pe,fontFamily:"'Great Vibes', cursive"},children:x.dearFriends}),u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:173:11",className:"mt-4 text-[17px] leading-relaxed",style:{color:Lt},children:L}),u.jsxs("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:174:11",className:"mt-6 text-[15px] italic leading-relaxed",style:{color:nt},children:["“",z,"”"]})]})]}),u.jsx(qT,{"code-path":"src/components/invite/InvitationRenderer.tsx:179:7",events:n.events,t:x,names:`${n.groomName} & ${n.brideName}`}),u.jsx($T,{"code-path":"src/components/invite/InvitationRenderer.tsx:182:7",events:n.events,t:x,lang:m}),u.jsxs("section",{"code-path":"src/components/invite/InvitationRenderer.tsx:185:7",className:"relative px-7 py-20",style:{background:yi},children:[u.jsx($e,{"code-path":"src/components/invite/InvitationRenderer.tsx:186:9",title:x.location,script:!0}),j&&u.jsxs(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:188:11",...tt,className:"mt-10 max-w-md mx-auto text-center",children:[u.jsx("h3",{"code-path":"src/components/invite/InvitationRenderer.tsx:189:13",className:"text-2xl",style:{color:Pe,fontWeight:600},children:j.venue}),u.jsxs("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:190:13",className:"mt-1 text-[15px]",style:{color:nt},children:[$x(j.date)," · ",Bb(j.time)]}),u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:193:13",className:"mt-7 overflow-hidden",style:{border:"1px solid rgba(185,138,47,0.4)",boxShadow:"0 14px 36px rgba(74,26,35,0.12)"},children:u.jsx("iframe",{"code-path":"src/components/invite/InvitationRenderer.tsx:194:15",title:"map",src:`https://www.google.com/maps?q=${encodeURIComponent(j.venue??"")}&output=embed&hl=en`,className:"w-full h-[240px] block",loading:"lazy"})}),u.jsxs("a",{"code-path":"src/components/invite/InvitationRenderer.tsx:201:13",href:j.mapsUrl||`https://maps.google.com/?q=${encodeURIComponent(j.venue??"")}`,target:"_blank",rel:"noreferrer",className:"mt-5 inline-flex items-center gap-2 px-7 py-3 rounded-full text-[12px] tracking-[0.24em] uppercase",style:{background:Pe,color:"#f3dc9a",fontFamily:"'Jost', sans-serif",boxShadow:"0 10px 26px rgba(109,26,45,0.35)"},children:[u.jsx(_h,{"code-path":"src/components/invite/InvitationRenderer.tsx:208:15",size:14})," ",x.openInMaps]})]})]}),u.jsxs("section",{"code-path":"src/components/invite/InvitationRenderer.tsx:215:7",className:"relative px-7 py-20 overflow-hidden",style:{background:p.bgDeep},children:[u.jsx(Pl,{"code-path":"src/components/invite/InvitationRenderer.tsx:216:9"}),u.jsx("img",{"code-path":"src/components/invite/InvitationRenderer.tsx:217:9",src:"./art/blush-bouquet.png",alt:"","aria-hidden":!0,loading:"lazy",decoding:"async",className:"absolute -top-8 -left-16 w-56 opacity-90 pointer-events-none select-none",style:{transform:"rotate(160deg)"}}),u.jsx("img",{"code-path":"src/components/invite/InvitationRenderer.tsx:218:9",src:"./art/blush-bouquet.png",alt:"","aria-hidden":!0,loading:"lazy",decoding:"async",className:"absolute -bottom-10 -right-16 w-56 opacity-90 pointer-events-none select-none",style:{transform:"rotate(-18deg) scaleX(-1)"}}),u.jsx($e,{"code-path":"src/components/invite/InvitationRenderer.tsx:219:9",title:x.dressTitle,script:!0}),u.jsx(k.p,{"code-path":"src/components/invite/InvitationRenderer.tsx:220:9",...tt,className:"relative mt-8 max-w-sm mx-auto text-center text-[18px] leading-relaxed",style:{color:Lt},children:x.dressText})]}),u.jsx(ZT,{"code-path":"src/components/invite/InvitationRenderer.tsx:275:7",data:n,guest:a,t:x,onRsvp:l}),a&&y&&u.jsx("section",{"code-path":"src/components/invite/InvitationRenderer.tsx:282:9",className:"relative px-7 py-16 text-center",style:{background:"#f6e3e1"},children:u.jsxs(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:283:11",...tt,className:"max-w-xs mx-auto px-8 py-8",style:{background:"#fffdf9",border:"1px solid rgba(185,138,47,0.4)",boxShadow:"0 18px 44px rgba(74,26,35,0.12)"},children:[u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:284:13",className:"text-[11px] tracking-[0.34em] uppercase",style:{color:gt,fontFamily:"'Jost', sans-serif"},children:x.yourCode}),u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:285:13",className:"mt-4 flex justify-center",children:u.jsx(yc,{"code-path":"src/components/invite/InvitationRenderer.tsx:286:15",value:`${y}?code=${a.code}`,size:150,fgColor:"#4a1a23",bgColor:"#fffdf9",level:"M"})}),u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:288:13",className:"mt-4 text-2xl tracking-[0.3em]",style:{color:Pe,fontWeight:700},children:a.code}),u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:289:13",className:"mt-1 text-[13px]",style:{color:nt},children:x.scanHint}),a.checkedIn&&u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:290:33",className:"mt-3 text-[13px]",style:{color:"#1e7a4f"},children:x.checkedInBadge})]})}),u.jsxs("footer",{"code-path":"src/components/invite/InvitationRenderer.tsx:296:7",className:"relative pt-20 pb-12 px-7 text-center overflow-hidden",style:{background:"#fdf9f5"},children:[u.jsx(Pl,{"code-path":"src/components/invite/InvitationRenderer.tsx:297:9"}),u.jsx("img",{"code-path":"src/components/invite/InvitationRenderer.tsx:298:9",src:"./art/blush-bouquet.png",alt:"","aria-hidden":!0,loading:"lazy",className:"absolute -top-8 -left-14 w-52 opacity-90 pointer-events-none select-none",style:{transform:"rotate(155deg)"}}),u.jsx("img",{"code-path":"src/components/invite/InvitationRenderer.tsx:299:9",src:"./art/blush-bouquet.png",alt:"","aria-hidden":!0,loading:"lazy",className:"absolute -top-8 -right-14 w-52 opacity-90 pointer-events-none select-none",style:{transform:"rotate(205deg) scaleX(-1)"}}),u.jsx(k.p,{"code-path":"src/components/invite/InvitationRenderer.tsx:300:9",...tt,className:"mt-6 text-4xl",style:{fontFamily:"'Great Vibes', cursive",color:Pe},children:x.hopeToSee}),u.jsxs(k.p,{"code-path":"src/components/invite/InvitationRenderer.tsx:303:9",...tt,className:"mt-2 text-3xl",style:{fontFamily:"'Great Vibes', cursive",color:gt},children:[u.jsx("span",{style:{display:"inline-block"},children:n.groomName})," & ",u.jsx("span",{style:{display:"inline-block"},children:n.brideName})]}),u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:306:9",className:"mt-6 flex justify-center",children:u.jsx(Bt,{"code-path":"src/components/invite/InvitationRenderer.tsx:306:51",color:gt,width:180})}),u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:307:9",className:"mt-6 text-[11px] tracking-[0.3em] uppercase",style:{color:nt,fontFamily:"'Jost', sans-serif"},children:x.footer})]})]})}function YT({data:n,t:a,dateLabel:i,opened:r}){const l=w.useRef(null),{scrollYProgress:d}=Jr({target:l,offset:["start start","end start"]}),h=St(d,[0,1],["0%","14%"]),y=St(d,[0,.7],[1,0]),p=(m,g=9,x=22,b=1.05)=>({initial:!1,animate:r?{opacity:1,y:0,scale:1,filter:"blur(0px)"}:{opacity:0,y:x,scale:.96,filter:`blur(${g}px)`},transition:{duration:b,delay:m,ease:[.22,.8,.35,1]}});return u.jsxs("section",{"code-path":"src/components/invite/InvitationRenderer.tsx:337:5",ref:l,className:"relative overflow-hidden",style:{height:"100svh",minHeight:620},children:[u.jsx(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:339:7",className:"absolute inset-0",style:{y:h},children:u.jsx("img",{"code-path":"src/components/invite/InvitationRenderer.tsx:340:9",src:"./art/blush-bg-paper.jpg",alt:"",className:"w-full h-full object-cover",style:{objectPosition:"center center"}})}),u.jsx(Wr,{"code-path":"src/components/invite/InvitationRenderer.tsx:349:7",density:12}),u.jsx(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:352:7",className:"absolute inset-0 z-10 flex justify-center pointer-events-none",style:{opacity:y},children:u.jsxs("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:356:9",className:"relative h-full",style:{width:"min(100vw, 62svh)","--aw":"min(100vw, 62svh)"},children:[u.jsx("img",{"code-path":"src/components/invite/InvitationRenderer.tsx:361:11",src:"./art/blush-arch-crown.png",alt:"",draggable:!1,className:"absolute top-0 left-0 w-full block",style:{marginTop:"-1px"}}),u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:369:11",className:"absolute left-0 right-0",style:{top:"calc(var(--aw) * 1.0)",bottom:"calc(var(--aw) * 0.072)",backgroundImage:"url(./art/blush-arch-legs.png)",backgroundRepeat:"repeat-y",backgroundSize:"100% auto"}}),u.jsx("img",{"code-path":"src/components/invite/InvitationRenderer.tsx:380:11",src:"./art/blush-arch-bar.png",alt:"",draggable:!1,className:"absolute bottom-0 left-0 w-full block"}),u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:388:11",className:"absolute left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 w-full px-8 text-center",style:{top:"44%"},children:u.jsx(k.span,{"code-path":"src/components/invite/InvitationRenderer.tsx:389:13",className:"inline-block",style:{fontFamily:"'Amiri', serif",fontSize:"clamp(1.85rem, 6.8vw, 2.6rem)",color:"#b98a2f",textShadow:"0 0 22px rgba(233,190,110,0.55), 0 0 46px rgba(233,190,110,0.3)"},initial:!1,animate:r?{opacity:[0,1,1,0],y:[18,0,0,-16],scale:[.93,1,1,1.04],filter:["blur(12px)","blur(0px)","blur(0px)","blur(8px)"]}:{opacity:0,y:18,scale:.93,filter:"blur(12px)"},transition:r?{duration:2.65,delay:.85,times:[0,.3,.72,1],ease:"easeInOut"}:{duration:.2},children:a.bismillah})}),u.jsxs("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:410:11",className:"absolute inset-x-[6%] flex flex-col items-center text-center z-10",style:{top:"calc(var(--aw) * 0.42)"},children:[u.jsx(k.span,{"code-path":"src/components/invite/InvitationRenderer.tsx:411:13",...p(2.75,10,18,1),className:"inline-block",style:{fontFamily:"'Great Vibes', cursive",color:Pe,fontSize:"clamp(22px, 6.2vw, 30px)",textShadow:"0 1px 10px rgba(253,249,245,0.9)"},children:a.weddingDay}),u.jsxs(k.h1,{"code-path":"src/components/invite/InvitationRenderer.tsx:418:13",...p(3.35,13,30,1.3),className:"leading-[1.08] mt-1",style:{fontFamily:"'Great Vibes', cursive",fontSize:"clamp(2.7rem, 11.5vw, 4rem)",textShadow:"0 0 18px rgba(253,249,245,0.95), 0 2px 8px rgba(74,26,35,0.14)"},children:[u.jsx(qx,{"code-path":"src/components/invite/InvitationRenderer.tsx:427:15",style:{display:"block",overflowWrap:"break-word"},children:n.groomName}),u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:428:15",style:{color:Pe,fontSize:"0.52em",display:"block",margin:"0.1em 0"},children:"&"}),u.jsx(qx,{"code-path":"src/components/invite/InvitationRenderer.tsx:429:15",style:{display:"block",overflowWrap:"break-word"},children:n.brideName})]}),u.jsx(k.span,{"code-path":"src/components/invite/InvitationRenderer.tsx:431:13",...p(4.15,7,14,.9),className:"mt-2 inline-block tracking-[0.32em]",style:{color:Lt,fontFamily:"'Cormorant Garamond', serif",fontSize:"clamp(11px, 2.9vw, 14px)",textShadow:"0 1px 8px rgba(253,249,245,0.9)"},children:i})]}),u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:441:11",className:"absolute inset-x-0 flex justify-center",style:{top:"calc(var(--aw) * 0.84)"},children:u.jsx(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:442:13",style:{width:"45%",transformOrigin:"center 92%"},initial:!1,animate:r?{opacity:1,y:0,scale:1}:{opacity:0,y:150,scale:.86},transition:r?{opacity:{duration:.9,delay:4.2},y:{type:"spring",stiffness:58,damping:13,delay:4.2},scale:{type:"spring",stiffness:58,damping:13,delay:4.2}}:{duration:.25},children:u.jsx(k.img,{"code-path":"src/components/invite/InvitationRenderer.tsx:456:15",src:"./art/blush-couple-flat.png",alt:"the bride and groom",draggable:!1,className:"w-full block select-none",initial:!1,animate:r?{y:[0,-4,0],rotate:[0,.7,0]}:{y:0,rotate:0},transition:r?{duration:7,repeat:1/0,ease:"easeInOut",delay:5.4}:{duration:.2}})})})]})}),u.jsx(Yx,{"code-path":"src/components/invite/InvitationRenderer.tsx:471:7",side:"left",opened:r,delay:1.1}),u.jsx(Yx,{"code-path":"src/components/invite/InvitationRenderer.tsx:472:7",side:"right",opened:r,delay:1.3}),u.jsxs(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:475:7",className:"absolute inset-x-0 z-20 flex flex-col items-center gap-1",style:{bottom:"6%",opacity:y},initial:!1,animate:r?{opacity:1}:{opacity:0},transition:{delay:5.2,duration:1},children:[u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:482:9",className:"text-[10px] tracking-[0.42em] uppercase px-3 py-1 rounded-full",style:{color:Pe,fontFamily:"'Jost', sans-serif",background:"rgba(253,249,245,0.65)",backdropFilter:"blur(4px)"},children:a.scrollDown}),u.jsx(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:488:9",animate:{y:[0,7,0]},transition:{duration:2,repeat:1/0,ease:"easeInOut"},children:u.jsx(Lh,{"code-path":"src/components/invite/InvitationRenderer.tsx:489:11",size:17,color:gt})})]})]})}function qT({events:n,t:a,names:i}){const r=w.useMemo(()=>{const p=n[0];if(!p)return Date.now()+3888e6;const m=new Date(`${p.date}T${p.time||"00:00"}:00`);return isNaN(m.getTime())?Date.now()+3888e6:m.getTime()},[n]),[l,d]=w.useState(Date.now());w.useEffect(()=>{const p=setInterval(()=>d(Date.now()),1e3);return()=>clearInterval(p)},[]);const h=Math.max(0,r-l),y=[[a.days,Math.floor(h/864e5)],[a.hours,Math.floor(h/36e5)%24],[a.minutes,Math.floor(h/6e4)%60],[a.seconds,Math.floor(h/1e3)%60]];return u.jsxs("section",{"code-path":"src/components/invite/InvitationRenderer.tsx:522:5",className:"relative px-7 py-20 text-center overflow-hidden",style:{background:"#f6e3e1"},children:[u.jsx(Pl,{"code-path":"src/components/invite/InvitationRenderer.tsx:523:7"}),u.jsx(Wr,{"code-path":"src/components/invite/InvitationRenderer.tsx:524:7",density:6}),u.jsx($e,{"code-path":"src/components/invite/InvitationRenderer.tsx:525:7",title:a.beginsIn,script:!0}),u.jsx(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:526:7",...tt,className:"mt-10 flex items-start justify-center gap-1",children:y.map(([p,m],g)=>u.jsxs("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:528:11",className:"flex items-start",children:[g>0&&u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:530:15",className:"mx-1 mt-1 text-4xl",style:{color:gt,fontFamily:"'Cormorant Garamond', serif"},children:":"}),u.jsxs("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:532:13",className:"flex flex-col items-center w-[74px]",children:[u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:533:15",className:"text-[44px] leading-none tabular-nums",style:{color:Pe,fontFamily:"'Cormorant Garamond', serif",fontWeight:600},children:String(m).padStart(2,"0")}),u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:539:15",className:"mt-2 text-[10px] tracking-[0.28em] uppercase",style:{color:nt,fontFamily:"'Jost', sans-serif"},children:p})]})]},p))}),u.jsx(XT,{"code-path":"src/components/invite/InvitationRenderer.tsx:546:7",events:n,t:a,names:i})]})}function XT({events:n,t:a,names:i}){const r=n[0];if(!r)return null;const l=()=>{const d=new Date(`${r.date}T${r.time||"16:00"}:00`),h=new Date(d.getTime()+5*36e5),y=x=>`${x.getFullYear()}${String(x.getMonth()+1).padStart(2,"0")}${String(x.getDate()).padStart(2,"0")}T${String(x.getHours()).padStart(2,"0")}${String(x.getMinutes()).padStart(2,"0")}00`,p=["BEGIN:VCALENDAR","VERSION:2.0","PRODID:-//Harusi//Wedding//EN","BEGIN:VEVENT",`UID:${Date.now()}@harusi`,`DTSTAMP:${y(new Date)}`,`DTSTART:${y(d)}`,`DTEND:${y(h)}`,`SUMMARY:${i} — Wedding Day`,`LOCATION:${r.venue??""}`,"END:VEVENT","END:VCALENDAR"].join(`\r
`),m=URL.createObjectURL(new Blob([p],{type:"text/calendar"})),g=document.createElement("a");g.href=m,g.download="wedding-invitation.ics",g.click(),URL.revokeObjectURL(m)};return u.jsxs(k.button,{"code-path":"src/components/invite/InvitationRenderer.tsx:577:5",onClick:l,whileTap:{scale:.94},className:"mt-9 inline-flex items-center gap-2 px-7 py-3 rounded-full text-[11px] tracking-[0.26em] uppercase",style:{border:`1.5px solid ${gt}`,color:Pe,fontFamily:"'Jost', sans-serif",background:"rgba(253,249,245,0.7)"},initial:{opacity:0,y:16},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.7,delay:.2},children:[u.jsxs("svg",{"code-path":"src/components/invite/InvitationRenderer.tsx:587:7",width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:Pe,strokeWidth:"2",strokeLinecap:"round",children:[u.jsx("rect",{"code-path":"src/components/invite/InvitationRenderer.tsx:588:9",x:"3",y:"5",width:"18",height:"16",rx:"2"}),u.jsx("path",{"code-path":"src/components/invite/InvitationRenderer.tsx:588:59",d:"M8 3v4M16 3v4M3 10h18M12 14v4M10 16h4"})]}),a.addToCalendar]})}function $T({events:n,t:a,lang:i}){const r=w.useRef(null),{scrollYProgress:l}=Jr({target:r,offset:["start 0.72","end 0.55"]}),d=St(l,[0,1],["1%","94%"]),h=St(l,[0,1],[-14,16]);return u.jsxs("section",{"code-path":"src/components/invite/InvitationRenderer.tsx:605:5",className:"relative px-7 py-20",style:{background:yi},children:[u.jsx($e,{"code-path":"src/components/invite/InvitationRenderer.tsx:606:7",title:a.schedule,script:!0}),u.jsxs("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:607:7",ref:r,className:"relative mt-12 max-w-md mx-auto pl-[86px]",children:[u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:609:9",className:"absolute top-1 bottom-1",style:{left:74,width:0,borderLeft:"2px dotted rgba(185,138,47,0.65)"}}),u.jsx(k.img,{"code-path":"src/components/invite/InvitationRenderer.tsx:614:9",src:"./art/blush-rosebud.png",alt:"","aria-hidden":!0,className:"absolute z-10 pointer-events-none select-none",style:{left:74,top:d,x:"-50%",rotate:h,width:52,filter:"drop-shadow(0 4px 10px rgba(74,26,35,0.3))"}}),u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:621:9",className:"flex flex-col gap-9",children:n.map((y,p)=>u.jsxs(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:623:13",initial:{opacity:0,x:24},whileInView:{opacity:1,x:0},viewport:{once:!0,margin:"-40px"},transition:{duration:.7,delay:p*.06},className:"relative",children:[u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:632:15",className:"absolute text-right tabular-nums",style:{left:-86,width:72,top:2,color:nt,fontSize:13,fontFamily:"'Cormorant Garamond', serif"},children:Bb(y.time)}),u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:639:15",className:"absolute rounded-full",style:{left:-16.5,top:6,width:9,height:9,background:"#fdf9f5",border:`2px solid ${gt}`}}),u.jsx("h3",{"code-path":"src/components/invite/InvitationRenderer.tsx:643:15",className:"text-[26px] leading-tight",style:{fontFamily:"'Great Vibes', cursive",color:Pe},children:i==="sw"&&y.nameSw||y.name}),u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:646:15",className:"text-[13px] mt-0.5",style:{color:nt},children:y.venue})]},p))})]})]})}function QT({g:n,t:a}){const[i,r]=w.useState(!1),l=async()=>{try{await navigator.clipboard.writeText(n.accountNumber),r(!0),setTimeout(()=>r(!1),1800)}catch{}};return u.jsxs(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:668:5",...tt,className:"flex items-center justify-between gap-4 px-6 py-5",style:{background:"#fffdf9",border:"1px solid rgba(185,138,47,0.4)",boxShadow:"0 12px 30px rgba(74,26,35,0.09)"},children:[u.jsxs("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:673:7",className:"text-left",children:[u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:674:9",className:"text-[15px] tracking-[0.12em] uppercase",style:{color:gt,fontFamily:"'Jost', sans-serif"},children:n.provider}),u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:675:9",className:"text-[13px]",style:{color:nt},children:n.accountName}),u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:676:9",className:"text-lg mt-0.5 tabular-nums",style:{color:Lt,fontWeight:600},children:n.accountNumber})]}),u.jsxs(k.button,{"code-path":"src/components/invite/InvitationRenderer.tsx:678:7",onClick:l,whileTap:{scale:.88},className:"flex items-center gap-1.5 px-4 py-2 rounded-full text-[11px] tracking-[0.18em] uppercase shrink-0",style:{background:i?"#1e7a4f":Pe,color:"#f3dc9a",fontFamily:"'Jost', sans-serif",transition:"background 0.3s"},children:[i?u.jsx(Ur,{"code-path":"src/components/invite/InvitationRenderer.tsx:689:19",size:13}):u.jsx(Gh,{"code-path":"src/components/invite/InvitationRenderer.tsx:689:41",size:13}),i?a.copied:a.copy]})]})}function ZT({data:n,guest:a,t:i,onRsvp:r}){const[l,d]=w.useState(!1),[h,y]=w.useState(!1),[p,m]=w.useState(!1),[g,x]=w.useState(a?.name??""),[b,M]=w.useState(null),[S,T]=w.useState(1),[j,O]=w.useState(""),[L,z]=w.useState(""),[D,X]=w.useState(""),J=async()=>{if(b===null||!g.trim())return;m(!0);const E=[D&&`${D}`,j&&`Song: ${j}`,L&&`Children: ${L}`].filter(Boolean).join(" · ");try{await r?.(b,S-1,E)}finally{m(!1),y(!0)}},Q=`Hello! RSVP for ${n.groomName} & ${n.brideName}'s wedding — ${g||"Guest"}: ${b?"attending":"regrets"}.`;return u.jsxs("section",{"code-path":"src/components/invite/InvitationRenderer.tsx:736:5",className:"relative px-7 py-24 text-center overflow-hidden",style:{background:"#fdf9f5"},children:[u.jsx("img",{"code-path":"src/components/invite/InvitationRenderer.tsx:737:7",src:"./art/blush-bouquet.png",alt:"","aria-hidden":!0,loading:"lazy",decoding:"async",className:"absolute -top-10 -right-14 w-60 opacity-90 pointer-events-none select-none",style:{transform:"rotate(195deg)"}}),u.jsx($e,{"code-path":"src/components/invite/InvitationRenderer.tsx:738:7",title:i.confirmTitle,script:!0}),u.jsx(k.p,{"code-path":"src/components/invite/InvitationRenderer.tsx:739:7",...tt,className:"mt-4 max-w-xs mx-auto text-[15px]",style:{color:nt},children:i.confirmSub}),u.jsxs(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:741:7",...tt,className:"mt-9 flex flex-col items-center gap-3",children:[u.jsx(Lb,{"code-path":"src/components/invite/InvitationRenderer.tsx:742:9",size:138,src:"./art/blush-seal-rsvp.png",onClick:()=>d(!0)}),u.jsxs(k.span,{"code-path":"src/components/invite/InvitationRenderer.tsx:743:9",className:"text-[11px] tracking-[0.34em] uppercase",style:{color:Pe,fontFamily:"'Jost', sans-serif"},animate:{opacity:[.5,1,.5]},transition:{duration:2.4,repeat:1/0},children:["⌃ ",i.clickToOpen]})]}),u.jsx(Ti,{"code-path":"src/components/invite/InvitationRenderer.tsx:753:7",children:l&&u.jsx(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:755:11",className:"fixed inset-0 z-[80] overflow-y-auto",style:{background:"rgba(74,26,35,0.5)",backdropFilter:"blur(6px)"},initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:()=>d(!1),children:u.jsx(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:763:13",className:"relative min-h-full flex items-start justify-center py-8 px-4",initial:{y:60,opacity:0},animate:{y:0,opacity:1},exit:{y:60,opacity:0},transition:{type:"spring",stiffness:210,damping:24},onClick:E=>E.stopPropagation(),children:u.jsxs("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:771:15",className:"relative w-full max-w-md px-7 py-9 text-left",style:{background:"linear-gradient(rgba(253,249,245,0.96), rgba(253,249,245,0.96)), url(./art/blush-envelope-texture.jpg)",backgroundSize:"cover",border:"1px solid rgba(185,138,47,0.5)",boxShadow:"0 30px 70px rgba(74,26,35,0.4)"},children:[u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:780:17",className:"absolute inset-2 pointer-events-none",style:{border:"1px solid rgba(185,138,47,0.3)"}}),u.jsx("button",{"code-path":"src/components/invite/InvitationRenderer.tsx:781:17",onClick:()=>d(!1),className:"absolute top-4 right-4 z-10 w-9 h-9 flex items-center justify-center rounded-full",style:{border:"1px solid rgba(185,138,47,0.5)",color:Pe,background:"rgba(253,249,245,0.9)"},"aria-label":"close",children:u.jsx(Bh,{"code-path":"src/components/invite/InvitationRenderer.tsx:787:19",size:16})}),h?u.jsxs("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:887:19",className:"relative py-14 text-center",children:[u.jsx(Ob,{"code-path":"src/components/invite/InvitationRenderer.tsx:888:21",fire:h}),u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:889:21",className:"text-4xl",style:{fontFamily:"'Great Vibes', cursive",color:Pe},children:i.rsvpDone}),u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:890:21",className:"mt-5 flex justify-center",children:u.jsx(Bt,{"code-path":"src/components/invite/InvitationRenderer.tsx:890:63",color:gt,width:170})})]}):u.jsxs("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:791:19",className:"relative",children:[u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:792:21",className:"text-center text-[12px] tracking-[0.2em] uppercase",style:{color:gt,fontFamily:"'Jost', sans-serif"},children:i.rsvpBefore}),u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:795:21",className:"mt-2 flex justify-center",children:u.jsx(Bt,{"code-path":"src/components/invite/InvitationRenderer.tsx:795:63",color:gt,width:170})}),u.jsx("label",{"code-path":"src/components/invite/InvitationRenderer.tsx:797:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:nt,fontFamily:"'Jost', sans-serif"},children:i.yourName}),u.jsx("input",{"code-path":"src/components/invite/InvitationRenderer.tsx:798:21",value:g,onChange:E=>x(E.target.value),className:"mt-2 w-full px-4 py-3 text-[16px] outline-none",style:{background:"#fffdf9",border:"1px solid rgba(185,138,47,0.45)",color:Lt,fontFamily:"'Cormorant Garamond', serif"}}),u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:805:21",className:"mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:nt,fontFamily:"'Jost', sans-serif"},children:i.attendQ}),u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:806:21",className:"mt-3 flex flex-col gap-2.5",children:[{v:!0,label:i.accept},{v:!1,label:i.decline}].map(E=>u.jsxs("button",{"code-path":"src/components/invite/InvitationRenderer.tsx:811:25",onClick:()=>M(E.v),className:"flex items-center gap-3 px-4 py-3 text-left transition-all",style:{border:`1px solid ${b===E.v?Pe:"rgba(185,138,47,0.4)"}`,background:b===E.v?"rgba(109,26,45,0.06)":"#fffdf9"},children:[u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:820:27",className:"w-4 h-4 rounded-full flex items-center justify-center shrink-0",style:{border:`1.5px solid ${b===E.v?Pe:gt}`},children:b===E.v&&u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:824:51",className:"w-2 h-2 rounded-full",style:{background:Pe}})}),u.jsx("span",{"code-path":"src/components/invite/InvitationRenderer.tsx:826:27",className:"text-[16px]",style:{color:Lt},children:E.label})]},String(E.v)))}),u.jsx("label",{"code-path":"src/components/invite/InvitationRenderer.tsx:831:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:nt,fontFamily:"'Jost', sans-serif"},children:i.guestsAttending}),u.jsx("select",{"code-path":"src/components/invite/InvitationRenderer.tsx:832:21",value:S,onChange:E=>T(Number(E.target.value)),className:"mt-2 w-full px-4 py-3 text-[16px] outline-none",style:{background:"#fffdf9",border:"1px solid rgba(185,138,47,0.45)",color:Lt,fontFamily:"'Cormorant Garamond', serif"},children:[1,2,3,4,5].map(E=>u.jsx("option",{"code-path":"src/components/invite/InvitationRenderer.tsx:838:51",value:E,children:E},E))}),u.jsx("label",{"code-path":"src/components/invite/InvitationRenderer.tsx:841:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:nt,fontFamily:"'Jost', sans-serif"},children:i.songLabel}),u.jsx("input",{"code-path":"src/components/invite/InvitationRenderer.tsx:842:21",value:j,onChange:E=>O(E.target.value),className:"mt-2 w-full px-4 py-3 text-[16px] outline-none",style:{background:"#fffdf9",border:"1px solid rgba(185,138,47,0.45)",color:Lt,fontFamily:"'Cormorant Garamond', serif"}}),u.jsx("label",{"code-path":"src/components/invite/InvitationRenderer.tsx:849:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:nt,fontFamily:"'Jost', sans-serif"},children:i.childrenLabel}),u.jsx("textarea",{"code-path":"src/components/invite/InvitationRenderer.tsx:850:21",value:L,onChange:E=>z(E.target.value),rows:2,className:"mt-2 w-full px-4 py-3 text-[16px] outline-none resize-none",style:{background:"#fffdf9",border:"1px solid rgba(185,138,47,0.45)",color:Lt,fontFamily:"'Cormorant Garamond', serif"}}),u.jsx("label",{"code-path":"src/components/invite/InvitationRenderer.tsx:858:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:nt,fontFamily:"'Jost', sans-serif"},children:i.dietary}),u.jsx("input",{"code-path":"src/components/invite/InvitationRenderer.tsx:859:21",value:D,onChange:E=>X(E.target.value),className:"mt-2 w-full px-4 py-3 text-[16px] outline-none",style:{background:"#fffdf9",border:"1px solid rgba(185,138,47,0.45)",color:Lt,fontFamily:"'Cormorant Garamond', serif"}}),u.jsx(k.button,{"code-path":"src/components/invite/InvitationRenderer.tsx:866:21",onClick:J,disabled:b===null||!g.trim()||p,whileTap:{scale:.97},className:"mt-8 w-full py-4 rounded-full text-[13px] tracking-[0.3em] uppercase disabled:opacity-40",style:{background:Pe,color:"#f3dc9a",fontFamily:"'Jost', sans-serif",boxShadow:"0 14px 32px rgba(109,26,45,0.4)"},children:p?"…":i.submit}),u.jsxs("a",{"code-path":"src/components/invite/InvitationRenderer.tsx:876:21",href:Fh(n.whatsappNumber,Q),target:"_blank",rel:"noreferrer",className:"mt-3 w-full py-3.5 rounded-full text-[12px] tracking-[0.24em] uppercase flex items-center justify-center gap-2",style:{border:"1px solid rgba(30,122,79,0.5)",color:"#1e7a4f",fontFamily:"'Jost', sans-serif"},children:[u.jsx(gc,{"code-path":"src/components/invite/InvitationRenderer.tsx:883:23",size:15})," ",i.rsvpWhats]})]})]})})})})]})}function KT({t:n,onGuestbook:a,messages:i,demo:r,guestName:l}){const[d,h]=w.useState(l??""),[y,p]=w.useState(""),[m,g]=w.useState([]),[x,b]=w.useState(!1),M=async()=>{!d.trim()||!y.trim()||(a&&await a(d.trim(),y.trim()),(r||!a)&&g(T=>[{id:Date.now(),guestName:d.trim(),body:y.trim()},...T]),p(""),b(!0),setTimeout(()=>b(!1),2600))},S=[...i,...m];return u.jsxs("section",{"code-path":"src/components/invite/InvitationRenderer.tsx:931:5",className:"relative px-7 py-20",style:{background:yi},children:[u.jsx($e,{"code-path":"src/components/invite/InvitationRenderer.tsx:932:7",title:n.guestbook,script:!0}),u.jsxs(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:933:7",...tt,className:"mt-9 max-w-sm mx-auto",children:[u.jsx("input",{"code-path":"src/components/invite/InvitationRenderer.tsx:934:9",value:d,onChange:T=>h(T.target.value),placeholder:n.guestbookName,className:"w-full px-4 py-3 text-[16px] outline-none",style:{background:"#fffdf9",border:"1px solid rgba(185,138,47,0.45)",color:Lt}}),u.jsx("textarea",{"code-path":"src/components/invite/InvitationRenderer.tsx:941:9",value:y,onChange:T=>p(T.target.value),placeholder:n.guestbookPh,rows:3,className:"mt-3 w-full px-4 py-3 text-[16px] outline-none resize-none",style:{background:"#fffdf9",border:"1px solid rgba(185,138,47,0.45)",color:Lt}}),u.jsx(k.button,{"code-path":"src/components/invite/InvitationRenderer.tsx:949:9",onClick:M,whileTap:{scale:.97},className:"mt-4 w-full py-3.5 rounded-full text-[12px] tracking-[0.28em] uppercase",style:{background:Pe,color:"#f3dc9a",fontFamily:"'Jost', sans-serif"},children:n.guestbookSend}),x&&u.jsx("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:957:20",className:"mt-3 text-center text-[14px]",style:{color:"#1e7a4f"},children:n.guestbookThanks})]}),S.length>0&&u.jsx("div",{"code-path":"src/components/invite/InvitationRenderer.tsx:960:9",className:"mt-9 max-w-sm mx-auto flex flex-col gap-3",children:S.slice(0,6).map(T=>u.jsxs(k.div,{"code-path":"src/components/invite/InvitationRenderer.tsx:962:13",initial:{opacity:0,y:14},whileInView:{opacity:1,y:0},viewport:{once:!0},className:"px-5 py-4 text-left",style:{background:"#fffdf9",border:"1px solid rgba(185,138,47,0.3)"},children:[u.jsxs("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:963:15",className:"text-[15px] italic",style:{color:Lt},children:["“",T.body,"”"]}),u.jsxs("p",{"code-path":"src/components/invite/InvitationRenderer.tsx:964:15",className:"mt-1.5 text-[12px] tracking-[0.18em] uppercase",style:{color:gt,fontFamily:"'Jost', sans-serif"},children:["— ",T.guestName]})]},T.id))})]})}const En="#eef4fa",Ee="#8a1c2e",JT="#6c1322",Ie="#c9a24a",Hn="#2f4156",Xt="#7186a0",Xe={initial:{opacity:0,y:30},whileInView:{opacity:1,y:0},viewport:{once:!0,margin:"-50px"},transition:{duration:.9,ease:Ot}};function Nn({fill:n,seed:a=5}){const i=n===Ee?"red":n===En?"light":"cream",r=a%2===0?"b":"a";return u.jsxs("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:35:5",className:"absolute left-0 right-0 z-[3] pointer-events-none select-none",style:{top:0,transform:"translateY(-46%)"},"aria-hidden":!0,children:[u.jsx("img",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:40:7",src:`./art/villa-torn-${i}-${r}.png`,alt:"",loading:"lazy",decoding:"async",draggable:!1,className:"w-full block"}),u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:48:7",className:"absolute inset-0",style:{background:`linear-gradient(to bottom, ${n} 0%, ${n} 26%, transparent 58%)`}})]})}function Qx(n){const a=new Date(n+"T00:00:00");return isNaN(a.getTime())?n:`${String(a.getDate()).padStart(2,"0")} · ${String(a.getMonth()+1).padStart(2,"0")} · ${a.getFullYear()}`}function WT(n){if(!n)return"";const[a,i]=n.split(":").map(Number);if(isNaN(a))return n;const r=a>=12?"PM":"AM";return`${a%12===0?12:a%12}:${String(i??0).padStart(2,"0")} ${r}`}function eN({data:n,guest:a,demo:i=!1,autoOpen:r=!1,onRsvp:l,onGuestbook:d,guestbookMessages:h=[],inviteUrl:y}){const p=_b(n.templateId),[m,g]=w.useState(n.language??"en"),x=Hh[m],[b,M]=w.useState(r),[S,T]=w.useState(r),j=n.events[0],O=j?Qx(j.date):"",L=m==="sw"&&n.storySw||n.storyEn,z=m==="sw"&&n.quoteSw||n.quoteEn;return u.jsxs("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:105:5",className:"relative min-h-screen",style:{background:p.bg,color:p.ink,fontFamily:p.fontBody},children:[!S&&u.jsx(Vb,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:108:9",hint:x.tapSeal,onOpenStart:()=>{M(!0)},onOpened:()=>T(!0),paperUrl:"./art/villa-paper.jpg",sealUrl:"./art/villa-seal.png",bg:"#e9eef4",accent:Ee,sealText:n.sealText??""}),S&&u.jsx(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:122:9",className:"fixed top-4 right-4 z-40 flex rounded-full overflow-hidden text-[11px] tracking-widest",style:{border:"1px solid rgba(201,162,74,0.55)",background:"rgba(255,255,255,0.85)",backdropFilter:"blur(8px)",fontFamily:"'Jost', sans-serif"},initial:{opacity:0,y:-12},animate:{opacity:1,y:0},transition:{delay:.9},children:["en","sw"].map(D=>u.jsx("button",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:130:13",onClick:()=>g(D),className:"px-3 py-1.5 uppercase transition-colors",style:{background:m===D?Ee:"transparent",color:m===D?"#f3dc9a":Xt},children:D},D))}),S&&a&&u.jsx(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:143:9",className:"fixed top-4 left-4 z-40 px-3 py-1.5 rounded-full text-[10px] tracking-[0.2em] uppercase",style:{border:"1px solid rgba(201,162,74,0.55)",background:"rgba(255,255,255,0.85)",backdropFilter:"blur(8px)",color:Xt,fontFamily:"'Jost', sans-serif"},initial:{opacity:0,y:-12},animate:{opacity:1,y:0},transition:{delay:.9},children:a.name}),u.jsx(tN,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:155:7",data:n,t:x,dateLabel:O,opened:b||S}),u.jsxs("section",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:158:7",className:"relative px-7 py-20 text-center",style:{background:Ee},children:[u.jsx(Nn,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:159:9",fill:"#ece5d6",seed:2}),u.jsx(k.p,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:160:9",...Xe,style:{fontFamily:"'Amiri', serif",color:Ie},className:"text-2xl leading-relaxed",children:x.bismillah}),u.jsxs(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:163:9",...Xe,transition:{...Xe.transition,delay:.1},className:"mt-8",children:[u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:164:11",className:"text-4xl leading-tight",style:{fontFamily:"'Great Vibes', cursive",color:"#fdf6ee"},children:x.dearFriends}),u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:167:11",className:"mt-5 flex justify-center",children:u.jsx(Bt,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:167:53",color:Ie,width:190})})]}),(n.groomFamily||n.brideFamily)&&u.jsxs(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:170:11",...Xe,transition:{...Xe.transition,delay:.14},className:"mt-8 max-w-md mx-auto",children:[u.jsxs("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:171:13",className:"text-[15px] leading-relaxed",style:{color:Ie,fontFamily:"'Cormorant Garamond', serif",letterSpacing:"0.06em"},children:[x.familyPre," ",u.jsx("span",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:172:29",style:{color:"#fdf6ee",fontWeight:600},children:n.groomFamily})," ",x.familyAnd," ",u.jsx("span",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:173:15",style:{color:"#fdf6ee",fontWeight:600},children:n.brideFamily})]}),u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:175:13",className:"mt-2 text-[15px] italic leading-relaxed",style:{color:"rgba(253,246,238,0.85)"},children:x.familyPost})]}),u.jsxs(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:178:9",...Xe,transition:{...Xe.transition,delay:.18},className:"mt-8 max-w-md mx-auto",children:[u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:179:11",className:"text-[17px] leading-relaxed",style:{color:"rgba(253,246,238,0.92)"},children:L}),u.jsxs("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:180:11",className:"mt-6 text-[15px] italic leading-relaxed",style:{color:"rgba(253,246,238,0.7)"},children:["“",z,"”"]})]})]}),u.jsx(nN,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:185:7",events:n.events,t:x,names:`${n.groomName} & ${n.brideName}`}),u.jsx(sN,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:188:7",events:n.events,t:x,lang:m}),u.jsxs("section",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:191:7",className:"relative px-7 py-20 overflow-hidden",style:{background:En},children:[u.jsx(Nn,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:192:9",fill:Ee,seed:5}),u.jsx($e,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:193:9",title:x.location,script:!0,color:Ee,gold:Ie}),j&&u.jsxs(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:195:11",...Xe,className:"mt-10 max-w-md mx-auto text-center",children:[u.jsx("h3",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:196:13",className:"text-2xl",style:{color:Ee,fontWeight:600},children:j.venue}),u.jsxs("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:197:13",className:"mt-1 text-[15px]",style:{color:Xt},children:[Qx(j.date)," · ",WT(j.time)]}),u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:200:13",className:"mt-7 overflow-hidden",style:{border:"1px solid rgba(201,162,74,0.45)",boxShadow:"0 14px 36px rgba(47,65,86,0.12)"},children:u.jsx("iframe",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:201:15",title:"map",src:`https://www.google.com/maps?q=${encodeURIComponent(j.venue??"")}&output=embed&hl=en`,className:"w-full h-[240px] block",loading:"lazy"})}),u.jsxs("a",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:208:13",href:j.mapsUrl||`https://maps.google.com/?q=${encodeURIComponent(j.venue??"")}`,target:"_blank",rel:"noreferrer",className:"mt-5 inline-flex items-center gap-2 px-7 py-3 rounded-full text-[12px] tracking-[0.24em] uppercase",style:{background:Ee,color:"#f3dc9a",fontFamily:"'Jost', sans-serif",boxShadow:"0 10px 26px rgba(138,28,46,0.35)"},children:[u.jsx(_h,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:215:15",size:14})," ",x.openInMaps]})]})]}),u.jsx(iN,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:222:7",t:x}),u.jsx(oN,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:290:7",data:n,guest:a,t:x,onRsvp:l}),a&&y&&u.jsxs("section",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:297:9",className:"relative px-7 py-16 text-center overflow-hidden",style:{background:Ee},children:[u.jsx(Nn,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:298:11",fill:En,seed:7}),u.jsxs(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:299:11",...Xe,className:"max-w-xs mx-auto px-8 py-8",style:{background:"#fffdf9",border:"1px solid rgba(201,162,74,0.55)",boxShadow:"0 22px 50px rgba(60,10,18,0.32)"},children:[u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:300:13",className:"text-[11px] tracking-[0.34em] uppercase",style:{color:Ie,fontFamily:"'Jost', sans-serif"},children:x.yourCode}),u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:301:13",className:"mt-4 flex justify-center",children:u.jsx(yc,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:302:15",value:`${y}?code=${a.code}`,size:150,fgColor:"#2f4156",bgColor:"#ffffff",level:"M"})}),u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:304:13",className:"mt-4 text-2xl tracking-[0.3em]",style:{color:Ee,fontWeight:700},children:a.code}),u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:305:13",className:"mt-1 text-[13px]",style:{color:Xt},children:x.scanHint}),a.checkedIn&&u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:306:33",className:"mt-3 text-[13px]",style:{color:"#1e7a4f"},children:x.checkedInBadge})]})]}),u.jsxs("footer",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:312:7",className:"relative pt-20 pb-12 px-7 text-center overflow-hidden",style:{background:JT},children:[u.jsx(Nn,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:313:9",fill:Ee,seed:17}),u.jsx(k.p,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:314:9",...Xe,className:"mt-6 text-4xl",style:{fontFamily:"'Great Vibes', cursive",color:"#fdf6ee"},children:x.hopeToSee}),u.jsxs(k.p,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:317:9",...Xe,className:"mt-2 text-3xl",style:{fontFamily:"'Great Vibes', cursive",color:Ie},children:[u.jsx("span",{style:{display:"inline-block"},children:n.groomName})," & ",u.jsx("span",{style:{display:"inline-block"},children:n.brideName})]}),u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:320:9",className:"mt-6 flex justify-center",children:u.jsx(Bt,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:320:51",color:Ie,width:180})}),u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:321:9",className:"mt-6 text-[11px] tracking-[0.3em] uppercase",style:{color:"rgba(253,246,238,0.65)",fontFamily:"'Jost', sans-serif"},children:x.footer})]})]})}function tN({data:n,t:a,dateLabel:i,opened:r}){const l=w.useRef(null),{scrollYProgress:d}=Jr({target:l,offset:["start start","end start"]}),h=St(d,[0,1],["0%","14%"]),y=St(d,[0,.7],[1,0]),p=(m,g=9,x=22,b=1.05)=>({initial:!1,animate:r?{opacity:1,y:0,scale:1,filter:"blur(0px)"}:{opacity:0,y:x,scale:.96,filter:`blur(${g}px)`},transition:{duration:b,delay:m,ease:[.22,.8,.35,1]}});return u.jsxs("section",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:348:5",ref:l,className:"relative overflow-hidden",style:{height:"100svh",minHeight:620},children:[u.jsx(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:350:7",className:"absolute inset-0",style:{y:h},children:u.jsx("img",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:351:9",src:"./art/villa-hero2.jpg",alt:"",className:"w-full h-full object-cover",style:{objectPosition:"center 28%"}})}),[{top:"15%",size:96,delay:1.6,dur:17},{top:"24%",size:64,delay:7.5,dur:21}].map((m,g)=>u.jsx(k.img,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:359:9",src:"./art/villa-dove.png",alt:"","aria-hidden":!0,draggable:!1,className:"absolute pointer-events-none select-none z-[6]",style:{top:m.top,width:m.size,left:0},initial:{x:"-18vw",opacity:0},animate:r?{x:["-18vw","112vw"],y:[0,-14,0],rotate:[0,3,0],opacity:1}:{x:"-18vw",opacity:0},transition:r?{x:{duration:m.dur,repeat:1/0,ease:"linear",delay:m.delay},y:{duration:4.4,repeat:1/0,ease:"easeInOut",delay:m.delay},rotate:{duration:5,repeat:1/0,ease:"easeInOut",delay:m.delay},opacity:{duration:.6,delay:m.delay}}:{duration:.2}},g)),u.jsx(Wr,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:383:7",density:10,src:"./art/villa-rosebud.png"}),u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:386:7",className:"absolute left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 w-full px-8 text-center",style:{top:"44%"},children:u.jsx(k.span,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:387:9",className:"inline-block",style:{fontFamily:"'Amiri', serif",fontSize:"clamp(1.85rem, 6.8vw, 2.6rem)",color:"#f0d68f",textShadow:"0 0 22px rgba(74,96,130,0.7), 0 2px 10px rgba(47,65,86,0.6)"},initial:!1,animate:r?{opacity:[0,1,1,0],y:[18,0,0,-16],scale:[.93,1,1,1.04],filter:["blur(12px)","blur(0px)","blur(0px)","blur(8px)"]}:{opacity:0,y:18,scale:.93,filter:"blur(12px)"},transition:r?{duration:2.65,delay:.85,times:[0,.3,.72,1],ease:"easeInOut"}:{duration:.2},children:a.bismillah})}),u.jsxs(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:408:7",className:"absolute inset-x-0 z-10 flex flex-col items-center text-center px-6",style:{top:"16%",opacity:y},children:[u.jsx(k.span,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:409:9",...p(2.75,10,18,1),className:"inline-block",style:{fontFamily:"'Great Vibes', cursive",color:"#ffffff",fontSize:"clamp(26px, 7vw, 34px)",textShadow:"0 1px 14px rgba(47,65,86,0.65)"},children:a.weddingDay}),u.jsxs(k.h1,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:416:9",...p(3.35,13,30,1.3),className:"leading-[1.08] mt-2",style:{fontFamily:"'Great Vibes', cursive",fontSize:"clamp(3.1rem, 13vw, 4.6rem)",color:"#ffffff",textShadow:"0 2px 24px rgba(47,65,86,0.75), 0 0 46px rgba(238,244,250,0.4)"},children:[u.jsx("span",{style:{display:"block",overflowWrap:"break-word"},children:n.groomName}),u.jsx("span",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:427:11",style:{color:"#f0d68f",fontSize:"0.52em",display:"block",margin:"0.1em 0"},children:"&"}),u.jsx("span",{style:{display:"block",overflowWrap:"break-word"},children:n.brideName})]}),u.jsx(k.span,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:430:9",...p(4.15,7,14,.9),className:"mt-3 inline-block tracking-[0.34em]",style:{color:"#ffffff",fontFamily:"'Cormorant Garamond', serif",fontSize:"clamp(12px, 3.1vw, 15px)",textShadow:"0 1px 6px rgba(47,65,86,0.9), 0 0 18px rgba(47,65,86,0.7)",fontWeight:600},children:i})]}),u.jsx(k.img,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:440:7",src:"./art/villa-garland.png",alt:"","aria-hidden":!0,draggable:!1,className:"absolute left-0 w-full pointer-events-none select-none z-[8]",style:{bottom:0},initial:!1,animate:r?{opacity:1,y:0,scale:1}:{opacity:0,y:130,scale:.9},transition:r?{opacity:{duration:.9,delay:1.05},y:{type:"spring",stiffness:70,damping:15,delay:1.05},scale:{type:"spring",stiffness:70,damping:15,delay:1.05}}:{duration:.25}}),[{side:"left",flip:!1,delay:1.25},{side:"right",flip:!0,delay:1.4}].map(m=>u.jsx(k.img,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:456:9",src:"./art/villa-mound.png",alt:"","aria-hidden":!0,draggable:!1,className:"absolute pointer-events-none select-none z-[9]",style:{bottom:0,[m.side]:"-7%",width:"min(46vw, 320px)",filter:"drop-shadow(0 6px 16px rgba(47,65,86,0.25))"},initial:!1,animate:r?{opacity:1,y:0,scale:1,scaleX:m.flip?-1:1}:{opacity:0,y:90,scale:.8,scaleX:m.flip?-1:1},transition:r?{opacity:{duration:.9,delay:m.delay},y:{type:"spring",stiffness:70,damping:15,delay:m.delay},scale:{type:"spring",stiffness:70,damping:15,delay:m.delay}}:{duration:.25}},m.side)),u.jsxs(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:476:7",className:"absolute inset-x-0 z-20 flex flex-col items-center gap-1",style:{bottom:"19%",opacity:y},initial:!1,animate:r?{opacity:1}:{opacity:0},transition:{delay:5.2,duration:1},children:[u.jsx("span",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:483:9",className:"text-[10px] tracking-[0.42em] uppercase px-3 py-1 rounded-full",style:{color:"#ffffff",fontFamily:"'Jost', sans-serif",background:"rgba(47,65,86,0.4)",backdropFilter:"blur(4px)"},children:a.scrollDown}),u.jsx(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:489:9",animate:{y:[0,7,0]},transition:{duration:2,repeat:1/0,ease:"easeInOut"},children:u.jsx(Lh,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:490:11",size:17,color:"#f0d68f"})})]})]})}function nN({events:n,t:a,names:i}){const r=w.useMemo(()=>{const p=n[0];if(!p)return Date.now()+3888e6;const m=new Date(`${p.date}T${p.time||"00:00"}:00`);return isNaN(m.getTime())?Date.now()+3888e6:m.getTime()},[n]),[l,d]=w.useState(Date.now());w.useEffect(()=>{const p=setInterval(()=>d(Date.now()),1e3);return()=>clearInterval(p)},[]);const h=Math.max(0,r-l),y=[[a.days,Math.floor(h/864e5)],[a.hours,Math.floor(h/36e5)%24],[a.minutes,Math.floor(h/6e4)%60],[a.seconds,Math.floor(h/1e3)%60]];return u.jsxs("section",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:523:5",className:"relative px-7 py-20 text-center overflow-hidden",style:{background:En},children:[u.jsx(Nn,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:524:7",fill:Ee,seed:31}),u.jsx(Wr,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:525:7",density:5,src:"./art/villa-rosebud.png"}),u.jsx($e,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:526:7",title:a.beginsIn,script:!0,color:Ee,gold:Ie}),u.jsx(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:527:7",...Xe,className:"mt-10 flex items-start justify-center gap-1",children:y.map(([p,m],g)=>u.jsxs("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:529:11",className:"flex items-start",children:[g>0&&u.jsx("span",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:531:15",className:"mx-1 mt-1 text-4xl",style:{color:Ie,fontFamily:"'Cormorant Garamond', serif"},children:":"}),u.jsxs("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:533:13",className:"flex flex-col items-center w-[74px]",children:[u.jsx("span",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:534:15",className:"text-[44px] leading-none tabular-nums",style:{color:Ee,fontFamily:"'Cormorant Garamond', serif",fontWeight:600},children:String(m).padStart(2,"0")}),u.jsx("span",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:540:15",className:"mt-2 text-[10px] tracking-[0.28em] uppercase",style:{color:Xt,fontFamily:"'Jost', sans-serif"},children:p})]})]},p))}),u.jsx(aN,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:547:7",events:n,t:a,names:i})]})}function aN({events:n,t:a,names:i}){const r=n[0];if(!r)return null;const l=()=>{const d=new Date(`${r.date}T${r.time||"16:00"}:00`),h=new Date(d.getTime()+5*36e5),y=x=>`${x.getFullYear()}${String(x.getMonth()+1).padStart(2,"0")}${String(x.getDate()).padStart(2,"0")}T${String(x.getHours()).padStart(2,"0")}${String(x.getMinutes()).padStart(2,"0")}00`,p=["BEGIN:VCALENDAR","VERSION:2.0","PRODID:-//Harusi//Wedding//EN","BEGIN:VEVENT",`UID:${Date.now()}@harusi`,`DTSTAMP:${y(new Date)}`,`DTSTART:${y(d)}`,`DTEND:${y(h)}`,`SUMMARY:${i} — Wedding Day`,`LOCATION:${r.venue??""}`,"END:VEVENT","END:VCALENDAR"].join(`\r
`),m=URL.createObjectURL(new Blob([p],{type:"text/calendar"})),g=document.createElement("a");g.href=m,g.download="wedding-invitation.ics",g.click(),URL.revokeObjectURL(m)};return u.jsxs(k.button,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:578:5",onClick:l,whileTap:{scale:.94},className:"mt-9 inline-flex items-center gap-2 px-7 py-3 rounded-full text-[11px] tracking-[0.26em] uppercase",style:{border:`1.5px solid ${Ie}`,color:Ee,fontFamily:"'Jost', sans-serif",background:"rgba(255,255,255,0.75)"},initial:{opacity:0,y:16},whileInView:{opacity:1,y:0},viewport:{once:!0},transition:{duration:.7,delay:.2},children:[u.jsxs("svg",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:588:7",width:"14",height:"14",viewBox:"0 0 24 24",fill:"none",stroke:Ee,strokeWidth:"2",strokeLinecap:"round",children:[u.jsx("rect",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:589:9",x:"3",y:"5",width:"18",height:"16",rx:"2"}),u.jsx("path",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:589:59",d:"M8 3v4M16 3v4M3 10h18M12 14v4M10 16h4"})]}),a.addToCalendar]})}function sN({events:n,t:a,lang:i}){const r=w.useRef(null),{scrollYProgress:l}=Jr({target:r,offset:["start 0.72","end 0.55"]}),d=St(l,[0,1],["1%","94%"]),h=St(l,[0,1],[-14,16]);return u.jsxs("section",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:606:5",className:"relative px-7 py-20 overflow-hidden",style:{background:Ee},children:[u.jsx(Nn,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:607:7",fill:En,seed:13}),u.jsx($e,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:608:7",title:a.schedule,script:!0,color:"#fdf6ee",gold:Ie}),u.jsxs("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:609:7",ref:r,className:"relative mt-12 max-w-md mx-auto pl-[86px]",children:[u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:610:9",className:"absolute top-1 bottom-1",style:{left:74,width:0,borderLeft:"2px dotted rgba(233,214,143,0.65)"}}),u.jsx(k.img,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:614:9",src:"./art/villa-rosebud.png",alt:"","aria-hidden":!0,className:"absolute z-10 pointer-events-none select-none",style:{left:74,top:d,x:"-50%",rotate:h,width:52,filter:"drop-shadow(0 4px 10px rgba(0,0,0,0.4))"}}),u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:621:9",className:"flex flex-col gap-9",children:n.map((y,p)=>u.jsxs(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:623:13",initial:{opacity:0,x:24},whileInView:{opacity:1,x:0},viewport:{once:!0,margin:"-40px"},transition:{duration:.7,delay:p*.06},className:"relative",children:[u.jsx("span",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:631:15",className:"absolute text-right tabular-nums",style:{left:-86,width:72,top:2,color:"rgba(253,246,238,0.8)",fontSize:13,fontFamily:"'Cormorant Garamond', serif"},children:y.time}),u.jsx("span",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:637:15",className:"absolute rounded-full",style:{left:-16.5,top:6,width:9,height:9,background:"#fdf6ee",border:`2px solid ${Ie}`}}),u.jsx("h3",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:641:15",className:"text-[26px] leading-tight",style:{fontFamily:"'Great Vibes', cursive",color:"#fdf6ee"},children:i==="sw"&&y.nameSw||y.name}),u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:644:15",className:"text-[13px] mt-0.5",style:{color:"rgba(253,246,238,0.7)"},children:y.venue})]},p))})]})]})}function iN({t:n}){const a=["#9fb59a","#6d1a2d","#2f4156","#eef4fa"],i=[{img:"./art/villa-dress-men.jpg",caption:n.dressGents,tilt:-2},{img:"./art/villa-dress-ladies.jpg",caption:n.dressLadies,tilt:2}];return u.jsxs("section",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:663:5",className:"relative px-7 py-20 overflow-hidden",style:{background:Ee},children:[u.jsx(Nn,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:664:7",fill:En,seed:29}),u.jsx($e,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:665:7",title:n.dressTitle,script:!0,color:"#fdf6ee",gold:Ie}),u.jsx(k.p,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:666:7",...Xe,className:"relative mt-8 max-w-sm mx-auto text-center text-[17px] leading-relaxed",style:{color:"rgba(253,246,238,0.92)"},children:n.dressText}),u.jsx(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:669:7",...Xe,className:"mt-7 flex justify-center gap-4",children:a.map(r=>u.jsx("span",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:671:11",className:"rounded-full",style:{width:30,height:30,background:r,border:`2px solid ${Ie}`,boxShadow:"0 6px 16px rgba(0,0,0,0.3)"}},r))}),u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:678:7",className:"mt-10 max-w-sm mx-auto flex flex-col gap-8",children:i.map((r,l)=>u.jsxs(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:680:11",initial:{opacity:0,y:30,rotate:0},whileInView:{opacity:1,y:0,rotate:r.tilt},viewport:{once:!0,margin:"-60px"},transition:{duration:.8,delay:l*.1},className:"mx-auto w-[78%]",children:[u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:688:13",style:{padding:9,background:"linear-gradient(160deg, #f4e3b2, #c9a24a 45%, #8f6b1f)",boxShadow:"0 22px 48px rgba(0,0,0,0.4)"},children:u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:695:15",style:{border:"1px solid rgba(255,255,255,0.55)",padding:4,background:"#fff"},children:u.jsx("img",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:696:17",src:r.img,alt:"",loading:"lazy",decoding:"async",className:"w-full block"})})}),u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:699:13",className:"mt-3.5 text-center text-[14px] leading-relaxed px-2",style:{color:"rgba(253,246,238,0.85)"},children:r.caption})]},l))})]})}function rN({g:n,t:a}){const[i,r]=w.useState(!1),l=async()=>{try{await navigator.clipboard.writeText(n.accountNumber),r(!0),setTimeout(()=>r(!1),1800)}catch{}};return u.jsxs(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:722:5",...Xe,className:"flex items-center justify-between gap-4 px-6 py-5",style:{background:"#ffffff",border:"1px solid rgba(201,162,74,0.45)",boxShadow:"0 12px 30px rgba(47,65,86,0.09)"},children:[u.jsxs("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:727:7",className:"text-left",children:[u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:728:9",className:"text-[15px] tracking-[0.12em] uppercase",style:{color:Ie,fontFamily:"'Jost', sans-serif"},children:n.provider}),u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:729:9",className:"text-[13px]",style:{color:Xt},children:n.accountName}),u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:730:9",className:"text-lg mt-0.5 tabular-nums",style:{color:Hn,fontWeight:600},children:n.accountNumber})]}),u.jsxs(k.button,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:732:7",onClick:l,whileTap:{scale:.88},className:"flex items-center gap-1.5 px-4 py-2 rounded-full text-[11px] tracking-[0.18em] uppercase shrink-0",style:{background:i?"#1e7a4f":Ee,color:"#f3dc9a",fontFamily:"'Jost', sans-serif",transition:"background 0.3s"},children:[i?u.jsx(Ur,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:743:19",size:13}):u.jsx(Gh,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:743:41",size:13}),i?a.copied:a.copy]})]})}function oN({data:n,guest:a,t:i,onRsvp:r}){const[l,d]=w.useState(!1),[h,y]=w.useState(!1),[p,m]=w.useState(!1),[g,x]=w.useState(a?.name??""),[b,M]=w.useState(null),[S,T]=w.useState(1),[j,O]=w.useState(""),[L,z]=w.useState(""),[D,X]=w.useState(""),J=async()=>{if(b===null||!g.trim())return;m(!0);const E=[D&&`${D}`,j&&`Song: ${j}`,L&&`Children: ${L}`].filter(Boolean).join(" · ");try{await r?.(b,S-1,E)}finally{m(!1),y(!0)}},Q=`Hello! RSVP for ${n.groomName} & ${n.brideName}'s wedding — ${g||"Guest"}: ${b?"attending":"regrets"}.`;return u.jsxs("section",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:790:5",className:"relative px-7 py-24 text-center overflow-hidden",style:{background:En},children:[u.jsx(Nn,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:791:7",fill:Ee,seed:41}),u.jsx($e,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:792:7",title:i.confirmTitle,script:!0,color:Ee,gold:Ie}),u.jsx(k.p,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:793:7",...Xe,className:"mt-4 max-w-xs mx-auto text-[15px]",style:{color:Xt},children:i.confirmSub}),u.jsxs("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:796:7",className:"relative mt-9",children:[[{side:"left",flip:!1,delay:.15},{side:"right",flip:!0,delay:.28}].map(E=>u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:801:11",className:"absolute top-1/2 -translate-y-1/2 z-0 pointer-events-none select-none",style:{[E.side]:"-4%",width:"min(37vw, 240px)"},children:u.jsx(k.img,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:806:13",src:"./art/villa-mound.png",alt:"","aria-hidden":!0,draggable:!1,loading:"lazy",decoding:"async",className:"w-full block",style:{filter:"drop-shadow(0 8px 18px rgba(47,65,86,0.2))"},initial:{opacity:0,y:-26,scale:.7,scaleX:E.flip?-1:1},whileInView:{opacity:1,y:0,scale:1,scaleX:E.flip?-1:1},viewport:{once:!0,margin:"-60px"},transition:{duration:.9,delay:E.delay,type:"spring",stiffness:90,damping:15}})},E.side)),u.jsxs(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:822:9",...Xe,className:"relative z-10 flex flex-col items-center gap-3",children:[u.jsx(Lb,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:823:11",size:138,src:"./art/villa-seal.png",onClick:()=>d(!0)}),u.jsxs(k.span,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:824:11",className:"text-[11px] tracking-[0.34em] uppercase",style:{color:Ee,fontFamily:"'Jost', sans-serif"},animate:{opacity:[.5,1,.5]},transition:{duration:2.4,repeat:1/0},children:["⌃ ",i.clickToOpen]})]})]}),u.jsx(Ti,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:835:7",children:l&&u.jsx(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:837:11",className:"fixed inset-0 z-[80] overflow-y-auto",style:{background:"rgba(47,65,86,0.5)",backdropFilter:"blur(6px)"},initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:()=>d(!1),children:u.jsx(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:845:13",className:"relative min-h-full flex items-start justify-center py-8 px-4",initial:{y:60,opacity:0},animate:{y:0,opacity:1},exit:{y:60,opacity:0},transition:{type:"spring",stiffness:210,damping:24},onClick:E=>E.stopPropagation(),children:u.jsxs("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:853:15",className:"relative w-full max-w-md px-7 py-9 text-left",style:{background:"linear-gradient(rgba(255,255,255,0.95), rgba(255,255,255,0.95)), url(./art/villa-paper.jpg)",backgroundSize:"cover",border:"1px solid rgba(201,162,74,0.55)",boxShadow:"0 30px 70px rgba(47,65,86,0.4)"},children:[u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:862:17",className:"absolute inset-2 pointer-events-none",style:{border:"1px solid rgba(201,162,74,0.35)"}}),u.jsx("button",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:863:17",onClick:()=>d(!1),className:"absolute top-4 right-4 z-10 w-9 h-9 flex items-center justify-center rounded-full",style:{border:"1px solid rgba(201,162,74,0.55)",color:Ee,background:"rgba(255,255,255,0.92)"},"aria-label":"close",children:u.jsx(Bh,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:869:19",size:16})}),h?u.jsxs("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:969:19",className:"relative py-14 text-center",children:[u.jsx(Ob,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:970:21",fire:h}),u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:971:21",className:"text-4xl",style:{fontFamily:"'Great Vibes', cursive",color:Ee},children:i.rsvpDone}),u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:972:21",className:"mt-5 flex justify-center",children:u.jsx(Bt,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:972:63",color:Ie,width:170})})]}):u.jsxs("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:873:19",className:"relative",children:[u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:874:21",className:"text-center text-[12px] tracking-[0.2em] uppercase",style:{color:Ie,fontFamily:"'Jost', sans-serif"},children:i.rsvpBefore}),u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:877:21",className:"mt-2 flex justify-center",children:u.jsx(Bt,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:877:63",color:Ie,width:170})}),u.jsx("label",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:879:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:Xt,fontFamily:"'Jost', sans-serif"},children:i.yourName}),u.jsx("input",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:880:21",value:g,onChange:E=>x(E.target.value),className:"mt-2 w-full px-4 py-3 text-[16px] outline-none",style:{background:"#ffffff",border:"1px solid rgba(201,162,74,0.5)",color:Hn,fontFamily:"'Cormorant Garamond', serif"}}),u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:887:21",className:"mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:Xt,fontFamily:"'Jost', sans-serif"},children:i.attendQ}),u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:888:21",className:"mt-3 flex flex-col gap-2.5",children:[{v:!0,label:i.accept},{v:!1,label:i.decline}].map(E=>u.jsxs("button",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:893:25",onClick:()=>M(E.v),className:"flex items-center gap-3 px-4 py-3 text-left transition-all",style:{border:`1px solid ${b===E.v?Ee:"rgba(201,162,74,0.45)"}`,background:b===E.v?"rgba(138,28,46,0.06)":"#ffffff"},children:[u.jsx("span",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:902:27",className:"w-4 h-4 rounded-full flex items-center justify-center shrink-0",style:{border:`1.5px solid ${b===E.v?Ee:Ie}`},children:b===E.v&&u.jsx("span",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:906:51",className:"w-2 h-2 rounded-full",style:{background:Ee}})}),u.jsx("span",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:908:27",className:"text-[16px]",style:{color:Hn},children:E.label})]},String(E.v)))}),u.jsx("label",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:913:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:Xt,fontFamily:"'Jost', sans-serif"},children:i.guestsAttending}),u.jsx("select",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:914:21",value:S,onChange:E=>T(Number(E.target.value)),className:"mt-2 w-full px-4 py-3 text-[16px] outline-none",style:{background:"#ffffff",border:"1px solid rgba(201,162,74,0.5)",color:Hn,fontFamily:"'Cormorant Garamond', serif"},children:[1,2,3,4,5].map(E=>u.jsx("option",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:920:51",value:E,children:E},E))}),u.jsx("label",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:923:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:Xt,fontFamily:"'Jost', sans-serif"},children:i.songLabel}),u.jsx("input",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:924:21",value:j,onChange:E=>O(E.target.value),className:"mt-2 w-full px-4 py-3 text-[16px] outline-none",style:{background:"#ffffff",border:"1px solid rgba(201,162,74,0.5)",color:Hn,fontFamily:"'Cormorant Garamond', serif"}}),u.jsx("label",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:931:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:Xt,fontFamily:"'Jost', sans-serif"},children:i.childrenLabel}),u.jsx("textarea",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:932:21",value:L,onChange:E=>z(E.target.value),rows:2,className:"mt-2 w-full px-4 py-3 text-[16px] outline-none resize-none",style:{background:"#ffffff",border:"1px solid rgba(201,162,74,0.5)",color:Hn,fontFamily:"'Cormorant Garamond', serif"}}),u.jsx("label",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:940:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:Xt,fontFamily:"'Jost', sans-serif"},children:i.dietary}),u.jsx("input",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:941:21",value:D,onChange:E=>X(E.target.value),className:"mt-2 w-full px-4 py-3 text-[16px] outline-none",style:{background:"#ffffff",border:"1px solid rgba(201,162,74,0.5)",color:Hn,fontFamily:"'Cormorant Garamond', serif"}}),u.jsx(k.button,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:948:21",onClick:J,disabled:b===null||!g.trim()||p,whileTap:{scale:.97},className:"mt-8 w-full py-4 rounded-full text-[13px] tracking-[0.3em] uppercase disabled:opacity-40",style:{background:Ee,color:"#f3dc9a",fontFamily:"'Jost', sans-serif",boxShadow:"0 14px 32px rgba(138,28,46,0.4)"},children:p?"…":i.submit}),u.jsxs("a",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:958:21",href:Fh(n.whatsappNumber,Q),target:"_blank",rel:"noreferrer",className:"mt-3 w-full py-3.5 rounded-full text-[12px] tracking-[0.24em] uppercase flex items-center justify-center gap-2",style:{border:"1px solid rgba(30,122,79,0.5)",color:"#1e7a4f",fontFamily:"'Jost', sans-serif"},children:[u.jsx(gc,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:965:23",size:15})," ",i.rsvpWhats]})]})]})})})})]})}function lN({t:n,onGuestbook:a,messages:i,demo:r,guestName:l}){const[d,h]=w.useState(l??""),[y,p]=w.useState(""),[m,g]=w.useState([]),[x,b]=w.useState(!1),M=async()=>{!d.trim()||!y.trim()||(a&&await a(d.trim(),y.trim()),(r||!a)&&g(T=>[{id:Date.now(),guestName:d.trim(),body:y.trim()},...T]),p(""),b(!0),setTimeout(()=>b(!1),2600))},S=[...i,...m];return u.jsxs("section",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:1013:5",className:"relative px-7 py-20 overflow-hidden",style:{background:Ee},children:[u.jsx(Nn,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:1014:7",fill:En,seed:3}),u.jsx($e,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:1015:7",title:n.guestbook,script:!0,color:"#fdf6ee",gold:Ie}),u.jsxs(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:1016:7",...Xe,className:"mt-9 max-w-sm mx-auto",children:[u.jsx("input",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:1017:9",value:d,onChange:T=>h(T.target.value),placeholder:n.guestbookName,className:"w-full px-4 py-3 text-[16px] outline-none",style:{background:"#fdf6ee",border:"1px solid rgba(201,162,74,0.5)",color:Hn}}),u.jsx("textarea",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:1024:9",value:y,onChange:T=>p(T.target.value),placeholder:n.guestbookPh,rows:3,className:"mt-3 w-full px-4 py-3 text-[16px] outline-none resize-none",style:{background:"#fdf6ee",border:"1px solid rgba(201,162,74,0.5)",color:Hn}}),u.jsx(k.button,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:1032:9",onClick:M,whileTap:{scale:.97},className:"mt-4 w-full py-3.5 rounded-full text-[12px] tracking-[0.28em] uppercase",style:{background:"#fdf6ee",color:Ee,fontFamily:"'Jost', sans-serif"},children:n.guestbookSend}),x&&u.jsx("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:1040:20",className:"mt-3 text-center text-[14px]",style:{color:"#a7e0c0"},children:n.guestbookThanks})]}),S.length>0&&u.jsx("div",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:1043:9",className:"mt-9 max-w-sm mx-auto flex flex-col gap-3",children:S.slice(0,6).map(T=>u.jsxs(k.div,{"code-path":"src/components/invite/VillaRosaRenderer.tsx:1045:13",initial:{opacity:0,y:14},whileInView:{opacity:1,y:0},viewport:{once:!0},className:"px-5 py-4 text-left",style:{background:"rgba(253,246,238,0.08)",border:"1px solid rgba(201,162,74,0.4)"},children:[u.jsxs("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:1046:15",className:"text-[15px] italic",style:{color:"#fdf6ee"},children:["“",T.body,"”"]}),u.jsxs("p",{"code-path":"src/components/invite/VillaRosaRenderer.tsx:1047:15",className:"mt-1.5 text-[12px] tracking-[0.18em] uppercase",style:{color:Ie,fontFamily:"'Jost', sans-serif"},children:["— ",T.guestName]})]},T.id))})]})}const ha="#0b0908",eo="#10160f",ft="#f2e8d5",_e="#cbb896",re="#d4af6a",jt="rgba(212,175,106,0.45)",cN="#e58aa8",Ih="rgba(22,16,11,0.62)",xt={initial:{opacity:0,y:26,filter:"blur(6px)"},whileInView:{opacity:1,y:0,filter:"blur(0px)"},viewport:{once:!0,margin:"-60px"},transition:{duration:1,ease:Ot}};function Ub(n){if(!n)return"";const a=new Date(n+(n.length===10?"T12:00:00":""));return isNaN(a.getTime())?n:a.toLocaleDateString("en-GB",{weekday:"long",day:"numeric",month:"long",year:"numeric"})}function Hb(n){if(!n)return"";const[a,i]=n.split(":").map(Number);if(isNaN(a))return n;const r=a>=12?"PM":"AM";return`${a%12===0?12:a%12}:${String(i??0).padStart(2,"0")} ${r}`}function uN({density:n=34}){const a=w.useRef(null);return w.useEffect(()=>{const i=a.current;if(!i)return;const r=i.getContext("2d");if(!r)return;const l=Math.min(window.devicePixelRatio||1,2);let d=0,h=0,y=0;const p=()=>{d=i.clientWidth,h=i.clientHeight,i.width=d*l,i.height=h*l,r.setTransform(l,0,0,l,0,0)};p(),window.addEventListener("resize",p);const m=Array.from({length:n},()=>({x:Math.random(),y:Math.random(),r:.7+Math.random()*1.9,vy:.012+Math.random()*.03,sway:6+Math.random()*16,ph:Math.random()*Math.PI*2,tw:.5+Math.random()*1.6})),g=x=>{r.clearRect(0,0,d,h),r.globalCompositeOperation="lighter";for(const b of m){b.y-=b.vy/100,b.y<-.05&&(b.y=1.05,b.x=Math.random());const M=b.x*d+Math.sin(x/1600+b.ph)*b.sway,S=.14+.5*Math.abs(Math.sin(x/(900*b.tw)+b.ph)),T=r.createRadialGradient(M,b.y*h,0,M,b.y*h,b.r*4);T.addColorStop(0,`rgba(236,198,120,${S})`),T.addColorStop(1,"rgba(236,198,120,0)"),r.fillStyle=T,r.beginPath(),r.arc(M,b.y*h,b.r*4,0,Math.PI*2),r.fill()}y=requestAnimationFrame(g)};return y=requestAnimationFrame(g),()=>{cancelAnimationFrame(y),window.removeEventListener("resize",p)}},[n]),u.jsx("canvas",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:96:10",ref:a,className:"absolute inset-0 w-full h-full pointer-events-none","aria-hidden":!0})}function xs({x:n,y:a,s:i,delay:r=0,once:l=!1}){return u.jsx(k.span,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:104:5",className:"absolute pointer-events-none",style:{left:n,top:a,width:i,height:i,background:"radial-gradient(circle, rgba(255,240,200,0.95) 0%, rgba(255,220,140,0.5) 40%, transparent 70%)",clipPath:"polygon(50% 0, 62% 38%, 100% 50%, 62% 62%, 50% 100%, 38% 62%, 0 50%, 38% 38%)"},initial:{opacity:0,scale:.3},animate:l?{opacity:[0,1,0],scale:[.3,1.25,.4]}:{opacity:[.1,1,.1],scale:[.6,1.15,.6]},transition:l?{duration:1.1,delay:r,ease:"easeOut"}:{duration:1.6+r%1.4,repeat:1/0,delay:r,ease:"easeInOut"},"aria-hidden":!0})}function Ph({size:n=160,color:a="rgba(255,190,90,0.55)",className:i="",style:r={}}){return u.jsx(k.span,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:124:5",className:`absolute pointer-events-none rounded-full ${i}`,style:{width:n,height:n,background:`radial-gradient(circle, ${a} 0%, transparent 68%)`,filter:"blur(6px)",...r},animate:{opacity:[.65,1,.72,.95,.7],scale:[1,1.07,.98,1.05,1]},transition:{duration:3.4,repeat:1/0,ease:"easeInOut"},"aria-hidden":!0})}function dN({monogram:n,onTap:a,hint:i}){return u.jsxs(k.button,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:139:5",onClick:a,whileTap:{scale:.92},className:"relative rounded-full focus:outline-none",style:{width:148,height:148,WebkitTapHighlightColor:"transparent"},"aria-label":i,children:[u.jsx(k.span,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:146:7",className:"absolute -inset-7 rounded-full",style:{background:"radial-gradient(circle, rgba(255,205,110,0.5) 0%, rgba(255,190,90,0.16) 55%, transparent 75%)",filter:"blur(10px)"},animate:{scale:[1,1.22,1],opacity:[.55,.95,.55]},transition:{duration:3,repeat:1/0,ease:"easeInOut"}}),u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:152:7",className:"absolute inset-0 rounded-full",style:{background:"radial-gradient(circle at 34% 28%, #3a2c16 0%, #241a0d 55%, #17100a 100%)",border:"1.5px solid rgba(212,175,106,0.85)",boxShadow:"0 18px 44px rgba(0,0,0,0.75), inset 0 1px 2px rgba(255,230,170,0.45), inset 0 -3px 8px rgba(0,0,0,0.6)"}}),u.jsx(k.span,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:160:7",className:"absolute rounded-full",style:{inset:7,border:"1px solid rgba(212,175,106,0.5)"},animate:{rotate:360},transition:{duration:26,repeat:1/0,ease:"linear"},children:[0,60,120,180,240,300].map(r=>u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:167:11",className:"absolute left-1/2 top-1/2",style:{width:3,height:3,borderRadius:2,background:re,transform:`rotate(${r}deg) translateY(-64px)`,transformOrigin:"0 0",boxShadow:"0 0 6px rgba(255,220,150,0.9)"}},r))}),u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:179:7",className:"absolute inset-0 flex items-center justify-center",style:{fontFamily:"'Great Vibes', cursive",fontSize:n.length>3?30:40,color:re,textShadow:"0 0 18px rgba(255,215,140,0.65)"},children:n||"❦"})]})}function Fb({children:n,lit:a,width:i="min(84vw, 350px)",padBottom:r="0"}){return u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:198:5",className:"relative",style:{width:i},children:[u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:200:7",className:"absolute -inset-16 pointer-events-none",style:{background:"radial-gradient(ellipse at 50% 42%, rgba(255,200,105,0.28) 0%, transparent 65%)",filter:"blur(8px)"},initial:{opacity:0},animate:a?{opacity:1}:{},transition:{duration:1.6,delay:.35}}),u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:207:7",className:"relative overflow-hidden",style:{borderRadius:"999px 999px 26px 26px",background:"linear-gradient(172deg, rgba(34,25,15,0.82) 0%, rgba(18,13,9,0.78) 55%, rgba(24,17,11,0.82) 100%)",backdropFilter:"blur(9px)",WebkitBackdropFilter:"blur(9px)",border:`1px solid ${jt}`,boxShadow:"0 34px 80px rgba(0,0,0,0.65), inset 0 1px 0 rgba(255,225,160,0.28), inset 0 0 60px rgba(212,175,106,0.08)"},children:[u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:218:9",className:"absolute pointer-events-none",style:{inset:10,borderRadius:"999px 999px 18px 18px",border:"1px solid rgba(212,175,106,0.28)"}}),u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:219:9",style:{paddingBottom:r},children:n})]}),u.jsx("svg",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:222:7",className:"absolute inset-0 w-full h-full pointer-events-none",viewBox:"0 0 100 140",preserveAspectRatio:"none","aria-hidden":!0,children:u.jsx(k.path,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:223:9",d:"M 3 137 L 3 55 Q 3 8, 50 8 Q 97 8, 97 55 L 97 137",fill:"none",stroke:re,strokeWidth:"1.1",vectorEffect:"non-scaling-stroke",style:{filter:"drop-shadow(0 0 6px rgba(255,215,140,0.85))"},initial:{pathLength:0,opacity:0},animate:a?{pathLength:1,opacity:[0,1,1,.35]}:{},transition:{pathLength:{duration:2.1,ease:"easeInOut",delay:.15},opacity:{duration:3.4,delay:.15}}})})]})}function Zx({text:n,lit:a,baseDelay:i=0,fontSize:r}){const l=w.useMemo(()=>n.split(""),[n]);return u.jsxs("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:245:5",className:"relative inline-block",style:{maxWidth:"100%"},children:[l.map((d,h)=>u.jsx(k.span,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:247:9",className:"inline-block",style:{fontFamily:"'Great Vibes', cursive",fontSize:r,padding:"0.04em 0.17em 0.16em",margin:"-0.04em -0.17em -0.16em",background:`linear-gradient(100deg, #f6e3ae 0%, ${re} 45%, #f0d493 70%, #b8934a 100%)`,WebkitBackgroundClip:"text",backgroundClip:"text",color:"transparent",textShadow:"0 0 26px rgba(255,215,140,0.35)"},initial:{opacity:0,y:16,filter:"blur(8px)"},animate:a?{opacity:1,y:0,filter:"blur(0px)"}:{},transition:{duration:.85,ease:Ot,delay:i+h*.055},children:d===" "?" ":d},h)),u.jsx(k.span,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:271:7",className:"absolute inset-0 pointer-events-none",style:{background:"linear-gradient(105deg, transparent 30%, rgba(255,248,225,0.85) 50%, transparent 70%)",mixBlendMode:"overlay"},initial:{x:"-120%",opacity:0},animate:a?{x:"120%",opacity:[0,1,0]}:{},transition:{duration:1.4,delay:i+l.length*.055+.35,ease:"easeInOut"},"aria-hidden":!0})]})}function fN({monogram:n,hint:a,autoOpen:i,onLight:r,onOpened:l}){const[d,h]=w.useState(i),[y,p]=w.useState(!1),[m,g]=w.useState(i),x=w.useRef([]),b=()=>{d||(h(!0),r(),x.current.push(window.setTimeout(()=>p(!0),2650)),x.current.push(window.setTimeout(()=>g(!0),3350)),x.current.push(window.setTimeout(l,3300)))};return w.useEffect(()=>()=>x.current.forEach(clearTimeout),[]),m?null:u.jsxs(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:318:5",className:"fixed inset-0 z-50 overflow-hidden",initial:!1,animate:{opacity:y?0:1},transition:{duration:.7,ease:"easeInOut"},children:[u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:325:7",className:"absolute inset-0",style:{background:"radial-gradient(ellipse at 50% 46%, rgba(255,196,100,0.9) 0%, rgba(200,140,60,0.45) 40%, transparent 72%)"},initial:{opacity:0},animate:d?{opacity:[0,1,.25]}:{},transition:{duration:2.6,times:[0,.35,1],ease:"easeInOut"}}),u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:334:7",className:"absolute top-0 bottom-0 left-0 overflow-hidden",style:{width:"51.5%",boxShadow:"inset -30px 0 50px rgba(0,0,0,0.65)"},initial:!1,animate:d?{x:"-104%"}:{x:0},transition:{duration:1.9,ease:[.72,0,.28,1],delay:.35},children:u.jsx("img",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:341:9",src:"./art/midnight-door.png",alt:"",className:"w-full h-full object-cover",style:{transform:"scaleX(-1)",objectPosition:"center"}})}),u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:344:7",className:"absolute top-0 bottom-0 right-0 overflow-hidden",style:{width:"51.5%",boxShadow:"inset 30px 0 50px rgba(0,0,0,0.65)"},initial:!1,animate:d?{x:"104%"}:{x:0},transition:{duration:1.9,ease:[.72,0,.28,1],delay:.35},children:u.jsx("img",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:351:9",src:"./art/midnight-door.png",alt:"",className:"w-full h-full object-cover",style:{objectPosition:"center"}})}),u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:355:7",className:"absolute top-0 bottom-0 left-1/2 pointer-events-none",style:{width:3,x:"-50%",background:"linear-gradient(180deg, transparent 4%, rgba(255,215,140,0.95) 30%, rgba(255,225,160,1) 50%, rgba(255,215,140,0.95) 70%, transparent 96%)",boxShadow:"0 0 24px 6px rgba(255,200,105,0.75)"},animate:d?{width:90,opacity:[1,1,0]}:{opacity:[.55,1,.55]},transition:d?{width:{duration:1.5,delay:.25,ease:"easeInOut"},opacity:{duration:1.8,delay:.6}}:{duration:2.8,repeat:1/0}}),u.jsx(Ti,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:367:7",children:!d&&u.jsxs(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:369:11",className:"absolute inset-0 flex flex-col items-center justify-center gap-8",exit:{opacity:0,scale:1.15,transition:{duration:.45}},children:[u.jsx(k.p,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:373:13",className:"text-[11px] tracking-[0.5em] uppercase",style:{color:_e,fontFamily:"'Jost', sans-serif"},initial:{opacity:0,y:14},animate:{opacity:1,y:0},transition:{delay:.5,duration:1},children:"You are invited"}),u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:382:13",initial:{opacity:0,scale:.8},animate:{opacity:1,scale:1},transition:{delay:.25,duration:1.1,ease:Ot},children:u.jsx(dN,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:387:15",monogram:n,onTap:b,hint:a})}),u.jsxs(k.p,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:389:13",className:"text-[11px] tracking-[0.44em] uppercase",style:{color:re,fontFamily:"'Jost', sans-serif"},initial:{opacity:0},animate:{opacity:[.35,1,.35]},transition:{delay:.9,duration:2.6,repeat:1/0},children:["⌃ ",a]})]})})]})}function hN({data:n,t:a,dateLabel:i,lit:r}){const l=w.useRef(null),d=(n.sealText??"").trim()||`${n.groomName.charAt(0)} & ${n.brideName.charAt(0)}`,{scrollYProgress:h}=Jr({target:l,offset:["start start","end start"]}),y=St(h,[0,1],[0,70]),p=St(h,[0,1],[0,34]),m=St(h,[0,1],[0,26]),g=ac(0),x=ac(0),b=Bx(g,{stiffness:40,damping:14}),M=Bx(x,{stiffness:40,damping:14}),S=St(b,[-1,1],[8,-8]),T=St(b,[-1,1],[5,-5]),j=St(b,[-1,1],[13,-13]),O=St(b,[-1,1],[6,-6]),L=St(M,[-1,1],[4,-4]),z=E=>{const q=l.current?.getBoundingClientRect();q&&(g.set((E.clientX-q.left)/q.width*2-1),x.set((E.clientY-q.top)/q.height*2-1))},[D,X]=w.useState([]),J=E=>{const q=l.current?.getBoundingClientRect();if(!q)return;const ee=Date.now();X(oe=>[...oe,{id:ee,x:E.clientX-q.left,y:E.clientY-q.top}]),setTimeout(()=>X(oe=>oe.filter(me=>me.id!==ee)),1200)},Q=E=>({initial:{opacity:0,y:20,filter:"blur(6px)"},animate:r?{opacity:1,y:0,filter:"blur(0px)"}:{},transition:{duration:1,ease:Ot,delay:E}});return u.jsxs("section",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:463:5",ref:l,onPointerMove:z,onPointerDown:J,className:"relative min-h-screen overflow-hidden flex flex-col items-center justify-center",style:{background:`linear-gradient(178deg, #070505 0%, ${ha} 34%, #0d120c 72%, #080605 100%)`,touchAction:"pan-y"},children:[u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:471:7",className:"absolute inset-0 pointer-events-none",style:{background:"radial-gradient(ellipse at 50% 30%, rgba(255,196,100,0.13) 0%, transparent 60%)"},animate:{opacity:[.6,1,.6]},transition:{duration:7,repeat:1/0,ease:"easeInOut"}}),r&&u.jsx(uN,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:477:15",density:30}),u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:480:7",className:"absolute inset-x-0 top-0 z-[6] pointer-events-none",style:{y:p,x:T},children:[{l:"-4%",w:"60%",d:1.5,s:6.4},{r:"-4%",w:"60%",d:1.75,s:7.6}].map((E,q)=>u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:485:11",className:"absolute",style:{left:E.l,right:E.r,width:E.w,top:"-2.5%",transformOrigin:"50% 0%"},initial:{opacity:0,y:-46},animate:r?{opacity:1,y:0}:{},transition:{duration:1.5,ease:Ot,delay:E.d},children:u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:493:13",animate:{rotate:[-1,1,-1]},transition:{duration:E.s,repeat:1/0,ease:"easeInOut"},style:{transformOrigin:"50% 0%"},children:u.jsx("img",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:494:15",src:"./art/midnight-cascade.png",alt:"",className:"w-full",style:{transform:q===1?"scaleX(-1)":void 0},loading:"eager"})})},q))}),u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:501:7",className:"absolute inset-x-0 top-0 z-[7] pointer-events-none",style:{y,x:S},children:[{l:"50%",w:"34%",d:.95,s:5.8,big:!0},{l:"16%",w:"24%",d:1.25,s:6.9,big:!1},{l:"84%",w:"24%",d:1.5,s:7.4,big:!1}].map((E,q)=>u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:507:11",className:"absolute",style:{left:E.l,width:E.w,x:"-50%",transformOrigin:"50% 0%"},initial:{opacity:0,y:-30},animate:r?{opacity:1,y:0}:{},transition:{duration:1.3,ease:Ot,delay:E.d},children:u.jsxs(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:515:13",animate:{rotate:[-1.1,1.1,-1.1]},transition:{duration:E.s,repeat:1/0,ease:"easeInOut"},style:{transformOrigin:"50% 0%"},children:[u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:516:15",initial:{filter:"brightness(0.25)"},animate:r?{filter:["brightness(0.25)","brightness(1.9)","brightness(1)"]}:{},transition:{duration:1.15,delay:E.d+.25,times:[0,.4,1]},children:u.jsx("img",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:521:17",src:"./art/midnight-chandelier.png",alt:"",className:"w-full",loading:"eager"})}),u.jsx(k.span,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:524:15",className:"absolute left-1/2 top-[38%] rounded-full pointer-events-none",style:{width:E.big?190:130,height:E.big?190:130,x:"-50%",y:"-50%",background:"radial-gradient(circle, rgba(255,205,110,0.75) 0%, transparent 65%)",filter:"blur(10px)"},initial:{opacity:0,scale:.5},animate:r?{opacity:[0,.95,.45],scale:[.5,1.35,1]}:{},transition:{duration:1.5,delay:E.d+.25}}),r&&u.jsxs(u.Fragment,{children:[u.jsx(xs,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:534:19",x:"30%",y:"42%",s:14,delay:E.d+.7}),u.jsx(xs,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:535:19",x:"62%",y:"55%",s:10,delay:E.d+1.1}),u.jsx(xs,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:536:19",x:"48%",y:"70%",s:12,delay:E.d+1.5}),E.big&&u.jsx(xs,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:537:29",x:"70%",y:"34%",s:9,delay:E.d+1.9})]})]})},q))}),u.jsxs(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:546:7",className:"absolute right-[-8%] bottom-[-3%] z-[8] pointer-events-none",style:{width:"56%",x:j},initial:{opacity:0,x:60},animate:r?{opacity:1,x:0}:{},transition:{duration:1.6,ease:Ot,delay:1.9},children:[u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:554:9",className:"absolute left-[6%] right-[6%] bottom-[-2%] h-[14%] rounded-[50%] pointer-events-none",style:{background:"radial-gradient(ellipse, rgba(0,0,0,0.62) 0%, transparent 68%)",filter:"blur(7px)"}}),u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:558:9",animate:{rotate:[-.7,.7,-.7]},transition:{duration:9,repeat:1/0,ease:"easeInOut"},style:{transformOrigin:"50% 100%"},children:u.jsx("img",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:559:11",src:"./art/midnight-tree.png",alt:"",className:"w-full",style:{filter:"drop-shadow(0 0 26px rgba(229,138,168,0.22))"},loading:"eager"})})]}),u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:564:7",className:"relative z-[10] px-6",style:{y:m,x:O},children:u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:565:9",style:{y:L},children:u.jsx(Fb,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:566:11",lit:r,children:u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:567:13",className:"flex flex-col items-center text-center px-7 pt-14 pb-9",children:[u.jsx(k.span,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:568:15",...Q(2.15),style:{fontFamily:"'Great Vibes', cursive",fontSize:d.length>3?26:34,color:re,textShadow:"0 0 16px rgba(255,215,140,0.5)"},children:d}),u.jsx(k.p,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:571:15",...Q(2.4),className:"mt-4 text-[16px] leading-relaxed",style:{fontFamily:"'Amiri', serif",color:"#e3c88f"},children:a.bismillah}),u.jsx(k.p,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:574:15",...Q(2.7),className:"mt-5 text-[11px] tracking-[0.52em] uppercase",style:{color:_e,fontFamily:"'Jost', sans-serif"},children:a.weddingDay}),u.jsxs("h1",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:577:15",className:"mt-3 leading-[1.18]",children:[u.jsx(Zx,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:578:17",text:n.groomName,lit:r,baseDelay:2.95,fontSize:"clamp(2.5rem, 10.5vw, 3.4rem)"}),u.jsx(k.span,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:579:17",...Q(3.5),className:"block my-0.5",style:{fontFamily:"'Alex Brush', cursive",fontSize:"clamp(1.4rem, 5.5vw, 1.9rem)",color:cN},children:"&"}),u.jsx(Zx,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:582:17",text:n.brideName,lit:r,baseDelay:3.55,fontSize:"clamp(2.5rem, 10.5vw, 3.4rem)"})]}),u.jsx("svg",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:585:15",width:"190",height:"14",viewBox:"0 0 190 14",className:"mt-4","aria-hidden":!0,children:u.jsx(k.path,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:586:17",d:"M 6 8 C 50 2, 140 2, 184 8",fill:"none",stroke:re,strokeWidth:"1.4",strokeLinecap:"round",style:{filter:"drop-shadow(0 0 5px rgba(255,215,140,0.7))"},initial:{pathLength:0},animate:r?{pathLength:1}:{},transition:{duration:1.3,delay:4.15,ease:"easeInOut"}})}),u.jsx(k.p,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:595:15",...Q(4.35),className:"mt-3.5 text-[15px] tracking-[0.24em]",style:{color:ft,fontFamily:"'Cormorant Garamond', serif",fontWeight:600},children:i})]})})})}),u.jsxs(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:605:7",className:"absolute inset-x-[-8%] bottom-[-2%] z-[15] pointer-events-none flex justify-between",initial:{opacity:0,y:50},animate:r?{opacity:1,y:0}:{},transition:{duration:1.5,ease:Ot,delay:2.05},children:[u.jsx("img",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:611:9",src:"./art/midnight-bed.png",alt:"",className:"w-[76%] shrink-0",loading:"eager"}),u.jsx("img",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:612:9",src:"./art/midnight-bed.png",alt:"",className:"w-[76%] shrink-0",style:{transform:"scaleX(-1)"},loading:"eager"})]}),[{l:"3%",d:2.3},{r:"3%",d:2.45}].map((E,q)=>u.jsxs(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:617:9",className:"absolute bottom-[2.5%] z-[16] pointer-events-none",style:{left:E.l,right:E.r,width:"19%"},initial:{opacity:0,y:30},animate:r?{opacity:1,y:0}:{},transition:{duration:1.2,ease:Ot,delay:E.d},children:[u.jsx(Ph,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:625:11",size:120,style:{left:"50%",top:"16%",transform:"translateX(-50%)"}}),u.jsx("img",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:626:11",src:"./art/midnight-candles.png",alt:"",className:"relative w-full",style:{transform:q===1?"scaleX(-1)":void 0},loading:"eager"})]},q)),r&&u.jsx(Wr,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:630:15",density:10}),D.map(E=>u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:634:9",className:"absolute z-[25] pointer-events-none",style:{left:E.x,top:E.y},children:[0,45,90,135,180,225,270,315].map(q=>u.jsx(k.span,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:636:13",className:"absolute rounded-full",style:{width:4,height:4,background:"#ffe9b8",boxShadow:"0 0 8px rgba(255,215,140,0.95)"},initial:{x:0,y:0,opacity:1},animate:{x:Math.cos(q*Math.PI/180)*54,y:Math.sin(q*Math.PI/180)*54,opacity:0},transition:{duration:.85,ease:"easeOut"}},q))},E.id)),u.jsxs(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:649:7",className:"absolute bottom-5 left-1/2 z-[22] flex flex-col items-center gap-1",style:{x:"-50%"},initial:{opacity:0},animate:r?{opacity:1}:{},transition:{delay:4.9,duration:.9},children:[u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:656:9",className:"text-[10px] tracking-[0.42em] uppercase px-4 py-1.5 rounded-full",style:{color:_e,fontFamily:"'Jost', sans-serif",background:"rgba(7,5,5,0.55)",backdropFilter:"blur(6px)",WebkitBackdropFilter:"blur(6px)",border:"1px solid rgba(212,175,106,0.25)"},children:a.scrollDown}),u.jsx(k.span,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:662:9",animate:{y:[0,7,0]},transition:{duration:1.8,repeat:1/0,ease:"easeInOut"},style:{color:re},children:u.jsx(Lh,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:663:11",size:18})})]})]})}function zn({children:n,bg:a=ha,glow:i=!0,bedTop:r=!1}){return u.jsxs("section",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:675:5",className:`relative px-6 ${r?"pt-36 pb-20":"py-20"} overflow-hidden`,style:{background:a},children:[r&&u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:679:9",className:"absolute inset-x-[-8%] z-[5] pointer-events-none flex justify-between",style:{top:-12,transform:"translateY(-50%)"},"aria-hidden":!0,children:[u.jsx("img",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:680:11",src:"./art/midnight-bed.png",alt:"",className:"w-[76%] shrink-0",style:{transform:"scaleX(-1)"},loading:"lazy"}),u.jsx("img",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:681:11",src:"./art/midnight-bed.png",alt:"",className:"w-[76%] shrink-0",loading:"lazy"})]}),i&&u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:685:9",className:"absolute inset-0 pointer-events-none",style:{background:"radial-gradient(ellipse at 50% 0%, rgba(212,175,106,0.07) 0%, transparent 55%)"}}),n]})}function to({children:n,arch:a=!1,delay:i=0,className:r=""}){return u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:694:5",...xt,transition:{...xt.transition,delay:i},className:`relative ${r}`,style:{borderRadius:a?"54px 54px 18px 18px":18,background:Ih,backdropFilter:"blur(8px)",WebkitBackdropFilter:"blur(8px)",border:`1px solid ${jt}`,boxShadow:"0 22px 50px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,225,160,0.16)"},children:n})}function pN({data:n,t:a,lang:i}){const r=i==="sw"&&n.storySw||n.storyEn,l=i==="sw"&&n.quoteSw||n.quoteEn;return u.jsxs(zn,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:719:5",bg:ha,bedTop:!0,children:[(n.groomFamily||n.brideFamily)&&u.jsxs(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:721:9",...xt,className:"relative max-w-md mx-auto text-center",children:[u.jsxs("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:722:11",className:"text-[15px] leading-relaxed",style:{color:_e,letterSpacing:"0.05em"},children:[a.familyPre," ",u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:723:27",style:{color:ft,fontWeight:700},children:n.groomFamily})," ",a.familyAnd," ",u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:724:13",style:{color:ft,fontWeight:700},children:n.brideFamily})]}),u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:726:11",className:"mt-2 text-[16px] italic leading-relaxed",style:{color:ft},children:a.familyPost}),u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:727:11",className:"mt-6 flex justify-center",children:u.jsx(Bt,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:727:53",color:re,width:170})})]}),u.jsxs(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:730:7",...xt,transition:{...xt.transition,delay:.12},className:"relative mt-10 max-w-md mx-auto text-center",children:[u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:731:9",className:"text-2xl",style:{color:re,fontFamily:"'Great Vibes', cursive"},children:a.dearFriends}),u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:732:9",className:"mt-4 text-[17px] leading-relaxed",style:{color:ft},children:r}),u.jsxs("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:733:9",className:"mt-6 text-[15px] italic leading-relaxed",style:{color:_e},children:["“",l,"”"]}),u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:734:9",className:"mt-8 flex flex-col items-center gap-2",children:[u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:735:11",className:"text-4xl leading-tight",style:{fontFamily:"'Great Vibes', cursive",color:re,textShadow:"0 0 22px rgba(255,215,140,0.4)"},children:a.twoSouls}),u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:736:11",className:"text-lg tracking-[0.14em] uppercase",style:{color:_e,fontFamily:"'Cormorant Garamond', serif"},children:a.oneDestiny}),u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:737:11",className:"text-base mt-1 italic",style:{color:_e},children:a.lifetime})]})]})]})}function mN(n,a){const i=w.useMemo(()=>{const h=new Date(`${n}T${a||"00:00"}:00`);return isNaN(h.getTime())?null:h.getTime()},[n,a]),[r,l]=w.useState(Date.now());if(w.useEffect(()=>{const h=setInterval(()=>l(Date.now()),1e3);return()=>clearInterval(h)},[]),!i)return null;const d=Math.max(0,i-r);return{d:Math.floor(d/864e5),h:Math.floor(d/36e5%24),m:Math.floor(d/6e4%60),s:Math.floor(d/1e3%60)}}function gN({events:n,t:a}){const i=n[0],r=mN(i?.date??"",i?.time??"");if(!i||!r)return null;const l=[{v:r.d,l:a.days},{v:r.h,l:a.hours},{v:r.m,l:a.minutes},{v:r.s,l:a.seconds}];return u.jsxs(zn,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:778:5",bg:eo,children:[u.jsx($e,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:779:7",title:a.beginsIn,script:!0,color:re,gold:re}),u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:780:7",className:"relative mt-10 flex justify-center gap-3 sm:gap-4",children:l.map((d,h)=>u.jsxs(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:782:11",...xt,transition:{...xt.transition,delay:h*.1},className:"relative flex flex-col items-center justify-center overflow-hidden",style:{width:"clamp(64px, 19vw, 88px)",height:"clamp(98px, 28vw, 126px)",borderRadius:"999px 999px 16px 16px",background:Ih,border:`1px solid ${jt}`,boxShadow:"0 18px 40px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,225,160,0.18)"},children:[u.jsx(Ph,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:796:13",size:84,color:"rgba(255,190,90,0.4)",style:{left:"50%",top:"-18%",transform:"translateX(-50%)"}}),u.jsx(Ti,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:797:13",mode:"popLayout",children:u.jsx(k.span,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:798:15",initial:{y:12,opacity:0,filter:"blur(4px)"},animate:{y:0,opacity:1,filter:"blur(0px)"},exit:{y:-12,opacity:0,filter:"blur(4px)"},transition:{duration:.35,ease:Ot},className:"relative tabular-nums",style:{fontFamily:"'Cormorant Garamond', serif",fontWeight:700,fontSize:"clamp(1.7rem, 7vw, 2.3rem)",color:ft,textShadow:"0 0 18px rgba(255,215,140,0.35)"},children:String(d.v).padStart(2,"0")},d.v)}),u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:810:13",className:"relative mt-1 text-[9px] tracking-[0.24em] uppercase",style:{color:re,fontFamily:"'Jost', sans-serif"},children:d.l})]},d.l))})]})}function yN({events:n,t:a,lang:i}){return n.length?u.jsxs(zn,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:824:5",bg:ha,children:[u.jsx($e,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:825:7",title:a.schedule,script:!0,color:re,gold:re}),u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:826:7",className:"relative mt-12 max-w-md mx-auto",children:[u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:827:9",className:"absolute left-1/2 top-0 bottom-0 w-px",style:{background:`linear-gradient(180deg, transparent, ${re} 12%, ${re} 88%, transparent)`,boxShadow:"0 0 12px rgba(212,175,106,0.6)"}}),n.map((r,l)=>{const d=l%2===0;return u.jsxs(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:834:13",initial:{opacity:0,y:30,x:d?-20:20,filter:"blur(5px)"},whileInView:{opacity:1,y:0,x:0,filter:"blur(0px)"},viewport:{once:!0,margin:"-40px"},transition:{duration:.9,ease:Ot},className:"relative mb-8 flex",style:{justifyContent:d?"flex-start":"flex-end"},children:[u.jsx(k.span,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:843:15",className:"absolute left-1/2 top-7 -translate-x-1/2 w-3 h-3 rounded-full",style:{background:"#ffe9b8",boxShadow:"0 0 0 4px rgba(212,175,106,0.25), 0 0 14px rgba(255,215,140,0.9)"},animate:{scale:[1,1.25,1]},transition:{duration:2.6,repeat:1/0,delay:l*.4}}),u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:849:15",style:{width:"46%"},children:u.jsxs(to,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:850:15",arch:!0,className:"px-5 py-5 text-center",children:[u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:851:17",className:"text-[11px] tracking-[0.26em] uppercase",style:{color:re,fontFamily:"'Jost', sans-serif"},children:Hb(r.time)}),u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:854:17",className:"mt-1.5 text-lg leading-snug",style:{color:ft,fontFamily:"'Cormorant Garamond', serif",fontWeight:700},children:i==="sw"&&r.nameSw||r.name}),r.venue&&u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:857:30",className:"mt-1 text-[13px] italic",style:{color:_e},children:r.venue}),r.dressCode&&u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:859:19",className:"mt-2 inline-block px-3 py-1 rounded-full text-[10px] tracking-[0.18em] uppercase",style:{border:`1px solid ${jt}`,color:ft,fontFamily:"'Jost', sans-serif"},children:r.dressCode}),r.notes&&u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:863:30",className:"mt-2 text-[12px]",style:{color:_e},children:r.notes})]})})]},l)})]})]}):null}function xN({events:n,t:a}){const i=n[0];return i?u.jsxs(zn,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:881:5",bg:eo,children:[u.jsx($e,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:882:7",title:a.location,script:!0,color:re,gold:re}),u.jsxs(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:883:7",...xt,className:"mt-10 max-w-md mx-auto text-center",children:[u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:885:9",className:"relative mx-auto",style:{padding:10,borderRadius:14,border:`1px solid ${jt}`,background:"rgba(20,14,9,0.7)",boxShadow:"0 26px 60px rgba(0,0,0,0.6), inset 0 0 0 1px rgba(255,225,160,0.12)"},children:[u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:886:11",className:"absolute -top-5 left-1/2 -translate-x-1/2 px-5 py-1 rounded-full",style:{background:"#17110b",border:`1px solid ${jt}`},children:u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:887:13",className:"text-[10px] tracking-[0.34em] uppercase",style:{color:re,fontFamily:"'Jost', sans-serif"},children:"The stage awaits"})}),u.jsx(k.img,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:889:11",src:"./art/midnight-arch.png",alt:"The wedding stage",className:"w-full rounded-lg",loading:"lazy",initial:{scale:1.06},whileInView:{scale:1},viewport:{once:!0},transition:{duration:2.2,ease:Ot}})]}),u.jsx("h3",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:900:9",className:"mt-8 text-2xl",style:{color:ft,fontFamily:"'Cormorant Garamond', serif",fontWeight:700},children:i.venue}),u.jsxs("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:901:9",className:"mt-1 text-[15px]",style:{color:_e},children:[Ub(i.date)," · ",Hb(i.time)]}),u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:902:9",className:"mt-6 overflow-hidden",style:{borderRadius:14,border:`1px solid ${jt}`,boxShadow:"0 18px 44px rgba(0,0,0,0.5)"},children:u.jsx("iframe",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:903:11",title:"map",src:`https://www.google.com/maps?q=${encodeURIComponent(i.venue??"")}&output=embed&hl=en`,className:"w-full h-[230px] block",loading:"lazy"})}),u.jsxs(k.a,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:910:9",href:i.mapsUrl||`https://maps.google.com/?q=${encodeURIComponent(i.venue??"")}`,target:"_blank",rel:"noreferrer",whileTap:{scale:.95},className:"mt-6 inline-flex items-center gap-2 px-8 py-3.5 rounded-full text-[12px] tracking-[0.26em] uppercase",style:{background:`linear-gradient(120deg, #e8cd8f 0%, ${re} 45%, #b8934a 100%)`,color:"#241a0d",fontFamily:"'Jost', sans-serif",fontWeight:600,boxShadow:"0 14px 34px rgba(212,175,106,0.35)"},children:[u.jsx(_h,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:921:11",size:14})," ",a.openInMaps]})]})]}):null}function ic({title:n,text:a,delay:i=0}){return u.jsxs(to,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:933:5",arch:!0,delay:i,className:"px-6 pt-8 pb-7 text-center",children:[u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:934:7",className:"text-lg",style:{color:ft,fontFamily:"'Cormorant Garamond', serif",fontWeight:700},children:n}),u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:935:7",className:"mt-2 flex justify-center",children:u.jsx(Bt,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:935:49",color:re,width:120})}),u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:936:7",className:"mt-3 text-[15px] leading-relaxed",style:{color:_e},children:a})]})}function vN({t:n}){return u.jsxs(zn,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:943:5",bg:ha,children:[u.jsx($e,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:944:7",title:n.dressTitle,script:!0,color:re,gold:re}),u.jsx(k.p,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:945:7",...xt,className:"relative mt-7 max-w-sm mx-auto text-center text-[16px] leading-relaxed",style:{color:ft},children:n.dressText}),u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:948:7",className:"relative mt-9 max-w-md mx-auto grid gap-4 sm:grid-cols-2",children:[u.jsx(ic,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:949:9",title:"Gentlemen",text:n.dressGents}),u.jsx(ic,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:950:9",title:"Ladies",text:n.dressLadies,delay:.1})]})]})}function bN({t:n}){return u.jsxs(zn,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:958:5",bg:eo,children:[u.jsx($e,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:959:7",title:n.detailsTitle,script:!0,color:re,gold:re}),u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:960:7",className:"relative mt-9 max-w-md mx-auto grid gap-4",children:[u.jsx(ic,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:961:9",title:n.transportTitle,text:n.transportText}),u.jsx(ic,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:962:9",title:n.stayTitle,text:n.stayText,delay:.1})]})]})}function RN({g:n,t:a}){const[i,r]=w.useState(!1),l=async()=>{try{await navigator.clipboard.writeText(n.accountNumber)}catch{}r(!0),setTimeout(()=>r(!1),1800)};return u.jsxs(to,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:976:5",className:"flex items-center justify-between gap-4 px-6 py-5",children:[u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:977:7",className:"text-left",children:[u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:978:9",className:"text-[11px] tracking-[0.24em] uppercase",style:{color:re,fontFamily:"'Jost', sans-serif"},children:n.label}),u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:979:9",className:"text-[15px]",style:{color:ft,fontWeight:600},children:n.accountName||n.provider}),u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:980:9",className:"text-[14px] tabular-nums",style:{color:_e},children:n.accountNumber})]}),u.jsx(k.button,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:982:7",onClick:l,whileTap:{scale:.9},className:"shrink-0 w-11 h-11 rounded-full flex items-center justify-center",style:{border:`1px solid ${jt}`,color:i?"#8fd6a4":re,background:"rgba(20,14,9,0.7)"},"aria-label":a.copy,children:i?u.jsx(Ur,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:989:19",size:16}):u.jsx(Gh,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:989:41",size:15})})]})}function wN({data:n,t:a}){return n.gifts?.length?u.jsxs(zn,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:998:5",bg:eo,children:[u.jsx($e,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:999:7",title:a.giftTitle,script:!0,color:re,gold:re}),u.jsx(k.p,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1000:7",...xt,className:"relative mt-6 text-center text-[16px] italic",style:{color:_e},children:a.noBoxed}),u.jsx(k.p,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1001:7",...xt,className:"relative mt-2 text-center text-[14px] max-w-sm mx-auto",style:{color:_e},children:a.giftsNote}),u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1002:7",className:"relative mt-8 max-w-sm mx-auto flex flex-col gap-4",children:n.gifts.map((i,r)=>u.jsx(RN,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1003:35",g:i,t:a},r))})]}):null}function SN({data:n,t:a}){return n.contacts?.length?u.jsxs(zn,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1012:5",bg:eo,children:[u.jsx($e,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1013:7",title:a.contactsTitle,script:!0,color:re,gold:re}),u.jsx(k.p,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1014:7",...xt,className:"relative mt-4 text-center text-[15px]",style:{color:_e},children:a.contactsSub}),u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1015:7",className:"relative mt-7 max-w-sm mx-auto flex flex-col gap-3",children:n.contacts.map((i,r)=>u.jsxs(to,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1017:11",delay:r*.08,className:"flex items-center justify-between gap-4 px-6 py-4",children:[u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1018:13",className:"text-left",children:[u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1019:15",className:"text-[11px] tracking-[0.22em] uppercase",style:{color:re,fontFamily:"'Jost', sans-serif"},children:i.label}),u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1020:15",className:"text-lg",style:{color:ft,fontWeight:600},children:i.name}),u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1021:15",className:"text-[14px] tabular-nums",style:{color:_e},children:i.phone})]}),u.jsx(k.a,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1023:13",href:`tel:${i.phone.replace(/\s/g,"")}`,whileTap:{scale:.88},className:"w-11 h-11 rounded-full flex items-center justify-center shrink-0",style:{background:`linear-gradient(130deg, #e8cd8f, ${re} 60%, #b8934a)`,color:"#241a0d",boxShadow:"0 10px 24px rgba(212,175,106,0.35)"},"aria-label":a.callNow,children:u.jsx(bT,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1030:15",size:16})})]},r))})]}):null}function jN({data:n,guest:a,t:i,onRsvp:r}){const[l,d]=w.useState(!1),[h,y]=w.useState(!1),[p,m]=w.useState(!1),[g,x]=w.useState(a?.name??""),[b,M]=w.useState(a?.rsvpStatus==="attending"?!0:a?.rsvpStatus==="declined"?!1:null),[S,T]=w.useState(1+(a?.companions??0)),[j,O]=w.useState(""),[L,z]=w.useState(""),[D,X]=w.useState(a?.dietary??""),J=async()=>{if(b===null||!g.trim())return;m(!0);const q=[D,j&&`Song: ${j}`,L&&`Children: ${L}`].filter(Boolean).join(" · ");try{await r?.(b,S-1,q)}finally{m(!1),y(!0)}},Q=`Hello! RSVP for ${n.groomName} & ${n.brideName}'s wedding — ${g||"Guest"}: ${b?"attending":"regrets"}.`,E={background:"rgba(255,244,220,0.07)",border:`1px solid ${jt}`,color:ft,fontFamily:"'Cormorant Garamond', serif"};return u.jsxs(zn,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1077:5",bg:eo,children:[u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1078:7",className:"text-center",children:[u.jsx($e,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1079:9",title:i.confirmTitle,script:!0,color:re,gold:re}),u.jsx(k.p,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1080:9",...xt,className:"relative mt-4 max-w-xs mx-auto text-[15px]",style:{color:_e},children:i.confirmSub}),a?.rsvpStatus&&a.rsvpStatus!=="pending"?u.jsx(k.p,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1082:11",...xt,className:"relative mt-7 inline-block px-6 py-3 rounded-full text-[12px] tracking-[0.24em] uppercase",style:{border:`1px solid ${jt}`,color:re,fontFamily:"'Jost', sans-serif",background:Ih},children:a.rsvpStatus==="attending"?i.attendingBadge:i.declinedBadge}):null,u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1087:9",...xt,className:"relative mt-9 flex justify-center",children:u.jsxs(k.button,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1088:11",onClick:()=>d(!0),whileTap:{scale:.95},whileHover:{scale:1.04},className:"relative px-10 py-4 rounded-full text-[12px] tracking-[0.32em] uppercase focus:outline-none",style:{background:`linear-gradient(120deg, #e8cd8f 0%, ${re} 45%, #b8934a 100%)`,color:"#241a0d",fontFamily:"'Jost', sans-serif",fontWeight:600,boxShadow:"0 16px 40px rgba(212,175,106,0.35)",WebkitTapHighlightColor:"transparent"},children:[u.jsx(k.span,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1100:13",className:"absolute -inset-3 rounded-full pointer-events-none",style:{border:`1px solid ${jt}`},animate:{scale:[1,1.12,1],opacity:[.7,.15,.7]},transition:{duration:2.6,repeat:1/0,ease:"easeInOut"}}),i.clickToOpen]})})]}),u.jsx(Ti,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1111:7",children:l&&u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1113:11",className:"fixed inset-0 z-[80] overflow-y-auto",style:{background:"rgba(5,4,3,0.72)",backdropFilter:"blur(9px)"},initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},onClick:()=>d(!1),children:u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1119:13",className:"relative min-h-full flex items-start justify-center py-8 px-4",initial:{y:80,opacity:0,scale:.95},animate:{y:0,opacity:1,scale:1},exit:{y:80,opacity:0,scale:.95},transition:{type:"spring",stiffness:190,damping:24},onClick:q=>q.stopPropagation(),children:u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1127:15",className:"relative w-full max-w-md px-7 pb-9 pt-14 text-left",style:{borderRadius:"150px 150px 24px 24px",background:"linear-gradient(175deg, rgba(30,22,14,0.97) 0%, rgba(14,10,7,0.98) 100%)",border:`1px solid ${jt}`,boxShadow:"0 40px 90px rgba(0,0,0,0.8), inset 0 1px 0 rgba(255,225,160,0.2)"},children:[u.jsx(Ph,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1136:17",size:150,color:"rgba(255,190,90,0.22)",style:{left:"50%",top:"-6%",transform:"translateX(-50%)"}}),u.jsx("button",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1137:17",onClick:()=>d(!1),className:"absolute top-5 right-5 z-10 w-9 h-9 flex items-center justify-center rounded-full",style:{border:`1px solid ${jt}`,color:re,background:"rgba(20,14,9,0.85)"},"aria-label":"close",children:u.jsx(Bh,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1143:19",size:16})}),h?u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1213:19",className:"relative py-14 text-center",children:[u.jsx(xs,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1214:21",x:"30%",y:"20%",s:16,once:!0}),u.jsx(xs,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1215:21",x:"66%",y:"30%",s:12,once:!0,delay:.2}),u.jsx(xs,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1216:21",x:"50%",y:"60%",s:14,once:!0,delay:.35}),u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1217:21",className:"text-3xl leading-snug",style:{fontFamily:"'Great Vibes', cursive",color:re,textShadow:"0 0 24px rgba(255,215,140,0.5)"},children:i.rsvpDone}),u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1218:21",className:"mt-5 flex justify-center",children:u.jsx(Bt,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1218:63",color:re,width:170})})]}):u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1147:19",className:"relative",children:[u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1148:21",className:"text-center text-[12px] tracking-[0.2em] uppercase",style:{color:re,fontFamily:"'Jost', sans-serif"},children:i.rsvpBefore}),u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1149:21",className:"mt-2 flex justify-center",children:u.jsx(Bt,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1149:63",color:re,width:170})}),u.jsx("label",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1151:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:_e,fontFamily:"'Jost', sans-serif"},children:i.yourName}),u.jsx("input",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1152:21",value:g,onChange:q=>x(q.target.value),className:"mt-2 w-full px-4 py-3 text-[16px] outline-none rounded-xl",style:E}),u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1154:21",className:"mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:_e,fontFamily:"'Jost', sans-serif"},children:i.attendQ}),u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1155:21",className:"mt-3 flex flex-col gap-2.5",children:[{v:!0,label:i.accept},{v:!1,label:i.decline}].map(q=>u.jsxs("button",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1157:25",onClick:()=>M(q.v),className:"flex items-center gap-3 px-4 py-3 text-left rounded-xl transition-all",style:{border:`1px solid ${b===q.v?re:jt}`,background:b===q.v?"rgba(212,175,106,0.14)":"rgba(255,244,220,0.05)",boxShadow:b===q.v?"0 0 20px rgba(212,175,106,0.25)":void 0},children:[u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1167:27",className:"w-4 h-4 rounded-full flex items-center justify-center shrink-0",style:{border:`1.5px solid ${b===q.v?re:_e}`},children:b===q.v&&u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1168:51",className:"w-2 h-2 rounded-full",style:{background:re,boxShadow:"0 0 8px rgba(255,215,140,0.9)"}})}),u.jsx("span",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1170:27",className:"text-[16px]",style:{color:ft},children:q.label})]},String(q.v)))}),u.jsx("label",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1175:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:_e,fontFamily:"'Jost', sans-serif"},children:i.guestsAttending}),u.jsx("select",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1176:21",value:S,onChange:q=>T(Number(q.target.value)),className:"mt-2 w-full px-4 py-3 text-[16px] outline-none rounded-xl",style:{...E,background:"#1d150d"},children:Array.from({length:Math.max(5,(a?.maxCompanions??4)+1)},(q,ee)=>ee+1).map(q=>u.jsx("option",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1177:121",value:q,children:q},q))}),u.jsx("label",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1180:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:_e,fontFamily:"'Jost', sans-serif"},children:i.songLabel}),u.jsx("input",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1181:21",value:j,onChange:q=>O(q.target.value),className:"mt-2 w-full px-4 py-3 text-[16px] outline-none rounded-xl",style:E}),u.jsx("label",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1183:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:_e,fontFamily:"'Jost', sans-serif"},children:i.childrenLabel}),u.jsx("textarea",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1184:21",value:L,onChange:q=>z(q.target.value),rows:2,className:"mt-2 w-full px-4 py-3 text-[16px] outline-none resize-none rounded-xl",style:E}),u.jsx("label",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1186:21",className:"block mt-6 text-[12px] tracking-[0.22em] uppercase",style:{color:_e,fontFamily:"'Jost', sans-serif"},children:i.dietary}),u.jsx("input",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1187:21",value:D,onChange:q=>X(q.target.value),className:"mt-2 w-full px-4 py-3 text-[16px] outline-none rounded-xl",style:E}),u.jsx(k.button,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1189:21",onClick:J,disabled:b===null||!g.trim()||p,whileTap:{scale:.97},className:"mt-8 w-full py-4 rounded-full text-[13px] tracking-[0.3em] uppercase disabled:opacity-40",style:{background:`linear-gradient(120deg, #e8cd8f 0%, ${re} 45%, #b8934a 100%)`,color:"#241a0d",fontFamily:"'Jost', sans-serif",fontWeight:600,boxShadow:"0 16px 36px rgba(212,175,106,0.35)"},children:p?"…":i.submit}),u.jsxs("a",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1203:21",href:Fh(n.whatsappNumber,Q),target:"_blank",rel:"noreferrer",className:"mt-3 w-full py-3.5 rounded-full text-[12px] tracking-[0.24em] uppercase flex items-center justify-center gap-2",style:{border:"1px solid rgba(120,200,150,0.45)",color:"#8fd6a4",fontFamily:"'Jost', sans-serif"},children:[u.jsx(gc,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1209:23",size:15})," ",i.rsvpWhats]})]})]})})})})]})}function MN({t:n,onGuestbook:a,messages:i,demo:r,guestName:l}){const[d,h]=w.useState(l??""),[y,p]=w.useState(""),[m,g]=w.useState([]),[x,b]=w.useState(!1),M=async()=>{!d.trim()||!y.trim()||(a&&await a(d.trim(),y.trim()),(r||!a)&&g(j=>[{id:Date.now(),guestName:d.trim(),body:y.trim()},...j]),p(""),b(!0),setTimeout(()=>b(!1),2600))},S=[...i,...m],T={background:"rgba(255,244,220,0.07)",border:`1px solid ${jt}`,color:ft};return u.jsxs(zn,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1259:5",bg:eo,children:[u.jsx($e,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1260:7",title:n.guestbook,script:!0,color:re,gold:re}),u.jsxs(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1261:7",...xt,className:"relative mt-9 max-w-sm mx-auto",children:[u.jsx("input",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1262:9",value:d,onChange:j=>h(j.target.value),placeholder:n.guestbookName,className:"w-full px-4 py-3 text-[16px] outline-none rounded-xl placeholder:text-[#8a7a5e]",style:T}),u.jsx("textarea",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1263:9",value:y,onChange:j=>p(j.target.value),placeholder:n.guestbookPh,rows:3,className:"mt-3 w-full px-4 py-3 text-[16px] outline-none resize-none rounded-xl placeholder:text-[#8a7a5e]",style:T}),u.jsx(k.button,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1264:9",onClick:M,whileTap:{scale:.97},className:"mt-4 w-full py-3.5 rounded-full text-[12px] tracking-[0.28em] uppercase",style:{background:`linear-gradient(120deg, #e8cd8f 0%, ${re} 45%, #b8934a 100%)`,color:"#241a0d",fontFamily:"'Jost', sans-serif",fontWeight:600},children:n.guestbookSend}),x&&u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1272:20",className:"mt-3 text-center text-[14px]",style:{color:"#8fd6a4"},children:n.guestbookThanks})]}),S.length>0&&u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1275:9",className:"relative mt-9 max-w-sm mx-auto flex flex-col gap-3",children:S.slice(0,6).map(j=>u.jsxs(to,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1277:13",className:"px-5 py-4 text-left",children:[u.jsxs("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1278:15",className:"text-[15px] italic",style:{color:ft},children:["“",j.body,"”"]}),u.jsxs("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1279:15",className:"mt-1.5 text-[12px] tracking-[0.18em] uppercase",style:{color:re,fontFamily:"'Jost', sans-serif"},children:["— ",j.guestName]})]},j.id))})]})}function TN({data:n,guest:a,demo:i=!1,autoOpen:r=!1,onRsvp:l,onGuestbook:d,guestbookMessages:h=[],inviteUrl:y}){const[p,m]=w.useState(n.language??"en"),g=Hh[p],[x,b]=w.useState(r),[M,S]=w.useState(r),T=n.events[0],j=T?Ub(T.date):"",O=(n.sealText??"").trim()||`${n.groomName.charAt(0)} & ${n.brideName.charAt(0)}`;return w.useEffect(()=>{if(M){document.body.style.overflow="";return}const L=document.body.style.overflow;return document.body.style.overflow="hidden",()=>{document.body.style.overflow=L}},[M]),u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1327:5",className:"relative min-h-screen",style:{background:ha,color:ft,fontFamily:"'Cormorant Garamond', serif"},children:[u.jsx(fN,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1328:7",monogram:O,hint:p==="sw"?"Gusa kuingia":"Tap to enter",autoOpen:r,onLight:()=>b(!0),onOpened:()=>S(!0)}),M&&u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1338:9",className:"fixed top-4 right-4 z-40 flex rounded-full overflow-hidden text-[11px] tracking-widest",style:{border:`1px solid ${jt}`,background:"rgba(14,10,7,0.8)",backdropFilter:"blur(8px)",fontFamily:"'Jost', sans-serif"},initial:{opacity:0,y:-12},animate:{opacity:1,y:0},transition:{delay:.4},children:["en","sw"].map(L=>u.jsx("button",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1346:13",onClick:()=>m(L),className:"px-3 py-1.5 uppercase transition-colors",style:{background:p===L?re:"transparent",color:p===L?"#241a0d":_e},children:L},L))}),M&&a&&u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1358:9",className:"fixed top-4 left-4 z-40 px-3 py-1.5 rounded-full text-[10px] tracking-[0.2em] uppercase",style:{border:`1px solid ${jt}`,background:"rgba(14,10,7,0.8)",backdropFilter:"blur(8px)",color:_e,fontFamily:"'Jost', sans-serif"},initial:{opacity:0,y:-12},animate:{opacity:1,y:0},transition:{delay:.4},children:a.name}),u.jsx(hN,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1369:7",data:n,t:g,dateLabel:j,lit:x}),u.jsx(pN,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1370:7",data:n,t:g,lang:p}),u.jsx(gN,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1371:7",events:n.events,t:g}),u.jsx(yN,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1372:7",events:n.events,t:g,lang:p}),u.jsx(xN,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1373:7",events:n.events,t:g}),u.jsx(vN,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1374:7",t:g}),u.jsx(jN,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1378:7",data:n,guest:a,t:g,onRsvp:l}),a&&y&&u.jsx(zn,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1383:9",bg:ha,children:u.jsx(k.div,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1384:11",...xt,className:"max-w-xs mx-auto",children:u.jsx(Fb,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1385:13",lit:!0,padBottom:"2rem",children:u.jsxs("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1386:15",className:"px-8 pt-10 text-center",children:[u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1387:17",className:"text-[11px] tracking-[0.34em] uppercase",style:{color:re,fontFamily:"'Jost', sans-serif"},children:g.yourCode}),u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1388:17",className:"mt-4 flex justify-center p-3 rounded-2xl",style:{background:"#f2e8d5",border:`1px solid ${jt}`},children:u.jsx(yc,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1389:19",value:`${y}?code=${a.code}`,size:140,fgColor:"#241a0d",bgColor:"#f2e8d5",level:"M"})}),u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1391:17",className:"mt-4 text-2xl tracking-[0.3em]",style:{color:ft,fontWeight:700},children:a.code}),u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1392:17",className:"mt-1 text-[13px]",style:{color:_e},children:g.scanHint}),a.checkedIn&&u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1393:37",className:"mt-3 text-[13px]",style:{color:"#8fd6a4"},children:g.checkedInBadge})]})})})}),u.jsxs("footer",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1401:7",className:"relative pt-20 pb-12 px-7 text-center overflow-hidden",style:{background:"#080605"},children:[u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1402:9",className:"absolute inset-0 pointer-events-none",style:{background:"radial-gradient(ellipse at 50% 100%, rgba(212,175,106,0.1) 0%, transparent 55%)"}}),u.jsx(k.p,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1403:9",...xt,className:"relative mt-2 text-4xl",style:{fontFamily:"'Great Vibes', cursive",color:re,textShadow:"0 0 26px rgba(255,215,140,0.4)"},children:g.hopeToSee}),u.jsxs(k.p,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1406:9",...xt,className:"relative mt-3 text-3xl",style:{fontFamily:"'Great Vibes', cursive",color:ft},children:[u.jsx("span",{style:{display:"inline-block"},children:n.groomName})," & ",u.jsx("span",{style:{display:"inline-block"},children:n.brideName})]}),u.jsx("div",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1409:9",className:"relative mt-6 flex justify-center",children:u.jsx(Bt,{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1409:60",color:re,width:180})}),u.jsx("p",{"code-path":"src/components/invite/MidnightGardenRenderer.tsx:1410:9",className:"relative mt-6 text-[11px] tracking-[0.3em] uppercase",style:{color:_e,fontFamily:"'Jost', sans-serif"},children:g.footer})]})]})}function RNp(n){const f=w.useRef(null),g=()=>f.current&&f.current.contentWindow,ORIGIN=window.location.origin&&window.location.origin!=="null"?window.location.origin:"*";w.useEffect(()=>{function h(e){if(e.origin!==window.location.origin||e.source!==g())return;const d=e.data||{};if(typeof d!=="object")return;if(d.type==="noor-ready"){const c=g();c&&c.postMessage({type:"noor-init",canRsvp:!!n.onRsvp,canDua:!!n.onGuestbook,guest:n.guest||null,data:{groomName:n.data.groomName,brideName:n.data.brideName,events:n.data.events||[],language:n.data.language||"en",gifts:n.data.gifts||[],contacts:n.data.contacts||[],whatsappNumber:n.data.whatsappNumber||""},duas:(n.guestbookMessages||[]).map(m=>({n:m.guestName,b:m.body}))},ORIGIN)}if(d.type==="noor-rsvp"&&n.onRsvp){Promise.resolve(n.onRsvp(d.attending,d.companions,d.dietary)).then(()=>{const c=g();c&&c.postMessage({type:"noor-rsvp-ok"},ORIGIN)}).catch(()=>{const c=g();c&&c.postMessage({type:"noor-rsvp-fail"},ORIGIN)})}if(d.type==="noor-dua"&&n.onGuestbook){Promise.resolve(n.onGuestbook(d.name,d.body)).then(()=>{const c=g();c&&c.postMessage({type:"noor-dua-ok"},ORIGIN)}).catch(()=>{const c=g();c&&c.postMessage({type:"noor-dua-fail"},ORIGIN)})}}window.addEventListener("message",h);return()=>window.removeEventListener("message",h)},[n.guestbookMessages]);w.useEffect(()=>{const c=g();c&&c.postMessage({type:"noor-duas",duas:(n.guestbookMessages||[]).map(m=>({n:m.guestName,b:m.body}))},ORIGIN)},[n.guestbookMessages]);w.useEffect(()=>{const c=g();c&&c.postMessage({type:"noor-data",data:{groomName:n.data.groomName,brideName:n.data.brideName,events:n.data.events||[],language:n.data.language||"en",gifts:n.data.gifts||[],contacts:n.data.contacts||[],whatsappNumber:n.data.whatsappNumber||""}},ORIGIN)},[n.data]);const p={auto:n.autoOpen?"1":""};if(n.guest){p.guest=n.guest.name||"";p.code=n.guest.code||"";p.max=n.guest.maxCompanions??""}return u.jsx("iframe",{ref:f,src:"./royal-noor/index.html?"+new URLSearchParams(p).toString(),style:{width:"100%",height:n.demo?"100%":"100dvh",border:0,display:"block",background:"#070d22"},title:"Royal Noor invitation"})}function KDp(n){const f=w.useRef(null),L=w.useRef(n);L.current=n;const O=window.location.origin&&window.location.origin!=="null"?window.location.origin:"*",g=()=>f.current&&f.current.contentWindow,P=m=>{const c=g();c&&c.postMessage(m,O)},K=["groomName","brideName","groomFamily","brideFamily","quoteEn","quoteSw","storyEn","storySw","sealText","events","language","whatsappNumber"],D=d=>{const o={};if(d)for(const k of K)d[k]!=null&&(o[k]=d[k]);try{return JSON.parse(JSON.stringify(o))}catch(e){return o}},Q=l=>(l||[]).map(m=>({n:m.guestName||"",b:m.body||""})),G=x=>x?JSON.parse(JSON.stringify({name:x.name||"",code:x.code||"",maxCompanions:x.maxCompanions??0,rsvpStatus:x.rsvpStatus||"pending",checkedIn:!!x.checkedIn})):null;w.useEffect(()=>{function h(e){if(e.origin!==window.location.origin||!f.current||e.source!==f.current.contentWindow)return;const d=e.data||{};if(typeof d!=="object")return;const p=L.current;if(d.type==="kasri-ready")P({type:"kasri-init",canRsvp:!!p.onRsvp,canDua:!!p.onGuestbook,guest:G(p.guest),data:D(p.data),inviteUrl:p.inviteUrl||"",duas:Q(p.guestbookMessages)});if(d.type==="kasri-rsvp"&&p.onRsvp)Promise.resolve(p.onRsvp(!!d.attending,Number(d.companions)||0,String(d.dietary||""))).then(()=>P({type:"kasri-rsvp-ok"})).catch(()=>P({type:"kasri-rsvp-fail"}));if(d.type==="kasri-dua"&&p.onGuestbook)Promise.resolve(p.onGuestbook(String(d.name||"").slice(0,60),String(d.body||"").slice(0,280))).then(()=>P({type:"kasri-dua-ok"})).catch(()=>P({type:"kasri-dua-fail"}))}window.addEventListener("message",h);return()=>window.removeEventListener("message",h)},[]);w.useEffect(()=>{P({type:"kasri-data",data:D(n.data)})},[n.data]);w.useEffect(()=>{P({type:"kasri-guest",guest:G(n.guest)})},[n.guest]);w.useEffect(()=>{P({type:"kasri-duas",duas:Q(n.guestbookMessages)})},[n.guestbookMessages]);const p={auto:n.autoOpen?"1":""};if(n.guest){p.guest=n.guest.name||"";p.code=n.guest.code||"";p.max=n.guest.maxCompanions??""}return u.jsx("iframe",{ref:f,src:"./kasri-dhahabu/index.html?"+new URLSearchParams(p).toString(),style:{width:"100%",height:n.demo?"100%":"100dvh",border:0,display:"block",background:"#121A14"},title:"Kasri la Dhahabu invitation",allow:"clipboard-write"})}function Ib(n){return w.useEffect(()=>{"scrollRestoration"in history&&(history.scrollRestoration="manual"),window.scrollTo(0,0)},[]),w.useEffect(()=>{document.documentElement.lang=n.data.language==="sw"?"sw":"en"},[n.data.language]),n.data.templateId==="kasri-dhahabu"?u.jsx(KDp,{...n}):n.data.templateId==="royal-noor"?u.jsx(RNp,{...n}):n.data.templateId==="villa-rosa"?u.jsx(eN,{"code-path":"src/components/invite/TemplateRenderer.tsx:24:54",...n}):n.data.templateId==="midnight-garden"?u.jsx(TN,{"code-path":"src/components/invite/TemplateRenderer.tsx:25:59",...n}):n.data.templateId==="emerald-arch"?u.jsx(EA,{...n}):n.data.templateId==="rose-cascade"?u.jsx(RC,{"code-path":"src/components/invite/TemplateRenderer.tsx:26:56",...n}):u.jsx(PT,{"code-path":"src/components/invite/TemplateRenderer.tsx:27:10",...n})}const Kx="blush-swan";function NN(){const[n]=gw(),a=n.get("template")??Kx,i=Uh.some(l=>l.id===a)?a:Kx,r=i==="villa-rosa"?FT:{...HT,templateId:i};return u.jsxs("div",{"code-path":"src/pages/DemoPage.tsx:17:5",className:"relative",children:[u.jsxs(Vt,{"code-path":"src/pages/DemoPage.tsx:18:7",to:"/templates",className:"fixed z-50 flex items-center gap-2 px-4 py-2 rounded-full text-xs uppercase tracking-widest backdrop-blur",style:{left:"clamp(54px,12.5vw,90px)",bottom:"clamp(72px,14vw,104px)",background:"rgba(0,0,0,0.55)",color:"#fff",border:"1px solid rgba(255,255,255,0.25)",fontFamily:"'Jost', sans-serif"},children:[u.jsx(Oh,{"code-path":"src/pages/DemoPage.tsx:23:9",size:13})," Exit demo"]}),u.jsx(Ib,{"code-path":"src/pages/DemoPage.tsx:25:7",data:r,guest:IT,autoOpen:n.get("open")==="1",inviteUrl:`${Gb()}#/demo`})]})}function Jx(){const{slug:n,code:a0}=MR(),a=a0||((/[?&#]code=([A-Za-z0-9]{2,14})/i.exec(window.location.hash||"")||[])[1]||void 0),i=da.useUtils(),[r,l]=w.useState(!1),d=da.invitations.publicView.useQuery({slug:n??"",code:a},{enabled:!!n,retry:1});w.useEffect(()=>{if(!d.isLoading){l(!1);return}const b=setTimeout(()=>l(!0),8e3);return()=>clearTimeout(b)},[d.isLoading]);const h=da.guests.rsvp.useMutation({onSuccess:()=>i.invitations.publicView.invalidate()}),y=da.messages.add.useMutation({onSuccess:()=>i.invitations.publicView.invalidate()});if(d.isLoading)return u.jsxs("div",{"code-path":"src/pages/InvitePage.tsx:35:7",className:"min-h-screen flex flex-col items-center justify-center gap-6 px-6 text-center",style:{background:"#FBF8F2"},children:[u.jsx(k.div,{"code-path":"src/pages/InvitePage.tsx:36:9",className:"w-16 h-16 rounded-full",style:{background:"radial-gradient(circle at 32% 28%, #8e2a40, #5c1223)",border:"2px solid rgba(160,125,59,0.55)",boxShadow:"0 10px 30px rgba(0,0,0,0.45)"},animate:{scale:[1,1.09,1]},transition:{duration:1.5,repeat:1/0,ease:"easeInOut"}}),u.jsx("p",{"code-path":"src/pages/InvitePage.tsx:46:9",style:{color:"#A07D3B",fontFamily:"'Cormorant Garamond', serif"},className:"text-lg tracking-wide",children:"Unsealing your invitation…"}),r&&u.jsxs("div",{"code-path":"src/pages/InvitePage.tsx:50:11",className:"flex flex-col items-center gap-3",children:[u.jsx("p",{"code-path":"src/pages/InvitePage.tsx:51:13",className:"text-sm",style:{color:"#f5e9c8",opacity:.7,fontFamily:"'Cormorant Garamond', serif"},children:"Taking longer than usual — your connection may be slow."}),u.jsx("button",{"code-path":"src/pages/InvitePage.tsx:54:13",onClick:()=>{l(!1),d.refetch()},className:"px-5 py-2 rounded-full text-sm tracking-wide",style:{border:"1px solid rgba(160,125,59,0.55)",color:"#A07D3B"},children:"Try again"})]})]});if(d.error)return u.jsxs("div",{"code-path":"src/pages/InvitePage.tsx:68:7",className:"min-h-screen flex flex-col items-center justify-center gap-4 px-6 text-center",style:{background:"#FBF8F2",color:"#1E1A12"},children:[u.jsx("p",{"code-path":"src/pages/InvitePage.tsx:69:9",className:"text-4xl",style:{fontFamily:"'Marcellus', serif",letterSpacing:"0.04em"},children:"Harusi"}),u.jsx("p",{"code-path":"src/pages/InvitePage.tsx:70:9",style:{fontFamily:"'Cormorant Garamond', serif"},className:"text-lg opacity-80",children:"We couldn't reach the invitation — please check your connection and try again."}),u.jsx("button",{"code-path":"src/pages/InvitePage.tsx:73:9",onClick:()=>d.refetch(),className:"mt-2 px-6 py-2 rounded-full text-sm tracking-wide",style:{border:"1px solid rgba(160,125,59,0.55)",color:"#A07D3B"},children:"Try again"})]});if(!d.data)return u.jsxs("div",{"code-path":"src/pages/InvitePage.tsx:85:7",className:"min-h-screen flex flex-col items-center justify-center gap-4 px-6 text-center",style:{background:"#FBF8F2",color:"#1E1A12"},children:[u.jsx("p",{"code-path":"src/pages/InvitePage.tsx:86:9",className:"text-4xl",style:{fontFamily:"'Marcellus', serif",letterSpacing:"0.04em"},children:"Harusi"}),u.jsx("p",{"code-path":"src/pages/InvitePage.tsx:87:9",style:{fontFamily:"'Cormorant Garamond', serif"},className:"text-lg opacity-80",children:"This invitation link could not be found. Please check the link you received."})]});const p=d.data.invitation,m=d.data.guest,g={slug:p.slug,templateId:p.templateId,groomName:p.groomName,brideName:p.brideName,quoteEn:p.quoteEn,quoteSw:p.quoteSw,storyEn:p.storyEn??"",storySw:p.storySw??"",heroImage:p.heroImage??"",musicTrack:p.musicTrack,language:p.language,events:p.events,gifts:p.gifts,gallery:p.gallery,whatsappNumber:p.whatsappNumber,groomFamily:p.groomFamily??"",brideFamily:p.brideFamily??"",sealText:p.sealText??"",contacts:p.contacts??[]},x=m?{name:m.name,code:m.code,rsvpStatus:m.rsvpStatus,companions:m.companions,maxCompanions:m.maxCompanions,dietary:m.dietary,checkedIn:m.checkedIn}:null;return u.jsx(Ib,{"code-path":"src/pages/InvitePage.tsx:131:5",data:g,guest:x,inviteUrl:`${Gb()}#/i/${p.slug}`,guestbookMessages:d.data.messages,onRsvp:async(b,M,S)=>{a&&await h.mutateAsync({slug:p.slug,code:a,attending:b,companions:M,dietary:S})},onGuestbook:async(b,M)=>{await y.mutateAsync({slug:p.slug,guestName:b,body:M})}})}const EN="#A07D3B";function AN(){return u.jsxs("div",{"code-path":"src/pages/Login.tsx:10:5",className:"min-h-screen flex flex-col items-center justify-center px-5 py-14 relative overflow-hidden",style:{background:"#FBF8F2",color:"#1E1A12"},children:[u.jsx("div",{"code-path":"src/pages/Login.tsx:14:7",className:"absolute inset-0 pointer-events-none",style:{background:"radial-gradient(ellipse 70% 50% at 50% 0%, rgba(160,125,59,0.10), transparent 70%)"}}),u.jsx(k.p,{"code-path":"src/pages/Login.tsx:18:7",initial:{opacity:0,filter:"blur(8px)"},animate:{opacity:1,filter:"blur(0px)"},transition:{duration:1.1},className:"text-2xl md:text-3xl mb-8 text-center",style:{fontFamily:"'Amiri', serif",color:EN},children:"بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ"}),u.jsx(wb,{"code-path":"src/pages/Login.tsx:27:7"}),u.jsxs(Vt,{"code-path":"src/pages/Login.tsx:28:7",to:"/",className:"mt-8 flex items-center gap-1.5 text-sm opacity-60 hover:opacity-100 transition-opacity",style:{fontFamily:"'Jost', sans-serif"},children:[u.jsx(Oh,{"code-path":"src/pages/Login.tsx:33:9",size:14})," Back to harusi"]})]})}const df="#C6A45E",ff="w-full rounded-xl px-4 py-3 bg-transparent outline-none text-base",hf={border:"1px solid rgba(198,164,94,0.35)",color:"#F2E9D8",fontFamily:"'Cormorant Garamond', serif"};function CN(){const[n,a]=w.useState(""),[i,r]=w.useState(""),[l,d]=w.useState(""),[h,y]=w.useState(null),p=wi(),m=da.auth.signup.useMutation({onSuccess:()=>p("/admin"),onError:x=>y(x.message)}),g=x=>{x.preventDefault(),y(null),m.mutate({name:n.trim(),email:i.trim(),password:l})};return u.jsxs("div",{"code-path":"src/pages/Setup.tsx:40:5",className:"min-h-screen flex flex-col items-center justify-center px-5 py-14",style:{background:"#FBF8F2",color:"#1E1A12"},children:[u.jsxs(k.div,{"code-path":"src/pages/Setup.tsx:41:7",initial:{opacity:0,y:24},animate:{opacity:1,y:0},className:"w-full max-w-md rounded-[1.8rem] p-8",style:{background:"linear-gradient(160deg,#2A2214,#14100A)",border:"1px solid rgba(198,164,94,0.45)"},children:[u.jsxs("div",{"code-path":"src/pages/Setup.tsx:47:9",className:"text-center mb-6",children:[u.jsx(bb,{"code-path":"src/pages/Setup.tsx:48:11",size:26,className:"mx-auto",style:{color:df}}),u.jsx("p",{"code-path":"src/pages/Setup.tsx:49:11",className:"mt-2 text-3xl",style:{fontFamily:"'Marcellus', serif",color:df},children:"First-Run Setup"}),u.jsx("p",{"code-path":"src/pages/Setup.tsx:50:11",className:"mt-2 text-sm opacity-60",style:{fontFamily:"'Jost', sans-serif"},children:"Create the platform's admin account. This page only works once — before any account exists."})]}),u.jsxs("form",{"code-path":"src/pages/Setup.tsx:54:9",onSubmit:g,className:"space-y-4",children:[u.jsxs("label",{"code-path":"src/pages/Setup.tsx:55:11",className:"block",children:[u.jsx("span",{"code-path":"src/pages/Setup.tsx:56:13",className:"block text-[10px] uppercase tracking-[0.25em] mb-1.5 opacity-60",style:{fontFamily:"'Jost', sans-serif"},children:"Your name"}),u.jsx("input",{"code-path":"src/pages/Setup.tsx:57:13",className:ff,style:hf,value:n,onChange:x=>a(x.target.value),placeholder:"Admin name"})]}),u.jsxs("label",{"code-path":"src/pages/Setup.tsx:59:11",className:"block",children:[u.jsx("span",{"code-path":"src/pages/Setup.tsx:60:13",className:"block text-[10px] uppercase tracking-[0.25em] mb-1.5 opacity-60",style:{fontFamily:"'Jost', sans-serif"},children:"Email"}),u.jsx("input",{"code-path":"src/pages/Setup.tsx:61:13",type:"email",required:!0,className:ff,style:hf,value:i,onChange:x=>r(x.target.value),placeholder:"you@example.com"})]}),u.jsxs("label",{"code-path":"src/pages/Setup.tsx:63:11",className:"block",children:[u.jsx("span",{"code-path":"src/pages/Setup.tsx:64:13",className:"block text-[10px] uppercase tracking-[0.25em] mb-1.5 opacity-60",style:{fontFamily:"'Jost', sans-serif"},children:"Password"}),u.jsx("input",{"code-path":"src/pages/Setup.tsx:65:13",type:"password",required:!0,minLength:6,className:ff,style:hf,value:l,onChange:x=>d(x.target.value),placeholder:"••••••••"})]}),h&&u.jsx("p",{"code-path":"src/pages/Setup.tsx:68:13",className:"text-sm rounded-lg px-3 py-2",style:{background:"rgba(224,112,112,0.12)",color:"#f0a0a0",fontFamily:"'Jost', sans-serif"},children:h}),u.jsxs("button",{"code-path":"src/pages/Setup.tsx:72:11",type:"submit",disabled:m.isPending,className:"w-full flex items-center justify-center gap-2 py-3.5 rounded-full text-sm uppercase tracking-[0.25em] font-bold cursor-pointer disabled:opacity-50",style:{background:df,color:"#1E1A12",fontFamily:"'Jost', sans-serif"},children:[u.jsx(Hr,{"code-path":"src/pages/Setup.tsx:78:13",size:16})," ",m.isPending?"Creating…":"Create Admin"]})]})]}),u.jsx(Vt,{"code-path":"src/pages/Setup.tsx:82:7",to:"/",className:"mt-8 text-sm opacity-60 hover:opacity-100",style:{fontFamily:"'Jost', sans-serif"},children:"← Back to harusi"})]})}function Wx(n,a){if(typeof n=="function")return n(a);n!=null&&(n.current=a)}function kN(...n){return a=>{let i=!1;const r=n.map(l=>{const d=Wx(l,a);return!i&&typeof d=="function"&&(i=!0),d});if(i)return()=>{for(let l=0;l<r.length;l++){const d=r[l];typeof d=="function"?d():Wx(n[l],null)}}}}var DN=Symbol.for("react.lazy"),rc=z3[" use ".trim().toString()];function zN(n){return typeof n=="object"&&n!==null&&"then"in n}function Pb(n){return n!=null&&typeof n=="object"&&"$$typeof"in n&&n.$$typeof===DN&&"_payload"in n&&zN(n._payload)}function VN(n){const a=LN(n),i=w.forwardRef((r,l)=>{let{children:d,...h}=r;Pb(d)&&typeof rc=="function"&&(d=rc(d._payload));const y=w.Children.toArray(d),p=y.find(_N);if(p){const m=p.props.children,g=y.map(x=>x===p?w.Children.count(m)>1?w.Children.only(null):w.isValidElement(m)?m.props.children:null:x);return u.jsx(a,{...h,ref:l,children:w.isValidElement(m)?w.cloneElement(m,void 0,g):null})}return u.jsx(a,{...h,ref:l,children:d})});return i.displayName=`${n}.Slot`,i}var ON=VN("Slot");function LN(n){const a=w.forwardRef((i,r)=>{let{children:l,...d}=i;if(Pb(l)&&typeof rc=="function"&&(l=rc(l._payload)),w.isValidElement(l)){const h=UN(l),y=BN(d,l.props);return l.type!==w.Fragment&&(y.ref=r?kN(r,h):h),w.cloneElement(l,y)}return w.Children.count(l)>1?w.Children.only(null):null});return a.displayName=`${n}.SlotClone`,a}var GN=Symbol("radix.slottable");function _N(n){return w.isValidElement(n)&&typeof n.type=="function"&&"__radixId"in n.type&&n.type.__radixId===GN}function BN(n,a){const i={...a};for(const r in a){const l=n[r],d=a[r];/^on[A-Z]/.test(r)?l&&d?i[r]=(...y)=>{const p=d(...y);return l(...y),p}:l&&(i[r]=l):r==="style"?i[r]={...l,...d}:r==="className"&&(i[r]=[l,d].filter(Boolean).join(" "))}return{...n,...i}}function UN(n){let a=Object.getOwnPropertyDescriptor(n.props,"ref")?.get,i=a&&"isReactWarning"in a&&a.isReactWarning;return i?n.ref:(a=Object.getOwnPropertyDescriptor(n,"ref")?.get,i=a&&"isReactWarning"in a&&a.isReactWarning,i?n.props.ref:n.props.ref||n.ref)}function Yb(n){var a,i,r="";if(typeof n=="string"||typeof n=="number")r+=n;else if(typeof n=="object")if(Array.isArray(n)){var l=n.length;for(a=0;a<l;a++)n[a]&&(i=Yb(n[a]))&&(r&&(r+=" "),r+=i)}else for(i in n)n[i]&&(r&&(r+=" "),r+=i);return r}function qb(){for(var n,a,i=0,r="",l=arguments.length;i<l;i++)(n=arguments[i])&&(a=Yb(n))&&(r&&(r+=" "),r+=a);return r}const e1=n=>typeof n=="boolean"?`${n}`:n===0?"0":n,t1=qb,HN=(n,a)=>i=>{var r;if(a?.variants==null)return t1(n,i?.class,i?.className);const{variants:l,defaultVariants:d}=a,h=Object.keys(l).map(m=>{const g=i?.[m],x=d?.[m];if(g===null)return null;const b=e1(g)||e1(x);return l[m][b]}),y=i&&Object.entries(i).reduce((m,g)=>{let[x,b]=g;return b===void 0||(m[x]=b),m},{}),p=a==null||(r=a.compoundVariants)===null||r===void 0?void 0:r.reduce((m,g)=>{let{class:x,className:b,...M}=g;return Object.entries(M).every(S=>{let[T,j]=S;return Array.isArray(j)?j.includes({...d,...y}[T]):{...d,...y}[T]===j})?[...m,x,b]:m},[]);return t1(n,h,p,i?.class,i?.className)},FN=(n,a)=>{const i=new Array(n.length+a.length);for(let r=0;r<n.length;r++)i[r]=n[r];for(let r=0;r<a.length;r++)i[n.length+r]=a[r];return i},IN=(n,a)=>({classGroupId:n,validator:a}),Xb=(n=new Map,a=null,i)=>({nextPart:n,validators:a,classGroupId:i}),oc="-",n1=[],PN="arbitrary..",YN=n=>{const a=XN(n),{conflictingClassGroups:i,conflictingClassGroupModifiers:r}=n;return{getClassGroupId:h=>{if(h.startsWith("[")&&h.endsWith("]"))return qN(h);const y=h.split(oc),p=y[0]===""&&y.length>1?1:0;return $b(y,p,a)},getConflictingClassGroupIds:(h,y)=>{if(y){const p=r[h],m=i[h];return p?m?FN(m,p):p:m||n1}return i[h]||n1}}},$b=(n,a,i)=>{if(n.length-a===0)return i.classGroupId;const l=n[a],d=i.nextPart.get(l);if(d){const m=$b(n,a+1,d);if(m)return m}const h=i.validators;if(h===null)return;const y=a===0?n.join(oc):n.slice(a).join(oc),p=h.length;for(let m=0;m<p;m++){const g=h[m];if(g.validator(y))return g.classGroupId}},qN=n=>n.slice(1,-1).indexOf(":")===-1?void 0:(()=>{const a=n.slice(1,-1),i=a.indexOf(":"),r=a.slice(0,i);return r?PN+r:void 0})(),XN=n=>{const{theme:a,classGroups:i}=n;return $N(i,a)},$N=(n,a)=>{const i=Xb();for(const r in n){const l=n[r];Yh(l,i,r,a)}return i},Yh=(n,a,i,r)=>{const l=n.length;for(let d=0;d<l;d++){const h=n[d];QN(h,a,i,r)}},QN=(n,a,i,r)=>{if(typeof n=="string"){ZN(n,a,i);return}if(typeof n=="function"){KN(n,a,i,r);return}JN(n,a,i,r)},ZN=(n,a,i)=>{const r=n===""?a:Qb(a,n);r.classGroupId=i},KN=(n,a,i,r)=>{if(WN(n)){Yh(n(r),a,i,r);return}a.validators===null&&(a.validators=[]),a.validators.push(IN(i,n))},JN=(n,a,i,r)=>{const l=Object.entries(n),d=l.length;for(let h=0;h<d;h++){const[y,p]=l[h];Yh(p,Qb(a,y),i,r)}},Qb=(n,a)=>{let i=n;const r=a.split(oc),l=r.length;for(let d=0;d<l;d++){const h=r[d];let y=i.nextPart.get(h);y||(y=Xb(),i.nextPart.set(h,y)),i=y}return i},WN=n=>"isThemeGetter"in n&&n.isThemeGetter===!0,e8=n=>{if(n<1)return{get:()=>{},set:()=>{}};let a=0,i=Object.create(null),r=Object.create(null);const l=(d,h)=>{i[d]=h,a++,a>n&&(a=0,r=i,i=Object.create(null))};return{get(d){let h=i[d];if(h!==void 0)return h;if((h=r[d])!==void 0)return l(d,h),h},set(d,h){d in i?i[d]=h:l(d,h)}}},$f="!",a1=":",t8=[],s1=(n,a,i,r,l)=>({modifiers:n,hasImportantModifier:a,baseClassName:i,maybePostfixModifierPosition:r,isExternal:l}),n8=n=>{const{prefix:a,experimentalParseClassName:i}=n;let r=l=>{const d=[];let h=0,y=0,p=0,m;const g=l.length;for(let T=0;T<g;T++){const j=l[T];if(h===0&&y===0){if(j===a1){d.push(l.slice(p,T)),p=T+1;continue}if(j==="/"){m=T;continue}}j==="["?h++:j==="]"?h--:j==="("?y++:j===")"&&y--}const x=d.length===0?l:l.slice(p);let b=x,M=!1;x.endsWith($f)?(b=x.slice(0,-1),M=!0):x.startsWith($f)&&(b=x.slice(1),M=!0);const S=m&&m>p?m-p:void 0;return s1(d,M,b,S)};if(a){const l=a+a1,d=r;r=h=>h.startsWith(l)?d(h.slice(l.length)):s1(t8,!1,h,void 0,!0)}if(i){const l=r;r=d=>i({className:d,parseClassName:l})}return r},a8=n=>{const a=new Map;return n.orderSensitiveModifiers.forEach((i,r)=>{a.set(i,1e6+r)}),i=>{const r=[];let l=[];for(let d=0;d<i.length;d++){const h=i[d],y=h[0]==="[",p=a.has(h);y||p?(l.length>0&&(l.sort(),r.push(...l),l=[]),r.push(h)):l.push(h)}return l.length>0&&(l.sort(),r.push(...l)),r}},s8=n=>({cache:e8(n.cacheSize),parseClassName:n8(n),sortModifiers:a8(n),...YN(n)}),i8=/\s+/,r8=(n,a)=>{const{parseClassName:i,getClassGroupId:r,getConflictingClassGroupIds:l,sortModifiers:d}=a,h=[],y=n.trim().split(i8);let p="";for(let m=y.length-1;m>=0;m-=1){const g=y[m],{isExternal:x,modifiers:b,hasImportantModifier:M,baseClassName:S,maybePostfixModifierPosition:T}=i(g);if(x){p=g+(p.length>0?" "+p:p);continue}let j=!!T,O=r(j?S.substring(0,T):S);if(!O){if(!j){p=g+(p.length>0?" "+p:p);continue}if(O=r(S),!O){p=g+(p.length>0?" "+p:p);continue}j=!1}const L=b.length===0?"":b.length===1?b[0]:d(b).join(":"),z=M?L+$f:L,D=z+O;if(h.indexOf(D)>-1)continue;h.push(D);const X=l(O,j);for(let J=0;J<X.length;++J){const Q=X[J];h.push(z+Q)}p=g+(p.length>0?" "+p:p)}return p},o8=(...n)=>{let a=0,i,r,l="";for(;a<n.length;)(i=n[a++])&&(r=Zb(i))&&(l&&(l+=" "),l+=r);return l},Zb=n=>{if(typeof n=="string")return n;let a,i="";for(let r=0;r<n.length;r++)n[r]&&(a=Zb(n[r]))&&(i&&(i+=" "),i+=a);return i},l8=(n,...a)=>{let i,r,l,d;const h=p=>{const m=a.reduce((g,x)=>x(g),n());return i=s8(m),r=i.cache.get,l=i.cache.set,d=y,y(p)},y=p=>{const m=r(p);if(m)return m;const g=r8(p,i);return l(p,g),g};return d=h,(...p)=>d(o8(...p))},c8=[],pt=n=>{const a=i=>i[n]||c8;return a.isThemeGetter=!0,a},Kb=/^\[(?:(\w[\w-]*):)?(.+)\]$/i,Jb=/^\((?:(\w[\w-]*):)?(.+)\)$/i,u8=/^\d+\/\d+$/,d8=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,f8=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,h8=/^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,p8=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,m8=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,ci=n=>u8.test(n),be=n=>!!n&&!Number.isNaN(Number(n)),Fa=n=>!!n&&Number.isInteger(Number(n)),pf=n=>n.endsWith("%")&&be(n.slice(0,-1)),ca=n=>d8.test(n),g8=()=>!0,y8=n=>f8.test(n)&&!h8.test(n),Wb=()=>!1,x8=n=>p8.test(n),v8=n=>m8.test(n),b8=n=>!ne(n)&&!ae(n),R8=n=>Ni(n,n2,Wb),ne=n=>Kb.test(n),ps=n=>Ni(n,a2,y8),mf=n=>Ni(n,T8,be),i1=n=>Ni(n,e2,Wb),w8=n=>Ni(n,t2,v8),kl=n=>Ni(n,s2,x8),ae=n=>Jb.test(n),Tr=n=>Ei(n,a2),S8=n=>Ei(n,N8),r1=n=>Ei(n,e2),j8=n=>Ei(n,n2),M8=n=>Ei(n,t2),Dl=n=>Ei(n,s2,!0),Ni=(n,a,i)=>{const r=Kb.exec(n);return r?r[1]?a(r[1]):i(r[2]):!1},Ei=(n,a,i=!1)=>{const r=Jb.exec(n);return r?r[1]?a(r[1]):i:!1},e2=n=>n==="position"||n==="percentage",t2=n=>n==="image"||n==="url",n2=n=>n==="length"||n==="size"||n==="bg-size",a2=n=>n==="length",T8=n=>n==="number",N8=n=>n==="family-name",s2=n=>n==="shadow",E8=()=>{const n=pt("color"),a=pt("font"),i=pt("text"),r=pt("font-weight"),l=pt("tracking"),d=pt("leading"),h=pt("breakpoint"),y=pt("container"),p=pt("spacing"),m=pt("radius"),g=pt("shadow"),x=pt("inset-shadow"),b=pt("text-shadow"),M=pt("drop-shadow"),S=pt("blur"),T=pt("perspective"),j=pt("aspect"),O=pt("ease"),L=pt("animate"),z=()=>["auto","avoid","all","avoid-page","page","left","right","column"],D=()=>["center","top","bottom","left","right","top-left","left-top","top-right","right-top","bottom-right","right-bottom","bottom-left","left-bottom"],X=()=>[...D(),ae,ne],J=()=>["auto","hidden","clip","visible","scroll"],Q=()=>["auto","contain","none"],E=()=>[ae,ne,p],q=()=>[ci,"full","auto",...E()],ee=()=>[Fa,"none","subgrid",ae,ne],oe=()=>["auto",{span:["full",Fa,ae,ne]},Fa,ae,ne],me=()=>[Fa,"auto",ae,ne],He=()=>["auto","min","max","fr",ae,ne],Te=()=>["start","end","center","between","around","evenly","stretch","baseline","center-safe","end-safe"],de=()=>["start","end","center","stretch","center-safe","end-safe"],U=()=>["auto",...E()],K=()=>[ci,"auto","full","dvw","dvh","lvw","lvh","svw","svh","min","max","fit",...E()],Y=()=>[n,ae,ne],fe=()=>[...D(),r1,i1,{position:[ae,ne]}],ye=()=>["no-repeat",{repeat:["","x","y","space","round"]}],A=()=>["auto","cover","contain",j8,R8,{size:[ae,ne]}],I=()=>[pf,Tr,ps],Z=()=>["","none","full",m,ae,ne],W=()=>["",be,Tr,ps],he=()=>["solid","dashed","dotted","double"],ve=()=>["normal","multiply","screen","overlay","darken","lighten","color-dodge","color-burn","hard-light","soft-light","difference","exclusion","hue","saturation","color","luminosity"],ue=()=>[be,pf,r1,i1],vt=()=>["","none",S,ae,ne],Fe=()=>["none",be,ae,ne],Vn=()=>["none",be,ae,ne],pa=()=>[be,ae,ne],ma=()=>[ci,"full",...E()];return{cacheSize:500,theme:{animate:["spin","ping","pulse","bounce"],aspect:["video"],blur:[ca],breakpoint:[ca],color:[g8],container:[ca],"drop-shadow":[ca],ease:["in","out","in-out"],font:[b8],"font-weight":["thin","extralight","light","normal","medium","semibold","bold","extrabold","black"],"inset-shadow":[ca],leading:["none","tight","snug","normal","relaxed","loose"],perspective:["dramatic","near","normal","midrange","distant","none"],radius:[ca],shadow:[ca],spacing:["px",be],text:[ca],"text-shadow":[ca],tracking:["tighter","tight","normal","wide","wider","widest"]},classGroups:{aspect:[{aspect:["auto","square",ci,ne,ae,j]}],container:["container"],columns:[{columns:[be,ne,ae,y]}],"break-after":[{"break-after":z()}],"break-before":[{"break-before":z()}],"break-inside":[{"break-inside":["auto","avoid","avoid-page","avoid-column"]}],"box-decoration":[{"box-decoration":["slice","clone"]}],box:[{box:["border","content"]}],display:["block","inline-block","inline","flex","inline-flex","table","inline-table","table-caption","table-cell","table-column","table-column-group","table-footer-group","table-header-group","table-row-group","table-row","flow-root","grid","inline-grid","contents","list-item","hidden"],sr:["sr-only","not-sr-only"],float:[{float:["right","left","none","start","end"]}],clear:[{clear:["left","right","both","none","start","end"]}],isolation:["isolate","isolation-auto"],"object-fit":[{object:["contain","cover","fill","none","scale-down"]}],"object-position":[{object:X()}],overflow:[{overflow:J()}],"overflow-x":[{"overflow-x":J()}],"overflow-y":[{"overflow-y":J()}],overscroll:[{overscroll:Q()}],"overscroll-x":[{"overscroll-x":Q()}],"overscroll-y":[{"overscroll-y":Q()}],position:["static","fixed","absolute","relative","sticky"],inset:[{inset:q()}],"inset-x":[{"inset-x":q()}],"inset-y":[{"inset-y":q()}],start:[{start:q()}],end:[{end:q()}],top:[{top:q()}],right:[{right:q()}],bottom:[{bottom:q()}],left:[{left:q()}],visibility:["visible","invisible","collapse"],z:[{z:[Fa,"auto",ae,ne]}],basis:[{basis:[ci,"full","auto",y,...E()]}],"flex-direction":[{flex:["row","row-reverse","col","col-reverse"]}],"flex-wrap":[{flex:["nowrap","wrap","wrap-reverse"]}],flex:[{flex:[be,ci,"auto","initial","none",ne]}],grow:[{grow:["",be,ae,ne]}],shrink:[{shrink:["",be,ae,ne]}],order:[{order:[Fa,"first","last","none",ae,ne]}],"grid-cols":[{"grid-cols":ee()}],"col-start-end":[{col:oe()}],"col-start":[{"col-start":me()}],"col-end":[{"col-end":me()}],"grid-rows":[{"grid-rows":ee()}],"row-start-end":[{row:oe()}],"row-start":[{"row-start":me()}],"row-end":[{"row-end":me()}],"grid-flow":[{"grid-flow":["row","col","dense","row-dense","col-dense"]}],"auto-cols":[{"auto-cols":He()}],"auto-rows":[{"auto-rows":He()}],gap:[{gap:E()}],"gap-x":[{"gap-x":E()}],"gap-y":[{"gap-y":E()}],"justify-content":[{justify:[...Te(),"normal"]}],"justify-items":[{"justify-items":[...de(),"normal"]}],"justify-self":[{"justify-self":["auto",...de()]}],"align-content":[{content:["normal",...Te()]}],"align-items":[{items:[...de(),{baseline:["","last"]}]}],"align-self":[{self:["auto",...de(),{baseline:["","last"]}]}],"place-content":[{"place-content":Te()}],"place-items":[{"place-items":[...de(),"baseline"]}],"place-self":[{"place-self":["auto",...de()]}],p:[{p:E()}],px:[{px:E()}],py:[{py:E()}],ps:[{ps:E()}],pe:[{pe:E()}],pt:[{pt:E()}],pr:[{pr:E()}],pb:[{pb:E()}],pl:[{pl:E()}],m:[{m:U()}],mx:[{mx:U()}],my:[{my:U()}],ms:[{ms:U()}],me:[{me:U()}],mt:[{mt:U()}],mr:[{mr:U()}],mb:[{mb:U()}],ml:[{ml:U()}],"space-x":[{"space-x":E()}],"space-x-reverse":["space-x-reverse"],"space-y":[{"space-y":E()}],"space-y-reverse":["space-y-reverse"],size:[{size:K()}],w:[{w:[y,"screen",...K()]}],"min-w":[{"min-w":[y,"screen","none",...K()]}],"max-w":[{"max-w":[y,"screen","none","prose",{screen:[h]},...K()]}],h:[{h:["screen","lh",...K()]}],"min-h":[{"min-h":["screen","lh","none",...K()]}],"max-h":[{"max-h":["screen","lh",...K()]}],"font-size":[{text:["base",i,Tr,ps]}],"font-smoothing":["antialiased","subpixel-antialiased"],"font-style":["italic","not-italic"],"font-weight":[{font:[r,ae,mf]}],"font-stretch":[{"font-stretch":["ultra-condensed","extra-condensed","condensed","semi-condensed","normal","semi-expanded","expanded","extra-expanded","ultra-expanded",pf,ne]}],"font-family":[{font:[S8,ne,a]}],"fvn-normal":["normal-nums"],"fvn-ordinal":["ordinal"],"fvn-slashed-zero":["slashed-zero"],"fvn-figure":["lining-nums","oldstyle-nums"],"fvn-spacing":["proportional-nums","tabular-nums"],"fvn-fraction":["diagonal-fractions","stacked-fractions"],tracking:[{tracking:[l,ae,ne]}],"line-clamp":[{"line-clamp":[be,"none",ae,mf]}],leading:[{leading:[d,...E()]}],"list-image":[{"list-image":["none",ae,ne]}],"list-style-position":[{list:["inside","outside"]}],"list-style-type":[{list:["disc","decimal","none",ae,ne]}],"text-alignment":[{text:["left","center","right","justify","start","end"]}],"placeholder-color":[{placeholder:Y()}],"text-color":[{text:Y()}],"text-decoration":["underline","overline","line-through","no-underline"],"text-decoration-style":[{decoration:[...he(),"wavy"]}],"text-decoration-thickness":[{decoration:[be,"from-font","auto",ae,ps]}],"text-decoration-color":[{decoration:Y()}],"underline-offset":[{"underline-offset":[be,"auto",ae,ne]}],"text-transform":["uppercase","lowercase","capitalize","normal-case"],"text-overflow":["truncate","text-ellipsis","text-clip"],"text-wrap":[{text:["wrap","nowrap","balance","pretty"]}],indent:[{indent:E()}],"vertical-align":[{align:["baseline","top","middle","bottom","text-top","text-bottom","sub","super",ae,ne]}],whitespace:[{whitespace:["normal","nowrap","pre","pre-line","pre-wrap","break-spaces"]}],break:[{break:["normal","words","all","keep"]}],wrap:[{wrap:["break-word","anywhere","normal"]}],hyphens:[{hyphens:["none","manual","auto"]}],content:[{content:["none",ae,ne]}],"bg-attachment":[{bg:["fixed","local","scroll"]}],"bg-clip":[{"bg-clip":["border","padding","content","text"]}],"bg-origin":[{"bg-origin":["border","padding","content"]}],"bg-position":[{bg:fe()}],"bg-repeat":[{bg:ye()}],"bg-size":[{bg:A()}],"bg-image":[{bg:["none",{linear:[{to:["t","tr","r","br","b","bl","l","tl"]},Fa,ae,ne],radial:["",ae,ne],conic:[Fa,ae,ne]},M8,w8]}],"bg-color":[{bg:Y()}],"gradient-from-pos":[{from:I()}],"gradient-via-pos":[{via:I()}],"gradient-to-pos":[{to:I()}],"gradient-from":[{from:Y()}],"gradient-via":[{via:Y()}],"gradient-to":[{to:Y()}],rounded:[{rounded:Z()}],"rounded-s":[{"rounded-s":Z()}],"rounded-e":[{"rounded-e":Z()}],"rounded-t":[{"rounded-t":Z()}],"rounded-r":[{"rounded-r":Z()}],"rounded-b":[{"rounded-b":Z()}],"rounded-l":[{"rounded-l":Z()}],"rounded-ss":[{"rounded-ss":Z()}],"rounded-se":[{"rounded-se":Z()}],"rounded-ee":[{"rounded-ee":Z()}],"rounded-es":[{"rounded-es":Z()}],"rounded-tl":[{"rounded-tl":Z()}],"rounded-tr":[{"rounded-tr":Z()}],"rounded-br":[{"rounded-br":Z()}],"rounded-bl":[{"rounded-bl":Z()}],"border-w":[{border:W()}],"border-w-x":[{"border-x":W()}],"border-w-y":[{"border-y":W()}],"border-w-s":[{"border-s":W()}],"border-w-e":[{"border-e":W()}],"border-w-t":[{"border-t":W()}],"border-w-r":[{"border-r":W()}],"border-w-b":[{"border-b":W()}],"border-w-l":[{"border-l":W()}],"divide-x":[{"divide-x":W()}],"divide-x-reverse":["divide-x-reverse"],"divide-y":[{"divide-y":W()}],"divide-y-reverse":["divide-y-reverse"],"border-style":[{border:[...he(),"hidden","none"]}],"divide-style":[{divide:[...he(),"hidden","none"]}],"border-color":[{border:Y()}],"border-color-x":[{"border-x":Y()}],"border-color-y":[{"border-y":Y()}],"border-color-s":[{"border-s":Y()}],"border-color-e":[{"border-e":Y()}],"border-color-t":[{"border-t":Y()}],"border-color-r":[{"border-r":Y()}],"border-color-b":[{"border-b":Y()}],"border-color-l":[{"border-l":Y()}],"divide-color":[{divide:Y()}],"outline-style":[{outline:[...he(),"none","hidden"]}],"outline-offset":[{"outline-offset":[be,ae,ne]}],"outline-w":[{outline:["",be,Tr,ps]}],"outline-color":[{outline:Y()}],shadow:[{shadow:["","none",g,Dl,kl]}],"shadow-color":[{shadow:Y()}],"inset-shadow":[{"inset-shadow":["none",x,Dl,kl]}],"inset-shadow-color":[{"inset-shadow":Y()}],"ring-w":[{ring:W()}],"ring-w-inset":["ring-inset"],"ring-color":[{ring:Y()}],"ring-offset-w":[{"ring-offset":[be,ps]}],"ring-offset-color":[{"ring-offset":Y()}],"inset-ring-w":[{"inset-ring":W()}],"inset-ring-color":[{"inset-ring":Y()}],"text-shadow":[{"text-shadow":["none",b,Dl,kl]}],"text-shadow-color":[{"text-shadow":Y()}],opacity:[{opacity:[be,ae,ne]}],"mix-blend":[{"mix-blend":[...ve(),"plus-darker","plus-lighter"]}],"bg-blend":[{"bg-blend":ve()}],"mask-clip":[{"mask-clip":["border","padding","content","fill","stroke","view"]},"mask-no-clip"],"mask-composite":[{mask:["add","subtract","intersect","exclude"]}],"mask-image-linear-pos":[{"mask-linear":[be]}],"mask-image-linear-from-pos":[{"mask-linear-from":ue()}],"mask-image-linear-to-pos":[{"mask-linear-to":ue()}],"mask-image-linear-from-color":[{"mask-linear-from":Y()}],"mask-image-linear-to-color":[{"mask-linear-to":Y()}],"mask-image-t-from-pos":[{"mask-t-from":ue()}],"mask-image-t-to-pos":[{"mask-t-to":ue()}],"mask-image-t-from-color":[{"mask-t-from":Y()}],"mask-image-t-to-color":[{"mask-t-to":Y()}],"mask-image-r-from-pos":[{"mask-r-from":ue()}],"mask-image-r-to-pos":[{"mask-r-to":ue()}],"mask-image-r-from-color":[{"mask-r-from":Y()}],"mask-image-r-to-color":[{"mask-r-to":Y()}],"mask-image-b-from-pos":[{"mask-b-from":ue()}],"mask-image-b-to-pos":[{"mask-b-to":ue()}],"mask-image-b-from-color":[{"mask-b-from":Y()}],"mask-image-b-to-color":[{"mask-b-to":Y()}],"mask-image-l-from-pos":[{"mask-l-from":ue()}],"mask-image-l-to-pos":[{"mask-l-to":ue()}],"mask-image-l-from-color":[{"mask-l-from":Y()}],"mask-image-l-to-color":[{"mask-l-to":Y()}],"mask-image-x-from-pos":[{"mask-x-from":ue()}],"mask-image-x-to-pos":[{"mask-x-to":ue()}],"mask-image-x-from-color":[{"mask-x-from":Y()}],"mask-image-x-to-color":[{"mask-x-to":Y()}],"mask-image-y-from-pos":[{"mask-y-from":ue()}],"mask-image-y-to-pos":[{"mask-y-to":ue()}],"mask-image-y-from-color":[{"mask-y-from":Y()}],"mask-image-y-to-color":[{"mask-y-to":Y()}],"mask-image-radial":[{"mask-radial":[ae,ne]}],"mask-image-radial-from-pos":[{"mask-radial-from":ue()}],"mask-image-radial-to-pos":[{"mask-radial-to":ue()}],"mask-image-radial-from-color":[{"mask-radial-from":Y()}],"mask-image-radial-to-color":[{"mask-radial-to":Y()}],"mask-image-radial-shape":[{"mask-radial":["circle","ellipse"]}],"mask-image-radial-size":[{"mask-radial":[{closest:["side","corner"],farthest:["side","corner"]}]}],"mask-image-radial-pos":[{"mask-radial-at":D()}],"mask-image-conic-pos":[{"mask-conic":[be]}],"mask-image-conic-from-pos":[{"mask-conic-from":ue()}],"mask-image-conic-to-pos":[{"mask-conic-to":ue()}],"mask-image-conic-from-color":[{"mask-conic-from":Y()}],"mask-image-conic-to-color":[{"mask-conic-to":Y()}],"mask-mode":[{mask:["alpha","luminance","match"]}],"mask-origin":[{"mask-origin":["border","padding","content","fill","stroke","view"]}],"mask-position":[{mask:fe()}],"mask-repeat":[{mask:ye()}],"mask-size":[{mask:A()}],"mask-type":[{"mask-type":["alpha","luminance"]}],"mask-image":[{mask:["none",ae,ne]}],filter:[{filter:["","none",ae,ne]}],blur:[{blur:vt()}],brightness:[{brightness:[be,ae,ne]}],contrast:[{contrast:[be,ae,ne]}],"drop-shadow":[{"drop-shadow":["","none",M,Dl,kl]}],"drop-shadow-color":[{"drop-shadow":Y()}],grayscale:[{grayscale:["",be,ae,ne]}],"hue-rotate":[{"hue-rotate":[be,ae,ne]}],invert:[{invert:["",be,ae,ne]}],saturate:[{saturate:[be,ae,ne]}],sepia:[{sepia:["",be,ae,ne]}],"backdrop-filter":[{"backdrop-filter":["","none",ae,ne]}],"backdrop-blur":[{"backdrop-blur":vt()}],"backdrop-brightness":[{"backdrop-brightness":[be,ae,ne]}],"backdrop-contrast":[{"backdrop-contrast":[be,ae,ne]}],"backdrop-grayscale":[{"backdrop-grayscale":["",be,ae,ne]}],"backdrop-hue-rotate":[{"backdrop-hue-rotate":[be,ae,ne]}],"backdrop-invert":[{"backdrop-invert":["",be,ae,ne]}],"backdrop-opacity":[{"backdrop-opacity":[be,ae,ne]}],"backdrop-saturate":[{"backdrop-saturate":[be,ae,ne]}],"backdrop-sepia":[{"backdrop-sepia":["",be,ae,ne]}],"border-collapse":[{border:["collapse","separate"]}],"border-spacing":[{"border-spacing":E()}],"border-spacing-x":[{"border-spacing-x":E()}],"border-spacing-y":[{"border-spacing-y":E()}],"table-layout":[{table:["auto","fixed"]}],caption:[{caption:["top","bottom"]}],transition:[{transition:["","all","colors","opacity","shadow","transform","none",ae,ne]}],"transition-behavior":[{transition:["normal","discrete"]}],duration:[{duration:[be,"initial",ae,ne]}],ease:[{ease:["linear","initial",O,ae,ne]}],delay:[{delay:[be,ae,ne]}],animate:[{animate:["none",L,ae,ne]}],backface:[{backface:["hidden","visible"]}],perspective:[{perspective:[T,ae,ne]}],"perspective-origin":[{"perspective-origin":X()}],rotate:[{rotate:Fe()}],"rotate-x":[{"rotate-x":Fe()}],"rotate-y":[{"rotate-y":Fe()}],"rotate-z":[{"rotate-z":Fe()}],scale:[{scale:Vn()}],"scale-x":[{"scale-x":Vn()}],"scale-y":[{"scale-y":Vn()}],"scale-z":[{"scale-z":Vn()}],"scale-3d":["scale-3d"],skew:[{skew:pa()}],"skew-x":[{"skew-x":pa()}],"skew-y":[{"skew-y":pa()}],transform:[{transform:[ae,ne,"","none","gpu","cpu"]}],"transform-origin":[{origin:X()}],"transform-style":[{transform:["3d","flat"]}],translate:[{translate:ma()}],"translate-x":[{"translate-x":ma()}],"translate-y":[{"translate-y":ma()}],"translate-z":[{"translate-z":ma()}],"translate-none":["translate-none"],accent:[{accent:Y()}],appearance:[{appearance:["none","auto"]}],"caret-color":[{caret:Y()}],"color-scheme":[{scheme:["normal","dark","light","light-dark","only-dark","only-light"]}],cursor:[{cursor:["auto","default","pointer","wait","text","move","help","not-allowed","none","context-menu","progress","cell","crosshair","vertical-text","alias","copy","no-drop","grab","grabbing","all-scroll","col-resize","row-resize","n-resize","e-resize","s-resize","w-resize","ne-resize","nw-resize","se-resize","sw-resize","ew-resize","ns-resize","nesw-resize","nwse-resize","zoom-in","zoom-out",ae,ne]}],"field-sizing":[{"field-sizing":["fixed","content"]}],"pointer-events":[{"pointer-events":["auto","none"]}],resize:[{resize:["none","","y","x"]}],"scroll-behavior":[{scroll:["auto","smooth"]}],"scroll-m":[{"scroll-m":E()}],"scroll-mx":[{"scroll-mx":E()}],"scroll-my":[{"scroll-my":E()}],"scroll-ms":[{"scroll-ms":E()}],"scroll-me":[{"scroll-me":E()}],"scroll-mt":[{"scroll-mt":E()}],"scroll-mr":[{"scroll-mr":E()}],"scroll-mb":[{"scroll-mb":E()}],"scroll-ml":[{"scroll-ml":E()}],"scroll-p":[{"scroll-p":E()}],"scroll-px":[{"scroll-px":E()}],"scroll-py":[{"scroll-py":E()}],"scroll-ps":[{"scroll-ps":E()}],"scroll-pe":[{"scroll-pe":E()}],"scroll-pt":[{"scroll-pt":E()}],"scroll-pr":[{"scroll-pr":E()}],"scroll-pb":[{"scroll-pb":E()}],"scroll-pl":[{"scroll-pl":E()}],"snap-align":[{snap:["start","end","center","align-none"]}],"snap-stop":[{snap:["normal","always"]}],"snap-type":[{snap:["none","x","y","both"]}],"snap-strictness":[{snap:["mandatory","proximity"]}],touch:[{touch:["auto","none","manipulation"]}],"touch-x":[{"touch-pan":["x","left","right"]}],"touch-y":[{"touch-pan":["y","up","down"]}],"touch-pz":["touch-pinch-zoom"],select:[{select:["none","text","all","auto"]}],"will-change":[{"will-change":["auto","scroll","contents","transform",ae,ne]}],fill:[{fill:["none",...Y()]}],"stroke-w":[{stroke:[be,Tr,ps,mf]}],stroke:[{stroke:["none",...Y()]}],"forced-color-adjust":[{"forced-color-adjust":["auto","none"]}]},conflictingClassGroups:{overflow:["overflow-x","overflow-y"],overscroll:["overscroll-x","overscroll-y"],inset:["inset-x","inset-y","start","end","top","right","bottom","left"],"inset-x":["right","left"],"inset-y":["top","bottom"],flex:["basis","grow","shrink"],gap:["gap-x","gap-y"],p:["px","py","ps","pe","pt","pr","pb","pl"],px:["pr","pl"],py:["pt","pb"],m:["mx","my","ms","me","mt","mr","mb","ml"],mx:["mr","ml"],my:["mt","mb"],size:["w","h"],"font-size":["leading"],"fvn-normal":["fvn-ordinal","fvn-slashed-zero","fvn-figure","fvn-spacing","fvn-fraction"],"fvn-ordinal":["fvn-normal"],"fvn-slashed-zero":["fvn-normal"],"fvn-figure":["fvn-normal"],"fvn-spacing":["fvn-normal"],"fvn-fraction":["fvn-normal"],"line-clamp":["display","overflow"],rounded:["rounded-s","rounded-e","rounded-t","rounded-r","rounded-b","rounded-l","rounded-ss","rounded-se","rounded-ee","rounded-es","rounded-tl","rounded-tr","rounded-br","rounded-bl"],"rounded-s":["rounded-ss","rounded-es"],"rounded-e":["rounded-se","rounded-ee"],"rounded-t":["rounded-tl","rounded-tr"],"rounded-r":["rounded-tr","rounded-br"],"rounded-b":["rounded-br","rounded-bl"],"rounded-l":["rounded-tl","rounded-bl"],"border-spacing":["border-spacing-x","border-spacing-y"],"border-w":["border-w-x","border-w-y","border-w-s","border-w-e","border-w-t","border-w-r","border-w-b","border-w-l"],"border-w-x":["border-w-r","border-w-l"],"border-w-y":["border-w-t","border-w-b"],"border-color":["border-color-x","border-color-y","border-color-s","border-color-e","border-color-t","border-color-r","border-color-b","border-color-l"],"border-color-x":["border-color-r","border-color-l"],"border-color-y":["border-color-t","border-color-b"],translate:["translate-x","translate-y","translate-none"],"translate-none":["translate","translate-x","translate-y","translate-z"],"scroll-m":["scroll-mx","scroll-my","scroll-ms","scroll-me","scroll-mt","scroll-mr","scroll-mb","scroll-ml"],"scroll-mx":["scroll-mr","scroll-ml"],"scroll-my":["scroll-mt","scroll-mb"],"scroll-p":["scroll-px","scroll-py","scroll-ps","scroll-pe","scroll-pt","scroll-pr","scroll-pb","scroll-pl"],"scroll-px":["scroll-pr","scroll-pl"],"scroll-py":["scroll-pt","scroll-pb"],touch:["touch-x","touch-y","touch-pz"],"touch-x":["touch"],"touch-y":["touch"],"touch-pz":["touch"]},conflictingClassGroupModifiers:{"font-size":["leading"]},orderSensitiveModifiers:["*","**","after","backdrop","before","details-content","file","first-letter","first-line","marker","placeholder","selection"]}},A8=l8(E8);function no(...n){return A8(qb(n))}const C8=HN("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive",{variants:{variant:{default:"bg-primary text-primary-foreground hover:bg-primary/90",destructive:"bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60",outline:"border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50",secondary:"bg-secondary text-secondary-foreground hover:bg-secondary/80",ghost:"hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",link:"text-primary underline-offset-4 hover:underline"},size:{default:"h-9 px-4 py-2 has-[>svg]:px-3",sm:"h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",lg:"h-10 rounded-md px-6 has-[>svg]:px-4",icon:"size-9","icon-sm":"size-8","icon-lg":"size-10"}},defaultVariants:{variant:"default",size:"default"}});function k8({className:n,variant:a="default",size:i="default",asChild:r=!1,...l}){const d=r?ON:"button";return u.jsx(d,{"code-path":"src/components/ui/button.tsx:52:5","data-slot":"button","data-variant":a,"data-size":i,className:no(C8({variant:a,size:i,className:n})),...l})}function D8({className:n,...a}){return u.jsx("div",{"code-path":"src/components/ui/card.tsx:7:5","data-slot":"card",className:no("bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm",n),...a})}function z8({className:n,...a}){return u.jsx("div",{"code-path":"src/components/ui/card.tsx:20:5","data-slot":"card-header",className:no("@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-2 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6",n),...a})}function V8({className:n,...a}){return u.jsx("div",{"code-path":"src/components/ui/card.tsx:33:5","data-slot":"card-title",className:no("leading-none font-semibold",n),...a})}function O8({className:n,...a}){return u.jsx("div",{"code-path":"src/components/ui/card.tsx:66:5","data-slot":"card-content",className:no("px-6",n),...a})}function L8(){return u.jsx("div",{"code-path":"src/pages/NotFound.tsx:7:5",className:"min-h-screen flex items-center justify-center",children:u.jsxs(D8,{"code-path":"src/pages/NotFound.tsx:8:7",className:"w-full max-w-sm text-center",children:[u.jsx(z8,{"code-path":"src/pages/NotFound.tsx:9:9",children:u.jsx(V8,{"code-path":"src/pages/NotFound.tsx:10:11",className:"text-4xl font-bold",children:"404"})}),u.jsxs(O8,{"code-path":"src/pages/NotFound.tsx:12:9",className:"space-y-4",children:[u.jsx("p",{"code-path":"src/pages/NotFound.tsx:13:11",className:"text-muted-foreground",children:"Page not found"}),u.jsx(k8,{"code-path":"src/pages/NotFound.tsx:14:11",asChild:!0,className:"w-full",children:u.jsx(Vt,{"code-path":"src/pages/NotFound.tsx:15:13",to:"/",children:"Back to Home"})})]})]})})}const G8=w.lazy(()=>Yr(()=>import("./Dashboard-B6tzCIQb.js").then(n=>n.D),[],import.meta.url)),_8=w.lazy(()=>Yr(()=>import("./Builder-DANMFasp.js"),__vite__mapDeps([0,1]),import.meta.url)),B8=w.lazy(()=>Yr(()=>import("./Scan-1E3DM2pr.js"),__vite__mapDeps([2,1]),import.meta.url)),U8=w.lazy(()=>Yr(()=>import("./Admin-BYfOqgqc.js"),__vite__mapDeps([3,1]),import.meta.url)),zl=u.jsx("div",{"code-path":"src/App.tsx:18:3",className:"min-h-screen flex items-center justify-center",style:{background:"#FBF8F2",color:"#A07D3B",fontFamily:"'Jost', sans-serif"},children:"Loading…"});function H8(){return u.jsxs(UR,{"code-path":"src/App.tsx:25:5",children:[u.jsx(rn,{"code-path":"src/App.tsx:26:7",path:"/",element:u.jsx(AT,{"code-path":"src/App.tsx:26:32"})}),u.jsx(rn,{"code-path":"src/App.tsx:27:7",path:"/templates",element:u.jsx(kT,{"code-path":"src/App.tsx:27:41"})}),u.jsx(rn,{"code-path":"src/App.tsx:28:7",path:"/demo",element:u.jsx(NN,{"code-path":"src/App.tsx:28:36"})}),u.jsx(rn,{"code-path":"src/App.tsx:29:7",path:"/i/:slug",element:u.jsx(Jx,{"code-path":"src/App.tsx:29:39"})}),u.jsx(rn,{"code-path":"src/App.tsx:30:7",path:"/i/:slug/:code",element:u.jsx(Jx,{"code-path":"src/App.tsx:30:45"})}),u.jsx(rn,{"code-path":"src/App.tsx:31:7",path:"/dashboard",element:u.jsx(w.Suspense,{"code-path":"src/App.tsx:31:41",fallback:zl,children:u.jsx(G8,{"code-path":"src/App.tsx:31:71"})})}),u.jsx(rn,{"code-path":"src/App.tsx:32:7",path:"/builder/:id",element:u.jsx(w.Suspense,{"code-path":"src/App.tsx:32:43",fallback:zl,children:u.jsx(_8,{"code-path":"src/App.tsx:32:73"})})}),u.jsx(rn,{"code-path":"src/App.tsx:33:7",path:"/scan/:id",element:u.jsx(w.Suspense,{"code-path":"src/App.tsx:33:40",fallback:zl,children:u.jsx(B8,{"code-path":"src/App.tsx:33:70"})})}),u.jsx(rn,{"code-path":"src/App.tsx:34:7",path:"/admin",element:u.jsx(w.Suspense,{"code-path":"src/App.tsx:34:37",fallback:zl,children:u.jsx(U8,{"code-path":"src/App.tsx:34:67"})})}),u.jsx(rn,{"code-path":"src/App.tsx:35:7",path:"/login",element:u.jsx(AN,{"code-path":"src/App.tsx:35:37"})}),u.jsx(rn,{"code-path":"src/App.tsx:36:7",path:"/setup",element:u.jsx(CN,{"code-path":"src/App.tsx:36:37"})}),u.jsx(rn,{"code-path":"src/App.tsx:37:7",path:"*",element:u.jsx(L8,{"code-path":"src/App.tsx:37:32"})})]})}U3.createRoot(document.getElementById("root")).render(u.jsx(w.StrictMode,{"code-path":"src/main.tsx:11:3",children:u.jsx(dw,{"code-path":"src/main.tsx:12:5",children:u.jsx(Nw,{"code-path":"src/main.tsx:13:7",children:u.jsx(H8,{"code-path":"src/main.tsx:14:9"})})})}));export{Oh as A,Ur as C,q8 as D,cT as E,Hr as G,Vt as L,gc as M,yc as Q,bb as S,Ib as T,Yr as _,Rb as a,wi as b,Mt as c,Gb as d,Uh as e,X8 as f,Gh as g,Ti as h,MT as i,u as j,F8 as k,I8 as l,k as m,P8 as n,w as r,da as t,MR as u};

/* === Harusi template 04: Rose Cascade === */

const RC_C = {
  bg: "#f8f1e5",
  bgSoft: "#f2e8d6",
  card: "#fdfaf2",
  ink: "#3e322c",
  inkSoft: "#7d6a58",
  rose: "#a85d5e",
  roseDark: "#7d3f45",
  blush: "#eec9c2",
  blushDeep: "#d9a39c",
  gold: "#b98a2f",
  goldSoft: "#d9c08a",
  goldDeep: "#8a6420",
  goldHi: "#f4d98c",
  goldFire: "#e9a13b"
};
const RC_CAPS = "'Cinzel', serif";
const RC_SERIF = "'Marcellus', serif";
const RC_SCRIPT = "'Pinyon Script', cursive";
const RC_SANS = "'Jost', sans-serif";
const RC_AMIRI = "'Amiri', serif";
const RC_EASE = [0.22, 1, 0.36, 1];
const RC_CV = { contentVisibility: "auto", containIntrinsicSize: "1100px" };
const RC_T = {
  en: {
    tapSeal: "Touch the seal to open",
    forYou: "For",
    scroll: "Scroll",
    invited: "You are warmly invited to the wedding of",
    bismillah: "\u0628\u0650\u0633\u0652\u0645\u0650 \u0671\u0644\u0644\u064E\u0651\u0670\u0647\u0650 \u0671\u0644\u0631\u064E\u0651\u062D\u0652\u0645\u064E\u0670\u0646\u0650 \u0671\u0644\u0631\u064E\u0651\u062D\u0650\u064A\u0645\u0650",
    twoSouls: "Two Souls",
    oneDestiny: "One Destiny",
    familyPre: "With the blessings of",
    familyPost: "two families become one",
    beginsIn: "The celebration begins in",
    cdTitle: "Counting Down",
    days: "Days",
    hours: "Hours",
    minutes: "Minutes",
    seconds: "Seconds",
    schedule: "The order of the day",
    celebration: "Celebration",
    location: "The Venue",
    whereWe: "Where we celebrate",
    openMaps: "Open in Maps",
    addCal: "Add to Calendar",
    dressTitle: "Dress Code",
    whatToWear: "What to wear",
    dressText: "We kindly invite you to wear formal attire that complements the elegance and spirit of our special day.",
    dressGents: "Gentlemen \u2014 well-tailored suits with polished dress shoes.",
    dressLadies: "Ladies \u2014 formal gowns or elegant evening dresses.",
    dressTag: "Attire",
    mapLink: "Map",
    detailsTitle: "Details",
    detailsSub: "Good to know",
    transportTitle: "Transport & Parking",
    transportText: "Complimentary valet parking is available at the main gate. A shuttle runs from the parking area to the venue every 15 minutes.",
    stayTitle: "Where to Stay",
    stayText: "For our guests travelling in, we recommend the nearby beach resorts of Nungwi and Kendwa \u2014 kindly book early for the season.",
    giftsTitle: "Gifts & Michango",
    presence: "Your presence is the gift",
    noBoxed: "Kindly, no boxed gifts please.",
    giftsNote: "Your presence is the greatest gift. Should you wish to honour us with a contribution, it will be warmly received with duas.",
    copy: "Copy",
    copied: "Copied!",
    contactsTitle: "Contacts",
    contactsSub: "For any inquiries, kindly reach us:",
    rsvp: "Kindly Respond",
    confirmTitle: "Confirm Your Attendance",
    confirmSub: "To help us prepare for a joyful celebration, kindly confirm below.",
    rsvpBefore: "Kindly respond before",
    rsvpSealHint: "Touch the seal to open your RSVP",
    yourName: "Your name",
    attendQ: "Will you be attending?",
    accept: "Accepts with pleasure",
    decline: "Declines with regret",
    guestsAttending: "Number of guests attending",
    songLabel: "A song that gets you dancing",
    childrenLabel: "Children attending (names & ages)",
    dietary: "Dietary needs (optional)",
    submit: "Submit RSVP",
    sending: "Sending\u2026",
    rsvpDone: "Thank you \u2014 your response has been received!",
    rsvpWhats: "or RSVP via WhatsApp",
    attendingBadge: "Attending \u2713",
    declinedBadge: "Regrets sent",
    guestbook: "Duas & Blessings",
    leaveBlessing: "Leave a blessing for the couple",
    guestbookName: "Your name",
    guestbookPh: "Write your dua or message\u2026",
    guestbookSend: "Send Blessing",
    guestbookThanks: "Shukran! Your blessing has been added.",
    yourCode: "Your guest code",
    scanHint: "Show this code at the entrance",
    checkedInBadge: "Checked in \u2713",
    hopeToSee: "Hope to see you there!",
    wmBless: "Blessings",
    wmTime: "Time",
    wmLove: "Love",
    wmJoy: "Joy",
    footer: "Made with love in Zanzibar"
  },
  sw: {
    tapSeal: "Gusa muhuri kufungua",
    forYou: "Kwa",
    scroll: "Sogeza chini",
    invited: "Umealikwa kwa heshima kubwa kwenye harusi ya",
    bismillah: "\u0628\u0650\u0633\u0652\u0645\u0650 \u0671\u0644\u0644\u064E\u0651\u0670\u0647\u0650 \u0671\u0644\u0631\u064E\u0651\u062D\u0652\u0645\u064E\u0670\u0646\u0650 \u0671\u0644\u0631\u064E\u0651\u062D\u0650\u064A\u0645\u0650",
    twoSouls: "Roho Mbili",
    oneDestiny: "Hatima Moja",
    familyPre: "Kwa baraka za",
    familyPost: "familia mbili zinakuwa moja",
    beginsIn: "Sherehe inaanza baada ya",
    cdTitle: "Tunahesabu",
    days: "Siku",
    hours: "Saa",
    minutes: "Dakika",
    seconds: "Sekunde",
    schedule: "Ratiba ya sherehe",
    celebration: "Sherehe",
    location: "Mahali",
    whereWe: "Mahali tutakaposherehekea",
    openMaps: "Fungua Ramani",
    addCal: "Weka Kalendari",
    dressTitle: "Mavazi",
    whatToWear: "Nini cha kuvaa",
    dressText: "Tunakualika kuvaa mavazi rasmi yanayooana na mvuto na roho ya siku yetu maalum.",
    dressGents: "Wanaume \u2014 suti zilizoshonwa vizuri na viatu vya kiume.",
    dressLadies: "Wanawake \u2014 mavazi marefu rasmi au ya kifahari.",
    dressTag: "Mavazi",
    mapLink: "Ramani",
    detailsTitle: "Maelezo",
    detailsSub: "Vizuri kujua",
    transportTitle: "Usafiri & Maegesho",
    transportText: "Maegesho ya bure yanapatikana getini. Basi ndogo hupitia kila dakika 15 kutoka maegeshoni hadi ukumbini.",
    stayTitle: "Malazi",
    stayText: "Kwa wageni wanaosafiri, tunapendekeza hoteli za ufukweni za Nungwi na Kendwa \u2014 tafadhali weka nafasi mapema.",
    giftsTitle: "Zawadi & Michango",
    presence: "Kuja kwako ndiyo zawadi",
    noBoxed: "Tafadhali, hakuna zawadi za maboksi.",
    giftsNote: "Kuja kwako ndiyo zawadi kuu. Ukitaka kutupa mchango, utapokelewa kwa shukrani na dua.",
    copy: "Nakili",
    copied: "Imenakiliwa!",
    contactsTitle: "Mawasiliano",
    contactsSub: "Kwa maswali yoyote, tupigie:",
    rsvp: "Tafadhali Jibu",
    confirmTitle: "Thibitisha Kuhudhuria",
    confirmSub: "Ili kutuandalia sherehe njema, tafadhali thibitisha hapa chini.",
    rsvpBefore: "Tafadhali jibu kabla ya",
    rsvpSealHint: "Gusa muhuri kufungua fomu ya RSVP",
    yourName: "Jina lako",
    attendQ: "Je, utahudhuria?",
    accept: "Nitahudhuria kwa furaha",
    decline: "Samahani, sitahudhuria",
    guestsAttending: "Idadi ya wageni",
    songLabel: "Wimbo unaokufanya ucheze",
    childrenLabel: "Watoto wanaohudhuria (majina & umri)",
    dietary: "Mahitaji ya chakula (hiari)",
    submit: "Tuma RSVP",
    sending: "Inatuma\u2026",
    rsvpDone: "Asante \u2014 jibu lako limepokelewa!",
    rsvpWhats: "au jibu kwa WhatsApp",
    attendingBadge: "Nitahudhuria \u2713",
    declinedBadge: "Samahani tumetumwa",
    guestbook: "Dua & Salamu",
    leaveBlessing: "Acha dua au salamu kwa wanandoa",
    guestbookName: "Jina lako",
    guestbookPh: "Andika dua au salamu zako\u2026",
    guestbookSend: "Tuma Dua",
    guestbookThanks: "Shukran! Dua yako imeongezwa.",
    yourCode: "Msimbo wako wa mgeni",
    scanHint: "Onyesha msimbo huu mlangoni",
    checkedInBadge: "Umeingia \u2713",
    hopeToSee: "Tunatarajia kukuona!",
    wmBless: "Baraka",
    wmTime: "Muda",
    wmLove: "Mapenzi",
    wmJoy: "Furaha",
    footer: "Imetengenezwa kwa upendo Zanzibar"
  }
};
function RCRev({ children, delay = 0, y = 28, style }) {
  return /* @__PURE__ */ u.jsx(
    k.div,
    {
      initial: { opacity: 0, y, filter: "blur(4px)" },
      whileInView: { opacity: 1, y: 0, filter: "blur(0px)" },
      viewport: { once: true, margin: "-48px" },
      transition: { delay, duration: 0.95, ease: RC_EASE },
      style,
      children
    }
  );
}
function RCDivider({ width = 190 }) {
  return /* @__PURE__ */ u.jsxs("svg", { width, height: "22", viewBox: "0 0 190 22", fill: "none", style: { display: "block", margin: "14px auto 0" }, children: [
    /* @__PURE__ */ u.jsx(k.path, { d: "M6 11 H74", stroke: RC_C.gold, strokeWidth: "1", initial: { pathLength: 0 }, whileInView: { pathLength: 1 }, viewport: { once: true }, transition: { duration: 1.1, ease: "easeOut" } }),
    /* @__PURE__ */ u.jsx(k.path, { d: "M116 11 H184", stroke: RC_C.gold, strokeWidth: "1", initial: { pathLength: 0 }, whileInView: { pathLength: 1 }, viewport: { once: true }, transition: { duration: 1.1, ease: "easeOut" } }),
    /* @__PURE__ */ u.jsx(k.path, { d: "M95 3.5 107 11 95 18.5 83 11 Z", stroke: RC_C.gold, strokeWidth: "1.1", initial: { pathLength: 0 }, whileInView: { pathLength: 1 }, viewport: { once: true }, transition: { duration: 0.9, delay: 0.4 } }),
    /* @__PURE__ */ u.jsx("circle", { cx: "78", cy: "11", r: "1.6", fill: RC_C.gold }),
    /* @__PURE__ */ u.jsx("circle", { cx: "112", cy: "11", r: "1.6", fill: RC_C.gold })
  ] });
}
function RCMark({ word }) {
  return /* @__PURE__ */ u.jsx(
    k.span,
    {
      "aria-hidden": "true",
      animate: { y: [-9, 9] },
      transition: { duration: 9, repeat: Infinity, repeatType: "mirror", ease: "easeInOut" },
      style: {
        position: "absolute",
        left: "50%",
        top: "50%",
        x: "-50%",
        y: "-50%",
        fontFamily: RC_SCRIPT,
        fontSize: "clamp(96px,23vw,210px)",
        lineHeight: 1,
        color: "rgba(168,93,94,0.05)",
        whiteSpace: "nowrap",
        pointerEvents: "none",
        zIndex: 0
      },
      children: word
    }
  );
}
function RCHead({ eyebrow, title }) {
  return /* @__PURE__ */ u.jsxs("div", { style: { textAlign: "center", position: "relative", zIndex: 1 }, children: [
    /* @__PURE__ */ u.jsx(RCRev, { children: /* @__PURE__ */ u.jsx("p", { style: { fontFamily: RC_CAPS, fontSize: 11, letterSpacing: "0.42em", textTransform: "uppercase", color: RC_C.goldDeep, margin: 0 }, children: eyebrow }) }),
    /* @__PURE__ */ u.jsx(RCRev, { delay: 0.08, children: /* @__PURE__ */ u.jsx("h2", { style: { fontFamily: RC_SCRIPT, fontSize: "clamp(38px,7vw,56px)", color: RC_C.roseDark, margin: "10px 0 0", fontWeight: 400, lineHeight: 1.15 }, children: title }) }),
    /* @__PURE__ */ u.jsx(RCRev, { delay: 0.16, children: /* @__PURE__ */ u.jsx(RCDivider, {}) })
  ] });
}
function RCPetals({ density = 12 }) {
  const ref = w.useRef(null);
  w.useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d");
    let W = 0, H = 0, raf = 0, vis = false;
    const fit = () => {
      const r = cv.parentElement.getBoundingClientRect();
      W = r.width;
      H = r.height;
      const dpr = Math.min(1.75, window.devicePixelRatio || 1);
      cv.width = W * dpr;
      cv.height = H * dpr;
      cv.style.width = W + "px";
      cv.style.height = H + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(cv.parentElement);
    const R = (a, b) => a + Math.random() * (b - a);
    const mk = (top) => {
      const depth = R(0.35, 1);
      return {
        x: R(0, W),
        y: top ? R(-H * 0.1, -20) : R(0, H),
        depth,
        s: R(6, 11) * (0.55 + depth * 0.75),
        vy: R(22, 46) * (0.5 + depth * 0.8),
        sw: R(14, 40) * depth,
        swf: R(0.4, 0.9),
        swp: R(0, 6.28),
        rot: R(0, 6.28),
        vr: R(-0.9, 0.9),
        fl: R(1.2, 2.4),
        flp: R(0, 6.28),
        a: 0.3 + depth * 0.5
      };
    };
    const ps = [];
    for (let i = 0; i < density; i++) ps.push(mk(false));
    let t0 = performance.now();
    const draw = (t) => {
      if (!vis) return;
      const dt = Math.min(0.05, (t - t0) / 1e3);
      t0 = t;
      ctx.clearRect(0, 0, W, H);
      for (const p of ps) {
        p.y += p.vy * dt;
        p.x += Math.sin(t / 1e3 * p.swf + p.swp) * p.sw * dt;
        p.rot += p.vr * dt;
        const twx = 0.45 + 0.55 * Math.abs(Math.sin(t / 1e3 * p.fl + p.flp));
        if (p.y > H + 26) {
          Object.assign(p, mk(true));
          p.x = R(0, W);
        }
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.scale(p.s / 10 * twx + p.s / 10 * (1 - twx) * 0.4, p.s / 10);
        const g = ctx.createLinearGradient(0, -11, 0, 12);
        g.addColorStop(0, "rgba(240,205,198," + p.a + ")");
        g.addColorStop(0.55, "rgba(222,164,156," + p.a + ")");
        g.addColorStop(1, "rgba(198,128,122," + p.a + ")");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.moveTo(0, -11);
        ctx.bezierCurveTo(9.5, -8, 10.5, 4.5, 0, 12);
        ctx.bezierCurveTo(-10.5, 4.5, -9.5, -8, 0, -11);
        ctx.fill();
        ctx.strokeStyle = "rgba(150,74,80," + p.a * 0.45 + ")";
        ctx.lineWidth = 0.8;
        ctx.beginPath();
        ctx.moveTo(0, -9);
        ctx.quadraticCurveTo(1.6, 0.5, 0, 10);
        ctx.stroke();
        ctx.restore();
      }
      raf = requestAnimationFrame(draw);
    };
    const io = new IntersectionObserver((es) => {
      const v = es[0].isIntersecting;
      if (v && !vis) {
        vis = true;
        t0 = performance.now();
        raf = requestAnimationFrame(draw);
      } else if (!v && vis) {
        vis = false;
        cancelAnimationFrame(raf);
      }
    });
    io.observe(cv);
    return () => {
      vis = false;
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
    };
  }, [density]);
  return /* @__PURE__ */ u.jsx("canvas", { ref, style: { position: "absolute", inset: 0, pointerEvents: "none" } });
}
function RCMotes({ density = 12 }) {
  const ref = w.useRef(null);
  w.useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d");
    let W = 0, H = 0, raf = 0, vis = false;
    const fit = () => {
      const r = cv.parentElement.getBoundingClientRect();
      W = r.width;
      H = r.height;
      const dpr = Math.min(1.75, window.devicePixelRatio || 1);
      cv.width = W * dpr;
      cv.height = H * dpr;
      cv.style.width = W + "px";
      cv.style.height = H + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(cv.parentElement);
    const R = (a, b) => a + Math.random() * (b - a);
    const mk = (bottom) => ({
      x: R(0, W),
      y: bottom ? H + R(10, 60) : R(0, H),
      r: R(1.2, 4.2),
      vy: R(9, 26),
      sw: R(6, 20),
      swf: R(0.25, 0.6),
      swp: R(0, 6.28),
      twf: R(0.8, 1.8),
      twp: R(0, 6.28),
      a: R(0.25, 0.6)
    });
    const ms = [];
    for (let i = 0; i < density; i++) ms.push(mk(false));
    let t0 = performance.now();
    const draw = (t) => {
      if (!vis) return;
      const dt = Math.min(0.05, (t - t0) / 1e3);
      t0 = t;
      ctx.clearRect(0, 0, W, H);
      for (const m of ms) {
        m.y -= m.vy * dt;
        m.x += Math.sin(t / 1e3 * m.swf + m.swp) * m.sw * dt;
        if (m.y < -20) Object.assign(m, mk(true));
        const tw = 0.55 + 0.45 * Math.sin(t / 1e3 * m.twf + m.twp);
        const g = ctx.createRadialGradient(m.x, m.y, 0, m.x, m.y, m.r * 3.2);
        g.addColorStop(0, "rgba(244,217,140," + m.a * tw + ")");
        g.addColorStop(0.4, "rgba(217,192,138," + m.a * tw * 0.45 + ")");
        g.addColorStop(1, "rgba(217,192,138,0)");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(m.x, m.y, m.r * 3.2, 0, 6.29);
        ctx.fill();
      }
      raf = requestAnimationFrame(draw);
    };
    const io = new IntersectionObserver((es) => {
      const v = es[0].isIntersecting;
      if (v && !vis) {
        vis = true;
        t0 = performance.now();
        raf = requestAnimationFrame(draw);
      } else if (!v && vis) {
        vis = false;
        cancelAnimationFrame(raf);
      }
    });
    io.observe(cv);
    return () => {
      vis = false;
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
    };
  }, [density]);
  return /* @__PURE__ */ u.jsx("canvas", { ref, style: { position: "absolute", inset: 0, pointerEvents: "none" } });
}
function RCSpark({ burst }) {
  const ref = w.useRef(null);
  const last = w.useRef(0);
  w.useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d");
    let W = 0, H = 0, raf = 0;
    const fit = () => {
      W = window.innerWidth;
      H = window.innerHeight;
      const dpr = Math.min(1.5, window.devicePixelRatio || 1);
      cv.width = W * dpr;
      cv.height = H * dpr;
      cv.style.width = W + "px";
      cv.style.height = H + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    fit();
    window.addEventListener("resize", fit);
    const R = (a, b) => a + Math.random() * (b - a);
    const mk = () => ({
      x: R(0, W),
      y: R(0, H * 0.9),
      s: R(1.6, 4.6),
      twf: R(0.7, 1.9),
      twp: R(0, 6.28),
      vy: R(-6, -16),
      vx: R(-4, 4),
      a: R(0.5, 1)
    });
    const sp = [];
    for (let i = 0; i < 22; i++) sp.push(mk());
    const bo = [];
    if (last.current === 0 && burst === 1) {
      const cx = W / 2, cy = H * 0.62;
      for (let i = 0; i < 36; i++) {
        const an = R(0, 6.28), sp2 = R(60, 300);
        bo.push({ x: cx, y: cy, vx: Math.cos(an) * sp2, vy: Math.sin(an) * sp2 * 0.8 - 30, s: R(2, 5.4), life: R(0.7, 1.4), age: 0 });
      }
    }
    last.current = burst;
    let t0 = performance.now();
    const star = (x, y, s, a) => {
      ctx.strokeStyle = "rgba(250,226,150," + a + ")";
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      ctx.moveTo(x - s, y);
      ctx.lineTo(x + s, y);
      ctx.moveTo(x, y - s);
      ctx.lineTo(x, y + s);
      ctx.stroke();
      ctx.fillStyle = "rgba(255,248,220," + a + ")";
      ctx.beginPath();
      ctx.arc(x, y, s * 0.28, 0, 6.29);
      ctx.fill();
    };
    const draw = (t) => {
      const dt = Math.min(0.05, (t - t0) / 1e3);
      t0 = t;
      ctx.clearRect(0, 0, W, H);
      for (const s of sp) {
        s.y += s.vy * dt;
        s.x += s.vx * dt;
        if (s.y < -12 || s.x < -12 || s.x > W + 12) Object.assign(s, mk(), { y: H + 8 });
        const tw = Math.max(0, Math.sin(t / 1e3 * s.twf + s.twp));
        if (tw > 0.25) star(s.x, s.y, s.s * (0.7 + tw * 0.5), s.a * tw * 0.85);
      }
      for (let i = bo.length - 1; i >= 0; i--) {
        const b = bo[i];
        b.age += dt;
        if (b.age > b.life) {
          bo.splice(i, 1);
          continue;
        }
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        b.vy += 130 * dt;
        b.vx *= 0.985;
        star(b.x, b.y, b.s * (1 - b.age / b.life * 0.6), (1 - b.age / b.life) * 0.95);
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", fit);
    };
  }, [burst]);
  return /* @__PURE__ */ u.jsx("canvas", { ref, style: { position: "absolute", inset: 0, pointerEvents: "none" } });
}
function RCoin({ size = 72, mono = "", spin = true }) {
  const uid = w.useId().replace(/[:]/g, "");
  const ticks = [];
  for (let i = 0; i < 40; i++) {
    const an = i / 40 * Math.PI * 2;
    ticks.push(/* @__PURE__ */ u.jsx(
      "line",
      {
        x1: 50 + Math.cos(an) * 42.6,
        y1: 50 + Math.sin(an) * 42.6,
        x2: 50 + Math.cos(an) * 45.4,
        y2: 50 + Math.sin(an) * 45.4,
        stroke: "#a87c2c",
        strokeWidth: "0.55",
        opacity: "0.6"
      },
      i
    ));
  }
  return /* @__PURE__ */ u.jsxs("div", { style: {
    width: size,
    height: size,
    borderRadius: "50%",
    position: "relative",
    flexShrink: 0,
    background: "radial-gradient(circle at 34% 28%, #fffef9 0%, #f8eed9 55%, #eadbb9 100%)",
    boxShadow: "0 12px 26px -10px rgba(125,63,69,0.42), inset 0 2px 5px rgba(255,255,255,0.95), inset 0 -4px 9px rgba(150,116,84,0.32)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center"
  }, children: [
    /* @__PURE__ */ u.jsxs("svg", { style: { position: "absolute", inset: 0 }, viewBox: "0 0 100 100", children: [
      /* @__PURE__ */ u.jsx("defs", { children: /* @__PURE__ */ u.jsxs("linearGradient", { id: "rcg" + uid, x1: "0", y1: "0", x2: "1", y2: "1", children: [
        /* @__PURE__ */ u.jsx("stop", { offset: "0", stopColor: "#f6e3ae" }),
        /* @__PURE__ */ u.jsx("stop", { offset: "0.45", stopColor: "#caa14e" }),
        /* @__PURE__ */ u.jsx("stop", { offset: "0.72", stopColor: "#8a6420" }),
        /* @__PURE__ */ u.jsx("stop", { offset: "1", stopColor: "#e8cd8d" })
      ] }) }),
      /* @__PURE__ */ u.jsx("circle", { cx: "50", cy: "50", r: "47.4", fill: "none", stroke: "url(#rcg" + uid + ")", strokeWidth: "2.8" }),
      /* @__PURE__ */ u.jsx("circle", { cx: "50", cy: "50", r: "40", fill: "none", stroke: "#b98a2f", strokeWidth: "0.7", opacity: "0.65" }),
      spin ? /* @__PURE__ */ u.jsx("g", { children: ticks }) : null
    ] }),
    mono ? /* @__PURE__ */ u.jsx("span", { style: { fontFamily: RC_SCRIPT, fontSize: size * 0.3, color: RC_C.roseDark, lineHeight: 1, paddingBottom: size * 0.04 }, children: mono }) : /* @__PURE__ */ u.jsx("svg", { width: size * 0.44, height: size * 0.44, viewBox: "0 0 24 24", fill: "none", stroke: RC_C.rose, strokeWidth: "1.5", children: /* @__PURE__ */ u.jsx("path", { d: "M12 21c-5-3.6-8-6.8-8-10.4C4 7 6.3 5 8.8 5c1.4 0 2.6.7 3.2 1.7C12.6 5.7 13.8 5 15.2 5 17.7 5 20 7 20 10.6c0 3.6-3 6.8-8 10.4z" }) }),
    /* @__PURE__ */ u.jsx("div", { style: {
      position: "absolute",
      top: "9%",
      left: "16%",
      width: "42%",
      height: "26%",
      borderRadius: "50%",
      background: "linear-gradient(160deg, rgba(255,255,255,0.85), rgba(255,255,255,0))",
      pointerEvents: "none"
    } })
  ] });
}
function RCSeal({ size = 96, mono = "" }) {
  const uid = w.useId().replace(/[:]/g, "");
  const pts = [];
  const N = 12;
  for (let i = 0; i <= N; i++) {
    const an = i / N * Math.PI * 2;
    const r = 46 + [2.4, -1.6, 1.2, -2.6, 2.1, -1.1, 2.8, -2.2, 1.5, -1.8, 2.2, -1.4][i % N];
    pts.push([50 + Math.cos(an) * r, 50 + Math.sin(an) * r]);
  }
  let d = "M" + pts[0][0].toFixed(1) + " " + pts[0][1].toFixed(1);
  for (let i = 1; i < pts.length; i++) {
    const p0 = pts[i - 1], p1 = pts[i];
    const mx = (p0[0] + p1[0]) / 2, my = (p0[1] + p1[1]) / 2;
    d += " Q" + p0[0].toFixed(1) + " " + p0[1].toFixed(1) + " " + mx.toFixed(1) + " " + my.toFixed(1);
  }
  d += " Z";
  return /* @__PURE__ */ u.jsxs("svg", { width: size, height: size, viewBox: "0 0 100 100", style: { display: "block", filter: "drop-shadow(0 10px 18px rgba(80,52,30,0.45))" }, children: [
    /* @__PURE__ */ u.jsxs("defs", { children: [
      /* @__PURE__ */ u.jsxs("radialGradient", { id: "rcw" + uid, cx: "0.38", cy: "0.3", r: "0.85", children: [
        /* @__PURE__ */ u.jsx("stop", { offset: "0", stopColor: "#fffef8" }),
        /* @__PURE__ */ u.jsx("stop", { offset: "0.6", stopColor: "#f3e9d2" }),
        /* @__PURE__ */ u.jsx("stop", { offset: "1", stopColor: "#ddc9a2" })
      ] }),
      /* @__PURE__ */ u.jsxs("linearGradient", { id: "rcm" + uid, x1: "0", y1: "0", x2: "1", y2: "1", children: [
        /* @__PURE__ */ u.jsx("stop", { offset: "0", stopColor: "#f6e3ae" }),
        /* @__PURE__ */ u.jsx("stop", { offset: "0.5", stopColor: "#caa14e" }),
        /* @__PURE__ */ u.jsx("stop", { offset: "1", stopColor: "#8a6420" })
      ] })
    ] }),
    /* @__PURE__ */ u.jsx("path", { d, fill: "url(#rcw" + uid + ")" }),
    /* @__PURE__ */ u.jsx("path", { d, fill: "none", stroke: "#c9b28a", strokeWidth: "1", opacity: "0.7" }),
    /* @__PURE__ */ u.jsx("circle", { cx: "50", cy: "50", r: "33.5", fill: "none", stroke: "url(#rcm" + uid + ")", strokeWidth: "1.6", opacity: "0.9" }),
    /* @__PURE__ */ u.jsx("circle", { cx: "50", cy: "50", r: "30", fill: "none", stroke: "#b98a2f", strokeWidth: "0.55", opacity: "0.55" }),
    /* @__PURE__ */ u.jsx("ellipse", { cx: "38", cy: "30", rx: "20", ry: "10", fill: "#ffffff", opacity: "0.5", transform: "rotate(-18 38 30)" }),
    /* @__PURE__ */ u.jsx("text", { x: "50", y: "57", textAnchor: "middle", fontFamily: RC_SCRIPT, fontSize: "26", fill: RC_C.roseDark, children: mono })
  ] });
}
function RCCrest({ size = 96, mono = "", draw = true }) {
  const uid = w.useId().replace(/[:]/g, "");
  const h = size * (150 / 120);
  const leaves = [
    [52, 137, -38],
    [42, 130, -46],
    [34, 120, -56],
    [29, 108, -66],
    [68, 137, 38],
    [78, 130, 46],
    [86, 120, 56],
    [91, 108, 66]
  ];
  return /* @__PURE__ */ u.jsx("div", { style: { width: size, height: h, position: "relative", filter: "drop-shadow(0 14px 22px rgba(125,63,69,0.35))" }, children: /* @__PURE__ */ u.jsx(
    k.div,
    {
      animate: { y: [0, -5, 0] },
      transition: { duration: 4.8, repeat: Infinity, ease: "easeInOut" },
      style: { width: size, height: h, position: "relative" },
      children: /* @__PURE__ */ u.jsxs("svg", { width: size, height: h, viewBox: "0 0 120 150", fill: "none", style: { display: "block" }, children: [
        /* @__PURE__ */ u.jsxs("defs", { children: [
          /* @__PURE__ */ u.jsxs("linearGradient", { id: "rcc" + uid, x1: "0", y1: "0", x2: "1", y2: "1", children: [
            /* @__PURE__ */ u.jsx("stop", { offset: "0", stopColor: "#f6e3ae" }),
            /* @__PURE__ */ u.jsx("stop", { offset: "0.45", stopColor: "#caa14e" }),
            /* @__PURE__ */ u.jsx("stop", { offset: "0.75", stopColor: "#8a6420" }),
            /* @__PURE__ */ u.jsx("stop", { offset: "1", stopColor: "#e8cd8d" })
          ] }),
          /* @__PURE__ */ u.jsxs("radialGradient", { id: "rci" + uid, cx: "0.4", cy: "0.28", r: "0.95", children: [
            /* @__PURE__ */ u.jsx("stop", { offset: "0", stopColor: "#fffef9" }),
            /* @__PURE__ */ u.jsx("stop", { offset: "0.6", stopColor: "#f9f0dc" }),
            /* @__PURE__ */ u.jsx("stop", { offset: "1", stopColor: "#ecdcb8" })
          ] })
        ] }),
        /* @__PURE__ */ u.jsx(
          k.path,
          {
            d: "M60 143 C48 140 34 130 27 110",
            stroke: "url(#rcc" + uid + ")",
            strokeWidth: "1.6",
            strokeLinecap: "round",
            initial: draw ? { pathLength: 0 } : false,
            animate: { pathLength: 1 },
            transition: { duration: 1.2, delay: 0.5, ease: "easeOut" }
          }
        ),
        /* @__PURE__ */ u.jsx(
          k.path,
          {
            d: "M60 143 C72 140 86 130 93 110",
            stroke: "url(#rcc" + uid + ")",
            strokeWidth: "1.6",
            strokeLinecap: "round",
            initial: draw ? { pathLength: 0 } : false,
            animate: { pathLength: 1 },
            transition: { duration: 1.2, delay: 0.5, ease: "easeOut" }
          }
        ),
        leaves.map((lf, i) => /* @__PURE__ */ u.jsx(
          k.ellipse,
          {
            cx: lf[0],
            cy: lf[1],
            rx: "5.2",
            ry: "2.3",
            fill: "url(#rcc" + uid + ")",
            style: { transformOrigin: lf[0] + "px " + lf[1] + "px" },
            initial: draw ? { scale: 0, rotate: lf[2] } : false,
            animate: { scale: 1, rotate: lf[2] },
            transition: { delay: 0.7 + i * 0.07, type: "spring", stiffness: 300, damping: 15 }
          },
          i
        )),
        /* @__PURE__ */ u.jsx("circle", { cx: "60", cy: "143.5", r: "2.2", fill: "#b98a2f" }),
        /* @__PURE__ */ u.jsx(
          k.path,
          {
            d: "M46 25 L50.5 12.5 L56.5 20.5 L60 9 L63.5 20.5 L69.5 12.5 L74 25 Q60 19.5 46 25 Z",
            fill: "url(#rcc" + uid + ")",
            stroke: "#8a6420",
            strokeWidth: "0.6",
            initial: draw ? { opacity: 0, y: 6 } : false,
            animate: { opacity: 1, y: 0 },
            transition: { delay: 0.35, duration: 0.6, ease: RC_EASE }
          }
        ),
        /* @__PURE__ */ u.jsx("circle", { cx: "60", cy: "7", r: "1.7", fill: "#e8cd8d" }),
        /* @__PURE__ */ u.jsx("circle", { cx: "50", cy: "10.5", r: "1.4", fill: "#e8cd8d" }),
        /* @__PURE__ */ u.jsx("circle", { cx: "70", cy: "10.5", r: "1.4", fill: "#e8cd8d" }),
        /* @__PURE__ */ u.jsx(
          k.path,
          {
            d: "M60 26 C40 26 24 42 24 68 L24 114 Q24 131 41 131 L79 131 Q96 131 96 114 L96 68 C96 42 80 26 60 26 Z",
            fill: "url(#rci" + uid + ")",
            stroke: "url(#rcc" + uid + ")",
            strokeWidth: "2.4",
            initial: draw ? { pathLength: 0, fillOpacity: 0 } : false,
            animate: { pathLength: 1, fillOpacity: 1 },
            transition: { pathLength: { duration: 1.3, ease: "easeInOut" }, fillOpacity: { delay: 0.8, duration: 0.7 } }
          }
        ),
        /* @__PURE__ */ u.jsx(
          "path",
          {
            d: "M60 33 C44 33 31 46 31 69 L31 112 Q31 124 43 124 L77 124 Q89 124 89 112 L89 69 C89 46 76 33 60 33 Z",
            fill: "none",
            stroke: "#b98a2f",
            strokeWidth: "0.7",
            opacity: "0.65"
          }
        ),
        /* @__PURE__ */ u.jsx("ellipse", { cx: "48", cy: "52", rx: "17", ry: "9", fill: "#ffffff", opacity: "0.4", transform: "rotate(-16 48 52)" }),
        /* @__PURE__ */ u.jsx(
          k.g,
          {
            initial: draw ? { opacity: 0, scale: 0.6 } : false,
            animate: { opacity: 1, scale: 1 },
            style: { transformOrigin: "60px 84px" },
            transition: { delay: 0.9, type: "spring", stiffness: 240, damping: 14 },
            children: /* @__PURE__ */ u.jsx(
              "text",
              {
                x: "60",
                y: mono.length > 3 ? 92 : 95,
                textAnchor: "middle",
                fontFamily: RC_SCRIPT,
                fontSize: mono.length > 3 ? 26 : 31,
                fill: RC_C.roseDark,
                children: mono
              }
            )
          }
        ),
        /* @__PURE__ */ u.jsx("path", { d: "M45 105 Q60 111 75 105", stroke: "#b98a2f", strokeWidth: "0.9", fill: "none", opacity: "0.85" }),
        /* @__PURE__ */ u.jsx("path", { d: "M60 111 L63.4 114.6 60 118.2 56.6 114.6 Z", fill: "#b98a2f", opacity: "0.9" })
      ] })
    }
  ) });
}
function RCSwash({ go, delay = 1.7 }) {
  return /* @__PURE__ */ u.jsxs("svg", { width: "210", height: "30", viewBox: "0 0 210 30", fill: "none", style: { display: "block", margin: "10px auto 0" }, children: [
    /* @__PURE__ */ u.jsx(
      k.path,
      {
        d: "M14 15 C 44 7, 66 8, 88 14",
        stroke: RC_C.gold,
        strokeWidth: "1.15",
        strokeLinecap: "round",
        initial: { pathLength: 0 },
        animate: go ? { pathLength: 1 } : {},
        transition: { delay, duration: 0.85, ease: "easeInOut" }
      }
    ),
    /* @__PURE__ */ u.jsx(
      k.path,
      {
        d: "M196 15 C 166 23, 144 22, 122 16",
        stroke: RC_C.gold,
        strokeWidth: "1.15",
        strokeLinecap: "round",
        initial: { pathLength: 0 },
        animate: go ? { pathLength: 1 } : {},
        transition: { delay, duration: 0.85, ease: "easeInOut" }
      }
    ),
    /* @__PURE__ */ u.jsx(
      k.path,
      {
        d: "M97 15 C 100 9.5, 110 9.5, 113 15 C 110 20.5, 100 20.5, 97 15 Z",
        stroke: RC_C.rose,
        strokeWidth: "1.25",
        initial: { pathLength: 0 },
        animate: go ? { pathLength: 1 } : {},
        transition: { delay: delay + 0.5, duration: 0.5 }
      }
    ),
    /* @__PURE__ */ u.jsx(
      k.circle,
      {
        cx: "105",
        cy: "15",
        r: "2.6",
        fill: RC_C.rose,
        initial: { scale: 0, opacity: 0 },
        animate: go ? { scale: 1, opacity: 1 } : {},
        style: { transformOrigin: "105px 15px" },
        transition: { delay: delay + 0.85, type: "spring", stiffness: 320, damping: 12 }
      }
    ),
    /* @__PURE__ */ u.jsx("path", { d: "M101.5 11.8 Q100 9.6 98.2 10.2", stroke: RC_C.rose, strokeWidth: "0.9", fill: "none", opacity: "0.85" }),
    /* @__PURE__ */ u.jsx("path", { d: "M108.5 18.2 Q110 20.4 111.8 19.8", stroke: RC_C.rose, strokeWidth: "0.9", fill: "none", opacity: "0.85" }),
    /* @__PURE__ */ u.jsx("circle", { cx: "90", cy: "14", r: "1.3", fill: RC_C.gold, opacity: "0.8" }),
    /* @__PURE__ */ u.jsx("circle", { cx: "120", cy: "16", r: "1.3", fill: RC_C.gold, opacity: "0.8" })
  ] });
}
function RCStar({ x, y, delay = 0, size = 14, go = true }) {
  return /* @__PURE__ */ u.jsx(
    k.span,
    {
      style: { position: "absolute", left: "50%", top: "50%", marginLeft: x, marginTop: y, pointerEvents: "none", zIndex: 2 },
      animate: go ? { opacity: [0, 1, 0], scale: [0.35, 1, 0.35], rotate: [0, 25, 0] } : { opacity: 0 },
      transition: go ? { duration: 2.7, repeat: Infinity, delay, ease: "easeInOut" } : { duration: 0.2 },
      children: /* @__PURE__ */ u.jsx("svg", { width: size, height: size, viewBox: "0 0 14 14", children: /* @__PURE__ */ u.jsx("path", { d: "M7 0 L8.4 5.6 L14 7 L8.4 8.4 L7 14 L5.6 8.4 L0 7 L5.6 5.6 Z", fill: "#e9c877" }) })
    }
  );
}
function useInViewOnce(threshold) {
  const ref = w.useRef(null);
  const [v, setV] = w.useState(false);
  w.useEffect(() => {
    const el = ref.current;
    if (!el || v) return void 0;
    const io = new IntersectionObserver((es) => {
      es.forEach((e) => {
        if (e.isIntersecting) setV(true);
      });
    }, { threshold: threshold == null ? 0.2 : threshold });
    io.observe(el);
    return () => io.disconnect();
  }, [v]);
  return [ref, v];
}
function RCArchIcon({ children, size = 46 }) {
  return /* @__PURE__ */ u.jsxs("div", { style: {
    width: size,
    height: size * 1.14,
    margin: "0 auto 14px",
    position: "relative",
    borderRadius: "999px 999px 10px 10px",
    border: "1px solid rgba(185,138,47,0.55)",
    background: "linear-gradient(180deg,#fdf8ec,#f5e9cf)",
    boxShadow: "0 8px 18px -8px rgba(125,63,69,0.35), inset 0 1px 3px rgba(255,255,255,0.9)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: RC_C.roseDark
  }, children: [
    /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 4, borderRadius: "999px 999px 8px 8px", border: "1px solid rgba(185,138,47,0.3)", pointerEvents: "none" } }),
    children
  ] });
}
function RCEvIcon({ ev, size = 22 }) {
  const s = (ev && (ev.name || "") + " " + (ev.nameSw || "") || "").toLowerCase();
  let kind = "star";
  if (/(arriv|guest|welcome|karibu|mapokeo|check.?in|ingress)/.test(s)) kind = "door";
  else if (/(nikkah|nikah|ceremon|akid|vow|ring|harusi|wedding|ndoa|ijab|qabul)/.test(s)) kind = "rings";
  else if (/(mocktail|cocktail|drink|juice|refresh|kahawa|chai|bar|toast|beverage)/.test(s)) kind = "glass";
  else if (/(dinner|lunch|breakfast|food|feast|meal|chakula|dish|cake|keki|buffet|repast|karamu)/.test(s)) kind = "cloche";
  else if (/(dance|party|ngoma|music|band|dansi|celebrat|dj|entertain|send.?off|ragsa)/.test(s)) kind = "note";
  else if (/(photo|picha|picture|shoot)/.test(s)) kind = "camera";
  const P = { fill: "none", stroke: RC_C.goldDeep, strokeWidth: 4.2, strokeLinecap: "round", strokeLinejoin: "round" };
  return /* @__PURE__ */ u.jsxs("svg", { width: size, height: size, viewBox: "0 0 96 96", "aria-hidden": "true", style: { display: "block" }, children: [
    kind === "door" ? /* @__PURE__ */ u.jsxs("g", { ...P, children: [
      /* @__PURE__ */ u.jsx("path", { d: "M20 82 V42 C20 24 32 12 48 12 C64 12 76 24 76 42 V82" }),
      /* @__PURE__ */ u.jsx("path", { d: "M10 82 H86" }),
      /* @__PURE__ */ u.jsx("path", { d: "M40 82 V52 C40 44 44 40 48 40 C52 40 56 44 56 52 V82" })
    ] }) : null,
    kind === "rings" ? /* @__PURE__ */ u.jsxs("g", { ...P, children: [
      /* @__PURE__ */ u.jsx("circle", { cx: "38", cy: "56", r: "17" }),
      /* @__PURE__ */ u.jsx("circle", { cx: "58", cy: "56", r: "17" }),
      /* @__PURE__ */ u.jsx("path", { d: "M48 12 L56 22 L48 32 L40 22 Z" })
    ] }) : null,
    kind === "glass" ? /* @__PURE__ */ u.jsxs("g", { ...P, children: [
      /* @__PURE__ */ u.jsx("path", { d: "M28 16 H68 L48 46 Z" }),
      /* @__PURE__ */ u.jsx("path", { d: "M48 46 V76" }),
      /* @__PURE__ */ u.jsx("path", { d: "M34 76 H62" }),
      /* @__PURE__ */ u.jsx("path", { d: "M56 22 C58 28 56 34 52 38", strokeWidth: "3.2" })
    ] }) : null,
    kind === "cloche" ? /* @__PURE__ */ u.jsxs("g", { ...P, children: [
      /* @__PURE__ */ u.jsx("path", { d: "M24 62 C24 44 34 32 48 32 C62 32 72 44 72 62" }),
      /* @__PURE__ */ u.jsx("path", { d: "M14 62 H82" }),
      /* @__PURE__ */ u.jsx("path", { d: "M20 72 H76", strokeWidth: "3.2" }),
      /* @__PURE__ */ u.jsx("path", { d: "M48 32 V24" }),
      /* @__PURE__ */ u.jsx("circle", { cx: "48", cy: "20", r: "4" })
    ] }) : null,
    kind === "note" ? /* @__PURE__ */ u.jsxs("g", { ...P, children: [
      /* @__PURE__ */ u.jsx("path", { d: "M58 14 V58" }),
      /* @__PURE__ */ u.jsx("circle", { cx: "48", cy: "64", r: "11" }),
      /* @__PURE__ */ u.jsx("path", { d: "M58 14 C68 17 75 24 76 36" })
    ] }) : null,
    kind === "camera" ? /* @__PURE__ */ u.jsxs("g", { ...P, children: [
      /* @__PURE__ */ u.jsx("rect", { x: "14", y: "30", width: "68", height: "46", rx: "9" }),
      /* @__PURE__ */ u.jsx("path", { d: "M36 30 L41 19 H55 L60 30" }),
      /* @__PURE__ */ u.jsx("circle", { cx: "48", cy: "52", r: "13" })
    ] }) : null,
    kind === "star" ? /* @__PURE__ */ u.jsx("g", { ...P, children: /* @__PURE__ */ u.jsx("path", { d: "M48 10 C51 32 56 40 78 48 C56 56 51 64 48 86 C45 64 40 56 18 48 C40 40 45 32 48 10 Z" }) }) : null
  ] });
}
function RCEnv({ mono, hint, guestName, forYou, onOpenStart, onFlood, onDone }) {
  const [ph, setPh] = w.useState(0);
  const tm = w.useRef([]);
  w.useEffect(() => () => tm.current.forEach(clearTimeout), []);
  const seq = (fn, ms) => tm.current.push(setTimeout(fn, ms));
  const open = () => {
    if (ph !== 0) return;
    onOpenStart && onOpenStart();
    setPh(1);
    seq(() => setPh(2), 650);
    seq(() => setPh(3), 2700);
    seq(() => {
      onFlood && onFlood();
    }, 3050);
    seq(() => onDone && onDone(), 4120);
  };
  const tex = "./art/rose-envelope-texture.jpg";
  return /* @__PURE__ */ u.jsx(
    k.div,
    {
      initial: { opacity: 0 },
      animate: { opacity: 1 },
      transition: { duration: 0.6 },
      style: {
        position: "fixed",
        inset: 0,
        zIndex: 70,
        overflow: "hidden",
        perspective: 1500,
        WebkitPerspective: 1500,
        touchAction: "manipulation",
        pointerEvents: ph >= 3 ? "none" : "auto"
      },
      children: /* @__PURE__ */ u.jsxs(
        k.div,
        {
          style: { position: "absolute", inset: 0, transformStyle: "preserve-3d", willChange: "transform" },
          animate: ph >= 3 ? { y: "118%" } : { y: "0%" },
          transition: ph >= 3 ? { duration: 1.25, ease: [0.52, 0, 0.86, 0.42] } : { duration: 0.3 },
          children: [
            /* @__PURE__ */ u.jsx("div", { style: {
              position: "absolute",
              inset: "-1.5%",
              backgroundImage: "url(" + tex + ")",
              backgroundSize: "cover",
              backgroundPosition: "50% 32%"
            } }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(248,241,229,0.12), rgba(240,228,204,0.28))" } }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, boxShadow: "inset 0 0 140px rgba(96,70,38,0.26)" } }),
            /* @__PURE__ */ u.jsx("div", { style: {
              position: "absolute",
              inset: "-1.5%",
              zIndex: 1,
              clipPath: "polygon(0 0, 100% 0, 50% 62.5%)",
              background: "radial-gradient(ellipse 95% 64% at 50% 24%, #fdf6e0 0%, #f5e5bd 52%, #ecd6a4 100%)"
            } }),
            /* @__PURE__ */ u.jsxs("svg", { style: { position: "absolute", inset: 0, zIndex: 1, pointerEvents: "none" }, viewBox: "0 0 100 100", preserveAspectRatio: "none", children: [
              /* @__PURE__ */ u.jsx("path", { d: "M50 7 C 39 7 33 17 33 30 L33 56 L67 56 L67 30 C67 17 61 7 50 7 Z", fill: "rgba(255,250,238,0.5)", stroke: "#b98a2f", strokeWidth: "0.5", opacity: "0.85" }),
              /* @__PURE__ */ u.jsx("path", { d: "M50 11 C 41.5 11 36.5 19.5 36.5 31 L36.5 53 L63.5 53 L63.5 31 C63.5 19.5 58.5 11 50 11 Z", fill: "none", stroke: "#b98a2f", strokeWidth: "0.28", opacity: "0.6" })
            ] }),
            /* @__PURE__ */ u.jsxs("svg", { style: { position: "absolute", inset: 0, zIndex: 2, pointerEvents: "none" }, viewBox: "0 0 100 100", preserveAspectRatio: "none", children: [
              /* @__PURE__ */ u.jsx("path", { d: "M50 62.5 L0.4 0.4", stroke: "#fffdf2", strokeWidth: "1.05", fill: "none", opacity: ph >= 2 ? 0.95 : 0.35, style: { transition: "opacity .8s" } }),
              /* @__PURE__ */ u.jsx("path", { d: "M50 62.5 L99.6 0.4", stroke: "#fffdf2", strokeWidth: "1.05", fill: "none", opacity: ph >= 2 ? 0.95 : 0.35, style: { transition: "opacity .8s" } })
            ] }),
            /* @__PURE__ */ u.jsx(
              k.div,
              {
                style: {
                  position: "absolute",
                  inset: 0,
                  zIndex: 1,
                  background: "radial-gradient(ellipse 72% 42% at 50% 60%, rgba(80,52,26,0.32), transparent 62%)"
                },
                initial: { opacity: 0 },
                animate: ph >= 2 ? { opacity: 1 } : {},
                transition: { duration: 0.9 }
              }
            ),
            /* @__PURE__ */ u.jsx(
              k.div,
              {
                style: {
                  position: "absolute",
                  inset: "-1.5%",
                  zIndex: 4,
                  clipPath: "polygon(0 0, 100% 0, 50% 62.5%)",
                  backgroundImage: "linear-gradient(180deg, rgba(255,252,244,0.16) 0%, rgba(240,224,192,0.14) 30%, rgba(96,66,30,0.12) 55%, rgba(96,66,30,0.30) 61%, rgba(96,66,30,0) 69%), url(" + tex + ")",
                  backgroundSize: "cover",
                  backgroundPosition: "50% 32%",
                  transformOrigin: "50% 0%",
                  backfaceVisibility: "hidden",
                  WebkitBackfaceVisibility: "hidden",
                  willChange: "transform"
                },
                animate: ph >= 2 ? { rotateX: -158 } : { rotateX: 0 },
                transition: { duration: 1.65, ease: [0.68, 0, 0.16, 1] }
              }
            ),
            /* @__PURE__ */ u.jsx(
              k.div,
              {
                style: {
                  position: "absolute",
                  inset: "-1.5%",
                  zIndex: 4,
                  clipPath: "polygon(0 0, 100% 0, 50% 62.5%)",
                  backfaceVisibility: "hidden",
                  WebkitBackfaceVisibility: "hidden",
                  background: "linear-gradient(180deg, rgba(70,46,20,0.28) 0%, rgba(70,46,20,0.5) 68%, rgba(70,46,20,0) 96%)",
                  transformOrigin: "50% 0%",
                  pointerEvents: "none",
                  willChange: "transform, opacity"
                },
                initial: { rotateX: 0, opacity: 0 },
                animate: ph >= 2 ? { rotateX: -158, opacity: 1 } : { rotateX: 0, opacity: 0 },
                transition: { rotateX: { duration: 1.65, ease: [0.68, 0, 0.16, 1] }, opacity: { duration: 1.05, ease: "easeOut" } }
              }
            ),
            /* @__PURE__ */ u.jsxs("div", { style: {
              position: "absolute",
              inset: 14,
              zIndex: 5,
              pointerEvents: "none",
              border: "1px solid rgba(185,138,47,0.5)"
            }, children: [
              /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 5, border: "1px solid rgba(185,138,47,0.28)" } }),
              [["top", 5, "left", 5, 0], ["top", 5, "right", 5, 90], ["bottom", 5, "right", 5, 180], ["bottom", 5, "left", 5, 270]].map((c3, i) => /* @__PURE__ */ u.jsxs(
                "svg",
                {
                  width: "26",
                  height: "26",
                  viewBox: "0 0 30 30",
                  fill: "none",
                  stroke: RC_C.gold,
                  strokeWidth: "1.5",
                  style: { position: "absolute", [c3[0]]: c3[1], [c3[2]]: c3[3], transform: "rotate(" + c3[4] + "deg)" },
                  children: [
                    /* @__PURE__ */ u.jsx("path", { d: "M3 27 V10 Q3 3 10 3 H27" }),
                    /* @__PURE__ */ u.jsx("path", { d: "M8.5 27 V12.5 Q8.5 8.5 12.5 8.5 H27", opacity: "0.5" })
                  ]
                },
                i
              ))
            ] }),
            ph < 3 ? /* @__PURE__ */ u.jsx(
              k.div,
              {
                style: {
                  position: "absolute",
                  top: "-20%",
                  bottom: "-20%",
                  width: "40%",
                  zIndex: 6,
                  background: "linear-gradient(105deg, transparent, rgba(255,255,255,0.32) 50%, transparent)",
                  pointerEvents: "none",
                  willChange: "transform"
                },
                initial: { x: "-160%" },
                animate: { x: "380%" },
                transition: { duration: 4.6, repeat: Infinity, repeatDelay: 5.5, ease: "easeInOut" }
              }
            ) : null,
            /* @__PURE__ */ u.jsxs("div", { style: { position: "absolute", left: 0, right: 0, top: "62%", zIndex: 7, textAlign: "center" }, children: [
              /* @__PURE__ */ u.jsxs(
                k.button,
                {
                  onClick: open,
                  whileHover: ph === 0 ? { scale: 1.06 } : {},
                  whileTap: ph === 0 ? { scale: 0.93 } : {},
                  style: {
                    position: "relative",
                    y: "-50%",
                    background: "none",
                    border: 0,
                    padding: 0,
                    cursor: ph === 0 ? "pointer" : "default"
                  },
                  animate: ph >= 2 ? { scale: 0.4, opacity: 0, y: "-190%" } : ph === 1 ? { scale: 0.88 } : {},
                  transition: ph >= 2 ? { delay: 0.15, duration: 0.8, ease: "easeIn" } : { duration: 0.24, ease: "easeOut" },
                  children: [
                    ph === 0 ? /* @__PURE__ */ u.jsx(
                      k.span,
                      {
                        style: { display: "block" },
                        animate: { scale: [1, 1.03, 1] },
                        transition: { duration: 3.4, repeat: Infinity, ease: "easeInOut" },
                        children: /* @__PURE__ */ u.jsx(RCSeal, { size: 106, mono })
                      }
                    ) : /* @__PURE__ */ u.jsx(RCSeal, { size: 106, mono }),
                    ph === 0 ? /* @__PURE__ */ u.jsxs("span", { children: [
                      /* @__PURE__ */ u.jsx(RCStar, { x: -66, y: -58, delay: 0, size: 13 }),
                      /* @__PURE__ */ u.jsx(RCStar, { x: 54, y: -66, delay: 1.1, size: 11 }),
                      /* @__PURE__ */ u.jsx(RCStar, { x: 62, y: 42, delay: 2, size: 12 }),
                      /* @__PURE__ */ u.jsx(RCStar, { x: -58, y: 50, delay: 0.6, size: 10 })
                    ] }) : null,
                    ph >= 1 ? /* @__PURE__ */ u.jsx(
                      k.span,
                      {
                        style: {
                          position: "absolute",
                          left: "50%",
                          top: "50%",
                          x: "-50%",
                          y: "-50%",
                          width: 150,
                          height: 150,
                          borderRadius: "50%",
                          pointerEvents: "none",
                          background: "radial-gradient(circle, rgba(255,244,200,0.95) 0%, rgba(255,214,120,0.55) 46%, rgba(255,214,120,0) 70%)",
                          willChange: "transform, opacity"
                        },
                        initial: { scale: 0.4, opacity: 1 },
                        animate: { scale: 2.4, opacity: 0 },
                        transition: { duration: 0.7, ease: "easeOut" }
                      }
                    ) : null
                  ]
                }
              ),
              guestName ? /* @__PURE__ */ u.jsxs(
                k.p,
                {
                  style: { margin: "4px 0 0", fontFamily: RC_SCRIPT, fontSize: 27, color: RC_C.roseDark, lineHeight: 1.2 },
                  animate: ph === 0 ? { opacity: 1 } : { opacity: 0 },
                  transition: { duration: 0.4 },
                  children: [
                    forYou,
                    " ",
                    guestName
                  ]
                }
              ) : null,
              /* @__PURE__ */ u.jsx(
                k.p,
                {
                  style: {
                    margin: guestName ? "10px 0 0" : "34px 0 0",
                    fontFamily: RC_CAPS,
                    fontSize: 11,
                    letterSpacing: "0.44em",
                    textTransform: "uppercase",
                    color: RC_C.goldDeep
                  },
                  animate: ph === 0 ? { opacity: [0.45, 1, 0.45] } : { opacity: 0 },
                  transition: ph === 0 ? { duration: 2.8, repeat: Infinity } : { duration: 0.35 },
                  children: hint
                }
              ),
              /* @__PURE__ */ u.jsx(
                k.div,
                {
                  style: { margin: "10px auto 0", width: 16 },
                  animate: ph === 0 ? { y: [0, 7, 0], opacity: [0.5, 1, 0.5] } : { opacity: 0 },
                  transition: ph === 0 ? { duration: 2.2, repeat: Infinity } : { duration: 0.3 },
                  children: /* @__PURE__ */ u.jsx("svg", { width: "16", height: "10", viewBox: "0 0 16 10", fill: "none", stroke: RC_C.gold, strokeWidth: "1.6", children: /* @__PURE__ */ u.jsx("path", { d: "M1.5 1.5 8 8 14.5 1.5" }) })
                }
              )
            ] }),
            ph < 3 ? /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, zIndex: 8, pointerEvents: "none" }, children: /* @__PURE__ */ u.jsx(RCSpark, { burst: ph }) }) : null
          ]
        }
      )
    }
  );
}
function RCDressChip({ tag, txt }) {
  return /* @__PURE__ */ u.jsxs("span", { style: {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    marginTop: 10,
    padding: "5px 12px",
    borderRadius: 999,
    border: "1px solid rgba(185,138,47,0.4)",
    background: "rgba(185,138,47,0.08)",
    fontFamily: RC_CAPS,
    fontSize: 9.5,
    letterSpacing: "0.22em",
    textTransform: "uppercase",
    color: RC_C.goldDeep
  }, children: [
    /* @__PURE__ */ u.jsx("svg", { width: "11", height: "11", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", children: /* @__PURE__ */ u.jsx("path", { d: "M9 3h6l1 4 4 2-2 12H6L4 9l4-2z" }) }),
    tag,
    ": ",
    txt
  ] });
}
function RCUnit({ v, label, delay, go = true }) {
  return /* @__PURE__ */ u.jsx(RCRev, { delay, y: 24, children: /* @__PURE__ */ u.jsxs(
    k.div,
    {
      whileHover: { y: -5, boxShadow: "0 26px 50px -22px rgba(125,63,69,0.45)" },
      style: {
        width: "clamp(74px,20vw,88px)",
        padding: "22px 0 16px",
        textAlign: "center",
        background: "linear-gradient(180deg,#fdfaf2,#f7efdd)",
        borderRadius: "999px 999px 16px 16px",
        border: "1px solid rgba(185,138,47,0.55)",
        position: "relative",
        overflow: "hidden",
        boxShadow: "0 18px 40px -20px rgba(125,63,69,0.35), inset 0 1px 3px rgba(255,255,255,0.9)"
      },
      children: [
        /* @__PURE__ */ u.jsx("div", { style: {
          position: "absolute",
          inset: 5,
          borderRadius: "999px 999px 12px 12px",
          border: "1px solid rgba(185,138,47,0.3)",
          pointerEvents: "none"
        } }),
        /* @__PURE__ */ u.jsx(
          k.div,
          {
            style: {
              position: "absolute",
              top: "-30%",
              bottom: "-30%",
              width: "34%",
              background: "linear-gradient(105deg, transparent, rgba(255,236,180,0.6) 50%, transparent)",
              pointerEvents: "none",
              willChange: "transform"
            },
            initial: { x: "-240%" },
            animate: go ? { x: "420%" } : {},
            transition: { duration: 2.8, repeat: Infinity, repeatDelay: 3.4, delay: delay + 0.8, ease: "easeInOut" }
          }
        ),
        /* @__PURE__ */ u.jsxs("div", { style: { position: "relative" }, children: [
          /* @__PURE__ */ u.jsx(
            k.span,
            {
              initial: { y: 12, opacity: 0 },
              animate: { y: 0, opacity: 1 },
              transition: { duration: 0.45, ease: RC_EASE },
              style: { display: "block", fontFamily: RC_SERIF, fontSize: "clamp(26px,7vw,32px)", color: RC_C.roseDark, lineHeight: 1.1 },
              children: String(v).padStart(2, "0")
            },
            v
          ),
          /* @__PURE__ */ u.jsx("span", { style: {
            display: "block",
            fontFamily: RC_CAPS,
            fontSize: 8.5,
            letterSpacing: "0.24em",
            textTransform: "uppercase",
            color: RC_C.inkSoft,
            marginTop: 5
          }, children: label })
        ] })
      ]
    }
  ) });
}
function RCProcession({ evList, mob, lang, t, fmtDay }) {
  const railRef = w.useRef(null);
  const { scrollYProgress: prog } = Jr({ target: railRef, offset: ["start 0.85", "end 0.55"] });
  const roseTop = St(prog, [0, 1], ["0.4%", "99.6%"]);
  const ROMAN = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];
  return /* @__PURE__ */ u.jsxs("section", { style: {
    position: "relative",
    padding: "clamp(76px,12vw,116px) 22px",
    overflow: "hidden",
    ...RC_CV,
    background: "linear-gradient(180deg," + RC_C.bg + " 0%, #f5e9de 55%, " + RC_C.bg + " 100%)"
  }, children: [
    /* @__PURE__ */ u.jsx(RCMark, { word: t.celebration }),
    /* @__PURE__ */ u.jsx(RCMotes, { density: 6 }),
    /* @__PURE__ */ u.jsx(RCHead, { eyebrow: t.schedule, title: t.celebration }),
    /* @__PURE__ */ u.jsxs("div", { ref: railRef, style: { position: "relative", zIndex: 1, maxWidth: 920, margin: "52px auto 0" }, children: [
      /* @__PURE__ */ u.jsx("div", { "aria-hidden": "true", style: mob ? { position: "absolute", left: 16, top: 8, bottom: 8, width: 1.5, background: "rgba(185,138,47,0.16)" } : { position: "absolute", left: "50%", top: 8, bottom: 8, width: 1.5, marginLeft: -0.75, background: "rgba(185,138,47,0.15)" } }),
      /* @__PURE__ */ u.jsx(k.div, { "aria-hidden": "true", style: mob ? {
        position: "absolute",
        left: 16,
        top: 8,
        bottom: 8,
        width: 2,
        transformOrigin: "top center",
        scaleY: prog,
        background: "linear-gradient(180deg," + RC_C.gold + " 0%, #dcb95f 55%, " + RC_C.goldDeep + " 100%)"
      } : {
        position: "absolute",
        left: "50%",
        top: 8,
        bottom: 8,
        width: 2,
        marginLeft: -1,
        transformOrigin: "top center",
        scaleY: prog,
        background: "linear-gradient(180deg," + RC_C.gold + " 0%, #dcb95f 55%, " + RC_C.goldDeep + " 100%)"
      } }),
      /* @__PURE__ */ u.jsx(k.div, { "aria-hidden": "true", style: { position: "absolute", left: mob ? 16 : "50%", top: roseTop, x: "-50%", y: "-50%", zIndex: 3, pointerEvents: "none" }, children: /* @__PURE__ */ u.jsx("div", { style: {
        width: 27,
        height: 27,
        borderRadius: "50%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "radial-gradient(circle at 36% 30%, #fffdf4 0%, #f7e8c8 55%, #e6cd96 100%)",
        border: "1px solid rgba(185,138,47,0.75)",
        boxShadow: "0 6px 14px -6px rgba(125,63,69,0.5), 0 0 0 5px rgba(248,241,229,0.8)"
      }, children: /* @__PURE__ */ u.jsx(
        k.svg,
        {
          width: "13",
          height: "13",
          viewBox: "0 0 96 96",
          style: { display: "block" },
          animate: { rotate: 360 },
          transition: { duration: 14, repeat: Infinity, ease: "linear" },
          children: /* @__PURE__ */ u.jsx(
            "path",
            {
              d: "M48 10 C51 32 56 40 78 48 C56 56 51 64 48 86 C45 64 40 56 18 48 C40 40 45 32 48 10 Z",
              fill: "none",
              stroke: RC_C.goldDeep,
              strokeWidth: "7"
            }
          )
        }
      ) }) }),
      evList.map((ev, idx) => {
        const base = Math.min(idx * 0.07, 0.35);
        const leftSide = idx % 2 === 1;
        const vp = { once: true, margin: "-10% 0px -10% 0px" };
        return /* @__PURE__ */ u.jsxs("div", { style: {
          position: "relative",
          display: "flex",
          justifyContent: mob ? "flex-start" : leftSide ? "flex-start" : "flex-end",
          padding: mob ? "14px 0 14px 42px" : "16px 0"
        }, children: [
          /* @__PURE__ */ u.jsx(
            k.div,
            {
              "aria-hidden": "true",
              initial: { opacity: 0, scale: 0, rotate: 45 },
              whileInView: { opacity: 1, scale: 1, rotate: 45 },
              viewport: vp,
              transition: { delay: base + 0.1, type: "spring", stiffness: 360, damping: 15 },
              style: mob ? {
                position: "absolute",
                left: 16,
                top: 42,
                width: 11,
                height: 11,
                x: "-50%",
                marginLeft: 0.5,
                background: "linear-gradient(135deg,#f9ecd0,#dcbc77)",
                border: "1px solid rgba(185,138,47,0.8)",
                boxShadow: "0 4px 10px -4px rgba(125,63,69,0.5)"
              } : {
                position: "absolute",
                left: "50%",
                top: 42,
                width: 11,
                height: 11,
                x: "-50%",
                background: "linear-gradient(135deg,#f9ecd0,#dcbc77)",
                border: "1px solid rgba(185,138,47,0.8)",
                boxShadow: "0 4px 10px -4px rgba(125,63,69,0.5)"
              }
            }
          ),
          /* @__PURE__ */ u.jsx(
            k.div,
            {
              "aria-hidden": "true",
              initial: { scaleX: 0 },
              whileInView: { scaleX: 1 },
              viewport: vp,
              transition: { delay: base + 0.28, duration: 0.6, ease: RC_EASE },
              style: mob ? {
                position: "absolute",
                left: 21,
                top: 47,
                width: 21,
                height: 1,
                transformOrigin: "left center",
                background: "linear-gradient(90deg, rgba(185,138,47,0.85), rgba(185,138,47,0.2))"
              } : {
                position: "absolute",
                top: 47,
                height: 1,
                width: 50,
                transformOrigin: leftSide ? "right center" : "left center",
                left: leftSide ? "auto" : "50%",
                right: leftSide ? "50%" : "auto",
                background: "linear-gradient(" + (leftSide ? "270deg" : "90deg") + ", rgba(185,138,47,0.85), rgba(185,138,47,0.18))"
              }
            }
          ),
          /* @__PURE__ */ u.jsx(
            k.div,
            {
              initial: { opacity: 0, y: 34, x: mob ? -16 : leftSide ? -26 : 26 },
              whileInView: { opacity: 1, y: 0, x: 0 },
              viewport: vp,
              transition: { delay: base, duration: 0.85, ease: RC_EASE },
              style: { width: mob ? "100%" : "calc(50% - 58px)" },
              children: /* @__PURE__ */ u.jsxs(
                k.div,
                {
                  whileHover: { y: -4 },
                  whileTap: { scale: 0.985 },
                  transition: { type: "spring", stiffness: 330, damping: 22 },
                  style: {
                    position: "relative",
                    overflow: "hidden",
                    textAlign: "left",
                    background: "linear-gradient(180deg,#fdfaf3,#f8efdf)",
                    border: "1px solid rgba(185,138,47,0.42)",
                    borderRadius: 16,
                    padding: "19px 20px 17px",
                    boxShadow: "0 22px 46px -24px rgba(125,63,69,0.42), inset 0 1px 3px rgba(255,255,255,0.9)"
                  },
                  children: [
                    /* @__PURE__ */ u.jsx("span", { "aria-hidden": "true", style: {
                      position: "absolute",
                      top: 6,
                      right: 13,
                      fontFamily: RC_CAPS,
                      fontSize: 44,
                      lineHeight: 1,
                      color: RC_C.roseDark,
                      opacity: 0.07,
                      pointerEvents: "none"
                    }, children: ROMAN[idx] || "\u2726" }),
                    /* @__PURE__ */ u.jsx(
                      k.div,
                      {
                        "aria-hidden": "true",
                        initial: { scaleX: 0 },
                        whileInView: { scaleX: 1 },
                        viewport: vp,
                        transition: { delay: base + 0.22, duration: 0.55, ease: RC_EASE },
                        style: {
                          position: "absolute",
                          left: 7,
                          right: 7,
                          top: 7,
                          height: 1,
                          transformOrigin: "left center",
                          background: "rgba(185,138,47,0.38)",
                          pointerEvents: "none"
                        }
                      }
                    ),
                    /* @__PURE__ */ u.jsx(
                      k.div,
                      {
                        "aria-hidden": "true",
                        initial: { scaleY: 0 },
                        whileInView: { scaleY: 1 },
                        viewport: vp,
                        transition: { delay: base + 0.3, duration: 0.5, ease: RC_EASE },
                        style: {
                          position: "absolute",
                          top: 7,
                          bottom: 7,
                          right: 7,
                          width: 1,
                          transformOrigin: "top center",
                          background: "rgba(185,138,47,0.38)",
                          pointerEvents: "none"
                        }
                      }
                    ),
                    /* @__PURE__ */ u.jsx(
                      k.div,
                      {
                        "aria-hidden": "true",
                        initial: { scaleX: 0 },
                        whileInView: { scaleX: 1 },
                        viewport: vp,
                        transition: { delay: base + 0.38, duration: 0.55, ease: RC_EASE },
                        style: {
                          position: "absolute",
                          left: 7,
                          right: 7,
                          bottom: 7,
                          height: 1,
                          transformOrigin: "right center",
                          background: "rgba(185,138,47,0.38)",
                          pointerEvents: "none"
                        }
                      }
                    ),
                    /* @__PURE__ */ u.jsx(
                      k.div,
                      {
                        "aria-hidden": "true",
                        initial: { scaleY: 0 },
                        whileInView: { scaleY: 1 },
                        viewport: vp,
                        transition: { delay: base + 0.46, duration: 0.5, ease: RC_EASE },
                        style: {
                          position: "absolute",
                          top: 7,
                          bottom: 7,
                          left: 7,
                          width: 1,
                          transformOrigin: "bottom center",
                          background: "rgba(185,138,47,0.38)",
                          pointerEvents: "none"
                        }
                      }
                    ),
                    /* @__PURE__ */ u.jsx(
                      k.div,
                      {
                        "aria-hidden": "true",
                        initial: { x: "-170%" },
                        whileInView: { x: "280%" },
                        viewport: vp,
                        transition: { delay: base + 0.5, duration: 1.15, ease: "easeInOut" },
                        style: {
                          position: "absolute",
                          top: 0,
                          bottom: 0,
                          left: 0,
                          width: "42%",
                          transform: "skewX(-16deg)",
                          background: "linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,252,240,0.85) 50%, rgba(255,255,255,0) 100%)",
                          pointerEvents: "none"
                        }
                      }
                    ),
                    /* @__PURE__ */ u.jsxs("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }, children: [
                      /* @__PURE__ */ u.jsxs(
                        k.div,
                        {
                          initial: { opacity: 0, x: -16 },
                          whileInView: { opacity: 1, x: 0 },
                          viewport: vp,
                          transition: { delay: base + 0.16, duration: 0.65, ease: RC_EASE },
                          children: [
                            ev.time ? /* @__PURE__ */ u.jsx("div", { style: {
                              fontFamily: RC_SERIF,
                              fontSize: "clamp(21px,4.8vw,25px)",
                              color: RC_C.goldDeep,
                              lineHeight: 1.05,
                              letterSpacing: "0.03em"
                            }, children: ev.time }) : null,
                            ev.date ? /* @__PURE__ */ u.jsx("div", { style: {
                              fontFamily: RC_CAPS,
                              fontSize: 8.5,
                              letterSpacing: "0.27em",
                              textTransform: "uppercase",
                              color: RC_C.goldDeep,
                              opacity: 0.85,
                              marginTop: 5
                            }, children: fmtDay(ev.date) }) : null
                          ]
                        }
                      ),
                      /* @__PURE__ */ u.jsx(
                        k.div,
                        {
                          "aria-hidden": "true",
                          initial: { opacity: 0, scale: 0, rotate: -12 },
                          whileInView: { opacity: 1, scale: 1, rotate: 0 },
                          viewport: vp,
                          transition: { delay: base + 0.2, type: "spring", stiffness: 320, damping: 14 },
                          style: {
                            flex: "0 0 auto",
                            width: 42,
                            height: 42,
                            borderRadius: "50%",
                            background: "radial-gradient(circle at 34% 28%, #fffef9 0%, #f9efdb 55%, #ecdcb9 100%)",
                            border: "1px solid rgba(185,138,47,0.6)",
                            boxShadow: "0 10px 18px -9px rgba(125,63,69,0.5), inset 0 1px 3px rgba(255,255,255,0.95), inset 0 0 0 3px rgba(185,138,47,0.14)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center"
                          },
                          children: /* @__PURE__ */ u.jsx(RCEvIcon, { ev, size: 19 })
                        }
                      )
                    ] }),
                    /* @__PURE__ */ u.jsx(
                      k.div,
                      {
                        "aria-hidden": "true",
                        initial: { scaleX: 0 },
                        whileInView: { scaleX: 1 },
                        viewport: vp,
                        transition: { delay: base + 0.4, duration: 0.6, ease: RC_EASE },
                        style: {
                          height: 1,
                          margin: "13px 0 11px",
                          transformOrigin: "left center",
                          background: "linear-gradient(90deg, rgba(185,138,47,0.65), rgba(185,138,47,0.08))"
                        }
                      }
                    ),
                    /* @__PURE__ */ u.jsxs(
                      k.div,
                      {
                        initial: { opacity: 0, y: 12 },
                        whileInView: { opacity: 1, y: 0 },
                        viewport: vp,
                        transition: { delay: base + 0.3, duration: 0.6, ease: RC_EASE },
                        children: [
                          /* @__PURE__ */ u.jsx("div", { style: {
                            fontFamily: RC_SERIF,
                            fontSize: "clamp(16.5px,3vw,19px)",
                            color: RC_C.ink,
                            lineHeight: 1.3,
                            letterSpacing: "0.05em",
                            textTransform: "uppercase"
                          }, children: lang === "sw" ? ev.nameSw || ev.name : ev.name || ev.nameSw }),
                          ev.nameSw && lang !== "sw" && ev.name ? /* @__PURE__ */ u.jsx("div", { style: { fontFamily: RC_SERIF, fontStyle: "italic", fontSize: 13.5, color: RC_C.goldDeep, marginTop: 3 }, children: ev.nameSw }) : null
                        ]
                      }
                    ),
                    ev.venue ? /* @__PURE__ */ u.jsxs("div", { style: { display: "flex", alignItems: "baseline", gap: 7, fontFamily: RC_SANS, fontSize: 13, color: RC_C.inkSoft, marginTop: 9 }, children: [
                      /* @__PURE__ */ u.jsx("span", { "aria-hidden": "true", style: { color: RC_C.gold, fontSize: 11 }, children: "\u25C6" }),
                      /* @__PURE__ */ u.jsx("span", { children: ev.venue })
                    ] }) : null,
                    ev.dressCode ? /* @__PURE__ */ u.jsx(RCDressChip, { tag: t.dressTag, txt: ev.dressCode }) : null,
                    ev.notes ? /* @__PURE__ */ u.jsx("div", { style: { fontFamily: RC_SERIF, fontStyle: "italic", fontSize: 13, color: RC_C.inkSoft, lineHeight: 1.65, marginTop: 9 }, children: ev.notes }) : null,
                    ev.mapsUrl ? /* @__PURE__ */ u.jsxs("a", { href: ev.mapsUrl, target: "_blank", rel: "noreferrer", style: { display: "inline-block", marginTop: 12, fontFamily: RC_CAPS, fontSize: 10, letterSpacing: "0.24em", textTransform: "uppercase", color: RC_C.goldDeep, textDecoration: "none", borderBottom: "1px solid rgba(185,138,47,0.45)", paddingBottom: 2 }, children: [
                      t.mapLink,
                      " \u2192"
                    ] }) : null
                  ]
                }
              )
            }
          )
        ] }, idx);
      })
    ] })
  ] });
}
function RC({ data, guest, autoOpen = false, onRsvp, onGuestbook, guestbookMessages = [], inviteUrl = "" }) {
  const [lang, setLang] = w.useState(data.language ?? "en");
  const t = RC_T[lang] ?? RC_T.en;
  const [flood, setFlood] = w.useState(autoOpen);
  const [envGone, setEnvGone] = w.useState(autoOpen);
  const [petalsOn, setPetalsOn] = w.useState(autoOpen);
  w.useEffect(() => {
    if (!envGone || petalsOn) return void 0;
    const id = setTimeout(() => setPetalsOn(true), 420);
    return () => clearTimeout(id);
  }, [envGone, petalsOn]);
  const [cdRef, cdIn] = useInViewOnce(0.22);
  const [rsvpRef, rsvpIn] = useInViewOnce(0.15);
  const [mob, setMob] = w.useState(() => window.innerWidth < 680);
  w.useEffect(() => {
    const f = () => setMob(window.innerWidth < 680);
    window.addEventListener("resize", f);
    return () => window.removeEventListener("resize", f);
  }, []);
  const ev0 = data.events && data.events[0];
  const story = lang === "sw" && data.storySw || data.storyEn || "";
  const quote = lang === "sw" && data.quoteSw || data.quoteEn || "";
  const mono = (data.sealText || (data.brideName || "F")[0] + "\xB7" + (data.groomName || "S")[0]).toUpperCase();
  const heroImg = data.heroImage && String(data.heroImage).trim() || "./art/rose2-hero.jpg";
  const handleFlood = () => {
    setFlood(true);
  };
  w.useEffect(() => {
    [heroImg, "./art/rose2-branch.png", "./art/rose2-rings.png", "./art/rose2-doves.png"].forEach((src) => {
      try {
        const im = new Image();
        im.src = src;
        if (im.decode) im.decode().catch(() => {
        });
      } catch (_) {
      }
    });
  }, [heroImg]);
  const target = w.useMemo(() => {
    if (!ev0) return null;
    const d = /* @__PURE__ */ new Date(ev0.date + "T" + (ev0.time || "16:00") + ":00");
    return isNaN(d.getTime()) ? null : d.getTime();
  }, [ev0 && ev0.date, ev0 && ev0.time]);
  const [now, setNow] = w.useState(() => Date.now());
  w.useEffect(() => {
    if (!target) return;
    const id = setInterval(() => setNow(Date.now()), 1e3);
    return () => clearInterval(id);
  }, [target]);
  const diff = target ? Math.max(0, target - now) : 0;
  const cd = { d: Math.floor(diff / 864e5), h: Math.floor(diff / 36e5) % 24, m: Math.floor(diff / 6e4) % 60, s: Math.floor(diff / 1e3) % 60 };
  const loc = lang === "sw" ? "sw-TZ" : "en-GB";
  const dateLabel = ev0 ? (/* @__PURE__ */ new Date(ev0.date + "T12:00:00")).toLocaleDateString(loc, { weekday: "long", day: "numeric", month: "long", year: "numeric" }) : "";
  const rsvpBy = ev0 ? new Date((/* @__PURE__ */ new Date(ev0.date + "T12:00:00")).getTime() - 14 * 864e5).toLocaleDateString(loc, { day: "numeric", month: "long" }) : "";
  const [copied, setCopied] = w.useState(-1);
  const doCopy = async (text, i) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch (_) {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand("copy");
      } catch (e) {
      }
      ta.remove();
    }
    setCopied(i);
    setTimeout(() => setCopied(-1), 2200);
  };
  const addCal = () => {
    if (!ev0) return;
    const dt = (ev0.date || "").replace(/-/g, "");
    const tm2 = (ev0.time || "16:00").replace(":", "") + "00";
    const end = String((parseInt((ev0.time || "16:00").split(":")[0], 10) + 4) % 24).padStart(2, "0") + (ev0.time || "16:00").split(":")[1] + "00";
    const ics = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "BEGIN:VEVENT",
      "DTSTART:" + dt + "T" + tm2,
      "DTEND:" + dt + "T" + end,
      "SUMMARY:" + (data.groomName || "") + " & " + (data.brideName || "") + " \u2014 Harusi",
      "LOCATION:" + (ev0.venue || ""),
      "END:VEVENT",
      "END:VCALENDAR"
    ].join("\r\n");
    const url = URL.createObjectURL(new Blob([ics], { type: "text/calendar" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "harusi.ics";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4e3);
  };
  const [rsvpOpen, setRsvpOpen] = w.useState(false);
  const [sealFlash, setSealFlash] = w.useState(false);
  const openRsvp = () => {
    if (rsvpOpen) return;
    setSealFlash(true);
    setTimeout(() => setRsvpOpen(true), 480);
  };
  const [attending, setAttending] = w.useState(null);
  const [rsvpName, setRsvpName] = w.useState(guest && guest.name || "");
  const [companions, setCompanions] = w.useState(0);
  const [song, setSong] = w.useState("");
  const [children, setChildren] = w.useState("");
  const [dietary, setDietary] = w.useState("");
  const [rsvpBusy, setRsvpBusy] = w.useState(false);
  const [rsvpDone, setRsvpDone] = w.useState(guest && guest.rsvpStatus && guest.rsvpStatus !== "pending");
  const submitRsvp = async (e) => {
    e.preventDefault();
    if (attending === null || !rsvpName.trim() || rsvpBusy) return;
    setRsvpBusy(true);
    const pack = [dietary && dietary, song && "Song: " + song, children && "Children: " + children].filter(Boolean).join(" \xB7 ");
    try {
      await (onRsvp && onRsvp(attending, companions, pack));
    } catch (_) {
    }
    setRsvpBusy(false);
    setRsvpDone(true);
  };
  const waText = encodeURIComponent("Hello! RSVP for " + data.groomName + " & " + data.brideName + "'s wedding \u2014 " + (rsvpName || "Guest") + ": " + (attending ? "attending" : "regrets") + (companions ? " (+" + companions + ")" : ""));
  const [gbName, setGbName] = w.useState(guest && guest.name || "");
  const [gbBody, setGbBody] = w.useState("");
  const [gbSent, setGbSent] = w.useState(false);
  const [gbBusy, setGbBusy] = w.useState(false);
  const submitGb = async (e) => {
    e.preventDefault();
    if (!gbName.trim() || !gbBody.trim() || gbBusy) return;
    setGbBusy(true);
    try {
      await (onGuestbook && onGuestbook(gbName.trim(), gbBody.trim()));
    } catch (_) {
    }
    setGbBusy(false);
    setGbSent(true);
    setGbBody("");
    setTimeout(() => setGbSent(false), 3200);
  };
  const inputStyle = { width: "100%", padding: "13px 15px", fontSize: 15, color: RC_C.ink, background: RC_C.bg, border: "1px solid rgba(150,116,84,0.3)", borderRadius: 10, outline: "none", fontFamily: RC_SANS, letterSpacing: "0.02em" };
  const labelStyle = { display: "block", fontFamily: RC_CAPS, fontSize: 10.5, letterSpacing: "0.3em", textTransform: "uppercase", color: RC_C.goldDeep, marginBottom: 8 };
  const hin = (delay) => ({
    initial: { opacity: 0, y: 26 },
    animate: flood ? { opacity: 1, y: 0 } : {},
    transition: { delay, duration: 0.95, ease: RC_EASE }
  });
  const GRAIN = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='240' height='240'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='240' height='240' filter='url(%23n)' opacity='0.55'/%3E%3C/svg%3E")`;
  const evList = (data.events || []).filter((ev) => ev && (ev.name || ev.nameSw || ev.venue || ev.date));
  const famLines = (fam) => {
    if (!fam) return [];
    if (typeof fam === "string") return fam.split(/\n+/).map((x) => x.trim()).filter(Boolean);
    if (typeof fam === "object") {
      const L = [];
      if (fam.parents) L.push(fam.parents);
      const m = fam.members;
      if (Array.isArray(m)) L.push(...m.filter(Boolean));
      else if (m) L.push(...String(m).split(/\n+/).map((x) => x.trim()).filter(Boolean));
      return L.filter(Boolean);
    }
    return [];
  };
  const hasFam = famLines(data.groomFamily).length > 0 || famLines(data.brideFamily).length > 0;
  const fmtDay = (ds) => {
    if (!ds) return "";
    const dd = /* @__PURE__ */ new Date(ds + "T12:00:00");
    return isNaN(dd.getTime()) ? "" : dd.toLocaleDateString(loc, { weekday: "long", day: "numeric", month: "long" });
  };
  const letters = (nm, base) => nm.split("").map((ch, i) => /* @__PURE__ */ u.jsx(
    k.span,
    {
      "aria-hidden": "true",
      style: { display: "inline-block" },
      initial: { opacity: 0, y: 16 },
      animate: flood ? { opacity: 1, y: 0 } : {},
      transition: { delay: base + i * 0.03, duration: 0.6, ease: RC_EASE },
      children: ch === " " ? " " : ch
    },
    i
  ));
  const heroSections = w.useMemo(() => /* @__PURE__ */ u.jsxs(w.Fragment, { children: [
    quote ? /* @__PURE__ */ u.jsxs("section", { style: { position: "relative", padding: "clamp(76px,12vw,116px) 22px", overflow: "hidden", ...RC_CV }, children: [
      /* @__PURE__ */ u.jsx(RCMark, { word: t.wmBless }),
      /* @__PURE__ */ u.jsx(RCMotes, { density: 8 }),
      /* @__PURE__ */ u.jsxs(RCRev, { style: { position: "relative", zIndex: 1, maxWidth: 620, margin: "0 auto", textAlign: "center" }, children: [
        /* @__PURE__ */ u.jsx(
          k.div,
          {
            style: { width: "clamp(64px,14vw,84px)", margin: "0 auto 14px" },
            animate: { y: [0, -7, 0] },
            transition: { duration: 6.5, repeat: Infinity, ease: "easeInOut" },
            children: /* @__PURE__ */ u.jsx(
              "img",
              {
                src: "./art/rose2-rings.png",
                alt: "",
                "aria-hidden": "true",
                style: { width: "100%", display: "block", filter: "drop-shadow(0 14px 20px rgba(125,63,69,0.28))" }
              }
            )
          }
        ),
        /* @__PURE__ */ u.jsxs("p", { style: { fontFamily: RC_SERIF, fontStyle: "italic", fontSize: "clamp(17px,3vw,21px)", lineHeight: 1.75, color: RC_C.ink, margin: 0 }, children: [
          "\u201C",
          quote,
          "\u201D"
        ] }),
        /* @__PURE__ */ u.jsx(RCDivider, { width: 180 })
      ] })
    ] }) : null,
    story ? /* @__PURE__ */ u.jsxs("section", { style: { position: "relative", padding: "clamp(72px,11vw,108px) 22px", overflow: "hidden", ...RC_CV, background: "linear-gradient(180deg," + RC_C.bg + " 0%, #f4e8dc 50%, " + RC_C.bg + " 100%)" }, children: [
      /* @__PURE__ */ u.jsx(RCHead, { eyebrow: t.twoSouls, title: t.oneDestiny }),
      /* @__PURE__ */ u.jsx(RCRev, { delay: 0.18, style: { position: "relative", zIndex: 1, maxWidth: 560, margin: "18px auto 0", textAlign: "center" }, children: /* @__PURE__ */ u.jsx("p", { style: { fontFamily: RC_SERIF, fontStyle: "italic", fontSize: "clamp(15px,2.6vw,17.5px)", lineHeight: 1.85, color: RC_C.inkSoft, margin: 0, whiteSpace: "pre-line" }, children: story }) })
    ] }) : null,
    hasFam ? /* @__PURE__ */ u.jsxs("section", { style: { position: "relative", padding: "clamp(72px,11vw,108px) 22px", overflow: "hidden", ...RC_CV }, children: [
      /* @__PURE__ */ u.jsx(RCHead, { eyebrow: t.familyPre, title: t.familyPost }),
      /* @__PURE__ */ u.jsx("div", { style: { position: "relative", zIndex: 1, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(270px, 1fr))", gap: 24, maxWidth: 920, margin: "34px auto 0" }, children: [
        { fam: data.groomFamily, fb: lang === "sw" ? "Familia ya Bwano Harusi" : "The Groom's Family" },
        { fam: data.brideFamily, fb: lang === "sw" ? "Familia ya Bibi Harusi" : "The Bride's Family" }
      ].map((side, i) => /* @__PURE__ */ u.jsx(RCRev, { delay: 0.1 + i * 0.1, children: /* @__PURE__ */ u.jsxs("div", { style: { background: "linear-gradient(180deg,#fdfaf2,#f7eedb)", border: "1px solid rgba(185,138,47,0.45)", borderRadius: "120px 120px 22px 22px", padding: "44px 26px 32px", textAlign: "center", boxShadow: "0 24px 56px -26px rgba(125,63,69,0.38)", position: "relative" }, children: [
        /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 7, borderRadius: "113px 113px 16px 16px", border: "1px solid rgba(185,138,47,0.25)", pointerEvents: "none" } }),
        /* @__PURE__ */ u.jsx("div", { style: { fontFamily: RC_CAPS, fontSize: 10, letterSpacing: "0.32em", textTransform: "uppercase", color: RC_C.goldDeep, marginBottom: 16 }, children: side.fam && typeof side.fam === "object" && side.fam.label || side.fb }),
        famLines(side.fam).map((m, j) => /* @__PURE__ */ u.jsx("div", { style: { fontFamily: RC_SERIF, fontSize: "clamp(16px,2.8vw,18.5px)", lineHeight: 1.9, color: RC_C.roseDark }, children: m }, j))
      ] }) }, i)) })
    ] }) : null
  ] }), [lang, mob, data]);
  const tailSections = w.useMemo(() => /* @__PURE__ */ u.jsxs(w.Fragment, { children: [
    evList.length ? /* @__PURE__ */ u.jsx(RCProcession, { evList, mob, lang, t, fmtDay }) : null,
    ev0 ? /* @__PURE__ */ u.jsx("section", { style: { position: "relative", padding: "clamp(72px,11vw,104px) 22px", textAlign: "center", overflow: "hidden", ...RC_CV }, children: /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 1, maxWidth: 660, margin: "0 auto" }, children: [
      /* @__PURE__ */ u.jsx(RCHead, { eyebrow: t.whereWe, title: t.location }),
      /* @__PURE__ */ u.jsx(RCRev, { delay: 0.2, children: /* @__PURE__ */ u.jsx("p", { style: { fontFamily: RC_SERIF, fontSize: "clamp(21px,4.4vw,27px)", color: RC_C.ink, margin: "22px 0 0" }, children: ev0.venue || "" }) }),
      ev0.dressCode ? /* @__PURE__ */ u.jsx(RCRev, { delay: 0.26, children: /* @__PURE__ */ u.jsx("div", { style: { display: "flex", justifyContent: "center" }, children: /* @__PURE__ */ u.jsx(RCDressChip, { tag: t.dressTag, txt: ev0.dressCode }) }) }) : null,
      /* @__PURE__ */ u.jsx(RCRev, { delay: 0.32, children: /* @__PURE__ */ u.jsxs("div", { style: { display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap", marginTop: 26 }, children: [
        ev0.mapsUrl ? /* @__PURE__ */ u.jsx("a", { href: ev0.mapsUrl, target: "_blank", rel: "noreferrer", style: { fontFamily: RC_CAPS, background: RC_C.gold, color: "#fffdf6", padding: "13px 26px", borderRadius: 999, letterSpacing: "0.2em", fontSize: 10.5, textTransform: "uppercase", textDecoration: "none", boxShadow: "0 14px 30px -14px rgba(185,138,47,0.7)" }, children: t.openMaps }) : null,
        /* @__PURE__ */ u.jsx("button", { type: "button", onClick: addCal, style: { fontFamily: RC_CAPS, border: "1px solid rgba(185,138,47,0.5)", color: RC_C.goldDeep, padding: "13px 24px", borderRadius: 999, background: "transparent", cursor: "pointer", fontSize: 10.5, letterSpacing: "0.2em", textTransform: "uppercase" }, children: t.addCal })
      ] }) })
    ] }) }) : null,
    /* @__PURE__ */ u.jsxs("section", { style: { position: "relative", padding: "clamp(76px,12vw,110px) 22px", textAlign: "center", overflow: "hidden", ...RC_CV, background: "linear-gradient(180deg," + RC_C.bg + " 0%, #f4e8dc 55%, " + RC_C.bg + " 100%)" }, children: [
      /* @__PURE__ */ u.jsx(RCMark, { word: t.wmLove }),
      /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 1, maxWidth: 760, margin: "0 auto" }, children: [
        /* @__PURE__ */ u.jsx(RCHead, { eyebrow: t.whatToWear, title: t.dressTitle }),
        /* @__PURE__ */ u.jsx(RCRev, { delay: 0.2, children: /* @__PURE__ */ u.jsx("p", { style: { fontFamily: RC_SERIF, fontStyle: "italic", fontSize: "clamp(14.5px,2.6vw,16.5px)", lineHeight: 1.8, color: RC_C.inkSoft, maxWidth: 540, margin: "20px auto 0" }, children: t.dressText }) }),
        /* @__PURE__ */ u.jsx(RCRev, { delay: 0.28, children: /* @__PURE__ */ u.jsx("div", { style: { display: "flex", justifyContent: "center", gap: 16, marginTop: 34, flexWrap: "wrap" }, children: [
          { c: "#faf5ee", n: "Ivory" },
          { c: RC_C.blush, n: "Blush" },
          { c: RC_C.rose, n: lang === "sw" ? "Waridi" : "Rose" },
          { c: RC_C.gold, n: lang === "sw" ? "Dhahabu" : "Gold" }
        ].map((sw2, idx) => /* @__PURE__ */ u.jsxs("div", { style: { textAlign: "center" }, children: [
          /* @__PURE__ */ u.jsx(
            k.div,
            {
              style: { width: 44, height: 58, borderRadius: "999px 999px 12px 12px", background: sw2.c, border: "3px solid #fffdf8", boxShadow: "0 18px 40px -20px rgba(125,63,69,0.35), inset 0 1px 3px rgba(255,255,255,0.9)", margin: "0 auto" },
              animate: { y: [0, -6, 0] },
              transition: { duration: 5 + idx * 0.7, repeat: Infinity, ease: "easeInOut", delay: idx * 0.5 }
            }
          ),
          /* @__PURE__ */ u.jsx("div", { style: { fontFamily: RC_CAPS, fontSize: 9, letterSpacing: "0.26em", textTransform: "uppercase", color: RC_C.goldDeep, marginTop: 9 }, children: sw2.n })
        ] }, idx)) }) }),
        /* @__PURE__ */ u.jsx(RCRev, { delay: 0.36, children: /* @__PURE__ */ u.jsxs("div", { style: { maxWidth: 520, margin: "30px auto 0", display: "grid", gap: 10 }, children: [
          /* @__PURE__ */ u.jsx("p", { style: { fontFamily: RC_SERIF, fontStyle: "italic", fontSize: 14, color: RC_C.roseDark, margin: 0 }, children: t.dressGents }),
          /* @__PURE__ */ u.jsx("p", { style: { fontFamily: RC_SERIF, fontStyle: "italic", fontSize: 14, color: RC_C.roseDark, margin: 0 }, children: t.dressLadies })
        ] }) })
      ] })
    ] }),
    
  ] }), [lang, mob, copied, data]);
  return /* @__PURE__ */ u.jsxs("div", { style: { minHeight: "100vh", background: RC_C.bg, color: RC_C.ink, fontFamily: RC_SANS, overflowX: "hidden", position: "relative" }, children: [
    !envGone && /* @__PURE__ */ u.jsxs("div", { "aria-hidden": "true", style: { position: "fixed", left: -40, top: -40, width: 8, height: 8, overflow: "hidden", opacity: 0.02, pointerEvents: "none", zIndex: 1 }, children: [
      /* @__PURE__ */ u.jsx("img", { src: heroImg, alt: "" }),
      /* @__PURE__ */ u.jsx("img", { src: "./art/rose2-branch.png", alt: "" }),
      /* @__PURE__ */ u.jsx("img", { src: "./art/rose2-rings.png", alt: "" }),
      /* @__PURE__ */ u.jsx("img", { src: "./art/rose2-doves.png", alt: "" })
    ] }),
    !envGone && /* @__PURE__ */ u.jsx(
      RCEnv,
      {
        mono,
        hint: t.tapSeal,
        guestName: guest && guest.name || "",
        forYou: t.forYou,
        groom: data.groomName || "",
        bride: data.brideName || "",
        dateStr: dateLabel,
        heroImg,
        onOpenStart: () => {
        },
        onFlood: handleFlood,
        onDone: () => setEnvGone(true)
      }
    ),
    /* @__PURE__ */ u.jsx("div", { "aria-hidden": "true", style: { position: "fixed", inset: 0, zIndex: 55, pointerEvents: "none", opacity: 0.05, backgroundImage: GRAIN, backgroundSize: "130px 130px" } }),
    /* @__PURE__ */ u.jsx("div", { style: { position: "fixed", top: 14, right: 14, zIndex: 60 }, children: /* @__PURE__ */ u.jsx(
      k.button,
      {
        type: "button",
        onClick: () => setLang(lang === "en" ? "sw" : "en"),
        initial: { opacity: 0, y: -8 },
        animate: envGone ? { opacity: 1, y: 0 } : {},
        transition: { delay: 0.5, duration: 0.7, ease: RC_EASE },
        whileTap: { scale: 0.92 },
        style: { border: "1px solid rgba(185,138,47,0.5)", background: "rgba(255,253,248,0.94)", color: RC_C.goldDeep, padding: "8px 16px", borderRadius: 999, fontFamily: RC_CAPS, fontSize: 10, letterSpacing: "0.22em", textTransform: "uppercase", cursor: "pointer", boxShadow: "0 10px 24px -12px rgba(125,63,69,0.4)" },
        children: lang === "en" ? "Kiswahili" : "English"
      }
    ) }),
    guest && guest.name ? /* @__PURE__ */ u.jsx("div", { style: { position: "fixed", top: 14, left: 14, zIndex: 60 }, children: /* @__PURE__ */ u.jsxs(
      k.div,
      {
        initial: { opacity: 0, y: -8 },
        animate: envGone ? { opacity: 1, y: 0 } : {},
        transition: { delay: 0.65, duration: 0.7, ease: RC_EASE },
        style: { border: "1px solid rgba(185,138,47,0.5)", background: "rgba(255,253,248,0.94)", color: RC_C.roseDark, padding: "8px 16px", borderRadius: 999, fontFamily: RC_SERIF, fontStyle: "italic", fontSize: 12.5, boxShadow: "0 10px 24px -12px rgba(125,63,69,0.4)" },
        children: [
          "\u2726 ",
          guest.name
        ]
      }
    ) }) : null,
    /* @__PURE__ */ u.jsxs("header", { style: {
      position: "relative",
      minHeight: "100svh",
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      textAlign: "center",
      padding: "84px 20px 78px",
      background: "radial-gradient(ellipse 130% 70% at 50% -8%, #f7e3da 0%, rgba(247,227,218,0) 58%), linear-gradient(180deg, #fbf3e2 0%, " + RC_C.bg + " 46%, " + RC_C.bg + " 100%)"
    }, children: [
      petalsOn ? /* @__PURE__ */ u.jsx(RCPetals, { density: mob ? 9 : 14 }) : null,
      /* @__PURE__ */ u.jsx("div", { "aria-hidden": "true", style: { position: "absolute", top: -24, left: -40, zIndex: 1, pointerEvents: "none" }, children: /* @__PURE__ */ u.jsx(
        k.img,
        {
          src: "./art/rose2-branch.png",
          alt: "",
          style: { width: "clamp(130px,22vw,200px)", transformOrigin: "top left", display: "block" },
          animate: envGone ? { rotate: [-2, 2.4, -2] } : {},
          transition: { duration: 10, repeat: Infinity, repeatType: "mirror", ease: "easeInOut", delay: 0.35 }
        }
      ) }),
      /* @__PURE__ */ u.jsx("div", { "aria-hidden": "true", style: { position: "absolute", top: -24, right: -40, zIndex: 1, pointerEvents: "none" }, children: /* @__PURE__ */ u.jsx(
        k.img,
        {
          src: "./art/rose2-branch.png",
          alt: "",
          style: { width: "clamp(130px,22vw,200px)", scaleX: -1, transformOrigin: "top right", display: "block" },
          animate: envGone ? { rotate: [2, -2.4, 2] } : {},
          transition: { duration: 11, repeat: Infinity, repeatType: "mirror", ease: "easeInOut", delay: 0.55 }
        }
      ) }),
      /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 2, width: "100%", maxWidth: 560, display: "flex", flexDirection: "column", alignItems: "center" }, children: [
        /* @__PURE__ */ u.jsx(k.p, { ...hin(0.15), lang: "ar", dir: "rtl", style: { fontFamily: RC_AMIRI, fontSize: "clamp(17px,3.6vw,21px)", color: RC_C.goldDeep, margin: "0 0 10px", lineHeight: 1.8 }, children: t.bismillah }),
        /* @__PURE__ */ u.jsx(k.p, { ...hin(0.3), style: { fontFamily: RC_CAPS, fontSize: 10, letterSpacing: "0.4em", textTransform: "uppercase", color: RC_C.goldDeep, margin: "0 0 4px", maxWidth: 320, lineHeight: 2 }, children: t.invited }),
        /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", width: "min(80vw,330px,42vh)", marginTop: 62 }, children: [
          /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", top: -58, left: "50%", marginLeft: -49, zIndex: 3 }, children: /* @__PURE__ */ u.jsx(RCCrest, { size: 98, mono, draw: envGone }) }),
          /* @__PURE__ */ u.jsx("div", { style: { borderRadius: "999px 999px 20px 20px", border: "1px solid rgba(185,138,47,0.6)", background: "linear-gradient(180deg,#fdf8ec,#f3e6cd)", padding: 8, boxShadow: "0 30px 64px -28px rgba(125,63,69,0.45)" }, children: /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", overflow: "hidden", borderRadius: "999px 999px 14px 14px", aspectRatio: "3 / 4" }, children: [
            /* @__PURE__ */ u.jsx(
              k.img,
              {
                src: heroImg,
                alt: "",
                style: { width: "100%", height: "100%", objectFit: "cover", display: "block" },
                animate: envGone ? { scale: [1, 1.075, 1] } : {},
                transition: { duration: 24, repeat: Infinity, repeatType: "mirror", ease: "easeInOut", delay: 0.7 }
              }
            ),
            /* @__PURE__ */ u.jsx("div", { "aria-hidden": "true", style: {
              position: "absolute",
              inset: 0,
              pointerEvents: "none",
              background: "linear-gradient(180deg, rgba(248,241,229,0) 30%, rgba(250,244,232,0.45) 55%, rgba(248,241,229,0.92) 82%, " + RC_C.bg + " 100%)"
            } }),
            /* @__PURE__ */ u.jsx("div", { "aria-hidden": "true", style: { position: "absolute", inset: 0, boxShadow: "inset 0 0 0 1px rgba(255,253,246,0.5)", borderRadius: "inherit", pointerEvents: "none" } }),
            /* @__PURE__ */ u.jsx(
              k.div,
              {
                "aria-hidden": "true",
                style: {
                  position: "absolute",
                  top: "-12%",
                  bottom: "-12%",
                  width: "42%",
                  left: 0,
                  pointerEvents: "none",
                  background: "linear-gradient(100deg, transparent 0%, rgba(255,255,255,0.3) 50%, transparent 100%)",
                  transform: "skewX(-14deg)"
                },
                initial: { x: "-180%" },
                animate: envGone ? { x: ["-180%", "430%"] } : {},
                transition: { delay: 0.8, duration: 2.6, repeat: Infinity, repeatDelay: 6.5, ease: "easeInOut" }
              }
            ),
            /* @__PURE__ */ u.jsx(
              k.div,
              {
                "aria-hidden": "true",
                style: {
                  position: "absolute",
                  left: "50%",
                  bottom: "33%",
                  width: "47%",
                  x: "-50%",
                  zIndex: 2,
                  pointerEvents: "none",
                  filter: "drop-shadow(0 8px 14px rgba(125,63,69,0.22))"
                },
                initial: { opacity: 0, y: -12 },
                animate: envGone ? { opacity: 1, y: 0 } : {},
                transition: { delay: 0.5, duration: 0.9, ease: RC_EASE },
                children: /* @__PURE__ */ u.jsx(
                  k.img,
                  {
                    src: "./art/rose2-doves.png",
                    alt: "",
                    style: { width: "100%", display: "block" },
                    animate: envGone ? { y: [0, -6, 0], rotate: [-1.2, 1.2] } : {},
                    transition: { duration: 5.6, repeat: Infinity, repeatType: "mirror", ease: "easeInOut", delay: 1.15 }
                  }
                )
              }
            ),
            /* @__PURE__ */ u.jsxs("div", { style: { position: "absolute", left: 0, right: 0, bottom: "6%", zIndex: 2 }, children: [
              /* @__PURE__ */ u.jsx("div", { "aria-label": data.groomName || "", style: { fontFamily: RC_SERIF, fontSize: "clamp(22px,5.6vw,32px)", letterSpacing: "0.06em", textTransform: "uppercase", color: RC_C.ink, lineHeight: 1.12 }, children: letters(data.groomName || "", 1.35) }),
              /* @__PURE__ */ u.jsx(k.div, { ...hin(1.62), style: { fontFamily: RC_SCRIPT, fontSize: "clamp(18px,4.2vw,26px)", color: RC_C.gold, lineHeight: 1.1, margin: "1px 0" }, children: "&" }),
              /* @__PURE__ */ u.jsx("div", { "aria-label": data.brideName || "", style: { fontFamily: RC_SERIF, fontSize: "clamp(22px,5.6vw,32px)", letterSpacing: "0.06em", textTransform: "uppercase", color: RC_C.roseDark, lineHeight: 1.12 }, children: letters(data.brideName || "", 1.78) })
            ] })
          ] }) })
        ] }),
        /* @__PURE__ */ u.jsx(RCSwash, { go: flood, delay: 2.15 }),
        dateLabel ? /* @__PURE__ */ u.jsx(k.p, { ...hin(2.35), style: { fontFamily: RC_CAPS, fontSize: "clamp(10.5px,2.3vw,12.5px)", letterSpacing: "0.3em", textTransform: "uppercase", color: RC_C.ink, margin: "14px 0 0" }, children: dateLabel }) : null,
        ev0 && ev0.venue ? /* @__PURE__ */ u.jsx(k.p, { ...hin(2.45), style: { fontFamily: RC_SERIF, fontStyle: "italic", fontSize: "clamp(13.5px,2.5vw,15.5px)", color: RC_C.inkSoft, margin: "5px 0 0" }, children: ev0.venue }) : null
      ] }),
      /* @__PURE__ */ u.jsxs(k.div, { ...hin(2.8), style: { position: "absolute", bottom: 18, left: "50%", x: "-50%", zIndex: 2, display: "flex", flexDirection: "column", alignItems: "center", gap: 7 }, children: [
        /* @__PURE__ */ u.jsx("span", { style: { fontFamily: RC_CAPS, fontSize: 9, letterSpacing: "0.42em", textTransform: "uppercase", color: RC_C.goldDeep }, children: t.scroll }),
        /* @__PURE__ */ u.jsx(
          k.span,
          {
            style: { width: 1, height: 30, background: "linear-gradient(180deg," + RC_C.gold + ", transparent)", transformOrigin: "top center", display: "block" },
            animate: { scaleY: [0.25, 1, 0.25], opacity: [0.4, 1, 0.4] },
            transition: { duration: 2.4, repeat: Infinity, ease: "easeInOut" }
          }
        )
      ] })
    ] }),
    heroSections,
    target ? /* @__PURE__ */ u.jsxs("section", { ref: cdRef, style: { position: "relative", padding: "clamp(76px,12vw,116px) 22px", textAlign: "center", overflow: "hidden", ...RC_CV, background: "linear-gradient(180deg," + RC_C.bg + " 0%, #f3e7da 50%, " + RC_C.bg + " 100%)" }, children: [
      /* @__PURE__ */ u.jsx(RCMark, { word: t.wmTime }),
      /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 1 }, children: [
        /* @__PURE__ */ u.jsx(RCHead, { eyebrow: t.beginsIn, title: t.cdTitle }),
        /* @__PURE__ */ u.jsxs("div", { style: { display: "flex", flexWrap: "wrap", justifyContent: "center", gap: mob ? 10 : 16, marginTop: 38 }, children: [
          /* @__PURE__ */ u.jsx(RCUnit, { v: cd.d, label: t.days, delay: 0.2, go: cdIn }),
          /* @__PURE__ */ u.jsx(RCUnit, { v: cd.h, label: t.hours, delay: 0.28, go: cdIn }),
          /* @__PURE__ */ u.jsx(RCUnit, { v: cd.m, label: t.minutes, delay: 0.36, go: cdIn }),
          /* @__PURE__ */ u.jsx(RCUnit, { v: cd.s, label: t.seconds, delay: 0.44, go: cdIn })
        ] })
      ] })
    ] }) : null,
    tailSections,
    /* @__PURE__ */ u.jsxs("section", { ref: rsvpRef, style: { position: "relative", padding: "clamp(72px,12vw,120px) 22px", overflow: "hidden", ...RC_CV }, children: [
      /* @__PURE__ */ u.jsx(RCMotes, { density: 8 }),
      /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 1, maxWidth: 560, margin: "0 auto", perspective: 1200 }, children: [
        /* @__PURE__ */ u.jsx(RCHead, { eyebrow: t.rsvp, title: t.confirmTitle }),
        !rsvpOpen && !rsvpDone ? /* @__PURE__ */ u.jsxs("div", { style: { textAlign: "center" }, children: [
          /* @__PURE__ */ u.jsxs(RCRev, { delay: 0.16, children: [
            /* @__PURE__ */ u.jsx("p", { style: { fontFamily: RC_SERIF, fontStyle: "italic", fontSize: "clamp(15px,2.2vw,17.5px)", color: RC_C.inkSoft, margin: "22px auto 6px", lineHeight: 1.8, maxWidth: 440 }, children: t.confirmSub }),
            rsvpBy ? /* @__PURE__ */ u.jsxs("p", { style: { fontFamily: RC_CAPS, fontSize: 10.5, letterSpacing: "0.28em", textTransform: "uppercase", color: RC_C.goldDeep, margin: "0 0 8px" }, children: [
              t.rsvpBefore,
              " ",
              rsvpBy
            ] }) : null
          ] }),
          /* @__PURE__ */ u.jsx(RCRev, { delay: 0.24, children: /* @__PURE__ */ u.jsxs("div", { style: { marginTop: 30, background: "linear-gradient(180deg,#fdfaf2,#f7eedb)", border: "1px solid rgba(185,138,47,0.5)", borderRadius: "110px 110px 20px 20px", padding: "52px 24px 38px", boxShadow: "0 24px 56px -26px rgba(125,63,69,0.38)", position: "relative", overflow: "hidden" }, children: [
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", top: 0, left: "16%", right: "16%", height: 3, background: "linear-gradient(90deg, transparent, " + RC_C.gold + ", transparent)" } }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 7, borderRadius: "104px 104px 15px 15px", border: "1px solid rgba(185,138,47,0.28)", pointerEvents: "none" } }),
            /* @__PURE__ */ u.jsx("svg", { style: { position: "absolute", inset: 0, pointerEvents: "none", opacity: 0.5 }, viewBox: "0 0 100 100", preserveAspectRatio: "none", children: /* @__PURE__ */ u.jsx("path", { d: "M0 0 L50 34 L100 0", fill: "none", stroke: RC_C.gold, strokeWidth: "0.35" }) }),
            /* @__PURE__ */ u.jsxs(
              k.button,
              {
                onClick: openRsvp,
                whileHover: { scale: 1.05 },
                whileTap: { scale: 0.93 },
                style: { position: "relative", background: "none", border: 0, padding: 0, cursor: "pointer", zIndex: 2 },
                children: [
                  /* @__PURE__ */ u.jsxs(
                    k.span,
                    {
                      style: { display: "inline-block", position: "relative", borderRadius: "50%", overflow: "hidden" },
                      animate: rsvpIn ? { scale: [1, 1.028, 1] } : {},
                      transition: { duration: 3.6, repeat: Infinity, ease: "easeInOut" },
                      children: [
                        /* @__PURE__ */ u.jsx(RCSeal, { size: 98, mono }),
                        /* @__PURE__ */ u.jsx(
                          k.span,
                          {
                            style: {
                              position: "absolute",
                              top: "-30%",
                              bottom: "-30%",
                              width: "36%",
                              pointerEvents: "none",
                              background: "linear-gradient(105deg, transparent, rgba(255,255,255,0.6) 50%, transparent)",
                              willChange: "transform"
                            },
                            initial: { x: "-240%" },
                            animate: rsvpIn ? { x: "400%" } : {},
                            transition: { duration: 2.6, repeat: Infinity, repeatDelay: 3.6, ease: "easeInOut" }
                          }
                        )
                      ]
                    }
                  ),
                  /* @__PURE__ */ u.jsx(RCStar, { x: -62, y: -48, delay: 0, size: 13, go: rsvpIn }),
                  /* @__PURE__ */ u.jsx(RCStar, { x: 54, y: -56, delay: 1.3, size: 11, go: rsvpIn }),
                  /* @__PURE__ */ u.jsx(RCStar, { x: 60, y: 42, delay: 2.1, size: 12, go: rsvpIn }),
                  /* @__PURE__ */ u.jsx(RCStar, { x: -56, y: 48, delay: 0.7, size: 10, go: rsvpIn }),
                  sealFlash ? /* @__PURE__ */ u.jsx(
                    k.span,
                    {
                      style: {
                        position: "absolute",
                        left: "50%",
                        top: "50%",
                        x: "-50%",
                        y: "-50%",
                        width: 140,
                        height: 140,
                        borderRadius: "50%",
                        pointerEvents: "none",
                        background: "radial-gradient(circle, rgba(255,244,200,0.95), rgba(255,214,120,0.55) 48%, rgba(255,214,120,0) 72%)",
                        willChange: "transform, opacity"
                      },
                      initial: { scale: 0.45, opacity: 1 },
                      animate: { scale: 2.3, opacity: 0 },
                      transition: { duration: 0.5, ease: "easeOut" }
                    }
                  ) : null
                ]
              }
            ),
            /* @__PURE__ */ u.jsx(
              k.p,
              {
                animate: rsvpIn ? { opacity: [0.55, 1, 0.55] } : {},
                transition: { duration: 2.6, repeat: Infinity },
                style: { fontFamily: RC_CAPS, fontSize: 10, letterSpacing: "0.32em", textTransform: "uppercase", color: RC_C.goldDeep, margin: "22px 0 0", position: "relative", zIndex: 2 },
                children: t.rsvpSealHint
              }
            )
          ] }) })
        ] }) : rsvpDone ? /* @__PURE__ */ u.jsx(RCRev, { delay: 0.1, children: /* @__PURE__ */ u.jsxs("div", { style: { marginTop: 36, textAlign: "center", background: RC_C.card, border: "1px solid rgba(185,138,47,0.45)", borderRadius: 20, padding: "44px 26px", boxShadow: "0 20px 48px -22px rgba(125,63,69,0.3)" }, children: [
          /* @__PURE__ */ u.jsxs("svg", { width: "66", height: "66", viewBox: "0 0 66 66", style: { margin: "0 auto 16px", display: "block" }, children: [
            /* @__PURE__ */ u.jsx(
              k.circle,
              {
                cx: "33",
                cy: "33",
                r: "29",
                fill: "none",
                stroke: RC_C.gold,
                strokeWidth: "1.6",
                initial: { pathLength: 0 },
                animate: { pathLength: 1 },
                transition: { duration: 1, ease: "easeOut" }
              }
            ),
            /* @__PURE__ */ u.jsx(
              k.path,
              {
                d: "M21 34.5 29 42 46 24",
                fill: "none",
                stroke: RC_C.rose,
                strokeWidth: "3",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                initial: { pathLength: 0 },
                animate: { pathLength: 1 },
                transition: { delay: 0.7, duration: 0.55 }
              }
            )
          ] }),
          /* @__PURE__ */ u.jsx("p", { style: { fontFamily: RC_SERIF, fontSize: 19, color: RC_C.ink, margin: "0 0 12px" }, children: t.rsvpDone }),
          guest && guest.rsvpStatus ? /* @__PURE__ */ u.jsx("span", { style: { display: "inline-block", padding: "8px 18px", borderRadius: 999, background: guest.rsvpStatus === "attending" ? "rgba(185,138,47,0.16)" : "rgba(125,63,69,0.12)", color: guest.rsvpStatus === "attending" ? RC_C.goldDeep : RC_C.roseDark, fontFamily: RC_CAPS, fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase" }, children: guest.rsvpStatus === "attending" ? t.attendingBadge : t.declinedBadge }) : null
        ] }) }) : /* @__PURE__ */ u.jsxs(
          k.form,
          {
            onSubmit: submitRsvp,
            initial: { opacity: 0, rotateX: -16, y: -16, transformOrigin: "50% 0%" },
            animate: { opacity: 1, rotateX: 0, y: 0 },
            transition: { type: "spring", stiffness: 170, damping: 19 },
            style: { marginTop: 36, background: RC_C.card, border: "1px solid rgba(185,138,47,0.45)", borderRadius: 20, padding: "34px 26px 30px", boxShadow: "0 24px 56px -26px rgba(125,63,69,0.36)", textAlign: "left" },
            children: [
              /* @__PURE__ */ u.jsxs("div", { style: { marginBottom: 20 }, children: [
                /* @__PURE__ */ u.jsx("label", { style: labelStyle, children: t.yourName }),
                /* @__PURE__ */ u.jsx("input", { value: rsvpName, onChange: (e) => setRsvpName(e.target.value), style: inputStyle, required: true })
              ] }),
              /* @__PURE__ */ u.jsxs("div", { style: { marginBottom: 20 }, children: [
                /* @__PURE__ */ u.jsx("label", { style: labelStyle, children: t.attendQ }),
                /* @__PURE__ */ u.jsx("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }, children: [[true, t.accept], [false, t.decline]].map((opt) => /* @__PURE__ */ u.jsxs(
                  k.button,
                  {
                    type: "button",
                    onClick: () => setAttending(opt[0]),
                    whileTap: { scale: 0.97 },
                    style: {
                      padding: "14px 10px",
                      borderRadius: 12,
                      cursor: "pointer",
                      fontFamily: RC_SERIF,
                      fontSize: 14.5,
                      border: attending === opt[0] ? "1.5px solid " + RC_C.rose : "1px solid rgba(150,116,84,0.3)",
                      background: attending === opt[0] ? "rgba(168,93,94,0.1)" : RC_C.bg,
                      color: attending === opt[0] ? RC_C.roseDark : RC_C.inkSoft,
                      transition: "all .3s"
                    },
                    children: [
                      attending === opt[0] ? "\u2713 " : "",
                      opt[1]
                    ]
                  },
                  String(opt[0])
                )) })
              ] }),
              attending ? /* @__PURE__ */ u.jsxs(k.div, { initial: { opacity: 0, height: 0 }, animate: { opacity: 1, height: "auto" }, transition: { duration: 0.5, ease: RC_EASE }, style: { overflow: "hidden" }, children: [
                /* @__PURE__ */ u.jsxs("div", { style: { marginBottom: 20 }, children: [
                  /* @__PURE__ */ u.jsx("label", { style: labelStyle, children: t.guestsAttending }),
                  /* @__PURE__ */ u.jsxs("div", { style: { display: "flex", alignItems: "center", gap: 16 }, children: [
                    /* @__PURE__ */ u.jsx(
                      k.button,
                      {
                        type: "button",
                        whileTap: { scale: 0.9 },
                        onClick: () => setCompanions(Math.max(0, companions - 1)),
                        style: { width: 40, height: 40, borderRadius: 11, border: "1px solid rgba(185,138,47,0.55)", background: RC_C.bg, color: RC_C.goldDeep, fontSize: 19, cursor: "pointer", fontFamily: RC_SERIF },
                        children: "\u2212"
                      }
                    ),
                    /* @__PURE__ */ u.jsx("span", { style: { fontFamily: RC_SERIF, fontSize: 22, color: RC_C.ink, minWidth: 28, textAlign: "center" }, children: companions + 1 }),
                    /* @__PURE__ */ u.jsx(
                      k.button,
                      {
                        type: "button",
                        whileTap: { scale: 0.9 },
                        onClick: () => setCompanions(Math.min(guest && guest.maxCompanions || 6, companions + 1)),
                        style: { width: 40, height: 40, borderRadius: 11, border: "1px solid rgba(185,138,47,0.55)", background: RC_C.bg, color: RC_C.goldDeep, fontSize: 19, cursor: "pointer", fontFamily: RC_SERIF },
                        children: "+"
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ u.jsxs("div", { style: { marginBottom: 20 }, children: [
                  /* @__PURE__ */ u.jsx("label", { style: labelStyle, children: t.songLabel }),
                  /* @__PURE__ */ u.jsx("input", { value: song, onChange: (e) => setSong(e.target.value), style: inputStyle })
                ] }),
                /* @__PURE__ */ u.jsxs("div", { style: { marginBottom: 20 }, children: [
                  /* @__PURE__ */ u.jsx("label", { style: labelStyle, children: t.childrenLabel }),
                  /* @__PURE__ */ u.jsx("input", { value: children, onChange: (e) => setChildren(e.target.value), style: inputStyle })
                ] })
              ] }) : null,
              /* @__PURE__ */ u.jsxs("div", { style: { marginBottom: 24 }, children: [
                /* @__PURE__ */ u.jsx("label", { style: labelStyle, children: t.dietary }),
                /* @__PURE__ */ u.jsx("input", { value: dietary, onChange: (e) => setDietary(e.target.value), style: inputStyle })
              ] }),
              /* @__PURE__ */ u.jsx(
                k.button,
                {
                  type: "submit",
                  disabled: attending === null || !rsvpName.trim() || rsvpBusy,
                  whileTap: { scale: 0.98 },
                  style: {
                    width: "100%",
                    padding: "16px",
                    borderRadius: 12,
                    border: 0,
                    cursor: "pointer",
                    fontFamily: RC_CAPS,
                    fontSize: 12.5,
                    letterSpacing: "0.24em",
                    textTransform: "uppercase",
                    background: attending === null || !rsvpName.trim() ? "rgba(125,63,69,0.4)" : RC_C.roseDark,
                    color: "#fdf6ee",
                    boxShadow: "0 14px 34px -14px rgba(125,63,69,0.55)",
                    opacity: rsvpBusy ? 0.7 : 1
                  },
                  children: rsvpBusy ? t.sending : t.submit
                }
              ),
              data.whatsappNumber ? /* @__PURE__ */ u.jsx(
                "a",
                {
                  href: "https://wa.me/" + String(data.whatsappNumber).replace(/[^0-9]/g, "") + "?text=" + waText,
                  target: "_blank",
                  rel: "noreferrer",
                  style: { display: "block", textAlign: "center", marginTop: 16, fontFamily: RC_SANS, fontSize: 13.5, color: RC_C.goldDeep, textDecoration: "none", borderBottom: "1px solid rgba(185,138,47,0.4)", paddingBottom: 1, width: "fit-content", margin: "16px auto 0" },
                  children: t.rsvpWhats
                }
              ) : null
            ]
          }
        )
      ] })
    ] }),
    guest && guest.code ? /* @__PURE__ */ u.jsxs("section", { style: { position: "relative", padding: "clamp(64px,10vw,110px) 22px", textAlign: "center", overflow: "hidden", ...RC_CV }, children: [
      /* @__PURE__ */ u.jsx(RCMotes, { density: 7 }),
      /* @__PURE__ */ u.jsx(RCRev, { children: /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 1, maxWidth: 380, margin: "0 auto", background: "linear-gradient(180deg,#fdfaf2,#f7eedb)", border: "1px solid rgba(185,138,47,0.55)", borderRadius: "130px 130px 22px 22px", padding: "58px 28px 32px", boxShadow: "0 26px 60px -28px rgba(125,63,69,0.42)" }, children: [
        /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", top: -27, left: "50%", transform: "translateX(-50%)", zIndex: 3 }, children: /* @__PURE__ */ u.jsx(RCCrest, { size: 44, mono, draw: false }) }),
        [["top", 14, "left", 14, 0], ["top", 14, "right", 14, 90], ["bottom", 14, "right", 14, 180], ["bottom", 14, "left", 14, 270]].map((c3, i) => /* @__PURE__ */ u.jsxs(
          "svg",
          {
            width: "30",
            height: "30",
            viewBox: "0 0 30 30",
            fill: "none",
            stroke: RC_C.gold,
            strokeWidth: "1.4",
            style: { position: "absolute", [c3[0]]: c3[1], [c3[2]]: c3[3], transform: "rotate(" + c3[4] + "deg)", opacity: 0.85 },
            children: [
              /* @__PURE__ */ u.jsx("path", { d: "M3 27 V10 Q3 3 10 3 H27" }),
              /* @__PURE__ */ u.jsx("path", { d: "M8 27 V12 Q8 8 12 8 H27", opacity: "0.5" })
            ]
          },
          i
        )),
        /* @__PURE__ */ u.jsx("p", { style: { fontFamily: RC_CAPS, fontSize: 10.5, letterSpacing: "0.36em", textTransform: "uppercase", color: RC_C.goldDeep, margin: "0 0 18px" }, children: t.yourCode }),
        /* @__PURE__ */ u.jsx("div", { style: { display: "inline-block", padding: 13, background: "#fdfaf2", border: "1px solid rgba(185,138,47,0.4)", borderRadius: 16, boxShadow: "0 10px 24px -12px rgba(125,63,69,0.35), inset 0 1px 3px rgba(255,255,255,0.9)" }, children: u.jsx(yc, { value: (inviteUrl || "https://harusi-invite.github.io") + "?code=" + guest.code, size: 148, fgColor: RC_C.roseDark, bgColor: "#fdfaf2", level: "M" }) }),
        /* @__PURE__ */ u.jsx("p", { style: { fontFamily: RC_SERIF, fontSize: 25, letterSpacing: "0.3em", color: RC_C.ink, margin: "18px 0 6px" }, children: guest.code }),
        /* @__PURE__ */ u.jsx("p", { style: { fontFamily: RC_SANS, fontSize: 13, color: RC_C.inkSoft, margin: 0 }, children: t.scanHint }),
        guest.checkedIn ? /* @__PURE__ */ u.jsx("span", { style: { display: "inline-block", marginTop: 14, padding: "7px 16px", borderRadius: 999, background: "rgba(185,138,47,0.16)", color: RC_C.goldDeep, fontFamily: RC_CAPS, fontSize: 10.5, letterSpacing: "0.2em", textTransform: "uppercase" }, children: t.checkedInBadge }) : null
      ] }) })
    ] }) : null,
    /* @__PURE__ */ u.jsxs("footer", { style: { position: "relative", padding: "clamp(76px,12vw,110px) 22px 60px", textAlign: "center", background: RC_C.bgSoft, overflow: "hidden" }, children: [
      /* @__PURE__ */ u.jsx(RCPetals, { density: mob ? 6 : 9 }),
      /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 1 }, children: [
        /* @__PURE__ */ u.jsx(RCRev, { children: /* @__PURE__ */ u.jsx(
          k.img,
          {
            src: "./art/rose2-doves.png",
            alt: "",
            animate: { y: [0, -9, 0], rotate: [-1.2, 1.2] },
            transition: { duration: 5.6, repeat: Infinity, ease: "easeInOut" },
            style: { width: "clamp(150px,36vw,224px)", margin: "0 auto 6px", display: "block" }
          }
        ) }),
        /* @__PURE__ */ u.jsx(RCRev, { delay: 0.08, children: /* @__PURE__ */ u.jsx("div", { style: { display: "flex", justifyContent: "center" }, children: /* @__PURE__ */ u.jsx(RCCrest, { size: 88, mono, draw: false }) }) }),
        /* @__PURE__ */ u.jsx(RCRev, { delay: 0.16, children: /* @__PURE__ */ u.jsxs("p", { style: { fontFamily: RC_SCRIPT, fontSize: "clamp(34px,6.4vw,44px)", color: RC_C.roseDark, margin: "18px 0 6px" }, children: [
          u.jsx("span", { style: { display: "inline-block" }, children: data.groomName }),
          " & ",
          u.jsx("span", { style: { display: "inline-block" }, children: data.brideName })
        ] }) }),
        /* @__PURE__ */ u.jsxs(RCRev, { delay: 0.24, children: [
          /* @__PURE__ */ u.jsx("p", { style: { fontFamily: RC_CAPS, fontSize: 10.5, letterSpacing: "0.34em", textTransform: "uppercase", color: RC_C.goldDeep, margin: 0 }, children: dateLabel }),
          /* @__PURE__ */ u.jsx(RCDivider, { width: 170 })
        ] }),
        /* @__PURE__ */ u.jsx(RCRev, { delay: 0.32, children: /* @__PURE__ */ u.jsxs("p", { style: { fontFamily: RC_SANS, fontSize: 10.5, letterSpacing: "0.22em", textTransform: "uppercase", color: RC_C.inkSoft, marginTop: 26 }, children: [
          t.footer,
          " \xB7 Harusi"
        ] }) })
      ] })
    ] })
  ] });
}















/* === Harusi template 05: Emerald Arch === */

const EA_C = {
  em: "#0e3b2c",
  emDeep: "#082a1f",
  emInk: "#f2e8cf",
  emInkSoft: "#b7c3a9",
  ivory: "#f6efdd",
  ivorySoft: "#efe4c8",
  ink: "#26332a",
  inkSoft: "#6f7460",
  gold: "#c9a24a",
  goldDeep: "#a07d2f",
  goldHi: "#e8cf8f"
};
const EA_CAPS = "'Cinzel', serif";
const EA_BODY = "'Cormorant Garamond', serif";
const EA_SCRIPT = "'Pinyon Script', cursive";
const EA_SANS = "'Jost', sans-serif";
const EA_AMIRI = "'Amiri', serif";
const EA_EASE = [0.22, 1, 0.36, 1];
const EA_CV = { contentVisibility: "auto", containIntrinsicSize: "1100px" };

const EA_NAME_SIZE = (s) => {
  const L = (s || "").trim().length;
  if (L <= 9) return "clamp(38px,10.6vw,52px)";
  if (L <= 13) return "clamp(31px,8.6vw,42px)";
  if (L <= 18) return "clamp(26px,7.2vw,34px)";
  return "clamp(22px,6vw,28px)";
};


const EA_T = {
  en: {
    forYou: "For",
    tapSeal: "Tap the seal to open",
    scroll: "Scroll",
    invited: "Together with their families",
    beginsIn: "The celebration begins in",
    cdTitle: "Counting the moments",
    scheduleEye: "The order of the day",
    scheduleTitle: "Celebration",
    locationEye: "Where we celebrate",
    locationTitle: "The Venue",
    openMaps: "Open in Maps",
    addCal: "Add to Calendar",
    dressEye: "What to wear",
    dressTitle: "Dress Code",
    dressText: "We kindly invite you to wear formal attire in deep emerald, ivory and gold — tones that complement the spirit of our day.",
    dressGents: "Gentlemen",
    dressGentsText: "Well-tailored suits or sherwani in emerald, ivory or black, with polished dress shoes.",
    dressLadies: "Ladies",
    dressLadiesText: "Formal gowns or elegant evening dresses in emerald, ivory or gold tones.",
    rsvpEye: "Kindly respond",
    rsvpTitle: "Confirm Your Attendance",
    rsvpSub: "To help us prepare for a joyful celebration, kindly confirm below.",
    rsvpSealHint: "Touch the seal to open your RSVP",
    yourName: "Your name",
    attendQ: "Will you be attending?",
    accept: "Accepts with pleasure",
    decline: "Declines with regret",
    guestsAttending: "Guests attending (incl. you)",
    songLabel: "A song that gets you dancing",
    childrenLabel: "Children attending (names & ages)",
    dietary: "Dietary needs (optional)",
    submit: "Send RSVP",
    sending: "Sending…",
    rsvpDone: "Thank you — your response has been received!",
    rsvpWhats: "or RSVP via WhatsApp",
    attendingBadge: "Attending ✓",
    declinedBadge: "Regrets sent",
    codeEye: "Entrance",
    codeTitle: "Guest Code",
    scanHint: "Show this code at the entrance",
    checkedInBadge: "Checked in ✓",
    hopeToSee: "We can't wait to celebrate with you",
    galleryEye: "Captured moments", galleryTitle: "Gallery",
    giftsEye: "If you wish to bless us", giftsTitle: "Gifts",
    contactsEye: "Questions?", contactsTitle: "Contacts",
    storyEye: "Our story",
    storyTitle: "Two souls, one destiny",
    days: "Days", hours: "Hours", minutes: "Minutes", seconds: "Seconds",
    footer: "Made with love"
  },
  sw: {
    forYou: "Kwa",
    tapSeal: "Gusa muhuri kufungua",
    scroll: "Sogeza chini",
    invited: "Kwa baraka za familia zao",
    beginsIn: "Sherehe inaanza baada ya",
    cdTitle: "Tunahesabu dakika",
    scheduleEye: "Mpangilio wa siku",
    scheduleTitle: "Sherehe",
    locationEye: "Tutakaposherehekea",
    locationTitle: "Mahali",
    openMaps: "Fungua Ramani",
    addCal: "Weka Kalendari",
    dressEye: "Mavazi",
    dressTitle: "Mavazi Rasmi",
    dressText: "Tunakualika kuvaa mavazi rasmi ya kijani kizito, pembe za ndovu na dhahabu — rangi zinazoendana na siku yetu.",
    dressGents: "Wanaume",
    dressGentsText: "Suti zilizoshonwa vizuri au sherwani za kijani, pembe za ndovu au nyeusi, na viatu safi.",
    dressLadies: "Wanawake",
    dressLadiesText: "Nguo ndefu rasmi au mavazi ya jioni ya kijani, pembe za ndovu au dhahabu.",
    rsvpEye: "Tafadhali jibu",
    rsvpTitle: "Thibitisha Kuhudhuria",
    rsvpSub: "Ili tuandae sherehe ya furaha, tafadhali thibitisha hapa chini.",
    rsvpSealHint: "Gusa muhuri kufungua RSVP yako",
    yourName: "Jina lako",
    attendQ: "Je, utahudhuria?",
    accept: "Nitahudhuria kwa furaha",
    decline: "Samahani, sitaweza",
    guestsAttending: "Wageni wanaohudhuria (wewe mojawapo)",
    songLabel: "Wimbo unaokufanya ucheze",
    childrenLabel: "Watoto wanaohudhuria (majina & umri)",
    dietary: "Mahitaji ya chakula (si lazima)",
    submit: "Tuma RSVP",
    sending: "Inatuma…",
    rsvpDone: "Asante — jibu lako limepokelewa!",
    rsvpWhats: "au RSVP kwa WhatsApp",
    attendingBadge: "Nitahudhuria ✓",
    declinedBadge: "Samahani limetumwa",
    codeEye: "Kuingia",
    codeTitle: "Msimbo wa Mgeni",
    scanHint: "Onyesha msimbo huu mlangoni",
    checkedInBadge: "Umeingia ✓",
    hopeToSee: "Tunatarajia kusherehekea nawe",
    galleryEye: "Matukio ya kupendeza", galleryTitle: "Picha",
    giftsEye: "Ukitaka kutu bariki", giftsTitle: "Zawadi",
    contactsEye: "Maswali?", contactsTitle: "Mawasiliano",
    storyEye: "Hadithi yetu",
    storyTitle: "Roho mbili, hatima moja",
    days: "Siku", hours: "Saa", minutes: "Dakika", seconds: "Sekunde",
    footer: "Imetengenezwa kwa upendo"
  }
};

/* ---------- shared bits ---------- */

function EARev({ children: n, delay: a = 0, y: i = 34, style: r, once: l = true }) {
  return /* @__PURE__ */ u.jsx(k.div, {
    initial: { opacity: 0, y: i, filter: "blur(6px)" },
    whileInView: { opacity: 1, y: 0, filter: "blur(0px)" },
    viewport: { once: l, margin: "-60px" },
    transition: { duration: 1, delay: a, ease: EA_EASE },
    style: r,
    children: n
  });
}

/* scalloped divider filled with the PREVIOUS section's colour + gold trim + gem */
function EADiv({ fill: n }) {
  const W = 1440, S = 150, H = 44;
  const scallop = (x0) => {
    const x1 = x0 + S, cx = x0 + S / 2;
    return `C ${x0 + S * 0.25},14 ${cx - S * 0.28},40 ${cx},40 C ${cx + S * 0.28},40 ${x1 - S * 0.25},14 ${x1},14 `;
  };
  let d = `M0,0 L${W},0 L${W},14 `;
  for (let x = W; x > 0; x -= S) {
    const x0 = x - S, x1 = x, cx = x0 + S / 2;
    d += `C ${x1 - S * 0.25},14 ${cx + S * 0.28},40 ${cx},40 C ${cx - S * 0.28},40 ${x0 + S * 0.25},14 ${x0},14 `;
  }
  d += "Z";
  const line = (() => {
    let s = `M0,14 `;
    for (let x = 0; x < W; x += S) s += scallop(x);
    return s;
  })();
  return /* @__PURE__ */ u.jsxs("div", {
    "aria-hidden": true,
    style: {
      position: "absolute", top: -1, left: 0, right: 0, height: H, zIndex: 3,
      filter: "drop-shadow(0 10px 18px rgba(4,20,14,0.35))", pointerEvents: "none"
    },
    children: [
      /* @__PURE__ */ u.jsxs("svg", {
        viewBox: `0 0 ${W} ${H}`, preserveAspectRatio: "none",
        style: { position: "absolute", inset: 0, width: "100%", height: "100%", display: "block" },
        children: [
          /* @__PURE__ */ u.jsx("path", { d, fill: n }),
          /* @__PURE__ */ u.jsx("path", { d: line, fill: "none", stroke: EA_C.gold, strokeWidth: 1.8, vectorEffect: "non-scaling-stroke", opacity: 0.9 })
        ]
      }),
      /* @__PURE__ */ u.jsx("div", {
        style: {
          position: "absolute", left: "50%", bottom: -8, transform: "translateX(-50%) rotate(45deg)",
          width: 13, height: 13, background: `linear-gradient(135deg, ${EA_C.goldHi}, ${EA_C.goldDeep})`,
          boxShadow: "0 0 0 2px rgba(246,239,221,0.55), 0 6px 14px rgba(0,0,0,0.35)"
        }
      })
    ]
  });
}

/* falling gold leaves / white petals with canvas physics */
function EALeaves({ kind: n = "leaves", density: a = 10, opacity: i = 1 }) {
  const ref = w.useRef(null);
  w.useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d");
    let W = 0, H = 0, raf = 0;
    const fit = () => {
      const r = cv.parentElement.getBoundingClientRect();
      W = r.width; H = r.height;
      const dpr = Math.min(1.6, window.devicePixelRatio || 1);
      cv.width = W * dpr; cv.height = H * dpr;
      cv.style.width = W + "px"; cv.style.height = H + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(cv.parentElement);
    const urls = n === "petals"
      ? ["./art/em-petal.png"]
      : ["./art/em-leaf-a.png", "./art/em-leaf-b.png"];
    const imgs = urls.map((s) => { const im = new Image(); im.src = s; return im; });
    const R = (x, y) => x + Math.random() * (y - x);
    const mk = (top) => {
      const depth = R(0.35, 1);
      return {
        x: R(-20, W + 20), y: top ? R(-H * 0.15, -30) : R(0, H),
        depth, img: imgs[Math.floor(Math.random() * imgs.length)],
        size: R(14, 30) * depth,
        vy: R(0.35, 0.9) * depth, vx: R(-0.15, 0.15),
        rot: R(0, Math.PI * 2), vr: R(-0.012, 0.012),
        ph: R(0, Math.PI * 2), sway: R(0.4, 1.1), swayAmp: R(14, 42) * depth,
        flip: R(0, Math.PI * 2), flipV: R(0.008, 0.02)
      };
    };
    let parts = Array.from({ length: a }, () => mk(false));
    let t = 0, visible = true;
    const io = new IntersectionObserver((e) => { visible = e[0].isIntersecting; });
    io.observe(cv);
    const step = () => {
      raf = requestAnimationFrame(step);
      if (!visible || !W || !H) return;
      t += 0.016;
      ctx.clearRect(0, 0, W, H);
      for (const p of parts) {
        p.y += p.vy + Math.sin(t * 1.3 + p.ph) * 0.18;
        p.x += p.vx + Math.sin(t * p.sway + p.ph) * 0.35;
        p.rot += p.vr; p.flip += p.flipV;
        if (p.y > H + 40 || p.x < -60 || p.x > W + 60) Object.assign(p, mk(true));
        const im = p.img;
        if (!im.complete || !im.naturalWidth) continue;
        const sx = Math.abs(Math.cos(p.flip)) * 0.75 + 0.25;
        ctx.save();
        ctx.translate(p.x + Math.sin(t * p.sway + p.ph) * p.swayAmp * 0.12, p.y);
        ctx.rotate(p.rot + Math.sin(t * 0.9 + p.ph) * 0.28);
        ctx.scale(sx, 1);
        ctx.globalAlpha = (0.45 + p.depth * 0.55) * i;
        ctx.drawImage(im, -p.size / 2, -p.size / 2, p.size, p.size);
        ctx.restore();
      }
    };
    step();
    return () => { cancelAnimationFrame(raf); ro.disconnect(); io.disconnect(); };
  }, [n, a, i]);
  return /* @__PURE__ */ u.jsx("canvas", {
    ref,
    style: { position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none", zIndex: 2 }
  });
}

/* section heading: eyebrow + script title + ornament */
function EAHead({ eyebrow: n, title: a, dark: i = false }) {
  return /* @__PURE__ */ u.jsxs("div", {
    style: { textAlign: "center", position: "relative", zIndex: 2 },
    children: [
      /* @__PURE__ */ u.jsx(EARev, { children: /* @__PURE__ */ u.jsx("p", {
        style: { fontFamily: EA_CAPS, fontSize: 11, letterSpacing: "0.44em", textTransform: "uppercase", color: i ? EA_C.goldHi : EA_C.goldDeep, margin: 0 },
        children: n
      }) }),
      /* @__PURE__ */ u.jsx(EARev, { delay: 0.08, children: /* @__PURE__ */ u.jsx("h2", {
        style: { fontFamily: EA_SCRIPT, fontSize: "clamp(40px,7.4vw,58px)", color: i ? EA_C.emInk : EA_C.em, margin: "12px 0 0", fontWeight: 400, lineHeight: 1.12 },
        children: a
      }) }),
      /* @__PURE__ */ u.jsx(EARev, { delay: 0.16, children: /* @__PURE__ */ u.jsxs("div", {
        style: { display: "flex", alignItems: "center", justifyContent: "center", gap: 10, marginTop: 18 },
        children: [
          /* @__PURE__ */ u.jsx("span", { style: { width: 46, height: 1, background: `linear-gradient(to right, transparent, ${EA_C.gold})` } }),
          /* @__PURE__ */ u.jsx("span", { style: { width: 7, height: 7, transform: "rotate(45deg)", background: EA_C.gold, boxShadow: `0 0 0 3px ${i ? "rgba(232,207,143,0.18)" : "rgba(201,162,74,0.18)"}` } }),
          /* @__PURE__ */ u.jsx("span", { style: { width: 46, height: 1, background: `linear-gradient(to left, transparent, ${EA_C.gold})` } })
        ]
      }) })
    ]
  });
}

/* ---------- the envelope: full-screen, villa geometry, true 3D flap ---------- */

function EAEnvelope({ hint: n, guestName: a, monogram: i, onOpened: r, onOpening: l }) {
  const [ph, setPh] = w.useState("idle"); // idle → seal → flap → part → fade
  const timers = w.useRef([]);
  w.useEffect(() => {
    "scrollRestoration" in history && (history.scrollRestoration = "manual");
    window.scrollTo(0, 0);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { timers.current.forEach(clearTimeout); document.body.style.overflow = prev; };
  }, []);
  const begin = () => {
    if (ph !== "idle") return;
    window.scrollTo(0, 0);
    setPh("seal");
    timers.current.push(setTimeout(() => setPh("flap"), 400));
    timers.current.push(setTimeout(() => { setPh("part"); l && l(); }, 1900));
    timers.current.push(setTimeout(() => setPh("fade"), 3050));
    timers.current.push(setTimeout(() => r && r(), 3450));
  };
  const opening = ph === "flap" || ph === "part" || ph === "fade";
  const parting = ph === "part" || ph === "fade";
  const paper = {
    backgroundImage: "url(./art/em-damask.jpg)",
    backgroundSize: "480px",
    backgroundColor: EA_C.em
  };
  const lining = {
    backgroundImage: "url(./art/em-ivory.jpg)",
    backgroundSize: "cover",
    backgroundColor: "#f3ead2"
  };
  return /* @__PURE__ */ u.jsxs(k.div, {
    style: { position: "fixed", inset: 0, zIndex: 60, overflow: "hidden", userSelect: "none", background: parting ? "transparent" : EA_C.emDeep },
    animate: { opacity: ph === "fade" ? 0 : 1 },
    transition: { duration: 0.4, ease: "easeOut" },
    role: "button", "aria-label": n, onClick: begin,
    children: [
      /* golden backdrop revealed while parting */
      /* @__PURE__ */ u.jsx(k.div, {
        style: {
          position: "absolute", inset: 0,
          background: "radial-gradient(90% 60% at 50% 40%, rgba(232,207,143,0.9) 0%, rgba(201,162,74,0.4) 42%, rgba(8,42,31,0.9) 100%)"
        },
        initial: { opacity: 0 },
        animate: parting ? { opacity: [0.55, 1, 0.45] } : ph === "flap" ? { opacity: [0, 0.55] } : { opacity: 0 },
        transition: parting ? { duration: 1.1, times: [0, 0.45, 1], ease: "easeOut" } : { duration: 1.2, ease: "easeOut" }
      }),

      /* the card that stands revealed (matches hero panel geometry) */
      /* @__PURE__ */ u.jsxs(k.div, {
        style: {
          position: "absolute", left: "50%", top: "50%", x: "-50%", y: "-50%",
          width: "min(84vw, 372px)", aspectRatio: "0.74",
          borderRadius: "min(42vw,186px) min(42vw,186px) 14px 14px",
          background: `linear-gradient(168deg, #fcf7ea 0%, ${EA_C.ivory} 55%, #ecdfba 100%)`,
          border: "1px solid rgba(201,162,74,0.9)",
          boxShadow: "0 34px 80px rgba(2,14,9,0.55), 0 4px 18px rgba(2,14,9,0.3), inset 0 1px 0 rgba(255,255,255,0.8), inset 0 0 0 6px rgba(246,239,221,0.85), inset 0 0 0 7px rgba(201,162,74,0.6)"
        },
        initial: { scale: 0.9, opacity: 0, filter: "brightness(1.7)" },
        animate: parting
          ? { scale: 1, opacity: 1, filter: "brightness(1)" }
          : ph === "flap"
            ? { scale: 0.96, opacity: 0.94, filter: "brightness(1.25)" }
            : { scale: 0.9, opacity: 0, filter: "brightness(1.7)" },
        transition: { duration: 1.0, ease: EA_EASE }
      }),

      /* 3D stage */
      /* @__PURE__ */ u.jsxs("div", {
        style: { position: "absolute", inset: 0, perspective: "1400px", perspectiveOrigin: "50% 8%" },
        children: [
          /* POCKET — full screen with the flap notch */
          /* @__PURE__ */ u.jsxs(k.div, {
            style: {
              position: "absolute", inset: 0,
              clipPath: "polygon(-2% 102%, 102% 102%, 102% -2%, 50% 50.6%, -2% -2%)",
              willChange: "transform"
            },
            animate: parting ? { y: "112%" } : { y: "0%" },
            transition: { duration: 1.0, ease: [0.55, 0, 0.75, 0.4] },
            children: [
              /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, ...paper } }),
              /* paper light + shading */
              /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "radial-gradient(120% 70% at 30% 12%, rgba(255,246,220,0.10) 0%, transparent 55%)" } }),
              /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(4,20,14,0.34) 42%, transparent 66%)" } }),
              /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(4,20,14,0.4) 0%, transparent 30%)" } }),
              /* gold seam lines corner→centre */
              /* @__PURE__ */ u.jsx(k.svg, {
                style: { position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" },
                viewBox: "0 0 100 100", preserveAspectRatio: "none", "aria-hidden": true,
                animate: { opacity: parting ? 0 : 1 }, transition: { duration: 0.3 },
                children: ["M0,0 L50,50.4", "M100,0 L50,50.4", "M0,100 L50,50.4", "M100,100 L50,50.4"].map((dd) => /* @__PURE__ */ u.jsxs("g", { children: [
                  /* @__PURE__ */ u.jsx("path", { d: dd, fill: "none", stroke: "rgba(232,207,143,0.5)", strokeWidth: 1.4, vectorEffect: "non-scaling-stroke", transform: "translate(0.28,0.28)" }),
                  /* @__PURE__ */ u.jsx("path", { d: dd, fill: "none", stroke: "rgba(4,20,14,0.5)", strokeWidth: 1, vectorEffect: "non-scaling-stroke" })
                ] }, dd))
              }),
              /* guest name on the pocket */
              a ? /* @__PURE__ */ u.jsxs(k.div, {
                style: { position: "absolute", left: 0, right: 0, top: "63%", textAlign: "center", pointerEvents: "none" },
                initial: { opacity: 0, y: 14 },
                animate: parting ? { opacity: 0 } : { opacity: 1, y: 0 },
                transition: parting ? { duration: 0.25 } : { duration: 1, delay: 1.15, ease: EA_EASE },
                children: [
                  /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_CAPS, fontSize: 10, letterSpacing: "0.44em", textTransform: "uppercase", color: EA_C.goldHi, margin: 0, opacity: 0.9 }, children: a.pre }),
                  /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_SCRIPT, fontSize: "clamp(30px,8.4vw,40px)", color: "#f6ecd2", margin: "8px 0 0", lineHeight: 1.15, textShadow: "0 2px 14px rgba(2,14,9,0.6)" }, children: a.name })
                ]
              }) : null
            ]
          }),

          /* golden light spilling from the notch as the flap lifts */
          /* @__PURE__ */ u.jsx(k.div, {
            style: {
              position: "absolute", left: "4%", right: "4%", top: 0, height: "56%",
              clipPath: "polygon(0 0, 100% 0, 50% 100%)",
              background: "radial-gradient(62% 64% at 50% 6%, rgba(255,238,186,0.98) 0%, rgba(232,207,143,0.72) 42%, rgba(232,207,143,0.25) 68%, transparent 84%)",
              filter: "blur(6px)", pointerEvents: "none"
            },
            initial: { opacity: 0 },
            animate: ph === "flap" ? { opacity: [0, 0.55, 0.95] } : parting ? { opacity: 0 } : { opacity: 0 },
            transition: ph === "flap" ? { duration: 1.35, times: [0, 0.45, 1], ease: "easeOut" } : { duration: 0.45 }
          }),

          /* the flap's shadow sweeping down the pocket */
          /* @__PURE__ */ u.jsx(k.div, {
            style: {
              position: "absolute", left: 0, right: 0, top: 0, height: "52%",
              clipPath: "polygon(0 0, 100% 0, 50% 100%)",
              background: "linear-gradient(to bottom, rgba(3,16,11,0.72), transparent 78%)",
              pointerEvents: "none"
            },
            initial: { opacity: 0, scaleY: 0.25 },
            animate: ph === "flap" ? { opacity: [0, 0.5, 0.68, 0], scaleY: [0.25, 0.7, 1, 1.04] } : { opacity: 0 },
            transition: { duration: 1.45, times: [0, 0.4, 0.75, 1], ease: "easeInOut" }
          }),

          /* FLAP — full-width triangle hinged on the top edge, real 3D */
          /* @__PURE__ */ u.jsxs(k.div, {
            style: {
              position: "absolute", inset: 0,
              transformOrigin: "50% 0%", transformStyle: "preserve-3d",
              willChange: "transform", pointerEvents: "none"
            },
            initial: { rotateX: 0 },
            animate: opening ? { rotateX: [-0, -121, -99, -110] } : { rotateX: 0 },
            transition: opening ? { duration: 1.42, times: [0, 0.68, 0.88, 1], ease: "easeInOut" } : { duration: 0.3 },
            children: [
              /* front face — emerald paper, gold trimmed edges */
              /* @__PURE__ */ u.jsxs(k.div, {
                style: {
                  position: "absolute", inset: 0,
                  clipPath: "polygon(-2% -2%, 102% -2%, 50% 51%)",
                  backfaceVisibility: "hidden", WebkitBackfaceVisibility: "hidden"
                },
                children: [
                  /* @__PURE__ */ u.jsx(k.div, {
                    style: { position: "absolute", inset: 0, ...paper },
                    animate: opening ? { filter: ["brightness(1)", "brightness(0.72)", "brightness(0.52)", "brightness(0.6)"] } : { filter: "brightness(1)" },
                    transition: { duration: 1.42, times: [0, 0.5, 0.8, 1] }
                  }),
                  /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(255,246,220,0.14) 0%, transparent 26%)" } }),
                  /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "linear-gradient(to bottom, transparent 22%, rgba(4,20,14,0.42) 52%)" } }),
                  /* gold edge trim on the two diagonals */
                  /* @__PURE__ */ u.jsxs("svg", {
                    style: { position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" },
                    viewBox: "0 0 100 100", preserveAspectRatio: "none", "aria-hidden": true,
                    children: ["M0,0 L50,51", "M100,0 L50,51"].map((dd) => /* @__PURE__ */ u.jsxs("g", { children: [
                      /* @__PURE__ */ u.jsx("path", { d: dd, fill: "none", stroke: "rgba(232,207,143,0.85)", strokeWidth: 2, vectorEffect: "non-scaling-stroke", transform: "translate(0.3,0.3)" }),
                      /* @__PURE__ */ u.jsx("path", { d: dd, fill: "none", stroke: "rgba(160,125,47,0.9)", strokeWidth: 1.1, vectorEffect: "non-scaling-stroke" })
                    ] }, dd))
                  })
                ]
              }),
              /* back face — ivory damask lining */
              /* @__PURE__ */ u.jsxs(k.div, {
                style: {
                  position: "absolute", inset: 0,
                  clipPath: "polygon(-2% -2%, 102% -2%, 50% 51%)",
                  transform: "rotateX(180deg)",
                  backfaceVisibility: "hidden", WebkitBackfaceVisibility: "hidden"
                },
                children: [
                  /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, ...lining } }),
                  /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(120,90,30,0.22) 0%, transparent 40%)" } }),
                  /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(120,90,30,0.16) 0%, transparent 30%)" } }),
                  /* @__PURE__ */ u.jsxs("svg", {
                    style: { position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" },
                    viewBox: "0 0 100 100", preserveAspectRatio: "none", "aria-hidden": true,
                    children: ["M0,0 L50,51", "M100,0 L50,51"].map((dd) => /* @__PURE__ */ u.jsx("path", { d: dd, fill: "none", stroke: "rgba(160,125,47,0.75)", strokeWidth: 1.6, vectorEffect: "non-scaling-stroke" }, dd))
                  })
                ]
              })
            ]
          })
        ]
      }),

      /* wax seal with live monogram — villa-style pop-in, breathe, crush-fade */
      /* @__PURE__ */ u.jsx("div", {
        style: { position: "absolute", left: "50%", top: "50%", transform: "translate(-50%,-50%)", pointerEvents: "none" },
        children: /* @__PURE__ */ u.jsxs(k.div, {
          style: { position: "relative", width: 148, height: 148 },
          initial: { scale: 0, rotate: -24, opacity: 0 },
          animate: ph === "idle"
            ? { scale: [1, 1.03, 1], rotate: 0, opacity: 1, y: 0, filter: "brightness(1) drop-shadow(0 14px 30px rgba(2,14,9,0.55))" }
            : { scale: [1.06, 0.7], rotate: 0, opacity: [1, 0], y: 6, filter: "brightness(1.35) drop-shadow(0 8px 20px rgba(2,14,9,0.4))" },
          transition: ph === "idle"
            ? { scale: { duration: 3, repeat: Infinity, ease: "easeInOut" }, rotate: { duration: 0.9 }, opacity: { duration: 0.8, delay: 0.3 } }
            : { duration: 0.36, ease: "easeIn", times: [0, 1] },
          children: [
            /* glow ring */
            /* @__PURE__ */ u.jsx(k.span, {
              style: {
                position: "absolute", inset: "-24%", borderRadius: "50%",
                background: "radial-gradient(circle, rgba(232,207,143,0.9) 0%, rgba(201,162,74,0.4) 45%, transparent 70%)",
                filter: "blur(5px)"
              },
              initial: { opacity: 0 },
              animate: ph === "seal" ? { opacity: [0, 1] } : ph === "idle" ? { opacity: [0.2, 0.38, 0.2] } : { opacity: 0 },
              transition: ph === "seal" ? { duration: 0.4 } : { duration: 2.6, repeat: Infinity, ease: "easeInOut" }
            }),
            /* @__PURE__ */ u.jsx("img", { src: "./art/em-seal-gold.png", alt: "wax seal", draggable: false, style: { position: "relative", width: "100%", height: "100%", objectFit: "contain" } }),
            /* @__PURE__ */ u.jsx("span", {
              style: {
                position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center",
                fontFamily: EA_CAPS, fontWeight: 700, fontSize: 30, color: "#6e5416",
                letterSpacing: "0.04em", textShadow: "0 1px 0 rgba(255,240,200,0.65), 0 -1px 2px rgba(0,0,0,0.35)",
                transform: "translateY(-2px)"
              },
              children: i
            })
          ]
        })
      }),

      /* hint */
      ph === "idle" ? /* @__PURE__ */ u.jsxs(k.div, {
        style: {
          position: "absolute", bottom: "8vh", left: 0, right: 0, display: "flex", flexDirection: "column",
          alignItems: "center", gap: 10, pointerEvents: "none"
        },
        initial: { opacity: 0 }, animate: { opacity: 1 }, transition: { delay: 1.5, duration: 0.9 },
        children: [
          /* @__PURE__ */ u.jsx(k.p, {
            style: { fontFamily: EA_SANS, fontSize: 11, letterSpacing: "0.4em", textTransform: "uppercase", color: "rgba(232,207,143,0.9)", margin: 0 },
            animate: { opacity: [0.55, 1, 0.55] }, transition: { duration: 2.4, repeat: Infinity, ease: "easeInOut" },
            children: n
          }),
          /* @__PURE__ */ u.jsx(k.span, {
            style: { width: 12, height: 12, borderRight: `1.5px solid ${EA_C.goldHi}`, borderBottom: `1.5px solid ${EA_C.goldHi}`, transform: "rotate(45deg)", opacity: 0.85 },
            animate: { y: [0, 6, 0], opacity: [0.4, 0.9, 0.4] },
            transition: { duration: 1.8, repeat: Infinity, ease: "easeInOut" }
          })
        ]
      }) : null,

      /* falling leaves above everything, subtle */
      /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, pointerEvents: "none" }, children: /* @__PURE__ */ u.jsx(EALeaves, { kind: "leaves", density: 7, opacity: 0.65 }) })
    ]
  });
}

/* ---------- hero: corner artworks, gilded arch frame, cinematic entrances ---------- */

function EAHero({ data: n, opened: a, t: i, guest: r }) {
  const ref = w.useRef(null);
  const { scrollYProgress: l } = Jr({ target: ref, offset: ["start start", "end start"] });
  const bgY = St(l, [0, 1], ["0%", "16%"]);
  const ev0 = (Array.isArray(n.events) && n.events[0]) || {};
  const dateLine = ev0.date ? Qx(ev0.date) : "";
  const venueLine = (ev0.venue || "").trim();

  /* villa-style entrance helper */
  const p = (delay, blur = 9, y = 24, dur = 1.05) => ({
    initial: !1,
    animate: a
      ? { opacity: 1, y: 0, scale: 1, filter: "blur(0px)" }
      : { opacity: 0, y, scale: 0.94, filter: `blur(${blur}px)` },
    transition: { duration: dur, delay, ease: [0.22, 0.8, 0.35, 1] }
  });

  return /* @__PURE__ */ u.jsxs("section", {
    ref,
    style: { position: "relative", minHeight: "100svh", overflow: "hidden", background: EA_C.emDeep },
    children: [
      /* parallax emerald damask field */
      /* @__PURE__ */ u.jsxs(k.div, {
        style: { position: "absolute", left: 0, right: 0, top: "-10%", bottom: "-10%", y: bgY, zIndex: 0 },
        children: [
          n.heroImage && String(n.heroImage).trim() ? /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, backgroundImage: `url(${n.heroImage})`, backgroundSize: "cover", backgroundPosition: "center 30%" } }) : null,
          /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, backgroundImage: "url(./art/em-damask.jpg)", backgroundSize: "520px", backgroundColor: EA_C.em, opacity: n.heroImage && String(n.heroImage).trim() ? 0.88 : 0.92 } }),
          /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "radial-gradient(130% 70% at 50% 34%, rgba(255,240,200,0.10) 0%, transparent 55%)" } }),
          /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "radial-gradient(120% 90% at 50% 110%, rgba(4,22,15,0.55) 0%, transparent 55%)" } }),
          /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(8,42,31,0.5) 0%, transparent 18%, transparent 82%, rgba(8,42,31,0.55) 100%)" } })
        ]
      }),

      /* upper corners — white rose clusters, arms hugging the frame, points outward */
      /* @__PURE__ */ u.jsx(k.img, {
        src: "./art/em-corner-rose-tl.png", alt: "", draggable: false,
        style: {
          position: "absolute", top: -18, left: -16, width: "min(50vw, 282px)",
          zIndex: 1, transformOrigin: "top left", pointerEvents: "none",
          filter: "drop-shadow(0 12px 24px rgba(3,16,11,0.45))"
        },
        initial: !1,
        animate: a ? { opacity: 1, scale: 1, rotate: [0, 1.2, 0, -1, 0] } : { opacity: 0, scale: 0.82, rotate: -4 },
        transition: a
          ? { opacity: { duration: 1.1, delay: 0.5 }, scale: { duration: 1.3, delay: 0.5, ease: EA_EASE }, rotate: { duration: 9, delay: 1.8, repeat: Infinity, ease: "easeInOut" } }
          : { duration: 0.2 }
      }),
      /* @__PURE__ */ u.jsx(k.img, {
        src: "./art/em-corner-rose-tr.png", alt: "", draggable: false,
        style: {
          position: "absolute", top: -18, right: -16, width: "min(50vw, 282px)",
          zIndex: 1, transformOrigin: "top right", pointerEvents: "none",
          filter: "drop-shadow(0 12px 24px rgba(3,16,11,0.45))"
        },
        initial: !1,
        animate: a ? { opacity: 1, scale: 1, rotate: [0, -1.2, 0, 1, 0] } : { opacity: 0, scale: 0.82, rotate: 4 },
        transition: a
          ? { opacity: { duration: 1.1, delay: 0.6 }, scale: { duration: 1.3, delay: 0.6, ease: EA_EASE }, rotate: { duration: 9, delay: 1.9, repeat: Infinity, ease: "easeInOut" } }
          : { duration: 0.2 }
      }),

      /* lower corners — gold filigree, elbows in the bottom corners, arms hugging the frame */
      /* @__PURE__ */ u.jsx(k.img, {
        src: "./art/em-corner-filigree-bl.png", alt: "", draggable: false,
        style: {
          position: "absolute", bottom: -12, left: -14, width: "min(52vw, 290px)",
          zIndex: 1, transformOrigin: "bottom left", pointerEvents: "none",
          filter: "drop-shadow(0 -8px 20px rgba(3,16,11,0.4))"
        },
        initial: !1,
        animate: a ? { opacity: 1, y: 0, rotate: [0, -1, 0, 0.8, 0] } : { opacity: 0, y: 90, rotate: 3 },
        transition: a
          ? { opacity: { duration: 1.2, delay: 0.9 }, y: { type: "spring", stiffness: 64, damping: 15, delay: 0.9 }, rotate: { duration: 10, delay: 2.1, repeat: Infinity, ease: "easeInOut" } }
          : { duration: 0.2 }
      }),
      /* @__PURE__ */ u.jsx(k.img, {
        src: "./art/em-corner-filigree-br.png", alt: "", draggable: false,
        style: {
          position: "absolute", bottom: -12, right: -14, width: "min(52vw, 290px)",
          zIndex: 1, transformOrigin: "bottom right", pointerEvents: "none",
          filter: "drop-shadow(0 -8px 20px rgba(3,16,11,0.4))"
        },
        initial: !1,
        animate: a ? { opacity: 1, y: 0, rotate: [0, 1, 0, -0.8, 0] } : { opacity: 0, y: 90, rotate: -3 },
        transition: a
          ? { opacity: { duration: 1.2, delay: 1.0 }, y: { type: "spring", stiffness: 64, damping: 15, delay: 1.0 }, rotate: { duration: 10, delay: 2.2, repeat: Infinity, ease: "easeInOut" } }
          : { duration: 0.2 }
      }),

      /* falling gold leaves */
      /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, zIndex: 2, pointerEvents: "none" }, children: /* @__PURE__ */ u.jsx(EALeaves, { kind: "leaves", density: 9, opacity: 0.85 }) }),

      /* the gilded arch panel */
      /* @__PURE__ */ u.jsxs(k.div, {
        style: {
          position: "relative", zIndex: 3, width: "min(84vw, 372px)",
          margin: "0 auto", minHeight: "100svh",
          display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
          padding: "11svh 0 9svh"
        },
        children: [
          /* ivory panel */
          /* @__PURE__ */ u.jsxs(k.div, {
            style: {
              position: "relative", width: "100%", aspectRatio: "0.74",
              padding: "clamp(40px,7vh,64px) 34px clamp(30px,5vh,44px)",
              borderRadius: "min(42vw,186px) min(42vw,186px) 14px 14px",
              background: `linear-gradient(168deg, #fcf7ea 0%, ${EA_C.ivory} 55%, #ecdfba 100%)`,
              border: "1px solid rgba(201,162,74,0.9)",
              boxShadow: "0 34px 80px rgba(2,14,9,0.55), 0 4px 18px rgba(2,14,9,0.3), inset 0 1px 0 rgba(255,255,255,0.8), inset 0 0 0 6px rgba(246,239,221,0.85), inset 0 0 0 7px rgba(201,162,74,0.6)",
              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center"
            },
            initial: !1,
            animate: a ? { opacity: 1, scale: 1, y: 0 } : { opacity: 0, scale: 0.95, y: 46 },
            transition: { type: "spring", stiffness: 62, damping: 16, delay: 0.25 },
            children: [
              /* inner hairline */
              /* @__PURE__ */ u.jsx("div", {
                style: {
                  position: "absolute", inset: 14, borderRadius: "min(37vw,172px) min(37vw,172px) 10px 10px",
                  border: "1px solid rgba(201,162,74,0.5)", pointerEvents: "none"
                }
              }),

              /* bismillah — cinematic */
              /* @__PURE__ */ u.jsx(k.p, {
                style: { fontFamily: EA_AMIRI, fontSize: "clamp(21px,5.4vw,26px)", color: EA_C.goldDeep, margin: "0 0 4px", lineHeight: 1.6, position: "relative" },
                initial: !1,
                animate: a
                  ? { opacity: [0, 0.55, 1], y: [18, 4, 0], scale: [0.92, 1.03, 1], filter: ["blur(10px)", "blur(2px)", "blur(0px)"] }
                  : { opacity: 0 },
                transition: { duration: 1.7, delay: 0.85, times: [0, 0.6, 1], ease: EA_EASE },
                children: n.bismillah || "بسم الله الرحمن الرحيم"
              }),

              /* @__PURE__ */ u.jsx(k.p, {
                ...p(1.35),
                style: { fontFamily: EA_CAPS, fontSize: 10, letterSpacing: "0.42em", textTransform: "uppercase", color: EA_C.inkSoft, margin: "14px 0 0", position: "relative" },
                children: i.invited
              }),

              /* names — groom above, ampersand, bride below */
              /* @__PURE__ */ u.jsxs("div", {
                style: { position: "relative", margin: "14px 0 0", maxWidth: "100%", display: "flex", flexDirection: "column", alignItems: "center" },
                children: [
                  /* @__PURE__ */ u.jsx(k.span, {
                    style: {
                      fontFamily: EA_SCRIPT, fontSize: EA_NAME_SIZE(n.groomName), lineHeight: 1.06, fontWeight: 400,
                      color: EA_C.em, margin: 0, padding: "0 4px", maxWidth: "100%", display: "block",
                      textShadow: "0 1px 0 rgba(255,255,255,0.7)", overflowWrap: "break-word"
                    },
                    initial: !1,
                    animate: a
                      ? { clipPath: ["inset(-12% 102% -12% -8%)", "inset(-12% -6% -12% -8%)"], opacity: 1, y: 0 }
                      : { clipPath: "inset(-12% 102% -12% -8%)", opacity: 0, y: 14 },
                    transition: { duration: 1.4, delay: 1.55, ease: [0.22, 0.8, 0.35, 1] },
                    children: n.groomName
                  }),
                  /* @__PURE__ */ u.jsx(k.span, {
                    style: { fontFamily: EA_SCRIPT, fontSize: "clamp(20px,5vw,26px)", color: EA_C.goldDeep, lineHeight: 1, margin: "4px 0 2px", display: "block" },
                    initial: !1,
                    animate: a ? { opacity: 1, scale: 1, filter: "blur(0px)" } : { opacity: 0, scale: 0.6, filter: "blur(4px)" },
                    transition: { duration: 0.9, delay: 1.95, ease: EA_EASE },
                    children: "&"
                  }),
                  /* @__PURE__ */ u.jsx(k.span, {
                    style: {
                      fontFamily: EA_SCRIPT, fontSize: EA_NAME_SIZE(n.brideName), lineHeight: 1.06, fontWeight: 400,
                      color: EA_C.em, margin: 0, padding: "0 4px", maxWidth: "100%", display: "block",
                      textShadow: "0 1px 0 rgba(255,255,255,0.7)", overflowWrap: "break-word"
                    },
                    initial: !1,
                    animate: a
                      ? { clipPath: ["inset(-12% 102% -12% -8%)", "inset(-12% -6% -12% -8%)"], opacity: 1, y: 0 }
                      : { clipPath: "inset(-12% 102% -12% -8%)", opacity: 0, y: 14 },
                    transition: { duration: 1.4, delay: 2.1, ease: [0.22, 0.8, 0.35, 1] },
                    children: n.brideName
                  })
                ]
              }),

              /* divider drawing in */
              /* @__PURE__ */ u.jsxs(k.div, {
                style: { display: "flex", alignItems: "center", gap: 10, margin: "18px 0 0" },
                initial: !1,
                animate: a ? { opacity: 1, scaleX: 1 } : { opacity: 0, scaleX: 0.3 },
                transition: { duration: 1.1, delay: 2.15, ease: EA_EASE },
                children: [
                  /* @__PURE__ */ u.jsx("span", { style: { width: 52, height: 1, background: `linear-gradient(to right, transparent, ${EA_C.gold})` } }),
                  /* @__PURE__ */ u.jsx("span", { style: { width: 8, height: 8, transform: "rotate(45deg)", background: `linear-gradient(135deg, ${EA_C.goldHi}, ${EA_C.goldDeep})`, boxShadow: "0 0 0 3px rgba(201,162,74,0.2)" } }),
                  /* @__PURE__ */ u.jsx("span", { style: { width: 52, height: 1, background: `linear-gradient(to left, transparent, ${EA_C.gold})` } })
                ]
              }),

              /* date + venue */
              /* @__PURE__ */ u.jsx(k.p, {
                ...p(2.35, 6, 16),
                style: { fontFamily: EA_CAPS, fontSize: "clamp(14px,3.8vw,16px)", letterSpacing: "0.3em", color: EA_C.ink, margin: "18px 0 0", fontWeight: 500 },
                children: dateLine
              }),
              venueLine ? /* @__PURE__ */ u.jsx(k.p, {
                ...p(2.5, 6, 14),
                style: { fontFamily: EA_BODY, fontSize: 15, color: EA_C.inkSoft, margin: "8px 0 0", fontStyle: "italic", padding: "0 6px" },
                children: venueLine
              }) : null
            ]
          }),

          /* scroll cue */
          /* @__PURE__ */ u.jsxs(k.div, {
            style: { marginTop: "5svh", display: "flex", flexDirection: "column", alignItems: "center", gap: 8 },
            initial: !1,
            animate: a ? { opacity: 1, y: 0 } : { opacity: 0, y: 12 },
            transition: { duration: 1, delay: 2.9 },
            children: [
              /* @__PURE__ */ u.jsx("span", { style: { fontFamily: EA_SANS, fontSize: 10, letterSpacing: "0.4em", textTransform: "uppercase", color: "rgba(232,207,143,0.85)" }, children: i.scroll }),
              /* @__PURE__ */ u.jsx(k.span, {
                style: { width: 11, height: 11, borderRight: `1.5px solid ${EA_C.goldHi}`, borderBottom: `1.5px solid ${EA_C.goldHi}`, transform: "rotate(45deg)" },
                animate: { y: [0, 7, 0], opacity: [0.4, 1, 0.4] },
                transition: { duration: 1.8, repeat: Infinity, ease: "easeInOut" }
              })
            ]
          })
        ]
      })
    ]
  });
}

/* ---------- countdown ---------- */

function EACountdown({ targetISO: n, t: a }) {
  const [now, setNow] = w.useState(() => Date.now());
  w.useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const diff = Math.max(0, new Date(n).getTime() - now);
  const d = Math.floor(diff / 864e5);
  const h = Math.floor(diff / 36e5) % 24;
  const m = Math.floor(diff / 6e4) % 60;
  const s = Math.floor(diff / 1e3) % 60;
  const cells = [[d, a.days], [h, a.hours], [m, a.minutes], [s, a.seconds]];
  return /* @__PURE__ */ u.jsxs("div", {
    style: { display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap", marginTop: 34, position: "relative", zIndex: 2 },
    children: cells.map(([v, lab], idx) => /* @__PURE__ */ u.jsxs(EARev, {
      delay: idx * 0.07, y: 22,
      children: [
        /* @__PURE__ */ u.jsxs("div", {
          style: {
            width: 70, height: 88, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            borderRadius: "35px 35px 8px 8px",
            background: "linear-gradient(170deg, #11443400, #11443466 0%, #082a1f 130%)",
            backgroundColor: "rgba(17,68,52,0.4)",
            border: "1px solid rgba(201,162,74,0.5)",
            boxShadow: "0 12px 26px rgba(2,14,9,0.35), inset 0 1px 0 rgba(232,207,143,0.35)"
          },
          children: [
            /* @__PURE__ */ u.jsx("div", { style: { fontFamily: EA_BODY, fontSize: 30, fontWeight: 600, color: EA_C.emInk, lineHeight: 1, fontVariantNumeric: "tabular-nums" }, children: String(v).padStart(2, "0") }),
            /* @__PURE__ */ u.jsx("div", { style: { fontFamily: EA_SANS, fontSize: 9, letterSpacing: "0.22em", textTransform: "uppercase", color: EA_C.emInkSoft, marginTop: 7 }, children: lab })
          ]
        })
      ]
    }, idx))
  });
}

/* ---------- schedule: villa-style dotted line with a travelling rose ---------- */

function EATimeline({ events: n, t: a }) {
  const ref = w.useRef(null);
  const { scrollYProgress: l } = Jr({ target: ref, offset: ["start 0.72", "end 0.55"] });
  const d = St(l, [0, 1], ["1%", "94%"]);
  const rot = St(l, [0, 1], [-14, 16]);
  return /* @__PURE__ */ u.jsx("div", {
    ref,
    style: { position: "relative", maxWidth: 520, margin: "46px auto 0", paddingLeft: 92 },
    children: [
      /* dotted gold spine */
      /* @__PURE__ */ u.jsx("div", {
        style: {
          position: "absolute", top: 6, bottom: 6, left: 74,
          borderLeft: "2px dotted rgba(232,207,143,0.6)"
        }
      }),
      /* travelling rosebud */
      /* @__PURE__ */ u.jsx(k.img, {
        src: "./art/em-rosebud.png", alt: "", draggable: false,
        style: {
          position: "absolute", left: 70, top: d, x: "-50%", rotate: rot,
          width: 48, pointerEvents: "none", zIndex: 3,
          filter: "drop-shadow(0 6px 14px rgba(2,14,9,0.55)) drop-shadow(0 0 18px rgba(232,207,143,0.35))"
        }
      }),
      /* @__PURE__ */ u.jsx("div", {
        style: { display: "flex", flexDirection: "column", gap: 40 },
        children: n.map((e, idx) => /* @__PURE__ */ u.jsxs(k.div, {
          style: { position: "relative" },
          initial: { opacity: 0, x: 26 },
          whileInView: { opacity: 1, x: 0 },
          viewport: { once: true, margin: "-40px" },
          transition: { duration: 0.9, delay: idx * 0.05, ease: EA_EASE },
          children: [
            /* time in the left gutter */
            /* @__PURE__ */ u.jsx("div", {
              style: {
                position: "absolute", left: -92, width: 68, top: 3, textAlign: "right",
                fontFamily: EA_BODY, fontSize: 13.5, letterSpacing: "0.02em",
                color: EA_C.goldHi, fontVariantNumeric: "tabular-nums", fontWeight: 600
              },
              children: WT(e.time)
            }),
            /* node on the line */
            /* @__PURE__ */ u.jsx("span", {
              style: {
                position: "absolute", left: -27.5, top: 7, width: 11, height: 11, borderRadius: "50%",
                background: EA_C.ivory, border: `2px solid ${EA_C.gold}`,
                boxShadow: "0 0 0 4px rgba(14,59,44,0.9), 0 0 0 5px rgba(232,207,143,0.4)"
              }
            }),
            /* @__PURE__ */ u.jsx("h3", {
              style: { fontFamily: EA_SCRIPT, fontSize: 29, color: EA_C.emInk, margin: 0, fontWeight: 400, lineHeight: 1.2, textShadow: "0 2px 12px rgba(2,14,9,0.5)" },
              children: e.name
            })
          ]
        }, idx))
      })
    ]
  });
}

/* ---------- RSVP: sealed arch card that opens into the form ---------- */

function EARsvp({ data: n, guest: a, t: i, onRsvp: r }) {
  const [open, setOpen] = w.useState(!!(a && a.rsvp));
  const [name, setName] = w.useState((a && a.name) || "");
  const [att, setAtt] = w.useState(null);
  const [count, setCount] = w.useState(1);
  const [song, setSong] = w.useState("");
  const [kids, setKids] = w.useState("");
  const [diet, setDiet] = w.useState("");
  const [busy, setBusy] = w.useState(false);
  const [sent, setSent] = w.useState(!!(a && a.rsvp));
  const sentAtt = a && a.rsvp ? !!a.rsvp.attending : att;

  const submit = async () => {
    if (busy || att === null) return;
    setBusy(true);
    const extras = [diet && diet, song && ("Song: " + song), kids && ("Children: " + kids)].filter(Boolean).join(" · ");
    try {
      r && (await r(att, Math.max(0, count - 1), extras));
      setSent(true);
    } finally {
      setBusy(false);
    }
  };

  const field = {
    width: "100%", boxSizing: "border-box",
    background: "rgba(246,239,221,0.08)", border: "1px solid rgba(201,162,74,0.45)",
    borderRadius: 10, padding: "12px 14px", color: EA_C.emInk,
    fontFamily: EA_BODY, fontSize: 16, outline: "none"
  };
  const lab = { fontFamily: EA_CAPS, fontSize: 10, letterSpacing: "0.3em", textTransform: "uppercase", color: EA_C.goldHi, margin: "0 0 8px", textAlign: "left" };

  return /* @__PURE__ */ u.jsxs("div", {
    style: { maxWidth: 460, margin: "42px auto 0", position: "relative", zIndex: 2 },
    children: [
      !open ? /* @__PURE__ */ u.jsxs(k.div, {
        style: {
          position: "relative", margin: "0 14px", padding: "64px 30px 40px", textAlign: "center", cursor: "pointer",
          borderRadius: "230px 230px 14px 14px",
          background: `linear-gradient(170deg, #12463a 0%, ${EA_C.em} 45%, ${EA_C.emDeep} 100%)`,
          border: "1px solid rgba(201,162,74,0.65)",
          boxShadow: "0 26px 60px rgba(2,14,9,0.4), inset 0 1px 0 rgba(232,207,143,0.4)"
        },
        initial: { opacity: 0, y: 40 },
        whileInView: { opacity: 1, y: 0 },
        viewport: { once: true, margin: "-60px" },
        transition: { duration: 1, ease: EA_EASE },
        onClick: () => setOpen(true),
        role: "button", "aria-label": i.rsvpSealHint,
        children: [
          /* @__PURE__ */ u.jsx(k.div, {
            style: { width: 92, height: 92, margin: "0 auto 6px", position: "relative" },
            animate: { scale: [1, 1.045, 1] },
            transition: { duration: 2.6, repeat: Infinity, ease: "easeInOut" },
            children: /* @__PURE__ */ u.jsx("img", { src: "./art/em-seal-gold.png", alt: "", draggable: false, style: { width: "100%", height: "100%", objectFit: "contain", filter: "drop-shadow(0 10px 22px rgba(2,14,9,0.5))" } })
          }),
          /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_SCRIPT, fontSize: 27, color: EA_C.emInk, margin: "10px 0 6px" }, children: i.rsvpTitle }),
          /* @__PURE__ */ u.jsx("p", {
            style: { fontFamily: EA_SANS, fontSize: 10, letterSpacing: "0.32em", textTransform: "uppercase", color: EA_C.goldHi, margin: 0, opacity: 0.9 },
            children: i.rsvpSealHint
          })
        ]
      }) : sent ? /* @__PURE__ */ u.jsxs(k.div, {
        style: {
          margin: "0 14px", padding: "58px 30px 44px", textAlign: "center",
          borderRadius: "230px 230px 14px 14px",
          background: `linear-gradient(170deg, #fcf7ea 0%, ${EA_C.ivory} 60%, #eee0bd 100%)`,
          border: "1px solid rgba(201,162,74,0.7)",
          boxShadow: "0 26px 60px rgba(2,14,9,0.25), inset 0 0 0 8px rgba(246,239,221,0.7), inset 0 0 0 9px rgba(201,162,74,0.4)"
        },
        initial: { opacity: 0, scale: 0.94, filter: "blur(6px)" },
        animate: { opacity: 1, scale: 1, filter: "blur(0px)" },
        transition: { duration: 0.8, ease: EA_EASE },
        children: [
          /* @__PURE__ */ u.jsx("div", { style: { fontSize: 40 }, children: sentAtt ? "💛" : "🌿" }),
          /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_SCRIPT, fontSize: 29, color: EA_C.em, margin: "10px 0 8px" }, children: i.rsvpDone }),
          /* @__PURE__ */ u.jsx("span", {
            style: {
              display: "inline-block", fontFamily: EA_CAPS, fontSize: 11, letterSpacing: "0.26em", textTransform: "uppercase",
              color: sentAtt ? EA_C.em : EA_C.inkSoft, border: `1px solid ${EA_C.gold}`, borderRadius: 999, padding: "8px 18px",
              background: "rgba(201,162,74,0.12)"
            },
            children: sentAtt ? i.attendingBadge : i.declinedBadge
          })
        ]
      }) : /* @__PURE__ */ u.jsxs(k.div, {
        style: {
          margin: "0 14px", padding: "46px 24px 34px",
          borderRadius: "230px 230px 14px 14px",
          background: `linear-gradient(170deg, #12463a 0%, ${EA_C.em} 45%, ${EA_C.emDeep} 100%)`,
          border: "1px solid rgba(201,162,74,0.65)",
          boxShadow: "0 26px 60px rgba(2,14,9,0.4), inset 0 1px 0 rgba(232,207,143,0.35)",
          display: "flex", flexDirection: "column", gap: 18
        },
        initial: { opacity: 0, scale: 0.94, filter: "blur(6px)" },
        animate: { opacity: 1, scale: 1, filter: "blur(0px)" },
        transition: { duration: 0.8, ease: EA_EASE },
        children: [
          /* @__PURE__ */ u.jsxs("div", { children: [
            /* @__PURE__ */ u.jsx("p", { style: lab, children: i.yourName }),
            /* @__PURE__ */ u.jsx("input", { value: name, onChange: (e) => setName(e.target.value), style: field, placeholder: i.yourName })
          ] }),
          /* @__PURE__ */ u.jsxs("div", { children: [
            /* @__PURE__ */ u.jsx("p", { style: lab, children: i.attendQ }),
            /* @__PURE__ */ u.jsxs("div", { style: { display: "flex", gap: 10 }, children: [
              [[true, i.accept], [false, i.decline]].map(([v, txt]) => /* @__PURE__ */ u.jsx("button", {
                onClick: () => setAtt(v),
                style: {
                  flex: 1, padding: "12px 8px", cursor: "pointer", borderRadius: 10,
                  fontFamily: EA_BODY, fontSize: 14.5,
                  border: att === v ? `1.5px solid ${EA_C.goldHi}` : "1px solid rgba(201,162,74,0.45)",
                  background: att === v ? "rgba(201,162,74,0.25)" : "rgba(246,239,221,0.06)",
                  color: att === v ? EA_C.goldHi : EA_C.emInkSoft,
                  transition: "all .25s ease"
                },
                children: txt
              }, String(v)))
            ] })
          ] }),
          att ? /* @__PURE__ */ u.jsxs("div", { children: [
            /* @__PURE__ */ u.jsx("p", { style: lab, children: i.guestsAttending }),
            /* @__PURE__ */ u.jsxs("div", { style: { display: "flex", alignItems: "center", gap: 16, justifyContent: "center" }, children: [
              /* @__PURE__ */ u.jsx("button", { onClick: () => setCount(Math.max(1, count - 1)), style: { width: 40, height: 40, borderRadius: "50%", border: `1px solid ${EA_C.gold}`, background: "transparent", color: EA_C.goldHi, fontSize: 20, cursor: "pointer" }, children: "−" }),
              /* @__PURE__ */ u.jsx("span", { style: { fontFamily: EA_BODY, fontSize: 26, color: EA_C.emInk, minWidth: 30, textAlign: "center", fontVariantNumeric: "tabular-nums" }, children: count }),
              /* @__PURE__ */ u.jsx("button", { onClick: () => setCount(Math.min(8, count + 1)), style: { width: 40, height: 40, borderRadius: "50%", border: `1px solid ${EA_C.gold}`, background: "transparent", color: EA_C.goldHi, fontSize: 20, cursor: "pointer" }, children: "+" })
            ] })
          ] }) : null,
          att ? /* @__PURE__ */ u.jsxs("div", { children: [
            /* @__PURE__ */ u.jsx("p", { style: lab, children: i.songLabel }),
            /* @__PURE__ */ u.jsx("input", { value: song, onChange: (e) => setSong(e.target.value), style: field })
          ] }) : null,
          att ? /* @__PURE__ */ u.jsxs("div", { children: [
            /* @__PURE__ */ u.jsx("p", { style: lab, children: i.childrenLabel }),
            /* @__PURE__ */ u.jsx("input", { value: kids, onChange: (e) => setKids(e.target.value), style: field })
          ] }) : null,
          /* @__PURE__ */ u.jsxs("div", { children: [
            /* @__PURE__ */ u.jsx("p", { style: lab, children: i.dietary }),
            /* @__PURE__ */ u.jsx("input", { value: diet, onChange: (e) => setDiet(e.target.value), style: field })
          ] }),
          /* @__PURE__ */ u.jsx(k.button, {
            onClick: submit,
            disabled: busy || att === null,
            whileTap: { scale: 0.97 },
            style: {
              marginTop: 6, padding: "15px 20px", borderRadius: 12, border: "none", cursor: att === null ? "default" : "pointer",
              fontFamily: EA_CAPS, fontSize: 12, letterSpacing: "0.34em", textTransform: "uppercase", fontWeight: 700,
              background: att === null ? "rgba(201,162,74,0.3)" : `linear-gradient(135deg, ${EA_C.goldHi} 0%, ${EA_C.gold} 45%, ${EA_C.goldDeep} 100%)`,
              color: att === null ? "rgba(246,239,221,0.5)" : "#3d2f0d",
              boxShadow: att === null ? "none" : "0 12px 28px rgba(201,162,74,0.35), inset 0 1px 0 rgba(255,244,210,0.8)",
              opacity: busy ? 0.7 : 1, transition: "all .3s ease"
            },
            children: busy ? i.sending : i.submit
          }),
          n.whatsappNumber ? /* @__PURE__ */ u.jsx("a", {
            href: Fh(n.whatsappNumber, "RSVP — " + (name || ((a && a.name) || ""))),
            target: "_blank", rel: "noreferrer",
            style: { fontFamily: EA_BODY, fontSize: 14, color: EA_C.emInkSoft, textAlign: "center", textDecoration: "underline", textUnderlineOffset: 4 },
            children: i.rsvpWhats
          }) : null
        ]
      })
    ]
  });
}

/* ---------- main ---------- */

function EA({ data: n, guest: a, demo: i = false, autoOpen: r = false, onRsvp: l, onGuestbook: d, guestbookMessages: h = [], inviteUrl: y }) {
  const [lang, setLang] = w.useState(n.language ?? "en");
  const [open, setOpen] = w.useState(!!r);
  const [parting, setParting] = w.useState(!!r);
  const t = { ...(Hh[lang] || {}), ...EA_T[lang] };
  const names = n.groomName + " & " + n.brideName;
  const mono = ((n.sealText || "").trim() || (((n.groomName || "A")[0] || "A") + ((n.brideName || "S")[0] || "S"))).toUpperCase();
  const ev = Array.isArray(n.events) ? n.events : [];
  const ev0 = ev[0] || {};
  const evMain = ev.find((e) => /nikkah|ceremon/i.test(e.name || "")) || ev0;
  const venueStr = (evMain.venue || "").trim();
  const venueParts = venueStr.split(",").map((s) => s.trim()).filter(Boolean);
  const venueName = venueParts[0] || "";
  const venueCity = venueParts.slice(1).join(", ");
  const mapsUrl = evMain.mapsUrl || "";
  const whatsapp = n.whatsappNumber || "";
  const cdTarget = ev0.date ? ev0.date + "T" + ((ev0.time || "12:00").slice(0, 5) || "12:00") : "";
  const story = (lang === "sw" && n.storySw) || n.storyEn || "";
  const quote = (lang === "sw" && n.quoteSw) || n.quoteEn || "";
  const gifts = Array.isArray(n.gifts) ? n.gifts : [];
  const contacts = Array.isArray(n.contacts) ? n.contacts : [];
  const gal = (Array.isArray(n.gallery) ? n.gallery : []).filter((u2) => u2 && String(u2).trim()).slice(0, 8);
  const hasGifts = gifts.length > 0 || contacts.length > 0;

  w.useEffect(() => {
    if (r) { "scrollRestoration" in history && (history.scrollRestoration = "manual"); window.scrollTo(0, 0); }
  }, [r]);

  const dlIcs = () => {
    try {
      const dt = (ev0.date || "").replace(/-/g, "");
      const e0 = ev0;
      let start = dt + "T120000", end = dt + "T180000";
      if (e0 && /\d/.test(e0.time || "")) {
        const tm = (e0.time || "12:00").replace(/[^\d:]/g, "");
        const d0 = new Date(ev0.date + "T" + (tm.length === 5 ? tm : "12:00"));
        if (!isNaN(d0)) {
          const p2 = (x) => String(x).padStart(2, "0");
          const f = (dx) => dx.getFullYear() + p2(dx.getMonth() + 1) + p2(dx.getDate()) + "T" + p2(dx.getHours()) + p2(dx.getMinutes()) + "00";
          start = f(d0); end = f(new Date(d0.getTime() + 6 * 36e5));
        }
      }
      const ics = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Harusi//EN", "BEGIN:VEVENT",
        "UID:" + Date.now() + "@harusi", "DTSTART:" + start, "DTEND:" + end,
        "SUMMARY:" + names + " — Wedding", "LOCATION:" + venueStr,
        "END:VEVENT", "END:VCALENDAR"].join("\r\n");
      const url = URL.createObjectURL(new Blob([ics], { type: "text/calendar" }));
      const el = document.createElement("a");
      el.href = url; el.download = "wedding.ics"; document.body.appendChild(el); el.click(); el.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
    } catch (e) {}
  };

  const sec = (bg) => ({ position: "relative", background: bg, overflow: "hidden", ...EA_CV });
  const pad = { padding: "86px 20px 104px" };
  const btnGold = {
    display: "inline-flex", alignItems: "center", gap: 8, padding: "13px 22px", borderRadius: 12,
    fontFamily: EA_CAPS, fontSize: 11, letterSpacing: "0.28em", textTransform: "uppercase", fontWeight: 700,
    background: `linear-gradient(135deg, ${EA_C.goldHi} 0%, ${EA_C.gold} 45%, ${EA_C.goldDeep} 100%)`,
    color: "#3d2f0d", textDecoration: "none", border: "none", cursor: "pointer",
    boxShadow: "0 12px 26px rgba(160,125,47,0.35), inset 0 1px 0 rgba(255,244,210,0.85)"
  };
  const btnGhost = {
    display: "inline-flex", alignItems: "center", gap: 8, padding: "12px 20px", borderRadius: 12,
    fontFamily: EA_CAPS, fontSize: 11, letterSpacing: "0.28em", textTransform: "uppercase",
    background: "transparent", color: EA_C.em, border: `1px solid ${EA_C.goldDeep}`, cursor: "pointer"
  };

  return /* @__PURE__ */ u.jsxs("div", {
    style: { position: "relative", minHeight: "100svh", background: EA_C.emDeep, fontFamily: EA_BODY, color: EA_C.ink },
    children: [
      /* language toggle */
      /* @__PURE__ */ u.jsxs("div", {
        style: {
          position: "fixed", top: 14, right: 14, zIndex: 80, display: "flex",
          borderRadius: 999, overflow: "hidden", border: "1px solid rgba(201,162,74,0.55)",
          background: "rgba(8,42,31,0.72)", backdropFilter: "blur(8px)", WebkitBackdropFilter: "blur(8px)"
        },
        children: ["en", "sw"].map((lg) => /* @__PURE__ */ u.jsx("button", {
          onClick: () => setLang(lg),
          style: {
            padding: "7px 13px", border: "none", cursor: "pointer",
            fontFamily: EA_CAPS, fontSize: 10, letterSpacing: "0.2em",
            background: lang === lg ? "rgba(201,162,74,0.85)" : "transparent",
            color: lang === lg ? "#3d2f0d" : EA_C.goldHi, transition: "all .25s ease"
          },
          children: lg.toUpperCase()
        }, lg))
      }),

      /* guest chip */
      a && a.name ? /* @__PURE__ */ u.jsx("div", {
        style: {
          position: "fixed", top: 14, left: 14, zIndex: 80, padding: "8px 14px", borderRadius: 999,
          border: "1px solid rgba(201,162,74,0.55)", background: "rgba(8,42,31,0.72)",
          backdropFilter: "blur(8px)", WebkitBackdropFilter: "blur(8px)",
          fontFamily: EA_BODY, fontSize: 13, color: EA_C.emInk, fontStyle: "italic"
        },
        children: t.forYou + " " + a.name
      }) : null,

      /* envelope overlay */
      !open ? /* @__PURE__ */ u.jsx(EAEnvelope, {
        hint: t.tapSeal,
        guestName: a && a.name ? { pre: t.forYou, name: a.name } : null,
        monogram: mono,
        onOpening: () => setParting(true),
        onOpened: () => setOpen(true)
      }) : null,

      /* page */
      /* @__PURE__ */ u.jsxs("main", {
        style: { position: "relative", zIndex: 1 },
        children: [
          /* HERO */
          /* @__PURE__ */ u.jsx(EAHero, { data: n, opened: parting, t, guest: a }),

          /* LETTER */
          /* @__PURE__ */ u.jsxs("section", { style: { ...sec(EA_C.ivory), ...pad }, children: [
            /* @__PURE__ */ u.jsx(EADiv, { fill: EA_C.emDeep }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, backgroundImage: "url(./art/em-ivory.jpg)", backgroundSize: "cover", opacity: 0.5 } }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "radial-gradient(90% 60% at 50% 0%, rgba(201,162,74,0.12) 0%, transparent 60%)" } }),
            /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 2, maxWidth: 560, margin: "0 auto", textAlign: "center" }, children: [
              /* @__PURE__ */ u.jsx(EAHead, { eyebrow: t.storyEye, title: t.storyTitle }),
              /* @__PURE__ */ u.jsxs(EARev, { delay: 0.15, children: [
                /* @__PURE__ */ u.jsx("img", { src: "./art/em-medallion.png", alt: "", draggable: false, style: { width: 74, height: 74, objectFit: "contain", margin: "26px auto 0", opacity: 0.95 } }),
                quote ? /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_BODY, fontSize: 15.5, lineHeight: 1.7, color: EA_C.goldDeep, fontStyle: "italic", margin: "20px 0 0", padding: "0 10px" }, children: "“" + quote + "”" }) : null,
                /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_BODY, fontSize: 17.5, lineHeight: 1.75, color: EA_C.inkSoft, fontStyle: "italic", margin: "18px 0 0", padding: "0 8px" }, children: story || (lang === "sw"
                  ? "Kwa neema ya Mwenyezi Mungu na kwa baraka za familia zetu, tunakualika kwa heshima kubwa kushuhudia siku tunapoanza safari yetu ya pamoja — siku ya upendo, dua na furaha."
                  : "By the grace of God and with the blessings of our families, we joyfully request the honour of your presence as we begin our journey as one — a day of love, prayer and celebration.") }),
                (n.groomFamily || n.brideFamily) ? /* @__PURE__ */ u.jsxs("p", { style: { fontFamily: EA_CAPS, fontSize: 11.5, letterSpacing: "0.18em", textTransform: "uppercase", color: EA_C.goldDeep, margin: "22px 0 0", lineHeight: 2 }, children: [
                  n.groomFamily || "", n.groomFamily && n.brideFamily ? "  ·  " : "", n.brideFamily || ""
                ] }) : null,
                /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_SCRIPT, fontSize: 27, color: EA_C.em, margin: "20px 0 0" }, children: names })
              ] })
            ] })
          ] }),

          /* COUNTDOWN */
          /* @__PURE__ */ u.jsxs("section", { style: { ...sec(EA_C.em), ...pad }, children: [
            /* @__PURE__ */ u.jsx(EADiv, { fill: EA_C.ivory }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, backgroundImage: "url(./art/em-damask.jpg)", backgroundSize: "520px", opacity: 0.5 } }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "radial-gradient(80% 55% at 50% 30%, rgba(232,207,143,0.14) 0%, transparent 65%)" } }),
            /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 2 }, children: [
              /* @__PURE__ */ u.jsx(EAHead, { eyebrow: t.beginsIn, title: t.cdTitle, dark: true }),
              /* @__PURE__ */ u.jsx(EACountdown, { targetISO: cdTarget, t })
            ] })
          ] }),

          /* SCHEDULE — villa-style travelling rose */
          /* @__PURE__ */ u.jsxs("section", { style: { ...sec(EA_C.emDeep), ...pad, paddingBottom: 116 }, children: [
            /* @__PURE__ */ u.jsx(EADiv, { fill: EA_C.em }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "radial-gradient(90% 50% at 50% 0%, rgba(17,68,52,0.55) 0%, transparent 60%)" } }),
            /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 2 }, children: [
              /* @__PURE__ */ u.jsx(EAHead, { eyebrow: t.scheduleEye, title: t.scheduleTitle, dark: true }),
              /* @__PURE__ */ u.jsx(EATimeline, { events: ev, t })
            ] })
          ] }),

          /* LOCATION */
          /* @__PURE__ */ u.jsxs("section", { style: { ...sec(EA_C.ivory), ...pad }, children: [
            /* @__PURE__ */ u.jsx(EADiv, { fill: EA_C.emDeep }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, backgroundImage: "url(./art/em-ivory.jpg)", backgroundSize: "cover", opacity: 0.5 } }),
            /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 2, maxWidth: 480, margin: "0 auto", textAlign: "center" }, children: [
              /* @__PURE__ */ u.jsx(EAHead, { eyebrow: t.locationEye, title: t.locationTitle }),
              /* @__PURE__ */ u.jsxs(EARev, { delay: 0.12, children: [
                /* @__PURE__ */ u.jsxs("div", { style: {
                  position: "relative", margin: "30px auto 0", width: "min(78vw, 320px)",
                  borderRadius: "160px 160px 12px 12px", padding: 8,
                  background: "linear-gradient(170deg, rgba(201,162,74,0.9), rgba(160,125,47,0.9))",
                  boxShadow: "0 24px 54px rgba(2,14,9,0.28)"
                }, children: [
                  /* @__PURE__ */ u.jsx("img", { src: "./art/em-venue.jpg", alt: venueName, draggable: false, style: { width: "100%", height: 210, objectFit: "cover", borderRadius: "152px 152px 8px 8px", display: "block" } })
                ] }),
                /* @__PURE__ */ u.jsx("h3", { style: { fontFamily: EA_CAPS, fontSize: 21, letterSpacing: "0.12em", color: EA_C.em, margin: "24px 0 0", fontWeight: 600 }, children: venueName || venueStr }),
                venueCity ? /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_BODY, fontSize: 15.5, color: EA_C.inkSoft, margin: "8px 0 0", fontStyle: "italic" }, children: venueCity }) : null,
                /* @__PURE__ */ u.jsxs("div", { style: { display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap", marginTop: 24 }, children: [
                  mapsUrl ? /* @__PURE__ */ u.jsx("a", { href: mapsUrl, target: "_blank", rel: "noreferrer", style: btnGold, children: t.openMaps }) : null,
                  /* @__PURE__ */ u.jsx("button", { onClick: dlIcs, style: btnGhost, children: t.addCal })
                ] })
              ] })
            ] })
          ] }),

          /* DRESS CODE */
          /* @__PURE__ */ u.jsxs("section", { style: { ...sec(EA_C.em), ...pad }, children: [
            /* @__PURE__ */ u.jsx(EADiv, { fill: EA_C.ivory }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, backgroundImage: "url(./art/em-damask.jpg)", backgroundSize: "520px", opacity: 0.5 } }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "radial-gradient(80% 55% at 50% 20%, rgba(232,207,143,0.12) 0%, transparent 60%)" } }),
            /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 2, maxWidth: 560, margin: "0 auto", textAlign: "center" }, children: [
              /* @__PURE__ */ u.jsx(EAHead, { eyebrow: t.dressEye, title: t.dressTitle, dark: true }),
              /* @__PURE__ */ u.jsx(EARev, { delay: 0.1, children: /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_BODY, fontSize: 16, lineHeight: 1.7, color: EA_C.emInkSoft, fontStyle: "italic", margin: "22px auto 0", maxWidth: 440 }, children: t.dressText }) }),
              /* @__PURE__ */ u.jsxs("div", { style: { display: "flex", gap: 18, justifyContent: "center", flexWrap: "wrap", marginTop: 34 }, children: [
                [[t.dressGents, t.dressGentsText, "./art/em-dress-gents.png"], [t.dressLadies, t.dressLadiesText, "./art/em-dress-ladies.png"]].map(([tt, tx, src], idx) => /* @__PURE__ */ u.jsx(EARev, { delay: 0.12 + idx * 0.08, y: 26, children: /* @__PURE__ */ u.jsxs("div", { style: {
                  width: 216, padding: "14px 16px 20px", borderRadius: "120px 120px 12px 12px",
                  background: "rgba(8,42,31,0.6)", border: "1px solid rgba(201,162,74,0.5)",
                  boxShadow: "0 18px 40px rgba(2,14,9,0.35), inset 0 1px 0 rgba(232,207,143,0.3)"
                }, children: [
                  /* @__PURE__ */ u.jsx("img", { src, alt: tt, draggable: false, style: { width: "100%", height: 170, objectFit: "contain" } }),
                  /* @__PURE__ */ u.jsx("h4", { style: { fontFamily: EA_CAPS, fontSize: 13, letterSpacing: "0.26em", textTransform: "uppercase", color: EA_C.goldHi, margin: "14px 0 0" }, children: tt }),
                  /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_BODY, fontSize: 14, lineHeight: 1.55, color: EA_C.emInkSoft, margin: "8px 0 0" }, children: tx })
                ] }) }, idx))
              ] })
            ] })
          ] }),

          /* RSVP */
          /* @__PURE__ */ u.jsxs("section", { style: { ...sec(EA_C.ivory), ...pad }, children: [
            /* @__PURE__ */ u.jsx(EADiv, { fill: EA_C.em }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, backgroundImage: "url(./art/em-ivory.jpg)", backgroundSize: "cover", opacity: 0.5 } }),
            /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 2 }, children: [
              /* @__PURE__ */ u.jsx(EAHead, { eyebrow: t.rsvpEye, title: t.rsvpTitle }),
              /* @__PURE__ */ u.jsx("p", { style: { textAlign: "center", fontFamily: EA_BODY, fontSize: 15.5, color: EA_C.inkSoft, fontStyle: "italic", margin: "18px auto 0", maxWidth: 400, position: "relative", zIndex: 2 }, children: t.rsvpSub }),
              /* @__PURE__ */ u.jsx(EARsvp, { data: n, guest: a, t, onRsvp: l })
            ] })
          ] }),


          /* GALLERY — only when photos are provided */
          gal.length ? /* @__PURE__ */ u.jsxs("section", { style: { ...sec(EA_C.em), ...pad }, children: [
            /* @__PURE__ */ u.jsx(EADiv, { fill: EA_C.ivory }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, backgroundImage: "url(./art/em-damask.jpg)", backgroundSize: "520px", opacity: 0.5 } }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "radial-gradient(80% 55% at 50% 20%, rgba(232,207,143,0.12) 0%, transparent 60%)" } }),
            /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 2, maxWidth: 560, margin: "0 auto" }, children: [
              /* @__PURE__ */ u.jsx(EAHead, { eyebrow: t.galleryEye, title: t.galleryTitle, dark: true }),
              /* @__PURE__ */ u.jsx("div", { style: { display: "flex", flexWrap: "wrap", gap: 14, justifyContent: "center", marginTop: 36 }, children: gal.map((src, gi) => /* @__PURE__ */ u.jsx(EARev, { delay: gi * 0.06, y: 24, children: /* @__PURE__ */ u.jsx("img", {
                src, alt: "", loading: "lazy", draggable: false,
                style: {
                  width: gal.length === 1 ? "min(78vw, 300px)" : "min(42vw, 168px)", height: gal.length === 1 ? 300 : 210,
                  objectFit: "cover", display: "block",
                  borderRadius: "110px 110px 10px 10px",
                  border: "1px solid rgba(201,162,74,0.7)",
                  boxShadow: "0 16px 36px rgba(2,14,9,0.4), inset 0 0 0 4px rgba(246,239,221,0.25)"
                }
              }) }, gi)) })
            ] })
          ] }) : null,

          /* GIFTS & CONTACTS — only when provided */
          hasGifts ? /* @__PURE__ */ u.jsxs("section", { style: { ...sec(EA_C.ivory), ...pad }, children: [
            /* @__PURE__ */ u.jsx(EADiv, { fill: gal.length ? EA_C.em : EA_C.ivory }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, backgroundImage: "url(./art/em-ivory.jpg)", backgroundSize: "cover", opacity: 0.5 } }),
            /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 2, maxWidth: 520, margin: "0 auto", textAlign: "center" }, children: [
              gifts.length ? /* @__PURE__ */ u.jsxs("div", { children: [
                /* @__PURE__ */ u.jsx(EAHead, { eyebrow: t.giftsEye, title: t.giftsTitle }),
                /* @__PURE__ */ u.jsx("div", { style: { display: "flex", flexWrap: "wrap", gap: 14, justifyContent: "center", marginTop: 34 }, children: gifts.map((g, gi) => /* @__PURE__ */ u.jsx(EARev, { delay: gi * 0.07, y: 24, children: /* @__PURE__ */ u.jsxs("div", {
                  style: {
                    width: 220, padding: "20px 18px 22px", borderRadius: "110px 110px 12px 12px", textAlign: "center",
                    background: "linear-gradient(170deg, #fcf7ea, #f0e3c2)",
                    border: "1px solid rgba(201,162,74,0.7)",
                    boxShadow: "0 16px 36px rgba(2,14,9,0.14), inset 0 0 0 5px rgba(246,239,221,0.7), inset 0 0 0 6px rgba(201,162,74,0.4)"
                  },
                  children: [
                    /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_CAPS, fontSize: 10.5, letterSpacing: "0.3em", textTransform: "uppercase", color: EA_C.goldDeep, margin: 0 }, children: g.label || g.provider || "" }),
                    g.provider && g.label ? /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_BODY, fontSize: 13, color: EA_C.inkSoft, fontStyle: "italic", margin: "4px 0 0" }, children: g.provider }) : null,
                    /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_BODY, fontSize: 15.5, color: EA_C.ink, margin: "12px 0 0", fontWeight: 600 }, children: g.accountName || "" }),
                    /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_CAPS, fontSize: 15, letterSpacing: "0.12em", color: EA_C.em, margin: "6px 0 0", fontWeight: 700, fontVariantNumeric: "tabular-nums" }, children: g.accountNumber || "" })
                  ]
                }) }, gi)) })
              ] }) : null,
              contacts.length ? /* @__PURE__ */ u.jsxs("div", { style: { marginTop: gifts.length ? 56 : 0 }, children: [
                /* @__PURE__ */ u.jsx(EAHead, { eyebrow: t.contactsEye, title: t.contactsTitle }),
                /* @__PURE__ */ u.jsx("div", { style: { display: "flex", flexDirection: "column", gap: 12, marginTop: 30 }, children: contacts.map((c, ci) => /* @__PURE__ */ u.jsx(EARev, { delay: ci * 0.06, y: 20, children: /* @__PURE__ */ u.jsxs("a", {
                  href: "tel:" + String(c.phone || "").replace(/[^+\d]/g, ""),
                  style: {
                    display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 14,
                    padding: "14px 20px", borderRadius: 12, textDecoration: "none",
                    background: "rgba(14,59,44,0.05)", border: "1px solid rgba(201,162,74,0.45)"
                  },
                  children: [
                    /* @__PURE__ */ u.jsxs("span", { style: { textAlign: "left" }, children: [
                      /* @__PURE__ */ u.jsx("span", { style: { fontFamily: EA_CAPS, fontSize: 9.5, letterSpacing: "0.28em", textTransform: "uppercase", color: EA_C.goldDeep, display: "block" }, children: c.label || "" }),
                      /* @__PURE__ */ u.jsx("span", { style: { fontFamily: EA_BODY, fontSize: 16.5, color: EA_C.ink, fontWeight: 600 }, children: c.name || "" })
                    ] }),
                    /* @__PURE__ */ u.jsx("span", { style: { fontFamily: EA_CAPS, fontSize: 12.5, letterSpacing: "0.08em", color: EA_C.em, fontVariantNumeric: "tabular-nums" }, children: c.phone || "" })
                  ]
                }) }, ci)) })
              ] }) : null
            ] })
          ] }) : null,

          /* GUEST CODE */
          /* @__PURE__ */ u.jsxs("section", { style: { ...sec(EA_C.emDeep), ...pad, paddingBottom: 92 }, children: [
            /* @__PURE__ */ u.jsx(EADiv, { fill: hasGifts || !gal.length ? EA_C.ivory : EA_C.em }),
            /* @__PURE__ */ u.jsx("div", { style: { position: "absolute", inset: 0, background: "radial-gradient(80% 50% at 50% 20%, rgba(17,68,52,0.5) 0%, transparent 60%)" } }),
            /* @__PURE__ */ u.jsxs("div", { style: { position: "relative", zIndex: 2, textAlign: "center" }, children: [
              /* @__PURE__ */ u.jsx(EAHead, { eyebrow: t.codeEye, title: t.codeTitle, dark: true }),
              /* @__PURE__ */ u.jsxs(EARev, { delay: 0.12, children: [
                /* @__PURE__ */ u.jsxs("div", { style: {
                  display: "inline-block", marginTop: 30, padding: "26px 30px 22px",
                  borderRadius: "120px 120px 16px 16px",
                  background: `linear-gradient(170deg, #fcf7ea 0%, ${EA_C.ivory} 65%, #eee0bd 100%)`,
                  border: "1px solid rgba(201,162,74,0.7)",
                  boxShadow: "0 26px 60px rgba(2,14,9,0.45), inset 0 0 0 8px rgba(246,239,221,0.7), inset 0 0 0 9px rgba(201,162,74,0.4)"
                }, children: [
                  /* @__PURE__ */ u.jsx(yc, { value: `${y || "https://harusi-invite.github.io"}?code=${(a && a.code) || "DEMO01"}`, size: 158, fgColor: "#0e3b2c", bgColor: "#fbf6e9", level: "M" }),
                  /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_CAPS, fontSize: 15, letterSpacing: "0.4em", color: EA_C.em, margin: "16px 0 0", fontWeight: 700 }, children: (a && a.code) || "DEMO01" }),
                  /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_BODY, fontSize: 13.5, color: EA_C.inkSoft, fontStyle: "italic", margin: "8px 0 0" }, children: t.scanHint })
                ] }),
                a && a.checkedIn ? /* @__PURE__ */ u.jsx("div", { children: /* @__PURE__ */ u.jsx("span", { style: {
                  display: "inline-block", marginTop: 18, fontFamily: EA_CAPS, fontSize: 11, letterSpacing: "0.26em", textTransform: "uppercase",
                  color: EA_C.goldHi, border: `1px solid ${EA_C.gold}`, borderRadius: 999, padding: "8px 18px", background: "rgba(201,162,74,0.14)"
                }, children: t.checkedInBadge }) }) : null
              ] })
            ] })
          ] }),

          /* FOOTER */
          /* @__PURE__ */ u.jsxs("footer", { style: { position: "relative", background: EA_C.emDeep, padding: "30px 20px 52px", textAlign: "center", overflow: "hidden" }, children: [
            /* @__PURE__ */ u.jsxs("div", { style: { display: "flex", alignItems: "center", justifyContent: "center", gap: 12, opacity: 0.9 }, children: [
              /* @__PURE__ */ u.jsx("span", { style: { width: 52, height: 1, background: `linear-gradient(to right, transparent, ${EA_C.gold})` } }),
              /* @__PURE__ */ u.jsx("span", { style: { width: 8, height: 8, transform: "rotate(45deg)", background: `linear-gradient(135deg, ${EA_C.goldHi}, ${EA_C.goldDeep})` } }),
              /* @__PURE__ */ u.jsx("span", { style: { width: 52, height: 1, background: `linear-gradient(to left, transparent, ${EA_C.gold})` } })
            ] }),
            /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_SCRIPT, fontSize: 32, color: EA_C.emInk, margin: "18px 0 0" }, children: names }),
            /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_CAPS, fontSize: 11, letterSpacing: "0.34em", color: EA_C.goldHi, margin: "12px 0 0" }, children: ev0.date ? Qx(ev0.date) : "" }),
            /* @__PURE__ */ u.jsx("p", { style: { fontFamily: EA_BODY, fontSize: 13, color: EA_C.emInkSoft, fontStyle: "italic", margin: "20px 0 0", opacity: 0.8 }, children: t.footer + " · Harusi" })
          ] })
        ]
      })
    ]
  });
}
