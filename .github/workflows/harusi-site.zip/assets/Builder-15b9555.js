import {
  AnimatePresence,
  Badge,
  Button,
  Card,
  Check,
  Empty,
  Field,
  HZ,
  I,
  Input,
  LinkButton,
  Menu,
  Modal,
  Note,
  React,
  Section,
  Seg,
  Select,
  Shell,
  Skel,
  Spinner,
  Stat,
  Switch,
  Textarea,
  call,
  copyText,
  csvOf,
  cx,
  downloadFile,
  errText,
  initials,
  motion,
  plural,
  useCallback,
  useData,
  useEffect,
  useMemo,
  useNavigate,
  useRef,
  useState,
  useStudioCss,
  useUI
} from "./studio-CGOZ5NHO-15b9555.js";

// studio/builder.jsx
import { u as useParams, Q as QRCodeSVG2 } from "./index-B4Ch-nvB-15b9555.js";

// studio/bfields.jsx
var cache = /* @__PURE__ */ new Map();
function fetchT(url, ms) {
  const c = typeof AbortController !== "undefined" ? new AbortController() : null;
  const t = setTimeout(() => c && c.abort(), ms);
  return fetch(url, c ? { signal: c.signal } : void 0).finally(() => clearTimeout(t));
}
function decode(s) {
  const d = document.createElement("textarea");
  d.innerHTML = s;
  return d.value;
}
async function machine(text, from, to) {
  const key = from + ">" + to + ":" + text;
  if (cache.has(key)) return cache.get(key);
  let out = null;
  try {
    const r = await fetchT("https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + from + "&tl=" + to + "&dt=t&q=" + encodeURIComponent(text), 6500);
    if (r.ok) {
      const j = await r.json();
      const s = (j && j[0] ? j[0] : []).map((x) => x && x[0] || "").join("");
      if (s.trim()) out = s;
    }
  } catch (e) {
  }
  if (!out) {
    try {
      const r = await fetchT("https://api.mymemory.translated.net/get?q=" + encodeURIComponent(text) + "&langpair=" + from + "|" + to, 7500);
      const j = await r.json();
      const s = j && j.responseData && j.responseData.translatedText;
      if (s && String(j.responseStatus) === "200" && !/MYMEMORY WARNING|QUERY LENGTH LIMIT|INVALID/i.test(s)) out = decode(s);
    } catch (e) {
    }
  }
  if (out) cache.set(key, out);
  return out;
}
function keepWords(src, out) {
  let o = out;
  if (/\bAllah\b/.test(src) && !/\bAllah\b/.test(o)) o = o.replace(/\bMungu\b/g, "Allah").replace(/\bGod\b/g, "Allah");
  for (const w of ["Nikkah", "Walima", "Walimah", "Maulid", "Maulidi", "Insha'Allah", "InshaAllah", "Masha'Allah", "Zanzibar", "Stone Town", "Unguja", "Pemba"]) {
    if (src.includes(w) && !o.includes(w)) {
      const low = new RegExp(w.replace(/[.*+?^${}()|[\]\\']/g, "\\$&"), "i");
      if (low.test(o)) o = o.replace(low, w);
    }
  }
  return o;
}
async function translate(text, from, to, kind) {
  const t = String(text || "").trim();
  if (!t) return { text: "", via: "empty" };
  if (kind === "family") return { text: HZ.honor(t, to), via: "rules" };
  if (HZ.isTerm(t, from)) {
    const g = HZ.gloss(t, to);
    if (g) return { text: g, via: "glossary" };
  }
  if (kind === "brand") return { text: t, via: "copy" };
  const lines = String(text).split("\n");
  const out = [];
  for (const ln of lines) {
    if (!ln.trim()) {
      out.push(ln);
      continue;
    }
    if (HZ.isTerm(ln, from)) {
      const g = HZ.gloss(ln, to);
      if (g) {
        out.push(g);
        continue;
      }
    }
    const m = await machine(ln.trim(), from, to);
    if (m == null) return { text: "", via: "failed" };
    out.push(keepWords(ln, m));
  }
  return { text: out.join("\n").trim(), via: "machine" };
}
var pairTop = (en, sw) => ({
  get: (f) => ({ en: f[en] || "", sw: f[sw] || "" }),
  put: (f, side, v) => ({ ...f, [side === "sw" ? sw : en]: v })
});
var pairItem = (list, key, en, sw) => ({
  get: (f) => {
    const x = (f[list] || []).find((z) => z && z.k === key) || {};
    return { en: x[en] || "", sw: x[sw] || "" };
  },
  put: (f, side, v) => ({ ...f, [list]: (f[list] || []).map((z) => z && z.k === key ? { ...z, [side === "sw" ? sw : en]: v } : z) })
});
var setAuto = (f, path, side) => {
  const a = { ...f.autoT || {} };
  if (side) a[path] = side;
  else delete a[path];
  return { ...f, autoT: a };
};
function Bi({ label, hint, path, pair, form, update, kind = "text", area, rows = 3, max = 600, phSw, phEn, right }) {
  const v = pair.get(form);
  const auto = (form.autoT || {})[path] || null;
  const [busy, setBusy] = useState(null);
  const [fail, setFail] = useState(null);
  const timer = useRef(null);
  const seq = useRef(0);
  useEffect(() => () => clearTimeout(timer.current), []);
  const run = (from, srcText, force) => {
    const to = from === "sw" ? "en" : "sw";
    clearTimeout(timer.current);
    const my = ++seq.current;
    timer.current = setTimeout(async () => {
      setBusy(to);
      setFail(null);
      const r = await translate(srcText, from, to, kind);
      if (my !== seq.current) return;
      setBusy(null);
      if (r.via === "failed") {
        setFail(to);
        return;
      }
      update((f) => {
        const cur = pair.get(f);
        const curAuto = (f.autoT || {})[path];
        if (cur[from] !== srcText) return f;
        if (!force && cur[to].trim() && curAuto !== to) return f;
        let g = pair.put(f, to, r.text);
        g = setAuto(g, path, r.text && r.text !== srcText ? to : null);
        return g;
      });
    }, force ? 0 : kind === "text" ? 900 : 650);
  };
  const onType = (side, val) => {
    const other = side === "sw" ? "en" : "sw";
    update((f) => {
      let g = pair.put(f, side, val);
      const a = (g.autoT || {})[path];
      if (a === side) g = setAuto(g, path, null);
      if (!val.trim() && a === other) g = pair.put(setAuto(g, path, null), other, "");
      return g;
    });
    const otherVal = v[other];
    if (val.trim() && (!otherVal.trim() || auto === other)) run(side, val, false);
    else {
      clearTimeout(timer.current);
      seq.current++;
      setBusy(null);
    }
  };
  const accept = () => update((f) => setAuto(f, path, null));
  const regen = (to) => {
    const from = to === "sw" ? "en" : "sw";
    if (!v[from].trim()) return;
    run(from, v[from], true);
  };
  const Tag = area ? "textarea" : "input";
  const box = (side) => {
    const isAuto = auto === side;
    const isBusy = busy === side;
    const other = side === "sw" ? "en" : "sw";
    return /* @__PURE__ */ React.createElement("div", { className: "hzs-bi-side", style: { position: "relative", minWidth: 0 } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-bi-tag" }, /* @__PURE__ */ React.createElement("span", { className: cx("hzs-lang", side) }, side === "sw" ? "Kiswahili" : "English"), side === "sw" ? /* @__PURE__ */ React.createElement("span", { className: "hzs-bi-first" }, "guests see first") : null, /* @__PURE__ */ React.createElement("span", { style: { marginLeft: "auto", display: "flex", gap: 6, alignItems: "center" } }, isBusy ? /* @__PURE__ */ React.createElement("span", { className: "hzs-bi-state" }, /* @__PURE__ */ React.createElement(Spinner, { size: 12 }), " translating\u2026") : null, !isBusy && isAuto ? /* @__PURE__ */ React.createElement("button", { type: "button", className: "hzs-bi-auto", onClick: accept, title: "Auto-translated. Tap to confirm it reads well, or edit it." }, /* @__PURE__ */ React.createElement(I.sparkle, { size: 11 }), " Auto \xB7 confirm ", /* @__PURE__ */ React.createElement(I.check, { size: 12 })) : null, !isBusy && fail === side ? /* @__PURE__ */ React.createElement("span", { className: "hzs-bi-state bad" }, "Couldn't translate \u2014 type it") : null, !isBusy && v[other].trim() && !isAuto ? /* @__PURE__ */ React.createElement("button", { type: "button", className: "hzs-bi-re", onClick: () => regen(side), title: "Translate from " + (other === "sw" ? "Kiswahili" : "English"), "aria-label": "Translate into " + (side === "sw" ? "Kiswahili" : "English") }, /* @__PURE__ */ React.createElement(I.languages, { size: 13 })) : null)), /* @__PURE__ */ React.createElement(
      Tag,
      {
        className: cx(area ? "hzs-textarea" : "hzs-input", isAuto && "hzs-is-auto"),
        rows: area ? rows : void 0,
        maxLength: max,
        value: v[side],
        placeholder: side === "sw" ? phSw : phEn,
        onChange: (e) => onType(side, e.target.value),
        lang: side
      }
    ));
  };
  return /* @__PURE__ */ React.createElement("div", { className: "hzs-field" }, label ? /* @__PURE__ */ React.createElement("span", { className: "hzs-label" }, label, right ? /* @__PURE__ */ React.createElement("span", { style: { marginLeft: "auto" } }, right) : null) : null, /* @__PURE__ */ React.createElement("div", { className: "hzs-bi" }, box("sw"), box("en")), hint ? /* @__PURE__ */ React.createElement("p", { className: "hzs-hint" }, hint) : null);
}
var BI_CSS = `
.hzs-bi{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.hzs-bi-tag{display:flex;align-items:center;gap:8px;margin:0 0 6px;min-height:22px}
.hzs-lang{font-size:10.5px;letter-spacing:.16em;text-transform:uppercase;font-weight:500;color:var(--ink3)}
.hzs-lang.sw{color:var(--gold)}
.hzs-bi-first{font-size:11px;color:var(--ink3);font-style:italic}
.hzs-bi-state{display:inline-flex;align-items:center;gap:5px;font-size:11.5px;color:var(--ink3)}
.hzs-bi-state.bad{color:var(--bad)}
.hzs-bi-auto{display:inline-flex;align-items:center;gap:5px;height:22px;padding:0 9px;border-radius:999px;border:1px solid var(--goldline);background:var(--goldbg);color:#7A5E26;font-size:11px;cursor:pointer;white-space:nowrap}
.hzs-bi-auto:hover{background:#EFE3C8}
.hzs-bi-re{display:inline-grid;place-items:center;width:24px;height:22px;border-radius:999px;border:0;background:transparent;color:var(--ink3);cursor:pointer}
.hzs-bi-re:hover{background:rgba(30,26,18,.06);color:var(--ink)}
.hzs-is-auto{background:#FFFBF1!important;border-color:var(--goldline)!important}
@media (max-width:720px){.hzs-bi{grid-template-columns:1fr;gap:10px}.hzs-bi-first{display:none}}
`;

// studio/bguests.jsx
import { Q as QRCodeSVG } from "./index-B4Ch-nvB-15b9555.js";
var guestLink = (slug, code) => HZ.base() + "#/i/" + slug + "/" + code;
function firstDateText(form, lang) {
  const d = (form.events || []).map((e) => HZ.ymd(e && e.date)).filter((x) => /^\d{4}-\d{2}-\d{2}$/.test(x)).sort()[0];
  return d ? HZ.dateLong(d, lang) : "";
}
function inviteMessage(form, g, lang) {
  const link = guestLink(form.slug, g.code);
  const names = (form.groomName || "") + " & " + (form.brideName || "");
  const sw = "Salaam " + g.name + ",\n\nUmealikwa kwa heshima kwenye harusi ya " + names + (firstDateText(form, "sw") ? " \u2014 " + firstDateText(form, "sw") : "") + ".\n\nFungua mwaliko wako hapa:\n" + link + "\n\nMsimbo wako wa kuingia: " + g.code + "\nKaribu sana! \u{1F49B}";
  const en = "Salaam " + g.name + ",\n\nYou are warmly invited to the wedding of " + names + (firstDateText(form, "en") ? " \u2014 " + firstDateText(form, "en") : "") + ".\n\nOpen your personal invitation here:\n" + link + "\n\nYour entrance code: " + g.code + "\nKaribu sana! \u{1F49B}";
  return lang === "en" ? en : lang === "both" ? sw + "\n\n\u2014 \u2014 \u2014\n\n" + en : sw;
}
var MSG_KEY = "hz-msg-lang";
function readPref() {
  try {
    return localStorage.getItem(MSG_KEY) || "sw";
  } catch (e) {
    return "sw";
  }
}
function GuestsPanel({ invId, form, q, ui }) {
  const guests = q.data || [];
  const [term, setTerm] = useState("");
  const [filter, setFilter] = useState("all");
  const [msgLang, setMsgLangS] = useState(readPref);
  const [modal, setModal] = useState(null);
  const setMsgLang = (v) => {
    setMsgLangS(v);
    try {
      localStorage.setItem(MSG_KEY, v);
    } catch (e) {
    }
  };
  const st = useMemo(() => {
    const s = { total: guests.length, people: 0, attending: 0, attPeople: 0, declined: 0, pending: 0, inside: 0, sent: 0 };
    for (const g of guests) {
      s.people += 1 + (Number(g.maxCompanions) || 0);
      if (g.rsvpStatus === "attending") {
        s.attending++;
        s.attPeople += 1 + (Number(g.companions) || 0);
      } else if (g.rsvpStatus === "declined") s.declined++;
      else s.pending++;
      if (g.checkedIn) s.inside++;
      if (g.sentAt) s.sent++;
    }
    return s;
  }, [guests]);
  const shown = guests.filter((g) => {
    if (filter === "pending" && g.rsvpStatus !== "pending" && g.rsvpStatus) return false;
    if (filter === "attending" && g.rsvpStatus !== "attending") return false;
    if (filter === "declined" && g.rsvpStatus !== "declined") return false;
    if (filter === "unsent" && g.sentAt) return false;
    if (filter === "check" && HZ.phone(g.phone).ok) return false;
    const t = term.trim().toLowerCase();
    if (t && !(String(g.name).toLowerCase().includes(t) || String(g.code).toLowerCase().includes(t) || String(g.phone || "").includes(t.replace(/\D/g, "") || "~"))) return false;
    return true;
  });
  const nextUnsent = guests.find((g) => !g.sentAt && HZ.phone(g.phone).ok);
  const badNumbers = guests.filter((g) => !HZ.phone(g.phone).ok).length;
  const patch = (id, o) => q.mutate((d) => (d || []).map((x) => x.id === id ? { ...x, ...o } : x));
  const send = async (g) => {
    const p = HZ.phone(g.phone);
    if (!p.ok) {
      ui.toast("Add a valid WhatsApp number for " + g.name + " first", { tone: "bad" });
      setModal({ t: "edit", g });
      return;
    }
    window.open("https://wa.me/" + p.num + "?text=" + encodeURIComponent(inviteMessage(form, g, msgLang)), "_blank");
    const at = Date.now();
    patch(g.id, { sentAt: at });
    try {
      await call((r) => r.guests.update({ id: g.id, sentAt: at }));
    } catch (e) {
    }
  };
  const remove = async (g) => {
    if (!await ui.confirm({ title: "Remove " + g.name + "?", body: "Their personal link and entrance code will stop working.", confirmText: "Remove guest", tone: "danger" })) return;
    try {
      await call((r) => r.guests.remove({ id: g.id, invitationId: invId }));
      q.mutate((d) => (d || []).filter((x) => x.id !== g.id));
      ui.toast(g.name + " removed");
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
    }
  };
  const exportCsv = () => {
    const rows = [["Name", "WhatsApp", "Code", "Allowed +", "Reply", "Coming (incl. guest)", "Notes", "Invite sent", "Checked in", "Personal link"]].concat(
      guests.map((g) => [
        g.name,
        HZ.phone(g.phone).num || g.phone || "",
        g.code,
        g.maxCompanions || 0,
        g.rsvpStatus || "pending",
        g.rsvpStatus === "attending" ? 1 + (Number(g.companions) || 0) : 0,
        g.dietary || "",
        g.sentAt ? new Date(g.sentAt).toLocaleString("en-GB") : "",
        g.checkedIn ? new Date(g.checkedInAt || 0).toLocaleString("en-GB") : "",
        guestLink(form.slug, g.code)
      ])
    );
    downloadFile("guests-" + form.slug + ".csv", csvOf(rows), "text/csv");
  };
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "hzs-grid hzs-g4" }, /* @__PURE__ */ React.createElement(Stat, { icon: I.users, label: "Invited", value: st.total, sub: st.people + " people incl. +guests" }), /* @__PURE__ */ React.createElement(Stat, { icon: I.okCircle, label: "Attending", value: st.attending, sub: st.attPeople + " people coming" }), /* @__PURE__ */ React.createElement(Stat, { icon: I.clock, label: "Waiting", value: st.pending, sub: st.declined + " declined" }), /* @__PURE__ */ React.createElement(Stat, { icon: I.chat, label: "Sent", value: st.sent, sub: st.total - st.sent + " not sent yet" })), /* @__PURE__ */ React.createElement(AddGuest, { invId, guests, q, ui, onMore: (t) => setModal({ t }) }), /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "hzs-sec", style: { display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" } }, /* @__PURE__ */ React.createElement("div", { style: { position: "relative", flex: "1 1 220px" } }, /* @__PURE__ */ React.createElement(I.search, { size: 16, style: { position: "absolute", left: 13, top: 14, color: "var(--ink3)" } }), /* @__PURE__ */ React.createElement(Input, { placeholder: "Search name, code or number", value: term, onChange: (e) => setTerm(e.target.value), style: { paddingLeft: 38 } })), /* @__PURE__ */ React.createElement(Select, { value: filter, onChange: (e) => setFilter(e.target.value), style: { width: "auto" }, options: [
    { value: "all", label: "All guests (" + st.total + ")" },
    { value: "unsent", label: "Not sent yet (" + (st.total - st.sent) + ")" },
    { value: "pending", label: "Waiting for reply (" + st.pending + ")" },
    { value: "attending", label: "Attending (" + st.attending + ")" },
    { value: "declined", label: "Declined (" + st.declined + ")" },
    { value: "check", label: "Numbers to check (" + badNumbers + ")" }
  ] }), /* @__PURE__ */ React.createElement(Menu, { items: [
    { label: "Import a client's list", icon: I.list, onClick: () => setModal({ t: "import" }) },
    { label: "Paste a list", icon: I.copy, onClick: () => setModal({ t: "paste" }) },
    guests.length ? { label: "Download CSV", icon: I.download, onClick: exportCsv } : null
  ] })), /* @__PURE__ */ React.createElement("div", { className: "hzs-sec", style: { display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center", background: "rgba(246,239,224,.45)", paddingTop: 14, paddingBottom: 14 } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-label", style: { margin: 0 } }, "WhatsApp message in"), /* @__PURE__ */ React.createElement(Seg, { value: msgLang, onChange: setMsgLang, items: [{ id: "sw", label: "Kiswahili" }, { id: "en", label: "English" }, { id: "both", label: "Both" }] }), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.eye, onClick: () => setModal({ t: "msg" }) }, "See message"), nextUnsent ? /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "gold", icon: I.chat, style: { marginLeft: "auto" }, onClick: () => send(nextUnsent) }, "Send next \xB7 ", nextUnsent.name.split(" ")[0]) : guests.length ? /* @__PURE__ */ React.createElement(Badge, { tone: "ok", style: { marginLeft: "auto" } }, /* @__PURE__ */ React.createElement(I.check, { size: 12 }), "All sent") : null), q.loading ? /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { display: "grid", gap: 10 } }, /* @__PURE__ */ React.createElement(Skel, { h: 44 }), /* @__PURE__ */ React.createElement(Skel, { h: 44 }), /* @__PURE__ */ React.createElement(Skel, { h: 44 })) : !guests.length ? /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { textAlign: "center", color: "var(--ink3)" } }, "No guests yet \u2014 add the first one above, or import a client's list.") : !shown.length ? /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { textAlign: "center", color: "var(--ink3)" } }, "No guest matches.") : /* @__PURE__ */ React.createElement("div", { className: "hzs-list" }, shown.map((g) => /* @__PURE__ */ React.createElement(GuestRow, { key: g.id, g, form, onSend: () => send(g), onEdit: () => setModal({ t: "edit", g }), onQr: () => setModal({ t: "qr", g }), onRemove: () => remove(g), ui })))), /* @__PURE__ */ React.createElement(AnimatePresence, null, modal && modal.t === "edit" ? /* @__PURE__ */ React.createElement(EditGuest, { key: "e", g: modal.g, onClose: () => setModal(null), onSaved: (o) => {
    patch(modal.g.id, o);
    setModal(null);
    ui.toast("Guest updated");
  }, ui }) : null, modal && modal.t === "qr" ? /* @__PURE__ */ React.createElement(QrModal, { key: "q", g: modal.g, form, onClose: () => setModal(null) }) : null, modal && modal.t === "msg" ? /* @__PURE__ */ React.createElement(MsgModal, { key: "m", form, lang: msgLang, g: guests[0] || { name: "Fatma", code: "AB12" }, onClose: () => setModal(null) }) : null, modal && modal.t === "import" ? /* @__PURE__ */ React.createElement(ImportModal, { key: "i", invId, guests, onClose: () => setModal(null), onDone: (n) => {
    setModal(null);
    q.reload();
    ui.toast(plural(n, "guest", "guests") + " added");
  }, ui }) : null, modal && modal.t === "paste" ? /* @__PURE__ */ React.createElement(PasteModal, { key: "p", invId, guests, onClose: () => setModal(null), onDone: (n) => {
    setModal(null);
    q.reload();
    ui.toast(plural(n, "guest", "guests") + " added");
  }, ui }) : null));
}
function AddGuest({ invId, guests, q, ui, onMore }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [plus, setPlus] = useState("0");
  const [busy, setBusy] = useState(false);
  const nameRef = useRef(null);
  const p = HZ.phone(phone);
  const dupe = p.ok && guests.find((g) => HZ.phone(g.phone).num === p.num);
  const add = async () => {
    if (!name.trim() || busy) return;
    setBusy(true);
    try {
      const g = await call((r) => r.guests.add({ invitationId: invId, name: name.trim(), phone: p.ok ? p.num : phone.trim(), maxCompanions: Number(plus) || 0 }));
      q.mutate((d) => [...d || [], g]);
      ui.toast(g.name + " added \xB7 code " + g.code);
      setName("");
      setPhone("");
      setPlus("0");
      nameRef.current && nameRef.current.focus();
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
    }
    setBusy(false);
  };
  return /* @__PURE__ */ React.createElement(
    Section,
    {
      icon: I.userPlus,
      title: "Add a guest",
      sub: "Each guest gets a personal link with their name and a private entrance code.",
      right: /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 6 } }, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "secondary", icon: I.list, onClick: () => onMore("import") }, "Import client list"))
    },
    /* @__PURE__ */ React.createElement("form", { onSubmit: (e) => {
      e.preventDefault();
      add();
    }, style: { display: "grid", gridTemplateColumns: "minmax(0,1.4fr) minmax(0,1fr) 110px auto", gap: 12, alignItems: "end" }, className: "hzg-add" }, /* @__PURE__ */ React.createElement(Field, { label: "Full name" }, /* @__PURE__ */ React.createElement(Input, { ref: nameRef, value: name, onChange: (e) => setName(e.target.value), placeholder: "Fatma Juma", maxLength: 60 })), /* @__PURE__ */ React.createElement(Field, { label: "WhatsApp number", error: phone && !p.ok ? "Check this number" : dupe ? "Already added: " + dupe.name : null }, /* @__PURE__ */ React.createElement(Input, { value: phone, onChange: (e) => setPhone(e.target.value), placeholder: "0777 123 456", inputMode: "tel", className: phone && !p.ok ? "bad" : "" })), /* @__PURE__ */ React.createElement(Field, { label: "Can bring" }, /* @__PURE__ */ React.createElement(Select, { value: plus, onChange: (e) => setPlus(e.target.value), options: Array.from({ length: 11 }, (_, i) => ({ value: String(i), label: i ? "+" + i : "Just them" })) })), /* @__PURE__ */ React.createElement(Button, { variant: "primary", icon: I.plus, busy, disabled: !name.trim(), type: "submit" }, "Add")),
    /* @__PURE__ */ React.createElement("style", null, "@media (max-width:760px){.hzg-add{grid-template-columns:1fr 1fr!important}.hzg-add>*:first-child{grid-column:1/-1}}")
  );
}
function GuestRow({ g, form, onSend, onEdit, onQr, onRemove, ui }) {
  const p = HZ.phone(g.phone);
  const rs = g.rsvpStatus === "attending" ? /* @__PURE__ */ React.createElement(Badge, { tone: "ok", dot: true }, "Attending", g.companions ? " +" + g.companions : "") : g.rsvpStatus === "declined" ? /* @__PURE__ */ React.createElement(Badge, { tone: "bad", dot: true }, "Declined") : /* @__PURE__ */ React.createElement(Badge, { dot: true }, "Waiting");
  return /* @__PURE__ */ React.createElement("div", { className: "hzs-item", style: { alignItems: "center", flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-avatar", style: { width: 38, height: 38, fontSize: 14 } }, initials(g.name)), /* @__PURE__ */ React.createElement("div", { style: { flex: "1 1 200px", minWidth: 0 } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("b", { style: { fontWeight: 500, fontSize: 15 } }, g.name), rs, g.checkedIn ? /* @__PURE__ */ React.createElement(Badge, { tone: "gold" }, /* @__PURE__ */ React.createElement(I.scan, { size: 11 }), "Inside") : null), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 10, fontSize: 13, color: "var(--ink3)", marginTop: 3, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("span", { style: { color: p.ok ? "var(--ink2)" : "var(--bad)" } }, p.ok ? HZ.fmtPhone(p.num) : g.phone ? g.phone + " \xB7 check number" : "No number"), /* @__PURE__ */ React.createElement("span", { className: "hzs-kbd" }, g.code), g.maxCompanions ? /* @__PURE__ */ React.createElement("span", null, "can bring +", g.maxCompanions) : null, g.sentAt ? /* @__PURE__ */ React.createElement("span", { style: { color: "var(--ok)" } }, "\u2713 sent") : null), g.dietary ? /* @__PURE__ */ React.createElement("div", { style: { fontSize: 12.5, color: "var(--ink2)", marginTop: 4, fontStyle: "italic" } }, "\u201C", g.dietary, "\u201D") : null), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 6 } }, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: g.sentAt ? "secondary" : "okSoft", icon: I.chat, onClick: onSend }, g.sentAt ? "Resend" : "Send"), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.link, "aria-label": "Copy personal link", title: "Copy personal link", onClick: () => copyText(guestLink(form.slug, g.code)).then(() => ui.toast("Link for " + g.name + " copied")) }), /* @__PURE__ */ React.createElement(Menu, { items: [
    { label: "Edit guest", icon: I.edit, onClick: onEdit },
    { label: "Show QR code", icon: I.qr, onClick: onQr },
    { label: "Open their invitation", icon: I.open, onClick: () => window.open(guestLink(form.slug, g.code), "_blank") },
    "-",
    { label: "Remove guest", icon: I.trash, danger: true, onClick: onRemove }
  ] })));
}
function EditGuest({ g, onClose, onSaved, ui }) {
  const [name, setName] = useState(g.name || "");
  const [phone, setPhone] = useState(g.phone || "");
  const [plus, setPlus] = useState(String(g.maxCompanions || 0));
  const [busy, setBusy] = useState(false);
  const p = HZ.phone(phone);
  const save = async () => {
    if (!name.trim()) return;
    setBusy(true);
    const o = { name: name.trim(), phone: p.ok ? p.num : phone.trim(), maxCompanions: Number(plus) || 0 };
    try {
      await call((r) => r.guests.update({ id: g.id, ...o }));
      onSaved(o);
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
      setBusy(false);
    }
  };
  return /* @__PURE__ */ React.createElement(Modal, { onClose, label: "Edit guest" }, /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { display: "grid", gap: 16 } }, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h2", style: { fontSize: 20 } }, "Edit guest"), /* @__PURE__ */ React.createElement(Field, { label: "Full name" }, /* @__PURE__ */ React.createElement(Input, { value: name, onChange: (e) => setName(e.target.value), autoFocus: true, maxLength: 60 })), /* @__PURE__ */ React.createElement(Field, { label: "WhatsApp number", error: phone && !p.ok ? "This doesn't look like a WhatsApp number." : null, hint: p.ok ? HZ.fmtPhone(p.num) : null }, /* @__PURE__ */ React.createElement(Input, { value: phone, onChange: (e) => setPhone(e.target.value), inputMode: "tel", className: phone && !p.ok ? "bad" : "" })), /* @__PURE__ */ React.createElement(Field, { label: "Can bring" }, /* @__PURE__ */ React.createElement(Select, { value: plus, onChange: (e) => setPlus(e.target.value), options: Array.from({ length: 11 }, (_, i) => ({ value: String(i), label: i ? "+" + i + (i === 1 ? " guest" : " guests") : "Just them" })) })), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { margin: 0 } }, "Their code ", /* @__PURE__ */ React.createElement("span", { className: "hzs-kbd" }, g.code), " and link stay the same.")), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { justifyContent: "flex-end", gap: 10, padding: "0 22px 22px" } }, /* @__PURE__ */ React.createElement(Button, { variant: "ghost", onClick: onClose }, "Cancel"), /* @__PURE__ */ React.createElement(Button, { variant: "primary", onClick: save, busy, disabled: !name.trim() }, "Save")));
}
function QrModal({ g, form, onClose }) {
  return /* @__PURE__ */ React.createElement(Modal, { onClose, label: "QR code", width: 380 }, /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { textAlign: "center" } }, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h2", style: { fontSize: 20 } }, g.name), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint" }, "Scanning opens their personal invitation. Entrance code ", /* @__PURE__ */ React.createElement("span", { className: "hzs-kbd" }, g.code)), /* @__PURE__ */ React.createElement("div", { style: { display: "inline-block", padding: 14, background: "#fff", borderRadius: 16, border: "1px solid var(--line)", marginTop: 12 } }, /* @__PURE__ */ React.createElement(QRCodeSVG, { value: guestLink(form.slug, g.code), size: 200, fgColor: "#1E1A12", level: "M" })), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 16 } }, /* @__PURE__ */ React.createElement(Button, { variant: "secondary", onClick: onClose }, "Close"))));
}
function MsgModal({ form, lang, g, onClose }) {
  return /* @__PURE__ */ React.createElement(Modal, { onClose, label: "Message preview", width: 460 }, /* @__PURE__ */ React.createElement("div", { className: "hzs-pad" }, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h2", style: { fontSize: 20 } }, "WhatsApp message"), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint" }, "Each guest gets this with their own name, link and code."), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 14, padding: 14, borderRadius: "14px 14px 14px 4px", background: "#E7F6DC", color: "#13261A", fontSize: 14, whiteSpace: "pre-wrap", wordBreak: "break-word", maxHeight: 360, overflowY: "auto" } }, inviteMessage(form, g, lang)), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 16, textAlign: "right" } }, /* @__PURE__ */ React.createElement(Button, { variant: "secondary", onClick: onClose }, "Close"))));
}
function useExisting(guests) {
  return useMemo(() => {
    const ph = /* @__PURE__ */ new Set(), nm = /* @__PURE__ */ new Set();
    for (const g of guests || []) {
      const n = HZ.phone(g.phone).num;
      if (n) ph.add(n);
      nm.add(String(g.name || "").trim().toLowerCase());
    }
    return { ph, nm };
  }, [guests]);
}
function rowsFrom(entries, have) {
  const seen = /* @__PURE__ */ new Set();
  return (entries || []).map((e, i) => {
    const p = HZ.phone(e.phone), name = String(e.name || "").trim();
    const key = p.num || name.toLowerCase();
    const dupe = p.num && have.ph.has(p.num) || !p.num && name && have.nm.has(name.toLowerCase());
    const rep = key && seen.has(key);
    if (key) seen.add(key);
    return { i, name, phone: p.ok ? p.num : String(e.phone || "").trim(), ok: p.ok, dupe: !!(dupe || rep), noName: !name };
  });
}
function RowsPicker({ rows, off, setOff }) {
  return /* @__PURE__ */ React.createElement("div", { style: { border: "1px solid var(--line)", borderRadius: 14, maxHeight: 300, overflowY: "auto", background: "#fff" }, className: "hzs-list" }, rows.map((r) => {
    const dis = r.dupe || r.noName;
    const on = !dis && !off[r.i];
    return /* @__PURE__ */ React.createElement("div", { key: r.i, className: "hzs-item", style: { padding: "9px 12px", opacity: dis ? 0.5 : 1, cursor: dis ? "default" : "pointer" }, onClick: () => !dis && setOff({ ...off, [r.i]: !off[r.i] }) }, dis ? /* @__PURE__ */ React.createElement("span", { style: { width: 20 } }) : /* @__PURE__ */ React.createElement(Check, { on, onChange: () => setOff({ ...off, [r.i]: !off[r.i] }), label: r.name }), /* @__PURE__ */ React.createElement("span", { style: { flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, r.name || /* @__PURE__ */ React.createElement("i", null, "no name")), /* @__PURE__ */ React.createElement("span", { style: { fontSize: 12.5, color: r.dupe ? "var(--ink3)" : r.ok ? "var(--ink2)" : "var(--bad)", whiteSpace: "nowrap" } }, r.dupe ? "already added" : r.ok ? HZ.fmtPhone(r.phone) : (r.phone || "no number") + " \xB7 check"));
  }));
}
function ImportModal({ invId, guests, onClose, onDone, ui }) {
  const [lists, setLists] = useState(null);
  const [err, setErr] = useState(null);
  const [sel, setSel] = useState("");
  const [off, setOff] = useState({});
  const [plus, setPlus] = useState("0");
  const [prog, setProg] = useState(null);
  const have = useExisting(guests);
  useEffect(() => {
    HZ.repo().then((r) => r.guestLists.mine()).then((l) => {
      setLists(l);
      const s = l.find((x) => !x.importedAt && (x.entries || []).length);
      if (s) setSel(s.id);
    }).catch(setErr);
  }, []);
  const L = (lists || []).find((l) => l.id === sel);
  const rows = useMemo(() => L ? rowsFrom(L.entries, have) : [], [L, have]);
  const chosen = rows.filter((r) => !r.dupe && !r.noName && !off[r.i]);
  const bad = chosen.filter((r) => !r.ok).length;
  const go = async () => {
    setProg(0);
    try {
      await call((r) => r.guests.addMany({ invitationId: invId, items: chosen.map((x) => ({ name: x.name, phone: x.phone, maxCompanions: Number(plus) || 0 })), onProgress: setProg }));
      try {
        await call((r) => r.guestLists.markImported({ id: L.id, invitationId: invId, count: chosen.length }));
      } catch (e) {
      }
      onDone(chosen.length);
    } catch (e) {
      setProg(null);
      ui.toast("Import stopped: " + errText(e), { tone: "bad" });
    }
  };
  return /* @__PURE__ */ React.createElement(Modal, { onClose: prog == null ? onClose : null, label: "Import a client's list", width: 560 }, /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { display: "grid", gap: 14 } }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h2", style: { fontSize: 20 } }, "Import a client's list"), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint" }, "Guests already on this invitation, and repeated names, are skipped automatically.")), err ? /* @__PURE__ */ React.createElement(Note, { tone: "bad", icon: I.alert }, errText(err)) : null, lists === null && !err ? /* @__PURE__ */ React.createElement(Skel, { h: 44 }) : null, lists && !lists.length ? /* @__PURE__ */ React.createElement(Note, { icon: I.info }, "No client lists yet. Create one on the ", /* @__PURE__ */ React.createElement("a", { href: "#/lists", style: { textDecoration: "underline" } }, "Guest lists"), " page and send it to your client.") : null, lists && lists.length ? /* @__PURE__ */ React.createElement(Field, { label: "Choose a list" }, /* @__PURE__ */ React.createElement(Select, { value: sel, onChange: (e) => {
    setSel(e.target.value);
    setOff({});
  }, options: [{ value: "", label: "\u2014" }].concat(lists.map((l) => ({ value: l.id, label: (l.label || l.weddingOf || "Untitled") + (l.clientName ? " \xB7 " + l.clientName : "") + " \xB7 " + (l.entries || []).length + " guests" + (l.importedAt ? " \xB7 imported" : l.status === "submitted" ? " \xB7 submitted" : "") }))) })) : null, L ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Badge, null, rows.length, " names"), /* @__PURE__ */ React.createElement(Badge, { tone: "ok" }, rows.filter((r) => !r.dupe && !r.noName).length, " new"), rows.filter((r) => r.dupe).length ? /* @__PURE__ */ React.createElement(Badge, null, rows.filter((r) => r.dupe).length, " already added / repeated") : null, bad ? /* @__PURE__ */ React.createElement(Badge, { tone: "bad" }, bad, " numbers to check") : null), rows.length ? /* @__PURE__ */ React.createElement(RowsPicker, { rows, off, setOff }) : /* @__PURE__ */ React.createElement("p", { className: "hzs-muted", style: { margin: 0 } }, "This list is empty."), bad ? /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { margin: 0 } }, "Guests with a number to check are added too \u2014 fix their number later with \u201CEdit guest\u201D, or untick them now.") : null, /* @__PURE__ */ React.createElement(Field, { label: "Each guest can bring", style: { maxWidth: 200 } }, /* @__PURE__ */ React.createElement(Select, { value: plus, onChange: (e) => setPlus(e.target.value), options: Array.from({ length: 11 }, (_, i) => ({ value: String(i), label: i ? "+" + i : "Just them" })) }))) : null), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { justifyContent: "flex-end", gap: 10, padding: "0 22px 22px" } }, /* @__PURE__ */ React.createElement(Button, { variant: "ghost", onClick: onClose, disabled: prog != null }, "Cancel"), /* @__PURE__ */ React.createElement(Button, { variant: "primary", onClick: go, disabled: !chosen.length || prog != null }, prog != null ? "Importing " + prog + " / " + chosen.length + "\u2026" : "Import " + plural(chosen.length, "guest", "guests"))));
}
function PasteModal({ invId, guests, onClose, onDone, ui }) {
  const [text, setText] = useState("");
  const [off, setOff] = useState({});
  const [plus, setPlus] = useState("0");
  const [prog, setProg] = useState(null);
  const have = useExisting(guests);
  const rows = useMemo(() => rowsFrom(HZ.parseBulk(text), have), [text, have]);
  const chosen = rows.filter((r) => !r.dupe && !r.noName && !off[r.i]);
  const go = async () => {
    setProg(0);
    try {
      await call((r) => r.guests.addMany({ invitationId: invId, items: chosen.map((x) => ({ name: x.name, phone: x.phone, maxCompanions: Number(plus) || 0 })), onProgress: setProg }));
      onDone(chosen.length);
    } catch (e) {
      setProg(null);
      ui.toast("Stopped: " + errText(e), { tone: "bad" });
    }
  };
  return /* @__PURE__ */ React.createElement(Modal, { onClose: prog == null ? onClose : null, label: "Paste a list", width: 560 }, /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { display: "grid", gap: 14 } }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h2", style: { fontSize: 20 } }, "Paste a list"), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint" }, "One guest per line \u2014 name and number, e.g. \u201CFatma Juma 0777 123 456\u201D. Works with lists copied from WhatsApp, Excel or Notes.")), /* @__PURE__ */ React.createElement(Textarea, { rows: 6, value: text, onChange: (e) => {
    setText(e.target.value);
    setOff({});
  }, placeholder: "Fatma Juma 0777 123 456\nAsha Omar 0654 987 321", autoFocus: true }), rows.length ? /* @__PURE__ */ React.createElement(RowsPicker, { rows, off, setOff }) : null, rows.length ? /* @__PURE__ */ React.createElement(Field, { label: "Each guest can bring", style: { maxWidth: 200 } }, /* @__PURE__ */ React.createElement(Select, { value: plus, onChange: (e) => setPlus(e.target.value), options: Array.from({ length: 11 }, (_, i) => ({ value: String(i), label: i ? "+" + i : "Just them" })) })) : null), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { justifyContent: "flex-end", gap: 10, padding: "0 22px 22px" } }, /* @__PURE__ */ React.createElement(Button, { variant: "ghost", onClick: onClose, disabled: prog != null }, "Cancel"), /* @__PURE__ */ React.createElement(Button, { variant: "primary", onClick: go, disabled: !chosen.length || prog != null }, prog != null ? "Adding " + prog + " / " + chosen.length + "\u2026" : "Add " + plural(chosen.length, "guest", "guests"))));
}

// studio/builder.jsx
var EA = "emerald-arch";
var rid = () => Math.random().toString(36).slice(2, 9);
var keyed = (arr) => (Array.isArray(arr) ? arr : []).filter(Boolean).map((x) => x && x.k ? x : { ...x, k: rid() });
var SECTIONS = [
  { id: "template", label: "Template", icon: I.palette },
  { id: "couple", label: "Couple", icon: I.heart },
  { id: "wording", label: "Wording", icon: I.type, ea: true },
  { id: "story", label: "Story & blessing", icon: I.book },
  { id: "events", label: "Events", icon: I.calendar },
  { id: "dress", label: "Dress code", icon: I.shirt, ea: true },
  { id: "gifts", label: "Gifts & contacts", icon: I.gift },
  { id: "guests", label: "Guests", icon: I.users },
  { id: "share", label: "Share", icon: I.share }
];
var CSS = `
.hzb{display:grid;grid-template-columns:232px minmax(0,1fr) 404px;gap:28px;max-width:1500px;margin:0 auto;padding:24px 24px 80px;align-items:start}
.hzb-rail{position:sticky;top:132px}
.hzb-rail a{display:flex;align-items:center;gap:11px;padding:10px 12px;border-radius:12px;color:var(--ink2);font-size:14.5px;cursor:pointer;transition:background .18s,color .18s;border:0;background:none;width:100%;text-align:left}
.hzb-rail a:hover{background:rgba(30,26,18,.045);color:var(--ink)}
.hzb-rail a.on{background:#fff;color:var(--ink);box-shadow:0 1px 2px rgba(30,26,18,.06),0 6px 16px -10px rgba(30,26,18,.25)}
.hzb-rail a .n{margin-left:auto;font-size:11.5px;color:var(--ink3)}
.hzb-rail a .ok{margin-left:auto;color:var(--ok)}
.hzb-rail .dim{opacity:.55}
.hzb-main{min-width:0;display:flex;flex-direction:column;gap:18px}
.hzb-prev{position:sticky;top:132px}
.hzb-phone{width:100%;max-width:380px;margin:0 auto;border-radius:44px;padding:11px;background:#1E1A12;box-shadow:0 40px 80px -30px rgba(30,26,18,.55),inset 0 0 0 1px rgba(255,255,255,.06)}
.hzb-screen{position:relative;border-radius:34px;overflow:hidden;background:#FBF8F2;aspect-ratio:390/780}
.hzb-screen iframe{position:absolute;top:0;left:0;width:390px;height:780px;border:0;transform-origin:0 0}
.hzb-bar{position:sticky;top:64px;z-index:35;background:rgba(251,248,242,.9);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border-bottom:1px solid var(--line)}
.hzb-bar-in{max-width:1500px;margin:0 auto;padding:10px 24px;display:flex;align-items:center;gap:14px;min-height:60px}
.hzb-tabs{display:none}
.hzb-fab{display:none}
.hzb-tpl{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px}
.hzb-tplc{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;border:1.5px solid var(--line);border-radius:16px;overflow:hidden;background:#fff;cursor:pointer;text-align:left;padding:0;transition:border-color .2s,box-shadow .2s,transform .2s}
.hzb-tplc:hover{border-color:var(--line2);transform:translateY(-2px)}
.hzb-tplc.on{border-color:var(--ink);box-shadow:0 0 0 3px rgba(30,26,18,.08)}
.hzb-item{border:1px solid var(--line);border-radius:16px;background:var(--paper)}
.hzb-item-h{display:flex;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid var(--line)}
.hzb-item-b{padding:16px;display:grid;gap:14px}
.hzb-num{width:26px;height:26px;border-radius:50%;display:grid;place-items:center;background:var(--goldbg);color:var(--gold);font-size:12.5px;font-weight:500;flex:none}
.hzb-choice{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
.hzb-choice button{text-align:left;padding:14px;border-radius:14px;border:1.5px solid var(--line);background:#fff;cursor:pointer;transition:all .18s}
.hzb-choice button.on{border-color:var(--ink);box-shadow:0 0 0 3px rgba(30,26,18,.07)}
.hzb-g2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.hzb-g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px}
@media (max-width:1320px){.hzb{grid-template-columns:210px minmax(0,1fr)}.hzb-prev{display:none}.hzb-fab{display:inline-flex}}
@media (max-width:900px){
 .hzb{grid-template-columns:minmax(0,1fr);padding:16px 16px calc(110px + env(safe-area-inset-bottom));gap:16px}
 .hzb-rail{display:none}
 .hzb-tabs{display:block;position:sticky;top:113px;z-index:30;margin:0 -16px;padding:8px 16px;box-shadow:0 -14px 0 rgba(251,248,242,.96);background:rgba(251,248,242,.92);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px)}
 .hzb-bar{top:58px}
 .hzb-bar-in{padding:8px 16px;gap:10px;min-height:56px}
 .hzb-fab{position:fixed;right:16px;bottom:calc(84px + env(safe-area-inset-bottom));z-index:46;box-shadow:0 14px 30px -10px rgba(30,26,18,.6)}
 .hzb-choice{grid-template-columns:1fr}
 .hzb-g3{grid-template-columns:1fr 1fr}
}
@media (max-width:560px){.hzb-g2{grid-template-columns:1fr}.hzb-g3{grid-template-columns:1fr}.hzb-hide-sm{display:none}}
`;
var cssDone = false;
function useBuilderCss() {
  useStudioCss();
  if (!cssDone) {
    cssDone = true;
    const s = document.createElement("style");
    s.textContent = CSS + BI_CSS;
    document.head.appendChild(s);
  }
}
function allPairs(f) {
  const P = [
    ["groomFamily", pairTop("groomFamily", "groomFamilySw"), "family"],
    ["brideFamily", pairTop("brideFamily", "brideFamilySw"), "family"],
    ["heroIntro", pairTop("heroIntroEn", "heroIntroSw"), "text"],
    ["quote", pairTop("quoteEn", "quoteSw"), "text"],
    ["story", pairTop("storyEn", "storySw"), "text"],
    ["dressNote", pairTop("dressNoteEn", "dressNoteSw"), "text"],
    ["dressLadies", pairTop("dressLadiesEn", "dressLadiesSw"), "text"],
    ["dressGents", pairTop("dressGentsEn", "dressGentsSw"), "text"]
  ];
  for (const e of f.events || []) {
    P.push(["ev." + e.k + ".name", pairItem("events", e.k, "name", "nameSw"), "term"]);
    P.push(["ev." + e.k + ".dress", pairItem("events", e.k, "dressCode", "dressCodeSw"), "term"]);
    P.push(["ev." + e.k + ".notes", pairItem("events", e.k, "notes", "notesSw"), "text"]);
  }
  for (const g of f.gifts || []) {
    P.push(["gf." + g.k + ".label", pairItem("gifts", g.k, "label", "labelSw"), "brand"]);
    P.push(["gf." + g.k + ".acct", pairItem("gifts", g.k, "accountName", "accountNameSw"), "brand"]);
  }
  for (const c of f.contacts || []) P.push(["ct." + c.k + ".label", pairItem("contacts", c.k, "label", "labelSw"), "term"]);
  for (const l of f.wordingLines || []) P.push(["wl." + l.k, pairItem("wordingLines", l.k, "en", "sw"), l.style === "name" ? "family" : "text"]);
  return P;
}
async function fillMissing(f0, update) {
  let n = 0;
  for (const [path, pair, kind] of allPairs(f0)) {
    const v = pair.get(f0);
    const from = v.sw.trim() && !v.en.trim() ? "sw" : v.en.trim() && !v.sw.trim() ? "en" : null;
    if (!from) continue;
    const to = from === "sw" ? "en" : "sw";
    const r = await translate(v[from], from, to, kind);
    if (!r.text) continue;
    n++;
    update((f) => {
      const cur = pair.get(f);
      if (cur[to].trim() || cur[from] !== v[from]) return f;
      const g = pair.put(f, to, r.text);
      return r.text === v[from] ? g : { ...g, autoT: { ...g.autoT || {}, [path]: to } };
    });
  }
  return n;
}
function Builder() {
  useBuilderCss();
  return /* @__PURE__ */ React.createElement(Shell, { active: "weddings", wide: true }, (user) => /* @__PURE__ */ React.createElement(Editor, { user }));
}
function tabFromHash() {
  const m = /[?&]tab=([a-z]+)/.exec(window.location.hash || "");
  return m && SECTIONS.some((s) => s.id === m[1]) ? m[1] : "template";
}
function Editor({ user }) {
  const { id } = useParams();
  const ui = useUI();
  const nav = useNavigate();
  const [form, setForm] = useState(null);
  const [loadErr, setLoadErr] = useState(null);
  const [sec, setSec] = useState(tabFromHash);
  const [save, setSave] = useState({ s: "saved", msg: "" });
  const [slugErr, setSlugErr] = useState("");
  const [lang, setLang] = useState("sw");
  const [prevOpen, setPrevOpen] = useState(false);
  const saved = useRef({});
  const timer = useRef(null);
  const formRef = useRef(null);
  formRef.current = form;
  const guestsQ = useData((r) => r.guests.list(id), [id]);
  useEffect(() => {
    let live = true;
    (async () => {
      try {
        const r = await HZ.repo();
        const inv = await r.invitations.get(id);
        if (!live) return;
        const f = {
          ...inv,
          events: keyed(inv.events).map((e) => ({ ...e, date: HZ.ymd(e.date) })),
          gifts: keyed(inv.gifts),
          contacts: keyed(inv.contacts),
          wordingLines: keyed(inv.wordingLines),
          gallery: Array.isArray(inv.gallery) ? inv.gallery : [],
          autoT: inv.autoT || {}
        };
        delete f.id;
        delete f.ownerId;
        const snap = {};
        for (const k in f) snap[k] = JSON.stringify(f[k]);
        saved.current = snap;
        setForm(f);
      } catch (e) {
        if (live) setLoadErr(e);
      }
    })();
    return () => {
      live = false;
    };
  }, [id]);
  const flush = useCallback(async () => {
    const f = formRef.current;
    if (!f) return;
    const changed = {};
    for (const k in f) {
      const j = JSON.stringify(f[k]);
      if (saved.current[k] !== j) changed[k] = f[k];
    }
    if (!Object.keys(changed).length) {
      setSave({ s: "saved", msg: "" });
      return;
    }
    const size = new Blob([JSON.stringify(f)]).size;
    if (size > 98e4) {
      setSave({ s: "error", msg: "Too large to save \u2014 use smaller photos" });
      return;
    }
    setSave({ s: "saving", msg: "" });
    try {
      const r = await HZ.repo();
      await r.invitations.update(id, changed);
      for (const k in changed) saved.current[k] = JSON.stringify(changed[k]);
      if ("slug" in changed) setSlugErr("");
      const still = Object.keys(formRef.current || {}).some((k) => saved.current[k] !== JSON.stringify(formRef.current[k]));
      setSave({ s: still ? "dirty" : "saved", msg: "" });
      if (still) {
        clearTimeout(timer.current);
        timer.current = setTimeout(flush, 900);
      }
      try {
        HZ.emit("*");
      } catch (e) {
      }
    } catch (e) {
      const m = errText(e);
      if (/link is taken/i.test(m)) {
        setSlugErr("That link is already used by another invitation \u2014 choose another.");
        setSave({ s: "error", msg: "Link already taken" });
      } else setSave({ s: "error", msg: m });
    }
  }, [id]);
  const update = useCallback((fn) => {
    setForm((f) => f ? fn(f) : f);
    setSave((s) => s.s === "saving" ? s : { s: "dirty", msg: "" });
    clearTimeout(timer.current);
    timer.current = setTimeout(flush, 1100);
  }, [flush]);
  const set = useCallback((k, v) => update((f) => ({ ...f, [k]: v })), [update]);
  useEffect(() => {
    const h = (e) => {
      if (save.s === "dirty" || save.s === "saving" || save.s === "error") {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", h);
    return () => window.removeEventListener("beforeunload", h);
  }, [save.s]);
  useEffect(() => () => {
    clearTimeout(timer.current);
  }, []);
  const go = (s) => {
    setSec(s);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const filled = useRef(false);
  useEffect(() => {
    if (!form || filled.current) return;
    filled.current = true;
    fillMissing(form, update).then((n) => {
      if (n) ui.toast(n === 1 ? "1 missing translation filled \u2014 marked Auto, please check it" : n + " missing translations filled \u2014 marked Auto, please check them", { ms: 6e3 });
    });
  }, [form, update]);
  if (loadErr) return /* @__PURE__ */ React.createElement("main", { className: "hzs-wrap" }, /* @__PURE__ */ React.createElement(Empty, { icon: I.alert, title: "This invitation couldn't be opened", text: errText(loadErr) }, /* @__PURE__ */ React.createElement(LinkButton, { to: "/dashboard", variant: "primary", icon: I.back }, "Back to weddings")));
  if (!form) return /* @__PURE__ */ React.createElement("main", { className: "hzb" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-rail" }, /* @__PURE__ */ React.createElement(Skel, { h: 300, r: 16 })), /* @__PURE__ */ React.createElement("div", { className: "hzb-main" }, /* @__PURE__ */ React.createElement(Skel, { h: 60, r: 16 }), /* @__PURE__ */ React.createElement(Skel, { h: 360, r: 18 })));
  const isEA = form.templateId === EA;
  const guests = guestsQ.data || [];
  const done = {
    template: true,
    couple: !!(form.groomName && form.brideName),
    events: (form.events || []).some((e) => e.date),
    guests: guests.length > 0,
    share: form.status === "active"
  };
  const link = HZ.base() + "#/i/" + form.slug;
  const props = { form, set, update, isEA, go, ui };
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "hzb-bar" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-bar-in" }, /* @__PURE__ */ React.createElement(Button, { variant: "ghost", size: "sm", icon: I.back, onClick: () => nav("/dashboard"), "aria-label": "Back to weddings", title: "Back to weddings" }), /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0 } }, /* @__PURE__ */ React.createElement("div", { style: { fontFamily: "'Great Vibes', cursive", fontSize: 26, lineHeight: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" } }, (form.groomName || "Groom") + " & " + (form.brideName || "Bride"))), /* @__PURE__ */ React.createElement(SaveState, { s: save, onRetry: flush }), /* @__PURE__ */ React.createElement("div", { style: { marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" } }, /* @__PURE__ */ React.createElement("label", { className: "hzs-row", style: { gap: 8, fontSize: 13, color: "var(--ink2)", cursor: "pointer" } }, /* @__PURE__ */ React.createElement(Switch, { on: form.status === "active", onChange: (v) => set("status", v ? "active" : "draft"), label: "Live" }), /* @__PURE__ */ React.createElement("span", { style: { whiteSpace: "nowrap" } }, form.status === "active" ? "Live" : "Draft")), /* @__PURE__ */ React.createElement(Button, { variant: "primary", size: "sm", icon: I.link, onClick: () => copyText(link).then(() => ui.toast("Invitation link copied")) }, /* @__PURE__ */ React.createElement("span", { className: "hzb-hide-sm" }, "Copy link"))))), /* @__PURE__ */ React.createElement("main", { className: "hzb" }, /* @__PURE__ */ React.createElement("nav", { className: "hzb-rail", "aria-label": "Sections" }, SECTIONS.map((s) => /* @__PURE__ */ React.createElement("a", { key: s.id, className: cx(sec === s.id && "on", s.ea && !isEA && "dim"), onClick: () => go(s.id), role: "button", tabIndex: 0, onKeyDown: (e) => e.key === "Enter" && go(s.id) }, /* @__PURE__ */ React.createElement(s.icon, { size: 17 }), s.label, s.id === "guests" ? /* @__PURE__ */ React.createElement("span", { className: "n" }, guests.length) : done[s.id] && s.id !== "template" ? /* @__PURE__ */ React.createElement(I.check, { size: 15, className: "ok" }) : null)), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 18, padding: "14px 12px", borderTop: "1px solid var(--line)" } }, /* @__PURE__ */ React.createElement(LinkButton, { to: "/scan/" + id, variant: "secondary", size: "sm", icon: I.scan, style: { width: "100%" } }, "Check-in at the door"))), /* @__PURE__ */ React.createElement("div", { className: "hzb-main" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-tabs" }, /* @__PURE__ */ React.createElement("div", { className: "hzs-tabs" }, SECTIONS.map((s) => /* @__PURE__ */ React.createElement("button", { key: s.id, ref: sec === s.id ? (el) => {
    if (el && el.parentElement) {
      const p = el.parentElement;
      p.scrollTo({ left: el.offsetLeft - (p.clientWidth - el.offsetWidth) / 2, behavior: "smooth" });
    }
  } : null, className: cx("hzs-tab", sec === s.id && "on"), onClick: () => go(s.id) }, /* @__PURE__ */ React.createElement(s.icon, { size: 14 }), s.label, s.id === "guests" ? /* @__PURE__ */ React.createElement("span", { className: "n" }, guests.length) : null)))), /* @__PURE__ */ React.createElement(AnimatePresence, { mode: "wait", initial: false }, /* @__PURE__ */ React.createElement(motion.div, { key: sec, initial: { opacity: 0, y: 8 }, animate: { opacity: 1, y: 0 }, exit: { opacity: 0, y: -4 }, transition: { duration: 0.2 }, style: { display: "flex", flexDirection: "column", gap: 18 } }, sec === "template" ? /* @__PURE__ */ React.createElement(TemplateSec, { ...props }) : null, sec === "couple" ? /* @__PURE__ */ React.createElement(CoupleSec, { ...props }) : null, sec === "wording" ? /* @__PURE__ */ React.createElement(WordingSec, { ...props }) : null, sec === "story" ? /* @__PURE__ */ React.createElement(StorySec, { ...props }) : null, sec === "events" ? /* @__PURE__ */ React.createElement(EventsSec, { ...props }) : null, sec === "dress" ? /* @__PURE__ */ React.createElement(DressSec, { ...props }) : null, sec === "gifts" ? /* @__PURE__ */ React.createElement(GiftsSec, { ...props }) : null, sec === "guests" ? /* @__PURE__ */ React.createElement(GuestsPanel, { invId: id, form, q: guestsQ, ui }) : null, sec === "share" ? /* @__PURE__ */ React.createElement(ShareSec, { ...props, id, link, slugErr, setSlugErr, nav }) : null)), /* @__PURE__ */ React.createElement(StepNav, { sec, go })), /* @__PURE__ */ React.createElement("aside", { className: "hzb-prev" }, /* @__PURE__ */ React.createElement(Preview, { form, lang, setLang }))), /* @__PURE__ */ React.createElement(Button, { variant: "primary", icon: I.eye, className: "hzb-fab", onClick: () => setPrevOpen(true) }, "Preview"), /* @__PURE__ */ React.createElement(AnimatePresence, null, prevOpen ? /* @__PURE__ */ React.createElement(PreviewSheet, { form, lang, setLang, onClose: () => setPrevOpen(false) }) : null));
}
function SaveState({ s, onRetry }) {
  if (s.s === "saving") return /* @__PURE__ */ React.createElement(Badge, { tone: "info" }, /* @__PURE__ */ React.createElement("span", { className: "hzs-dot", style: { animation: "hzs-pulse 1s infinite" } }), "Saving\u2026", /* @__PURE__ */ React.createElement("style", null, "@keyframes hzs-pulse{50%{opacity:.3}}"));
  if (s.s === "dirty") return /* @__PURE__ */ React.createElement(Badge, null, "Editing\u2026");
  if (s.s === "error") return /* @__PURE__ */ React.createElement("button", { className: "hzs-badge bad", onClick: onRetry, style: { border: 0, cursor: "pointer" }, title: "Tap to try again" }, /* @__PURE__ */ React.createElement(I.alert, { size: 12 }), " ", s.msg || "Not saved", " \xB7 retry");
  return /* @__PURE__ */ React.createElement(Badge, { tone: "ok" }, /* @__PURE__ */ React.createElement(I.check, { size: 12 }), "Saved");
}
function StepNav({ sec, go }) {
  const i = SECTIONS.findIndex((s) => s.id === sec);
  const prev = SECTIONS[i - 1], next = SECTIONS[i + 1];
  return /* @__PURE__ */ React.createElement("div", { className: "hzs-between", style: { marginTop: 6 } }, prev ? /* @__PURE__ */ React.createElement(Button, { variant: "ghost", icon: I.back, onClick: () => go(prev.id) }, prev.label) : /* @__PURE__ */ React.createElement("span", null), next ? /* @__PURE__ */ React.createElement(Button, { variant: "secondary", iconRight: I.right, onClick: () => go(next.id) }, "Next: ", next.label) : null);
}
var SAMPLE_GUEST = { name: "Fatma Juma", code: "DEMO01", rsvpStatus: "pending", companions: 0, maxCompanions: 2, dietary: "", checkedIn: false };
function useFeed(frameRef, form, lang, nonce) {
  const ready = useRef(false);
  const last = useRef(null);
  const send = useCallback(() => {
    const w = frameRef.current && frameRef.current.contentWindow;
    if (!w || !ready.current || !last.current) return;
    w.postMessage(last.current, window.location.origin);
  }, [frameRef]);
  useEffect(() => {
    const h = (e) => {
      if (e.origin === window.location.origin && e.data && e.data.type === "hz-preview-ready" && frameRef.current && e.source === frameRef.current.contentWindow) {
        ready.current = true;
        send();
      }
    };
    window.addEventListener("message", h);
    return () => window.removeEventListener("message", h);
  }, [send, frameRef]);
  useEffect(() => {
    const t = setTimeout(() => {
      last.current = { type: "hz-preview", data: form, lang, guest: SAMPLE_GUEST, nonce, autoOpen: true };
      send();
    }, 350);
    return () => clearTimeout(t);
  }, [form, lang, nonce, send]);
  return () => {
    ready.current = false;
  };
}
function PhoneFrame({ form, lang, height }) {
  const ref = useRef(null);
  const box = useRef(null);
  const [scale, setScale] = useState(0.92);
  const [nonce, setNonce] = useState(0);
  useFeed(ref, form, lang, nonce);
  useEffect(() => {
    const el = box.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => setScale(el.clientWidth / 390));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return /* @__PURE__ */ React.createElement("div", { className: "hzb-phone", style: height ? { maxWidth: Math.round(height * 390 / 780) + 22 } : null }, /* @__PURE__ */ React.createElement("div", { className: "hzb-screen", ref: box }, /* @__PURE__ */ React.createElement("iframe", { ref, src: "./#/preview", title: "Live preview", style: { transform: "scale(" + scale + ")" } })), /* @__PURE__ */ React.createElement("div", { style: { display: "flex", justifyContent: "center", paddingTop: 9 } }, /* @__PURE__ */ React.createElement("button", { onClick: () => setNonce((n) => n + 1), style: { border: 0, background: "transparent", color: "rgba(251,248,242,.7)", fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 6 } }, /* @__PURE__ */ React.createElement(I.refresh, { size: 12 }), "Reload preview")));
}
function Preview({ form, lang, setLang }) {
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "hzs-between", style: { marginBottom: 12 } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-eyebrow", style: { fontSize: 10 } }, "Live preview"), /* @__PURE__ */ React.createElement(Seg, { value: lang, onChange: setLang, items: [{ id: "sw", label: "SW" }, { id: "en", label: "EN" }] })), /* @__PURE__ */ React.createElement(PhoneFrame, { form, lang }), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { textAlign: "center", marginTop: 12 } }, "Guests open the card in Kiswahili and can switch to English."));
}
function PreviewSheet({ form, lang, setLang, onClose }) {
  const h = typeof window !== "undefined" ? Math.min(window.innerHeight - 150, 760) : 680;
  return /* @__PURE__ */ React.createElement(Modal, { onClose, width: 440, label: "Preview" }, /* @__PURE__ */ React.createElement("div", { style: { padding: "14px 16px 18px", background: "var(--bg)" } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between", style: { marginBottom: 12 } }, /* @__PURE__ */ React.createElement(Seg, { value: lang, onChange: setLang, items: [{ id: "sw", label: "Kiswahili" }, { id: "en", label: "English" }] }), /* @__PURE__ */ React.createElement(Button, { variant: "ghost", size: "sm", icon: I.x, onClick: onClose, "aria-label": "Close preview" })), /* @__PURE__ */ React.createElement(PhoneFrame, { form, lang, height: h })));
}
function EANote({ isEA, set }) {
  if (isEA) return null;
  return /* @__PURE__ */ React.createElement(Note, { tone: "info", icon: I.info }, "These options appear on the ", /* @__PURE__ */ React.createElement("b", null, "Emerald Arch"), " template. Your current template keeps its own built-in wording.", /* @__PURE__ */ React.createElement("div", { style: { marginTop: 8 } }, /* @__PURE__ */ React.createElement(Button, { size: "xs", variant: "secondary", onClick: () => set("templateId", EA) }, "Switch to Emerald Arch")));
}
function TemplateSec({ form, set }) {
  const T = HZ.templates || [];
  return /* @__PURE__ */ React.createElement(Section, { icon: I.palette, title: "Choose the template", sub: "You can switch at any time \u2014 your words, events and guests stay the same." }, /* @__PURE__ */ React.createElement("div", { className: "hzb-tpl" }, T.map((t) => /* @__PURE__ */ React.createElement("button", { key: t.id, className: cx("hzb-tplc", form.templateId === t.id && "on"), onClick: () => set("templateId", t.id), "aria-pressed": form.templateId === t.id }, /* @__PURE__ */ React.createElement("div", { style: { aspectRatio: "4 / 5", background: (t.palette || [])[0] || "#eee", overflow: "hidden" } }, /* @__PURE__ */ React.createElement("img", { src: t.previewImage, alt: "", loading: "lazy", style: { width: "100%", height: "100%", objectFit: "cover", objectPosition: "center top", display: "block" } })), /* @__PURE__ */ React.createElement("div", { style: { padding: "10px 12px 12px" } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between" }, /* @__PURE__ */ React.createElement("span", { style: { fontWeight: 500, fontSize: 14 } }, t.name), form.templateId === t.id ? /* @__PURE__ */ React.createElement(I.okCircle, { size: 16, style: { color: "var(--ok)" } }) : null), /* @__PURE__ */ React.createElement("div", { style: { display: "flex", gap: 4, marginTop: 7 } }, (t.palette || []).slice(0, 4).map((c) => /* @__PURE__ */ React.createElement("span", { key: c, style: { width: 12, height: 12, borderRadius: 99, background: c, border: "1px solid rgba(0,0,0,.08)" } }))), t.id === EA ? /* @__PURE__ */ React.createElement("div", { style: { fontSize: 11, color: "var(--gold)", marginTop: 7 } }, "Custom wording \xB7 dress photos") : null)))));
}
function CoupleSec({ form, set, update, isEA }) {
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Section, { icon: I.heart, title: "The couple", sub: "Names are written exactly as you type them, in both languages." }, /* @__PURE__ */ React.createElement("div", { className: "hzb-g2" }, /* @__PURE__ */ React.createElement(Field, { label: "Groom's name" }, /* @__PURE__ */ React.createElement(Input, { value: form.groomName || "", onChange: (e) => set("groomName", e.target.value), placeholder: "Yusuf", maxLength: 40 })), /* @__PURE__ */ React.createElement(Field, { label: "Bride's name" }, /* @__PURE__ */ React.createElement(Input, { value: form.brideName || "", onChange: (e) => set("brideName", e.target.value), placeholder: "Amina", maxLength: 40 })))), /* @__PURE__ */ React.createElement(Section, { icon: I.users, title: "The families", sub: "Shown as \u201CThe families of \u2026 and \u2026\u201D. Titles switch automatically \u2014 Mr. & Mrs. \u2194 Bw. na Bi." }, /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 18 } }, /* @__PURE__ */ React.createElement(Bi, { label: "Groom's family", kind: "family", path: "groomFamily", pair: pairTop("groomFamily", "groomFamilySw"), form, update, max: 90, phSw: "Bw. na Bi. Salim Juma", phEn: "Mr. & Mrs. Salim Juma" }), /* @__PURE__ */ React.createElement(Bi, { label: "Bride's family", kind: "family", path: "brideFamily", pair: pairTop("brideFamily", "brideFamilySw"), form, update, max: 90, phSw: "Bw. na Bi. Ali Hassan", phEn: "Mr. & Mrs. Ali Hassan" }))), /* @__PURE__ */ React.createElement(Section, { icon: I.sparkle, title: "Seal & opening line" }, /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 18 } }, /* @__PURE__ */ React.createElement(Field, { label: "Wax-seal monogram", hint: "Up to 9 characters \u2014 initials work best. Leave empty for the couple's initials." }, /* @__PURE__ */ React.createElement(Input, { value: form.sealText || "", onChange: (e) => set("sealText", e.target.value.slice(0, 9)), placeholder: "Y & A", style: { maxWidth: 220, letterSpacing: ".18em", textAlign: "center" } })), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement(
    Bi,
    {
      label: "Line above the names",
      kind: "text",
      path: "heroIntro",
      pair: pairTop("heroIntroEn", "heroIntroSw"),
      form,
      update,
      max: 70,
      phSw: "Kwa baraka za familia zao",
      phEn: "Together with their families",
      hint: "Emerald Arch only. Leave empty to keep the template's line."
    }
  )))));
}
var STYLES = [{ value: "caps", label: "Small caps" }, { value: "name", label: "Names \u2014 bold italic" }, { value: "body", label: "Sentence" }, { value: "script", label: "Script" }, { value: "gold", label: "Gold italic" }];
function WordingSec({ form, set, update, isEA, ui }) {
  const lines = form.wordingLines || [];
  const put = (arr) => set("wordingLines", arr.slice(0, 8));
  const move = (i, d) => {
    const a = lines.slice();
    const j = i + d;
    if (j < 0 || j >= a.length) return;
    [a[i], a[j]] = [a[j], a[i]];
    put(a);
  };
  const gf = form.groomFamily || "Mr. & Mrs. \u2026", bf = form.brideFamily || "Mr. & Mrs. \u2026";
  const gfs = form.groomFamilySw || HZ.honor(gf, "sw"), bfs = form.brideFamilySw || HZ.honor(bf, "sw");
  const presets = {
    families: [
      { style: "caps", en: "The families of", sw: "Familia za" },
      { style: "name", en: gf, sw: gfs },
      { style: "gold", en: "and", sw: "na" },
      { style: "name", en: bf, sw: bfs },
      { style: "body", en: "request the honour of your presence at the marriage of their beloved children", sw: "zinakuomba kwa heshima uhudhurie ndoa ya watoto wao wapendwa" }
    ],
    sisters: [
      { style: "caps", en: "The sisters of the bride", sw: "Dada wa bibi harusi" },
      { style: "name", en: "\u2026names of the sisters\u2026", sw: "\u2026majina ya dada\u2026" },
      { style: "body", en: "would like to invite you to the wedding of their beloved sister", sw: "wangependa kukualika kwenye harusi ya dada yao mpendwa" }
    ],
    brothers: [
      { style: "caps", en: "The brothers of the groom", sw: "Kaka wa bwana harusi" },
      { style: "name", en: "\u2026names of the brothers\u2026", sw: "\u2026majina ya kaka\u2026" },
      { style: "body", en: "would like to invite you to the wedding of their beloved brother", sw: "wangependa kukualika kwenye harusi ya kaka yao mpendwa" }
    ],
    parents: [
      { style: "caps", en: "The parents of the bride", sw: "Wazazi wa bibi harusi" },
      { style: "name", en: "Mr. & Mrs. \u2026", sw: "Bw. na Bi. \u2026" },
      { style: "body", en: "joyfully invite you to celebrate the marriage of their daughter", sw: "wanakualika kwa furaha kusherehekea ndoa ya binti yao" }
    ]
  };
  const usePreset = async (k) => {
    if (lines.length && !await ui.confirm({ title: "Replace the current wording?", body: "The lines you have now will be replaced with this layout.", confirmText: "Replace" })) return;
    update((f) => ({ ...f, wordingLines: presets[k].map((l) => ({ ...l, k: rid() })) }));
  };
  const reset = async () => {
    if (await ui.confirm({ title: "Go back to the default wording?", body: "Your custom lines will be removed and the card shows the two families as usual.", confirmText: "Use default", tone: "danger" })) set("wordingLines", []);
  };
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(EANote, { isEA, set }), /* @__PURE__ */ React.createElement(
    Section,
    {
      icon: I.type,
      title: "Invitation wording",
      sub: "Who is inviting, written the way the family wants \u2014 each line has its own style so the card stays beautifully set.",
      right: lines.length ? /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.undo, onClick: reset }, "Use default") : null
    },
    /* @__PURE__ */ React.createElement("div", { className: "hzs-wrapflex", style: { alignItems: "center", marginBottom: lines.length ? 18 : 0 } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-label", style: { margin: "0 4px 0 0" } }, "Start from"), [["families", "The families of"], ["sisters", "The sisters of"], ["brothers", "The brothers of"], ["parents", "The parents of"]].map(([k, l]) => /* @__PURE__ */ React.createElement("button", { key: k, className: "hzs-chip", onClick: () => usePreset(k) }, l))),
    !lines.length ? /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { marginTop: 14 } }, "No custom wording \u2014 the card shows \u201CThe families of ", gf, " and ", bf, "\u201D.") : null,
    /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 12 } }, lines.map((l, i) => /* @__PURE__ */ React.createElement("div", { key: l.k, className: "hzb-item" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-item-h" }, /* @__PURE__ */ React.createElement("span", { className: "hzb-num" }, i + 1), /* @__PURE__ */ React.createElement(Select, { value: l.style || "body", onChange: (e) => update((f) => ({ ...f, wordingLines: f.wordingLines.map((z) => z.k === l.k ? { ...z, style: e.target.value } : z) })), options: STYLES, style: { width: "auto", height: 36, fontSize: 13.5 } }), /* @__PURE__ */ React.createElement("div", { style: { marginLeft: "auto", display: "flex", gap: 2 } }, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.up, disabled: !i, onClick: () => move(i, -1), "aria-label": "Move up" }), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.down, disabled: i === lines.length - 1, onClick: () => move(i, 1), "aria-label": "Move down" }), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.trash, onClick: () => put(lines.filter((z) => z.k !== l.k)), "aria-label": "Remove line" }))), /* @__PURE__ */ React.createElement("div", { className: "hzb-item-b" }, /* @__PURE__ */ React.createElement(Bi, { kind: l.style === "name" ? "family" : "text", path: "wl." + l.k, pair: pairItem("wordingLines", l.k, "en", "sw"), form, update, max: 220, phSw: "Maandishi ya Kiswahili", phEn: "English text" }))))),
    lines.length && lines.length < 8 ? /* @__PURE__ */ React.createElement(Button, { variant: "secondary", size: "sm", icon: I.plus, style: { marginTop: 14 }, onClick: () => put([...lines, { k: rid(), style: "body", en: "", sw: "" }]) }, "Add a line") : null,
    lines.length ? /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { marginTop: 14 } }, /* @__PURE__ */ React.createElement("b", null, "Small caps"), " for short openers \xB7 ", /* @__PURE__ */ React.createElement("b", null, "Names"), " for people \xB7 ", /* @__PURE__ */ React.createElement("b", null, "Sentence"), " for the invitation \xB7 ", /* @__PURE__ */ React.createElement("b", null, "Script"), " for a flourish \xB7 ", /* @__PURE__ */ React.createElement("b", null, "Gold italic"), " for joining words like \u201Cand\u201D.") : null
  ));
}
function StorySec({ form, update }) {
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Section, { icon: I.book, title: "Blessing / Qur'an verse", sub: "Shown in a quote frame on the card." }, /* @__PURE__ */ React.createElement(Bi, { area: true, rows: 3, kind: "text", path: "quote", pair: pairTop("quoteEn", "quoteSw"), form, update, max: 400, phSw: "Na katika Ishara Zake\u2026", phEn: "And among His signs\u2026" })), /* @__PURE__ */ React.createElement(Section, { icon: I.heart, title: "Your letter to guests", sub: "A few warm sentences \u2014 how you met, or a welcome to your guests." }, /* @__PURE__ */ React.createElement(Bi, { area: true, rows: 5, kind: "text", path: "story", pair: pairTop("storyEn", "storySw"), form, update, max: 900, phSw: "Kwa neema ya Allah\u2026", phEn: "By the grace of Allah\u2026" })));
}
var QUICK = [
  { en: "Nikkah Ceremony", sw: "Sherehe ya Nikkah", time: "10:00" },
  { en: "Walima Reception", sw: "Karamu ya Walima", time: "19:00" },
  { en: "Henna Night", sw: "Usiku wa Henna", time: "19:00" },
  { en: "Send-off", sw: "Sherehe ya Kumuaga Bibi Harusi", time: "18:00" },
  { en: "Kitchen Party", sw: "Kitchen Party (Sherehe ya Jikoni)", time: "14:00" },
  { en: "Reception", sw: "Karamu", time: "18:00" }
];
function EventsSec({ form, set, update, ui }) {
  const ev = form.events || [];
  const first = ev.find((e) => e.date);
  const add = (q) => update((f) => ({ ...f, events: [...f.events || [], { k: rid(), name: q ? q.en : "", nameSw: q ? q.sw : "", date: first ? first.date : "", time: q ? q.time : "", venue: first ? first.venue || "" : "", mapsUrl: first ? first.mapsUrl || "" : "", dressCode: "", dressCodeSw: "", notes: "", notesSw: "" }] }));
  const upd = (k, field, v) => update((f) => ({ ...f, events: f.events.map((e) => e.k === k ? { ...e, [field]: v } : e) }));
  const move = (i, d) => {
    const a = ev.slice();
    const j = i + d;
    if (j < 0 || j >= a.length) return;
    [a[i], a[j]] = [a[j], a[i]];
    set("events", a);
  };
  const remove = async (e) => {
    if (await ui.confirm({ title: "Remove this event?", body: "\u201C" + (e.nameSw || e.name || "Untitled event") + "\u201D will be removed from the card.", confirmText: "Remove", tone: "danger" })) update((f) => ({ ...f, events: f.events.filter((z) => z.k !== e.k) }));
  };
  return /* @__PURE__ */ React.createElement(Section, { icon: I.calendar, title: "Events", sub: "The first event sets the countdown and the main venue. Times show as Swahili time on the Kiswahili card (16:00 \u2192 Saa 10:00 jioni)." }, !ev.length ? /* @__PURE__ */ React.createElement("div", { style: { textAlign: "center", padding: "10px 0 6px" } }, /* @__PURE__ */ React.createElement("p", { className: "hzs-muted", style: { margin: "0 0 14px" } }, "No events yet. Add the ceremonies guests are invited to."), /* @__PURE__ */ React.createElement(Button, { variant: "primary", icon: I.plus, onClick: () => {
    add(QUICK[0]);
    add(QUICK[1]);
  } }, "Add Nikkah & Walima")) : /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 14 } }, ev.map((e, i) => /* @__PURE__ */ React.createElement("div", { key: e.k, className: "hzb-item" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-item-h" }, /* @__PURE__ */ React.createElement("span", { className: "hzb-num" }, i + 1), /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0 } }, /* @__PURE__ */ React.createElement("div", { style: { fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" } }, e.nameSw || e.name || "Untitled event"), /* @__PURE__ */ React.createElement("div", { className: "hzs-hint", style: { margin: 0 } }, [e.date ? HZ.dateLong(e.date, "en") : "No date", e.time ? e.time + " \xB7 " + HZ.swTime(e.time) : ""].filter(Boolean).join(" \xB7 "))), /* @__PURE__ */ React.createElement("div", { style: { marginLeft: "auto", display: "flex", gap: 2 } }, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.up, disabled: !i, onClick: () => move(i, -1), "aria-label": "Move up" }), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.down, disabled: i === ev.length - 1, onClick: () => move(i, 1), "aria-label": "Move down" }), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.trash, onClick: () => remove(e), "aria-label": "Remove event" }))), /* @__PURE__ */ React.createElement("div", { className: "hzb-item-b" }, /* @__PURE__ */ React.createElement(Bi, { label: "Event name", kind: "term", path: "ev." + e.k + ".name", pair: pairItem("events", e.k, "name", "nameSw"), form, update, max: 60, phSw: "Sherehe ya Nikkah", phEn: "Nikkah Ceremony" }), /* @__PURE__ */ React.createElement("div", { className: "hzb-g2" }, /* @__PURE__ */ React.createElement(Field, { label: "Date" }, /* @__PURE__ */ React.createElement(Input, { type: "date", value: e.date || "", onChange: (x) => upd(e.k, "date", x.target.value) })), /* @__PURE__ */ React.createElement(Field, { label: "Time", hint: e.time ? "On the Kiswahili card: " + HZ.swTime(e.time) : null }, /* @__PURE__ */ React.createElement(Input, { type: "time", value: e.time || "", onChange: (x) => upd(e.k, "time", x.target.value) }))), /* @__PURE__ */ React.createElement(Field, { label: "Venue", hint: "Name, then area \u2014 e.g. \u201CGolden Tulip, Stone Town\u201D." }, /* @__PURE__ */ React.createElement(Input, { value: e.venue || "", onChange: (x) => upd(e.k, "venue", x.target.value), placeholder: "Masjid Jibreel, Stone Town", maxLength: 90 })), /* @__PURE__ */ React.createElement(Field, { label: "Google Maps link", right: e.venue ? /* @__PURE__ */ React.createElement("a", { href: "https://www.google.com/maps/search/" + encodeURIComponent(e.venue), target: "_blank", rel: "noreferrer", style: { color: "var(--gold)", fontSize: 12.5 } }, "Find on Maps \u2197") : null }, /* @__PURE__ */ React.createElement(Input, { value: e.mapsUrl || "", onChange: (x) => upd(e.k, "mapsUrl", x.target.value.trim()), placeholder: "https://maps.app.goo.gl/\u2026", inputMode: "url" })), /* @__PURE__ */ React.createElement(Bi, { label: "Dress code (optional)", kind: "term", path: "ev." + e.k + ".dress", pair: pairItem("events", e.k, "dressCode", "dressCodeSw"), form, update, max: 80, phSw: "Mavazi ya staha", phEn: "Modest attire" }), /* @__PURE__ */ React.createElement(Bi, { label: "Note (optional)", kind: "text", path: "ev." + e.k + ".notes", pair: pairItem("events", e.k, "notes", "notesSw"), form, update, max: 200, phSw: "Wanawake pekee", phEn: "Ladies only" }))))), ev.length ? /* @__PURE__ */ React.createElement("div", { style: { marginTop: 16 } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-label" }, "Add an event"), /* @__PURE__ */ React.createElement("div", { className: "hzs-wrapflex" }, QUICK.map((q) => /* @__PURE__ */ React.createElement("button", { key: q.en, className: "hzs-chip", onClick: () => add(q) }, /* @__PURE__ */ React.createElement(I.plus, { size: 13 }), q.sw)), /* @__PURE__ */ React.createElement("button", { className: "hzs-chip", onClick: () => add(null) }, /* @__PURE__ */ React.createElement(I.plus, { size: 13 }), "Other"))) : null);
}
function compress(file) {
  return new Promise((res, rej) => {
    if (!file || !/^image\//.test(file.type)) return rej(new Error("Please choose a photo (JPG, PNG or WebP)."));
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      const enc = (maxW, q) => {
        const sc = Math.min(1, maxW / img.naturalWidth, maxW * 1.6 / img.naturalHeight);
        const cw = Math.round(img.naturalWidth * sc), ch = Math.round(img.naturalHeight * sc);
        const cv = document.createElement("canvas");
        cv.width = cw;
        cv.height = ch;
        const c = cv.getContext("2d");
        c.fillStyle = "#f6efdd";
        c.fillRect(0, 0, cw, ch);
        c.drawImage(img, 0, 0, cw, ch);
        let d2 = cv.toDataURL("image/webp", q);
        if (!/^data:image\/webp/.test(d2)) d2 = cv.toDataURL("image/jpeg", q);
        return d2;
      };
      let d = enc(960, 0.8);
      if (d.length > 33e4) d = enc(860, 0.72);
      if (d.length > 33e4) d = enc(740, 0.64);
      if (d.length > 33e4) d = enc(640, 0.58);
      res(d);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      rej(new Error("This photo couldn't be read. Try a JPG or PNG."));
    };
    img.src = url;
  });
}
function Upload({ label, value, onChange }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [over, setOver] = useState(false);
  const ref = useRef(null);
  const pick = (f) => {
    setErr("");
    setBusy(true);
    compress(f).then(onChange).catch((e) => setErr(e.message)).finally(() => setBusy(false));
  };
  const kb = value ? Math.round(value.length * 0.75 / 1024) : 0;
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "hzs-label" }, label), /* @__PURE__ */ React.createElement(
    "div",
    {
      onDragOver: (e) => {
        e.preventDefault();
        setOver(true);
      },
      onDragLeave: () => setOver(false),
      onDrop: (e) => {
        e.preventDefault();
        setOver(false);
        e.dataTransfer.files[0] && pick(e.dataTransfer.files[0]);
      },
      style: { display: "flex", gap: 16, alignItems: "center", padding: 14, borderRadius: 16, border: "1.5px dashed " + (over ? "var(--gold)" : "var(--goldline)"), background: over ? "var(--goldbg)" : "var(--paper)" }
    },
    /* @__PURE__ */ React.createElement("div", { style: { width: 84, aspectRatio: "3 / 4", borderRadius: "42px 42px 8px 8px", overflow: "hidden", background: "var(--goldbg)", border: "1px solid var(--goldline)", flex: "none", display: "grid", placeItems: "center", color: "var(--gold)" } }, value ? /* @__PURE__ */ React.createElement("img", { src: value, alt: "", style: { width: "100%", height: "100%", objectFit: "cover", objectPosition: "center 18%" } }) : /* @__PURE__ */ React.createElement(I.image, { size: 22 })),
    /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0, flex: 1 } }, /* @__PURE__ */ React.createElement("p", { style: { margin: 0, fontSize: 14 } }, busy ? "Preparing photo\u2026" : value ? "Photo ready \xB7 " + kb + " KB" : "No photo yet \u2014 the template's illustration shows."), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { marginTop: 2 } }, "Portrait photos look best. Drag a photo here or choose one."), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, marginTop: 10, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "primary", icon: I.upload, busy, onClick: () => ref.current && ref.current.click() }, value ? "Replace" : "Upload photo"), value ? /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.trash, onClick: () => onChange("") }, "Remove") : null), err ? /* @__PURE__ */ React.createElement("p", { className: "hzs-err" }, err) : null),
    /* @__PURE__ */ React.createElement("input", { ref, type: "file", accept: "image/*", hidden: true, onChange: (e) => {
      e.target.files[0] && pick(e.target.files[0]);
      e.target.value = "";
    } })
  ));
}
function DressSec({ form, set, update, isEA }) {
  const mode = form.dressMode || "";
  const opts = [["", "Template illustration", "The built-in artwork, as in the demo"], ["ladies", "Ladies only", "One photo \u2014 for a ladies' event"], ["both", "Ladies & gentlemen", "A photo for each"]];
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(EANote, { isEA, set }), /* @__PURE__ */ React.createElement(Section, { icon: I.shirt, title: "Who is the dress code for?" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-choice" }, opts.map(([v, t, sub]) => /* @__PURE__ */ React.createElement("button", { key: v || "d", className: mode === v ? "on" : "", onClick: () => set("dressMode", v) }, /* @__PURE__ */ React.createElement("span", { className: "hzs-row", style: { gap: 8 } }, /* @__PURE__ */ React.createElement("span", { style: { width: 16, height: 16, borderRadius: 99, border: "1.5px solid " + (mode === v ? "var(--ink)" : "var(--line2)"), display: "grid", placeItems: "center" } }, mode === v ? /* @__PURE__ */ React.createElement("span", { style: { width: 8, height: 8, borderRadius: 99, background: "var(--ink)" } }) : null), /* @__PURE__ */ React.createElement("b", { style: { fontWeight: 500 } }, t)), /* @__PURE__ */ React.createElement("span", { className: "hzs-hint", style: { display: "block", marginTop: 4 } }, sub))))), mode ? /* @__PURE__ */ React.createElement(Section, { icon: I.image, title: "Photos", sub: "Resized automatically. Guests can tap a photo to see it full screen." }, /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 20 } }, /* @__PURE__ */ React.createElement(Upload, { label: "Ladies", value: form.dressImgLadies || "", onChange: (v) => set("dressImgLadies", v) }), /* @__PURE__ */ React.createElement(Bi, { label: "Ladies \u2014 caption (optional)", kind: "text", path: "dressLadies", pair: pairTop("dressLadiesEn", "dressLadiesSw"), form, update, max: 220, phSw: "Gauni ndefu rasmi za rangi ya kijani au krimu.", phEn: "Formal floor-length gowns in emerald or ivory." }), mode === "both" ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { style: { height: 1, background: "var(--line)" } }), /* @__PURE__ */ React.createElement(Upload, { label: "Gentlemen", value: form.dressImgGents || "", onChange: (v) => set("dressImgGents", v) }), /* @__PURE__ */ React.createElement(Bi, { label: "Gentlemen \u2014 caption (optional)", kind: "text", path: "dressGents", pair: pairTop("dressGentsEn", "dressGentsSw"), form, update, max: 220, phSw: "Suti au kanzu na koti.", phEn: "A suit, or kanzu with a coat." })) : null)) : null, /* @__PURE__ */ React.createElement(Section, { icon: I.type, title: "Description", sub: "The line under \u201CDress Code\u201D. Leave empty to keep the template's text." }, /* @__PURE__ */ React.createElement(Bi, { area: true, rows: 3, kind: "text", path: "dressNote", pair: pairTop("dressNoteEn", "dressNoteSw"), form, update, max: 320, phSw: "Wanawake \u2014 gauni ndefu za rangi ya zumaridi\u2026", phEn: "Ladies \u2014 elegant floor-length gowns in soft emerald\u2026" })));
}
var GIFT_QUICK = [{ label: "M-Pesa", provider: "Vodacom M-Pesa" }, { label: "Mixx by Yas", provider: "Mixx by Yas (Tigo Pesa)" }, { label: "Airtel Money", provider: "Airtel Money" }, { label: "HaloPesa", provider: "HaloPesa" }, { label: "Bank", provider: "" }];
function GiftsSec({ form, set, update, ui }) {
  const gifts = form.gifts || [], contacts = form.contacts || [];
  const updG = (k, f2, v) => update((f) => ({ ...f, gifts: f.gifts.map((g) => g.k === k ? { ...g, [f2]: v } : g) }));
  const updC = (k, f2, v) => update((f) => ({ ...f, contacts: f.contacts.map((g) => g.k === k ? { ...g, [f2]: v } : g) }));
  const wa = HZ.phone(form.whatsappNumber);
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Section, { icon: I.gift, title: "Gifts & contributions", sub: "Each card shows with a one-tap copy button. Leave the number empty to hide a card." }, /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 12 } }, gifts.map((g) => /* @__PURE__ */ React.createElement("div", { key: g.k, className: "hzb-item" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-item-h" }, /* @__PURE__ */ React.createElement(I.coins, { size: 16, style: { color: "var(--gold)" } }), /* @__PURE__ */ React.createElement("b", { style: { fontWeight: 500 } }, g.label || "Payment"), !String(g.accountNumber || "").trim() ? /* @__PURE__ */ React.createElement(Badge, { tone: "warn" }, "hidden \u2014 no number") : null, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.trash, style: { marginLeft: "auto" }, "aria-label": "Remove", onClick: () => update((f) => ({ ...f, gifts: f.gifts.filter((z) => z.k !== g.k) })) })), /* @__PURE__ */ React.createElement("div", { className: "hzb-item-b" }, /* @__PURE__ */ React.createElement(Bi, { label: "Label", kind: "brand", path: "gf." + g.k + ".label", pair: pairItem("gifts", g.k, "label", "labelSw"), form, update, max: 40, phSw: "M-Pesa", phEn: "M-Pesa" }), /* @__PURE__ */ React.createElement("div", { className: "hzb-g2" }, /* @__PURE__ */ React.createElement(Field, { label: "Provider" }, /* @__PURE__ */ React.createElement(Input, { value: g.provider || "", onChange: (e) => updG(g.k, "provider", e.target.value), placeholder: "Vodacom M-Pesa", maxLength: 50 })), /* @__PURE__ */ React.createElement(Field, { label: "Number / account" }, /* @__PURE__ */ React.createElement(Input, { value: g.accountNumber || "", onChange: (e) => updG(g.k, "accountNumber", e.target.value), placeholder: "0754 000 000", maxLength: 40 }))), /* @__PURE__ */ React.createElement(Bi, { label: "Account name", kind: "brand", path: "gf." + g.k + ".acct", pair: pairItem("gifts", g.k, "accountName", "accountNameSw"), form, update, max: 60, phSw: "Kamati ya Harusi", phEn: "Wedding Committee" }))))), /* @__PURE__ */ React.createElement("div", { className: "hzs-wrapflex", style: { marginTop: 14 } }, GIFT_QUICK.map((q) => /* @__PURE__ */ React.createElement("button", { key: q.label, className: "hzs-chip", onClick: () => update((f) => ({ ...f, gifts: [...f.gifts || [], { k: rid(), label: q.label, labelSw: q.label === "Bank" ? "Benki" : "", provider: q.provider, accountName: "", accountNameSw: "", accountNumber: "" }] })) }, /* @__PURE__ */ React.createElement(I.plus, { size: 13 }), q.label)))), /* @__PURE__ */ React.createElement(Section, { icon: I.phone, title: "Contacts", sub: "People guests can call with questions." }, /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 12 } }, contacts.map((c) => /* @__PURE__ */ React.createElement("div", { key: c.k, className: "hzb-item" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-item-h" }, /* @__PURE__ */ React.createElement(I.user, { size: 16, style: { color: "var(--gold)" } }), /* @__PURE__ */ React.createElement("b", { style: { fontWeight: 500 } }, c.name || "Contact"), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.trash, style: { marginLeft: "auto" }, "aria-label": "Remove", onClick: () => update((f) => ({ ...f, contacts: f.contacts.filter((z) => z.k !== c.k) })) })), /* @__PURE__ */ React.createElement("div", { className: "hzb-item-b" }, /* @__PURE__ */ React.createElement(Bi, { label: "Role", kind: "term", path: "ct." + c.k + ".label", pair: pairItem("contacts", c.k, "label", "labelSw"), form, update, max: 50, phSw: "Mratibu wa Harusi", phEn: "Wedding Coordinator" }), /* @__PURE__ */ React.createElement("div", { className: "hzb-g2" }, /* @__PURE__ */ React.createElement(Field, { label: "Name" }, /* @__PURE__ */ React.createElement(Input, { value: c.name || "", onChange: (e) => updC(c.k, "name", e.target.value), placeholder: "Bi. Khadija Rashid", maxLength: 50 })), /* @__PURE__ */ React.createElement(Field, { label: "Phone" }, /* @__PURE__ */ React.createElement(Input, { value: c.phone || "", onChange: (e) => updC(c.k, "phone", e.target.value), placeholder: "+255 754 111 222", inputMode: "tel", maxLength: 20 }))))))), /* @__PURE__ */ React.createElement(Button, { variant: "secondary", size: "sm", icon: I.plus, style: { marginTop: 14 }, onClick: () => update((f) => ({ ...f, contacts: [...f.contacts || [], { k: rid(), label: "", labelSw: "", name: "", phone: "" }] })) }, "Add contact")), /* @__PURE__ */ React.createElement(Section, { icon: I.chat, title: "RSVP on WhatsApp", sub: "Guests who reply on WhatsApp message this number." }, /* @__PURE__ */ React.createElement(Field, { error: form.whatsappNumber && !wa.ok ? "This doesn't look like a WhatsApp number." : null, hint: wa.ok ? "Will open: " + HZ.fmtPhone(wa.num) : "Tanzanian numbers can start with 07\u2026 or 06\u2026" }, /* @__PURE__ */ React.createElement(Input, { value: form.whatsappNumber || "", onChange: (e) => set("whatsappNumber", e.target.value), onBlur: () => wa.ok && set("whatsappNumber", wa.num), placeholder: "0777 123 456", inputMode: "tel", style: { maxWidth: 280 }, className: form.whatsappNumber && !wa.ok ? "bad" : "" }))));
}
function svgToPng(svgEl, size, name) {
  const xml = new XMLSerializer().serializeToString(svgEl);
  const img = new Image();
  img.onload = () => {
    const cv = document.createElement("canvas");
    const pad = Math.round(size * 0.08);
    cv.width = size + pad * 2;
    cv.height = size + pad * 2;
    const c = cv.getContext("2d");
    c.fillStyle = "#fff";
    c.fillRect(0, 0, cv.width, cv.height);
    c.drawImage(img, pad, pad, size, size);
    cv.toBlob((b) => b && downloadFile(name, b, "image/png"), "image/png");
  };
  img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(xml);
}
function ShareSec({ form, set, id, link, slugErr, setSlugErr, ui, nav }) {
  const qr = useRef(null);
  const [slug, setSlug] = useState(form.slug || "");
  useEffect(() => setSlug(form.slug || ""), [form.slug]);
  const commit = () => {
    const s = slug.toLowerCase().replace(/[^a-z0-9-]/g, "").replace(/^-+|-+$/g, "");
    if (s.length < 3) {
      setSlugErr("Use at least 3 letters or numbers.");
      return;
    }
    setSlugErr("");
    if (s !== form.slug) set("slug", s);
    setSlug(s);
  };
  const trash = async () => {
    if (!await ui.confirm({ title: "Delete this invitation?", body: "Guests will no longer be able to open it. It moves to the trash and can be restored by the admin.", confirmText: "Delete", tone: "danger" })) return;
    try {
      await call((r) => r.invitations.trash({ id }));
      ui.toast("Invitation deleted");
      nav("/dashboard");
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
    }
  };
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Section, { icon: I.link, title: "Invitation link", sub: "Each guest gets their own personal link from the Guests step \u2014 that's the one to send. This main link opens the card without a name." }, /* @__PURE__ */ React.createElement(Field, { label: "Link name", error: slugErr || null, hint: !slugErr ? "Letters, numbers and dashes. Changing it breaks links you've already sent." : null }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 0, alignItems: "stretch" } }, /* @__PURE__ */ React.createElement("span", { style: { display: "grid", placeItems: "center", padding: "0 12px", border: "1px solid var(--line2)", borderRight: 0, borderRadius: "12px 0 0 12px", background: "rgba(30,26,18,.03)", color: "var(--ink3)", fontSize: 13.5, whiteSpace: "nowrap" } }, "#/i/"), /* @__PURE__ */ React.createElement(Input, { value: slug, onChange: (e) => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "")), onBlur: commit, onKeyDown: (e) => e.key === "Enter" && commit(), style: { borderRadius: "0 12px 12px 0" }, maxLength: 40, className: slugErr ? "bad" : "" }))), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, marginTop: 14, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Button, { variant: "primary", size: "sm", icon: I.copy, onClick: () => copyText(link).then(() => ui.toast("Link copied")) }, "Copy link"), /* @__PURE__ */ React.createElement("a", { className: "hzs-btn secondary sm", href: link, target: "_blank", rel: "noreferrer" }, /* @__PURE__ */ React.createElement(I.open, { size: 15 }), "Open"))), /* @__PURE__ */ React.createElement(Section, { icon: I.qr, title: "QR code for printed cards", sub: "Opens the invitation when scanned with a phone camera." }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 20, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("div", { ref: qr, style: { padding: 12, borderRadius: 16, background: "#fff", border: "1px solid var(--line)" } }, /* @__PURE__ */ React.createElement(QRCodeSVG2, { value: link, size: 150, fgColor: "#1E1A12", level: "M" })), /* @__PURE__ */ React.createElement(Button, { variant: "secondary", size: "sm", icon: I.download, onClick: () => {
    const s = qr.current && qr.current.querySelector("svg");
    s && svgToPng(s, 900, "harusi-" + form.slug + "-qr.png");
  } }, "Download PNG"))), /* @__PURE__ */ React.createElement(Section, { icon: I.image, title: "Photos", sub: "Optional. Paste public image links (for example from Google Photos \u201Ccopy image address\u201D)." }, /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 16 } }, /* @__PURE__ */ React.createElement(Field, { label: "Hero photo link", hint: "Replaces the template's artwork at the top on templates that support it." }, /* @__PURE__ */ React.createElement(Input, { value: form.heroImage || "", onChange: (e) => set("heroImage", e.target.value.trim()), placeholder: "https://\u2026", inputMode: "url" })), /* @__PURE__ */ React.createElement(Field, { label: "Gallery photo links \u2014 one per line, up to 8" }, /* @__PURE__ */ React.createElement(Textarea, { rows: 3, value: (form.gallery || []).join("\n"), onChange: (e) => set("gallery", e.target.value.split("\n").map((x) => x.trim()).filter(Boolean).slice(0, 8)), placeholder: "https://\u2026/photo1.jpg\nhttps://\u2026/photo2.jpg" })))), /* @__PURE__ */ React.createElement(Card, { pad: true, style: { borderColor: "rgba(163,71,58,.22)" } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between", style: { flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h3" }, "Delete invitation"), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { marginTop: 2 } }, "Moves it to the trash. Guests can no longer open it.")), /* @__PURE__ */ React.createElement(Button, { variant: "dangerSoft", size: "sm", icon: I.trash, onClick: trash }, "Delete"))));
}
var builder_default = Builder;
export {
  builder_default as default
};
