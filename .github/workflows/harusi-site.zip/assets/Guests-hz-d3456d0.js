import {
  AnimatePresence,
  Badge,
  Button,
  Card,
  Check,
  Empty,
  Field,
  HZ,
  I,
  Input,
  LinkButton,
  Menu,
  Modal,
  Note,
  Progress,
  React,
  Seg,
  Select,
  Shell,
  Skel,
  Textarea,
  call,
  copyText,
  csvOf,
  cx,
  downloadFile,
  errText,
  initials,
  plural,
  useData,
  useEffect,
  useMemo,
  useNavigate,
  useRef,
  useState,
  useStudioCss,
  useUI
} from "./studio-IQ3KHCEJ-d3456d0.js";

// studio/guests.jsx
import { u as useParams } from "./index-B4Ch-nvB-d3456d0.js";

// studio/bguests.jsx
import { Q as QRCodeSVG } from "./index-B4Ch-nvB-d3456d0.js";
var guestLink = (slug, code) => HZ.base() + "#/i/" + slug + "/" + code;
function firstDateText(form, lang) {
  const d = (form.events || []).map((e) => HZ.ymd(e && e.date)).filter((x) => /^\d{4}-\d{2}-\d{2}$/.test(x)).sort()[0];
  return d ? HZ.dateLong(d, lang) : "";
}
function inviteMessage(form, g, lang) {
  const link = guestLink(form.slug, g.code);
  const names = (form.groomName || "") + " & " + (form.brideName || "");
  const sw = "Salaam " + g.name + ",\n\nUmealikwa kwa heshima kwenye harusi ya " + names + (firstDateText(form, "sw") ? " \u2014 " + firstDateText(form, "sw") : "") + ".\n\nFungua mwaliko wako hapa:\n" + link + "\n\nMsimbo wako wa kuingia: " + g.code + (tname(g.table) ? "\nMeza yako: " + tname(g.table) : "") + "\nKaribu sana! \u{1F49B}";
  const en = "Salaam " + g.name + ",\n\nYou are warmly invited to the wedding of " + names + (firstDateText(form, "en") ? " \u2014 " + firstDateText(form, "en") : "") + ".\n\nOpen your personal invitation here:\n" + link + "\n\nYour entrance code: " + g.code + (tname(g.table) ? "\nYour table: " + tname(g.table) : "") + "\nKaribu sana! \u{1F49B}";
  return lang === "en" ? en : lang === "both" ? sw + "\n\n\u2014 \u2014 \u2014\n\n" + en : sw;
}
var tname = (n) => HZ.tbl.name(n);
var tlow = (n) => HZ.tbl.name(n).toLowerCase();
function tableUse(guests, skipId) {
  const c = {};
  for (const g of guests || []) {
    if (skipId && g.id === skipId) continue;
    const l = tlow(g.table);
    if (l) c[l] = (c[l] || 0) + 1;
  }
  return c;
}
function seatPlan(tables, use, rows, listTables) {
  const tabs = tables.map((t) => ({ ...t })), cnt = { ...use }, assign = {};
  let missed = 0;
  for (const lt of HZ.tbl.clean(listTables)) {
    const t = HZ.tbl.find(tabs, lt.n);
    if (!t) tabs.push({ k: HZ.tbl.key(), n: lt.n, seats: lt.seats });
    else if (lt.seats > t.seats) t.seats = lt.seats;
  }
  for (const r of rows) {
    if (!tname(r.table)) continue;
    let t = HZ.tbl.find(tabs, r.table);
    if (!t) {
      t = { k: HZ.tbl.key(), n: tname(r.table), seats: HZ.tbl.seats((tabs[tabs.length - 1] || {}).seats || 10) };
      tabs.push(t);
    }
    const l = tlow(t.n);
    if ((cnt[l] || 0) < t.seats) {
      assign[r.i] = t.n;
      cnt[l] = (cnt[l] || 0) + 1;
    } else {
      assign[r.i] = "!" + t.n;
      missed++;
    }
  }
  const changed = JSON.stringify(tabs.map((t) => [t.n, t.seats])) !== JSON.stringify(tables.map((t) => [t.n, t.seats]));
  return { tabs, assign, missed, changed };
}
function TableSelect({ tables, use, value, onChange, keep, empty = "No table" }) {
  const own = tlow(keep);
  return /* @__PURE__ */ React.createElement(
    Select,
    {
      value: HZ.tbl.find(tables, value) ? HZ.tbl.find(tables, value).n : "",
      onChange: (e) => onChange(e.target.value),
      options: [{ value: "", label: empty }].concat(tables.map((t) => {
        const c = use[tlow(t.n)] || 0, left = t.seats - c, mine = !!own && own === tlow(t.n);
        return { value: t.n, label: "Table " + t.n + " \u2014 " + (mine ? "their table \xB7 " + (c + 1) + " of " + t.seats + " seats taken" : left > 0 ? left + " of " + t.seats + " seats free" : "full"), disabled: !mine && left <= 0 };
      }))
    }
  );
}
var MSG_KEY = "hz-msg-lang";
function readPref() {
  try {
    return localStorage.getItem(MSG_KEY) || "sw";
  } catch (e) {
    return "sw";
  }
}
function guestStats(guests) {
  const s = { total: guests.length, attending: 0, declined: 0, pending: 0, inside: 0, sent: 0, notArrived: 0 };
  for (const g of guests) {
    if (g.rsvpStatus === "attending") {
      s.attending++;
      if (!g.checkedIn) s.notArrived++;
    } else if (g.rsvpStatus === "declined") s.declined++;
    else s.pending++;
    if (g.checkedIn) s.inside++;
    if (g.sentAt) s.sent++;
  }
  return s;
}
var FILTERS = [
  ["all", "All"],
  ["unsent", "Not sent"],
  ["pending", "Waiting"],
  ["attending", "Attending"],
  ["declined", "Declined"],
  ["inside", "Inside"],
  ["away", "Not arrived"],
  ["check", "Numbers to check"]
];
function filterCount(id, st, guests) {
  return id === "all" ? st.total : id === "unsent" ? st.total - st.sent : id === "pending" ? st.pending : id === "attending" ? st.attending : id === "declined" ? st.declined : id === "inside" ? st.inside : id === "away" ? st.notArrived : guests.filter((g) => !HZ.phone(g.phone).ok).length;
}
function GuestsPanel({ invId, form, q, ui, initialFilter, onTables }) {
  const guests = q.data || [];
  const [term, setTerm] = useState("");
  const [filter, setFilter] = useState(initialFilter || "all");
  const [msgLang, setMsgLangS] = useState(readPref);
  const [modal, setModal] = useState(null);
  const setMsgLang = (v) => {
    setMsgLangS(v);
    try {
      localStorage.setItem(MSG_KEY, v);
    } catch (e) {
    }
  };
  const st = useMemo(() => guestStats(guests), [guests]);
  const tables = useMemo(() => HZ.tbl.clean(form.tables), [form.tables]);
  const use = useMemo(() => tableUse(guests), [guests]);
  const [tbl, setTbl] = useState("");
  const totalSeats = tables.reduce((a, t) => a + t.seats, 0);
  const seated = guests.filter((g) => HZ.tbl.find(tables, g.table)).length;
  const unseated = tables.length ? guests.length - seated : 0;
  const shown = guests.filter((g) => {
    if (tbl === "__none" && HZ.tbl.find(tables, g.table)) return false;
    if (tbl && tbl !== "__none" && tlow(g.table) !== tbl) return false;
    if (filter === "pending" && g.rsvpStatus !== "pending" && g.rsvpStatus) return false;
    if (filter === "attending" && g.rsvpStatus !== "attending") return false;
    if (filter === "declined" && g.rsvpStatus !== "declined") return false;
    if (filter === "unsent" && g.sentAt) return false;
    if (filter === "inside" && !g.checkedIn) return false;
    if (filter === "away" && (g.checkedIn || g.rsvpStatus !== "attending")) return false;
    if (filter === "check" && HZ.phone(g.phone).ok) return false;
    const t = term.trim().toLowerCase();
    if (t && !(String(g.name).toLowerCase().includes(t) || String(g.code).toLowerCase().includes(t) || String(g.phone || "").includes(t.replace(/\D/g, "") || "~") || tname(g.table) && ["table " + tlow(g.table), "meza " + tlow(g.table)].some((x) => x === t))) return false;
    return true;
  });
  const nextUnsent = guests.find((g) => !g.sentAt && HZ.phone(g.phone).ok);
  const patch = (id, o) => q.mutate((d) => (d || []).map((x) => x.id === id ? { ...x, ...o } : x));
  const send = async (g) => {
    const p = HZ.phone(g.phone);
    if (!p.ok) {
      ui.toast("Add a valid WhatsApp number for " + g.name + " first", { tone: "bad" });
      setModal({ t: "edit", g });
      return;
    }
    window.open("https://wa.me/" + p.num + "?text=" + encodeURIComponent(inviteMessage(form, g, msgLang)), "_blank");
    const at = Date.now();
    patch(g.id, { sentAt: at });
    try {
      await call((r) => r.guests.update({ id: g.id, sentAt: at }));
    } catch (e) {
    }
  };
  const checkIn = async (g, undo) => {
    const before = { checkedIn: !!g.checkedIn, checkedInAt: g.checkedInAt || null };
    patch(g.id, { checkedIn: !undo, checkedInAt: undo ? null : Date.now() });
    try {
      await call((r) => r.guests.setCheckIn({ id: g.id, undo }));
      ui.toast(undo ? g.name + " marked not arrived" : g.name + " checked in", undo ? null : { tone: "ok" });
    } catch (e) {
      patch(g.id, before);
      ui.toast(errText(e), { tone: "bad" });
    }
  };
  const remove = async (g) => {
    if (!await ui.confirm({ title: "Remove " + g.name + "?", body: "Their personal link and entrance code will stop working.", confirmText: "Remove guest", tone: "danger" })) return;
    try {
      await call((r) => r.guests.remove({ id: g.id, invitationId: invId }));
      q.mutate((d) => (d || []).filter((x) => x.id !== g.id));
      ui.toast(g.name + " removed");
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
    }
  };
  const exportCsv = () => {
    const rows = [["Name", "WhatsApp", "Code", "Table", "Reply", "Notes", "Invite sent", "Checked in", "Personal link"]].concat(
      guests.map((g) => [
        g.name,
        HZ.phone(g.phone).num || g.phone || "",
        g.code,
        tname(g.table),
        g.rsvpStatus || "pending",
        g.dietary || "",
        g.sentAt ? new Date(g.sentAt).toLocaleString("en-GB") : "",
        g.checkedIn ? new Date(g.checkedInAt || 0).toLocaleString("en-GB") : "",
        guestLink(form.slug, g.code)
      ])
    );
    downloadFile("guests-" + form.slug + ".csv", csvOf(rows), "text/csv");
  };
  const replied = st.attending + st.declined;
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "hzs-grid hzs-g2" }, /* @__PURE__ */ React.createElement(Card, { pad: true }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between", style: { alignItems: "baseline" } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-label", style: { margin: 0 } }, "Replies"), /* @__PURE__ */ React.createElement("span", { className: "hzs-hint", style: { margin: 0 } }, st.sent, " of ", st.total, " invitations sent")), /* @__PURE__ */ React.createElement("div", { style: { fontSize: 30, fontWeight: 300, lineHeight: 1.15, marginTop: 6 } }, replied, /* @__PURE__ */ React.createElement("span", { style: { fontSize: 16, color: "var(--ink3)" } }, " of ", st.total, " replied")), /* @__PURE__ */ React.createElement("div", { style: { margin: "12px 0 10px" } }, /* @__PURE__ */ React.createElement(Progress, { parts: [{ v: st.attending, c: "var(--ok)" }, { v: st.declined, c: "var(--bad)" }, { v: st.pending, c: "rgba(30,26,18,.12)" }] })), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 14, flexWrap: "wrap", fontSize: 13 } }, /* @__PURE__ */ React.createElement("button", { className: "hzg-leg", onClick: () => setFilter("attending") }, /* @__PURE__ */ React.createElement("i", { style: { background: "var(--ok)" } }), st.attending, " attending"), /* @__PURE__ */ React.createElement("button", { className: "hzg-leg", onClick: () => setFilter("declined") }, /* @__PURE__ */ React.createElement("i", { style: { background: "var(--bad)" } }), st.declined, " declined"), /* @__PURE__ */ React.createElement("button", { className: "hzg-leg", onClick: () => setFilter("pending") }, /* @__PURE__ */ React.createElement("i", { style: { background: "rgba(30,26,18,.2)" } }), st.pending, " waiting"))), /* @__PURE__ */ React.createElement(Card, { pad: true }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between", style: { alignItems: "baseline" } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-label", style: { margin: 0 } }, "At the door"), /* @__PURE__ */ React.createElement("a", { href: "#/scan/" + invId, className: "hzs-hint", style: { margin: 0, color: "var(--gold)" } }, "Open check-in \u2192")), /* @__PURE__ */ React.createElement("div", { style: { fontSize: 30, fontWeight: 300, lineHeight: 1.15, marginTop: 6 } }, st.inside, /* @__PURE__ */ React.createElement("span", { style: { fontSize: 16, color: "var(--ink3)" } }, " of ", st.total, " inside")), /* @__PURE__ */ React.createElement("div", { style: { margin: "12px 0 10px" } }, /* @__PURE__ */ React.createElement(Progress, { parts: [{ v: st.inside, c: "var(--gold)" }, { v: Math.max(0, st.total - st.inside), c: "rgba(30,26,18,.12)" }] })), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 14, flexWrap: "wrap", fontSize: 13 } }, /* @__PURE__ */ React.createElement("button", { className: "hzg-leg", onClick: () => setFilter("inside") }, /* @__PURE__ */ React.createElement("i", { style: { background: "var(--gold)" } }), st.inside, " inside"), /* @__PURE__ */ React.createElement("button", { className: "hzg-leg", onClick: () => setFilter("away") }, /* @__PURE__ */ React.createElement("i", { style: { background: "rgba(30,26,18,.2)" } }), st.notArrived, " attending, not arrived")))), /* @__PURE__ */ React.createElement(Card, { pad: true, className: "hzg-tables" }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between", style: { alignItems: "center", gap: 10, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-label", style: { margin: 0 } }, "Tables"), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: tables.length ? "secondary" : "gold", icon: I.table, onClick: () => setModal({ t: "tables" }) }, tables.length ? "Manage tables" : "Set up tables")), tables.length ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { style: { fontSize: 30, fontWeight: 300, lineHeight: 1.15, marginTop: 6 } }, seated, /* @__PURE__ */ React.createElement("span", { style: { fontSize: 16, color: "var(--ink3)" } }, " of ", totalSeats, " seats given \xB7 ", plural(tables.length, "table", "tables"))), /* @__PURE__ */ React.createElement("div", { className: "hzg-tchips" }, tables.map((t) => {
    const c = use[tlow(t.n)] || 0, l = tlow(t.n);
    return /* @__PURE__ */ React.createElement("button", { key: t.k, className: cx("hzg-tchip", c > t.seats && "over", c === t.seats && "full", tbl === l && "on"), onClick: () => setTbl(tbl === l ? "" : l), title: "Show the guests at table " + t.n }, /* @__PURE__ */ React.createElement("b", null, t.n), /* @__PURE__ */ React.createElement("span", null, c, "/", t.seats));
  })), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 14, flexWrap: "wrap", fontSize: 13, marginTop: 10 } }, unseated ? /* @__PURE__ */ React.createElement("button", { className: "hzg-leg", onClick: () => setTbl(tbl === "__none" ? "" : "__none") }, /* @__PURE__ */ React.createElement("i", { style: { background: "var(--warn, #B7791F)" } }), plural(unseated, "guest", "guests"), " without a table") : /* @__PURE__ */ React.createElement("span", { className: "hzg-leg", style: { cursor: "default" } }, /* @__PURE__ */ React.createElement("i", { style: { background: "var(--ok)" } }), "Every guest has a table"), tables.some((t) => (use[tlow(t.n)] || 0) > t.seats) ? /* @__PURE__ */ React.createElement("span", { style: { color: "var(--bad)" } }, "Some tables have more guests than seats \u2014 move guests or add seats.") : null)) : /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { margin: "8px 0 0" } }, "Write your tables and how many seats each has, then give every guest a table. Each guest sees their table on their invitation, and the check-in team sees it when they scan the code.")), /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "hzs-sec", style: { display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" } }, /* @__PURE__ */ React.createElement("div", { style: { position: "relative", flex: "1 1 220px" } }, /* @__PURE__ */ React.createElement(I.search, { size: 16, style: { position: "absolute", left: 13, top: 14, color: "var(--ink3)" } }), /* @__PURE__ */ React.createElement(Input, { placeholder: "Search name, code or number", value: term, onChange: (e) => setTerm(e.target.value), style: { paddingLeft: 38 } })), /* @__PURE__ */ React.createElement(Button, { variant: "primary", icon: I.userPlus, onClick: () => setModal({ t: "add" }) }, "Add guest"), /* @__PURE__ */ React.createElement(Menu, { title: "More", items: [
    { label: "Add one guest", icon: I.userPlus, onClick: () => setModal({ t: "add" }) },
    { label: "Import a client's list", icon: I.list, onClick: () => setModal({ t: "import" }) },
    { label: "Paste a list", icon: I.copy, onClick: () => setModal({ t: "paste" }) },
    guests.length ? { label: "Download CSV", icon: I.download, onClick: exportCsv } : null
  ] })), /* @__PURE__ */ React.createElement("div", { className: "hzs-sec hzg-chips", style: { paddingTop: 0, paddingBottom: 14 } }, FILTERS.map(([id, l]) => {
    const n = filterCount(id, st, guests);
    if (id === "check" && !n) return null;
    return /* @__PURE__ */ React.createElement("button", { key: id, className: cx("hzs-chip", filter === id && "on"), onClick: () => setFilter(id) }, l, /* @__PURE__ */ React.createElement("span", { style: { opacity: 0.65 } }, n));
  }), tbl ? /* @__PURE__ */ React.createElement("button", { className: "hzs-chip on hzg-tfilter", onClick: () => setTbl("") }, tbl === "__none" ? "No table" : "Table " + tname((HZ.tbl.find(tables, tbl) || { n: tbl }).n), /* @__PURE__ */ React.createElement(I.x, { size: 12 })) : null), /* @__PURE__ */ React.createElement("div", { className: "hzs-sec", style: { display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center", background: "rgba(246,239,224,.45)", paddingTop: 12, paddingBottom: 12 } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-label", style: { margin: 0 } }, "WhatsApp message in"), /* @__PURE__ */ React.createElement(Seg, { value: msgLang, onChange: setMsgLang, items: [{ id: "sw", label: "Kiswahili" }, { id: "en", label: "English" }, { id: "both", label: "Both" }] }), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.eye, onClick: () => setModal({ t: "msg" }) }, "See message"), nextUnsent ? /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "gold", icon: I.chat, style: { marginLeft: "auto" }, onClick: () => send(nextUnsent) }, "Send next \xB7 ", nextUnsent.name.split(" ")[0]) : guests.length ? /* @__PURE__ */ React.createElement(Badge, { tone: "ok", style: { marginLeft: "auto" } }, /* @__PURE__ */ React.createElement(I.check, { size: 12 }), "All sent") : null), q.loading ? /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { display: "grid", gap: 10 } }, /* @__PURE__ */ React.createElement(Skel, { h: 44 }), /* @__PURE__ */ React.createElement(Skel, { h: 44 }), /* @__PURE__ */ React.createElement(Skel, { h: 44 })) : !guests.length ? /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { textAlign: "center" } }, /* @__PURE__ */ React.createElement("p", { className: "hzs-muted", style: { margin: "0 0 14px" } }, "No guests yet. Add them one by one, paste a list, or import the list your client filled in."), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, justifyContent: "center", flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Button, { variant: "primary", icon: I.userPlus, onClick: () => setModal({ t: "add" }) }, "Add guest"), /* @__PURE__ */ React.createElement(Button, { variant: "secondary", icon: I.list, onClick: () => setModal({ t: "import" }) }, "Import client list"))) : !shown.length ? /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { textAlign: "center", color: "var(--ink3)" } }, "No guest matches.") : /* @__PURE__ */ React.createElement("div", { className: "hzs-list" }, shown.map((g) => /* @__PURE__ */ React.createElement(GuestRow, { key: g.id, g, form, tables, use, onSend: () => send(g), onCheck: (undo) => checkIn(g, undo), onEdit: () => setModal({ t: "edit", g }), onQr: () => setModal({ t: "qr", g }), onRemove: () => remove(g), ui })))), /* @__PURE__ */ React.createElement("style", null, GUESTS_CSS), /* @__PURE__ */ React.createElement(AnimatePresence, null, modal && modal.t === "add" ? /* @__PURE__ */ React.createElement(AddGuest, { key: "a", invId, guests, tables, q, ui, onClose: () => setModal(null), onMore: (t) => setModal({ t }) }) : null, modal && modal.t === "edit" ? /* @__PURE__ */ React.createElement(EditGuest, { key: "e", g: modal.g, tables, guests, onClose: () => setModal(null), onSaved: (o) => {
    patch(modal.g.id, o);
    setModal(null);
    ui.toast("Guest updated");
  }, ui }) : null, modal && modal.t === "qr" ? /* @__PURE__ */ React.createElement(QrModal, { key: "q", g: modal.g, form, onClose: () => setModal(null) }) : null, modal && modal.t === "msg" ? /* @__PURE__ */ React.createElement(MsgModal, { key: "m", form, lang: msgLang, g: guests[0] || { name: "Fatma", code: "AB12" }, onClose: () => setModal(null) }) : null, modal && modal.t === "import" ? /* @__PURE__ */ React.createElement(ImportModal, { key: "i", invId, guests, tables, onTables, onClose: () => setModal(null), onDone: (n) => {
    setModal(null);
    q.reload();
    ui.toast(plural(n, "guest", "guests") + " added");
  }, ui }) : null, modal && modal.t === "paste" ? /* @__PURE__ */ React.createElement(PasteModal, { key: "p", invId, guests, tables, onTables, onClose: () => setModal(null), onDone: (n) => {
    setModal(null);
    q.reload();
    ui.toast(plural(n, "guest", "guests") + " added");
  }, ui }) : null, modal && modal.t === "tables" ? /* @__PURE__ */ React.createElement(TablesModal, { key: "t", tables, guests, q, onTables, ui, onClose: () => setModal(null) }) : null));
}
var GUESTS_CSS = `
.hzg-leg{display:inline-flex;align-items:center;gap:7px;border:0;background:none;padding:0;cursor:pointer;color:var(--ink2);font:inherit}
.hzg-leg:hover{color:var(--ink)}
.hzg-leg i{width:9px;height:9px;border-radius:99px;display:inline-block}
.hzg-chips{display:flex;gap:6px;overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch}
.hzg-chips::-webkit-scrollbar{display:none}
.hzg-chips .hzs-chip{flex:none;gap:7px}
.hzg-tchips{display:flex;flex-wrap:wrap;gap:6px;margin-top:12px}
.hzg-tchip{display:inline-flex;align-items:center;gap:7px;height:32px;padding:0 11px;border-radius:999px;border:1px solid var(--line2);background:var(--card);cursor:pointer;font:inherit;font-size:13px;color:var(--ink2)}
.hzg-tchip b{font-weight:600;color:var(--ink)}
.hzg-tchip span{color:var(--ink3);font-size:12px}
.hzg-tchip.full{border-color:rgba(47,107,71,.45);background:#F1F7EF}
.hzg-tchip.over{border-color:var(--bad);background:#FBEFEC}.hzg-tchip.over span{color:var(--bad)}
.hzg-tchip.on{background:var(--ink);border-color:var(--ink)}.hzg-tchip.on b,.hzg-tchip.on span{color:#FBF8F2}
.hzg-trow{display:grid;grid-template-columns:minmax(0,1fr) 92px 64px 34px;gap:8px;align-items:center;padding:7px 0;border-top:1px solid var(--line)}
.hzg-trow .hzs-input{height:40px}
.hzg-row-act{display:flex;gap:6px;align-items:center;margin-left:auto}
@media (max-width:640px){.hzg-row-act{width:100%;justify-content:flex-end}}
`;
function AddGuest({ invId, guests, tables, q, ui, onClose, onMore }) {
  const [name, setName] = useState("");
  const [table, setTable] = useState("");
  const use = useMemo(() => tableUse(guests), [guests]);
  const tFull = (() => {
    const t = HZ.tbl.find(tables, table);
    return t && (use[tlow(t.n)] || 0) >= t.seats ? t : null;
  })();
  const [phone, setPhone] = useState("");
  const [busy, setBusy] = useState(false);
  const [added, setAdded] = useState([]);
  const nameRef = useRef(null);
  const p = HZ.phone(phone);
  const dupe = p.ok && guests.find((g) => HZ.phone(g.phone).num === p.num);
  const add = async () => {
    if (!name.trim() || busy) return;
    if (tFull) {
      ui.toast("Table " + tFull.n + " is full \u2014 choose another table or add seats", { tone: "bad" });
      return;
    }
    setBusy(true);
    try {
      const g = await call((r) => r.guests.add({ invitationId: invId, name: name.trim(), phone: p.ok ? p.num : phone.trim(), maxCompanions: 0, table: (HZ.tbl.find(tables, table) || {}).n || "" }));
      q.mutate((d) => [...d || [], g]);
      setAdded((a) => [g, ...a].slice(0, 4));
      setName("");
      setPhone("");
      {
        const t = HZ.tbl.find(tables, g.table);
        if (t && (use[tlow(t.n)] || 0) + 1 >= t.seats) {
          setTable("");
          ui.toast("Table " + t.n + " is now full");
        }
      }
      nameRef.current && nameRef.current.focus();
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
    }
    setBusy(false);
  };
  return /* @__PURE__ */ React.createElement(Modal, { onClose, label: "Add a guest", width: 520 }, /* @__PURE__ */ React.createElement("form", { className: "hzs-pad", style: { display: "grid", gap: 14 }, onSubmit: (e) => {
    e.preventDefault();
    add();
  } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between" }, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h2", style: { fontSize: 20 } }, "Add a guest"), /* @__PURE__ */ React.createElement(Button, { type: "button", variant: "ghost", size: "sm", icon: I.x, onClick: onClose, "aria-label": "Close" })), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { margin: 0 } }, "Each guest gets a personal invitation with their name and a private entrance code."), /* @__PURE__ */ React.createElement(Field, { label: "Full name" }, /* @__PURE__ */ React.createElement(Input, { ref: nameRef, value: name, onChange: (e) => setName(e.target.value), placeholder: "Fatma Juma", maxLength: 60, autoFocus: true })), /* @__PURE__ */ React.createElement(Field, { label: "WhatsApp number", error: phone && !p.ok ? "Check this number" : dupe ? "Already added: " + dupe.name : null }, /* @__PURE__ */ React.createElement(Input, { value: phone, onChange: (e) => setPhone(e.target.value), placeholder: "0777 123 456", inputMode: "tel", className: phone && !p.ok ? "bad" : "" })), tables.length ? /* @__PURE__ */ React.createElement(Field, { label: "Table", error: tFull ? "Table " + tFull.n + " is full" : null, hint: table ? "The next guests you add go to this table too, until it's full." : null }, /* @__PURE__ */ React.createElement(TableSelect, { tables, use, value: table, onChange: setTable })) : null, added.length ? /* @__PURE__ */ React.createElement("div", { className: "hzs-hint", style: { margin: 0 } }, "Added: ", added.map((g) => g.name + " (" + g.code + (tname(g.table) ? " \xB7 table " + tname(g.table) : "") + ")").join(" \xB7 ")) : null, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { justifyContent: "space-between", gap: 8, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Button, { type: "button", variant: "ghost", size: "sm", icon: I.list, onClick: () => onMore("paste") }, "Paste many at once"), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8 } }, /* @__PURE__ */ React.createElement(Button, { type: "button", variant: "secondary", onClick: onClose }, added.length ? "Done" : "Cancel"), /* @__PURE__ */ React.createElement(Button, { variant: "primary", icon: I.plus, busy, disabled: !name.trim(), type: "submit" }, "Add")))));
}
function GuestRow({ g, form, tables, use, onSend, onCheck, onEdit, onQr, onRemove, ui }) {
  const p = HZ.phone(g.phone);
  const rs = g.rsvpStatus === "attending" ? /* @__PURE__ */ React.createElement(Badge, { tone: "ok", dot: true }, "Attending") : g.rsvpStatus === "declined" ? /* @__PURE__ */ React.createElement(Badge, { tone: "bad", dot: true }, "Declined") : /* @__PURE__ */ React.createElement(Badge, { dot: true }, "Waiting");
  return /* @__PURE__ */ React.createElement("div", { className: "hzs-item", style: { alignItems: "center", flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-avatar", style: { width: 38, height: 38, fontSize: 14, background: g.checkedIn ? "var(--goldbg)" : void 0 } }, g.checkedIn ? /* @__PURE__ */ React.createElement(I.check, { size: 17, style: { color: "var(--gold)" } }) : initials(g.name)), /* @__PURE__ */ React.createElement("div", { style: { flex: "1 1 200px", minWidth: 0 } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("b", { style: { fontWeight: 500, fontSize: 15 } }, g.name), rs, g.checkedIn ? /* @__PURE__ */ React.createElement(Badge, { tone: "gold" }, /* @__PURE__ */ React.createElement(I.scan, { size: 11 }), "Inside", g.checkedInAt ? " \xB7 " + new Date(g.checkedInAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "") : null), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 10, fontSize: 13, color: "var(--ink3)", marginTop: 3, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("span", { style: { color: p.ok ? "var(--ink2)" : "var(--bad)" } }, p.ok ? HZ.fmtPhone(p.num) : g.phone ? g.phone + " \xB7 check number" : "No number"), /* @__PURE__ */ React.createElement("span", { className: "hzs-kbd" }, g.code), tname(g.table) ? /* @__PURE__ */ React.createElement("span", { className: "hzg-tbadge", style: { display: "inline-flex", alignItems: "center", gap: 5, color: (() => {
    const t = HZ.tbl.find(tables, g.table);
    return t && (use[tlow(t.n)] || 0) > t.seats ? "var(--bad)" : "var(--gold)";
  })(), fontWeight: 500 } }, /* @__PURE__ */ React.createElement(I.table, { size: 12 }), "Table ", tname(g.table)) : tables && tables.length ? /* @__PURE__ */ React.createElement("button", { className: "hzg-seat", onClick: onEdit, style: { border: 0, background: "none", padding: 0, font: "inherit", color: "var(--ink3)", textDecoration: "underline dotted", cursor: "pointer" } }, "no table") : null, g.sentAt ? /* @__PURE__ */ React.createElement("span", { style: { color: "var(--ok)" } }, "\u2713 sent") : null), g.dietary ? /* @__PURE__ */ React.createElement("div", { style: { fontSize: 12.5, color: "var(--ink2)", marginTop: 4, fontStyle: "italic" } }, "\u201C", g.dietary, "\u201D") : null), /* @__PURE__ */ React.createElement("div", { className: "hzg-row-act" }, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: g.sentAt ? "secondary" : "okSoft", icon: I.chat, onClick: onSend }, g.sentAt ? "Resend" : "Send"), g.checkedIn ? /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.undo, onClick: () => onCheck(true), title: "Mark as not arrived" }, "Undo") : /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "secondary", icon: I.scan, onClick: () => onCheck(false), title: "Mark as arrived" }, "Check in"), /* @__PURE__ */ React.createElement(Menu, { title: g.name, items: [
    { label: "Edit guest", icon: I.edit, onClick: onEdit },
    tables && tables.length ? { label: tname(g.table) ? "Change table" : "Choose a table", icon: I.table, onClick: onEdit } : null,
    { label: "Copy personal link", icon: I.link, onClick: () => copyText(guestLink(form.slug, g.code)).then(() => ui.toast("Link for " + g.name + " copied")) },
    { label: "Show QR code", icon: I.qr, onClick: onQr },
    { label: "Open their invitation", icon: I.open, onClick: () => window.open(guestLink(form.slug, g.code), "_blank") },
    "-",
    { label: "Remove guest", icon: I.trash, danger: true, onClick: onRemove }
  ] })));
}
function EditGuest({ g, tables, guests, onClose, onSaved, ui }) {
  const [name, setName] = useState(g.name || "");
  const [table, setTable] = useState(tname(g.table));
  const use = useMemo(() => tableUse(guests, g.id), [guests, g.id]);
  const tNew = HZ.tbl.find(tables, table), moved = tlow(table) !== tlow(g.table);
  const tFull = tNew && moved && (use[tlow(tNew.n)] || 0) >= tNew.seats ? tNew : null;
  const [phone, setPhone] = useState(g.phone || "");
  const [busy, setBusy] = useState(false);
  const p = HZ.phone(phone);
  const save = async () => {
    if (!name.trim() || tFull) return;
    setBusy(true);
    const o = { name: name.trim(), phone: p.ok ? p.num : phone.trim(), maxCompanions: 0 };
    if (tables.length) {
      const nt = tNew ? tNew.n : "";
      if (nt !== tname(g.table)) o.table = nt;
    }
    try {
      await call((r) => r.guests.update({ id: g.id, ...o }));
      onSaved(o);
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
      setBusy(false);
    }
  };
  return /* @__PURE__ */ React.createElement(Modal, { onClose, label: "Edit guest" }, /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { display: "grid", gap: 16 } }, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h2", style: { fontSize: 20 } }, "Edit guest"), /* @__PURE__ */ React.createElement(Field, { label: "Full name" }, /* @__PURE__ */ React.createElement(Input, { value: name, onChange: (e) => setName(e.target.value), autoFocus: true, maxLength: 60 })), /* @__PURE__ */ React.createElement(Field, { label: "WhatsApp number", error: phone && !p.ok ? "This doesn't look like a WhatsApp number." : null, hint: p.ok ? HZ.fmtPhone(p.num) : null }, /* @__PURE__ */ React.createElement(Input, { value: phone, onChange: (e) => setPhone(e.target.value), inputMode: "tel", className: phone && !p.ok ? "bad" : "" })), tables.length ? /* @__PURE__ */ React.createElement(Field, { label: "Table", error: tFull ? "Table " + tFull.n + " is full \u2014 choose another table or add seats" : null }, /* @__PURE__ */ React.createElement(TableSelect, { tables, use, value: table, onChange: setTable, keep: g.table })) : tname(g.table) ? /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { margin: 0 } }, "Table ", tname(g.table)) : null, /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { margin: 0 } }, "Their code ", /* @__PURE__ */ React.createElement("span", { className: "hzs-kbd" }, g.code), " and link stay the same.")), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { justifyContent: "flex-end", gap: 10, padding: "0 22px 22px" } }, /* @__PURE__ */ React.createElement(Button, { variant: "ghost", onClick: onClose }, "Cancel"), /* @__PURE__ */ React.createElement(Button, { variant: "primary", onClick: save, busy, disabled: !name.trim() || !!tFull }, "Save")));
}
function QrModal({ g, form, onClose }) {
  return /* @__PURE__ */ React.createElement(Modal, { onClose, label: "QR code", width: 380 }, /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { textAlign: "center" } }, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h2", style: { fontSize: 20 } }, g.name), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint" }, "Scanning opens their personal invitation. Entrance code ", /* @__PURE__ */ React.createElement("span", { className: "hzs-kbd" }, g.code), tname(g.table) ? " \xB7 Table " + tname(g.table) : ""), /* @__PURE__ */ React.createElement("div", { style: { display: "inline-block", padding: 14, background: "#fff", borderRadius: 16, border: "1px solid var(--line)", marginTop: 12 } }, /* @__PURE__ */ React.createElement(QRCodeSVG, { value: guestLink(form.slug, g.code), size: 200, fgColor: "#1E1A12", level: "M" })), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 16 } }, /* @__PURE__ */ React.createElement(Button, { variant: "secondary", onClick: onClose }, "Close"))));
}
function MsgModal({ form, lang, g, onClose }) {
  return /* @__PURE__ */ React.createElement(Modal, { onClose, label: "Message preview", width: 460 }, /* @__PURE__ */ React.createElement("div", { className: "hzs-pad" }, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h2", style: { fontSize: 20 } }, "WhatsApp message"), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint" }, "Each guest gets this with their own name, link and code."), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 14, padding: 14, borderRadius: "14px 14px 14px 4px", background: "#E7F6DC", color: "#13261A", fontSize: 14, whiteSpace: "pre-wrap", wordBreak: "break-word", maxHeight: 360, overflowY: "auto" } }, inviteMessage(form, g, lang)), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 16, textAlign: "right" } }, /* @__PURE__ */ React.createElement(Button, { variant: "secondary", onClick: onClose }, "Close"))));
}
function useExisting(guests) {
  return useMemo(() => {
    const ph = /* @__PURE__ */ new Set(), nm = /* @__PURE__ */ new Set();
    for (const g of guests || []) {
      const n = HZ.phone(g.phone).num;
      if (n) ph.add(n);
      nm.add(String(g.name || "").trim().toLowerCase());
    }
    return { ph, nm };
  }, [guests]);
}
function rowsFrom(entries, have) {
  const seen = /* @__PURE__ */ new Set();
  return (entries || []).map((e, i) => {
    const p = HZ.phone(e.phone), name = String(e.name || "").trim();
    const key = p.num || name.toLowerCase();
    const dupe = p.num && have.ph.has(p.num) || !p.num && name && have.nm.has(name.toLowerCase());
    const rep = key && seen.has(key);
    if (key) seen.add(key);
    return { i, name, phone: p.ok ? p.num : String(e.phone || "").trim(), ok: p.ok, dupe: !!(dupe || rep), noName: !name, table: tname(e.table) };
  });
}
function RowsPicker({ rows, off, setOff, assign }) {
  return /* @__PURE__ */ React.createElement("div", { style: { border: "1px solid var(--line)", borderRadius: 14, maxHeight: 300, overflowY: "auto", background: "#fff" }, className: "hzs-list" }, rows.map((r) => {
    const dis = r.dupe || r.noName;
    const on = !dis && !off[r.i];
    return /* @__PURE__ */ React.createElement("div", { key: r.i, className: "hzs-item", style: { padding: "9px 12px", opacity: dis ? 0.5 : 1, cursor: dis ? "default" : "pointer" }, onClick: () => !dis && setOff({ ...off, [r.i]: !off[r.i] }) }, dis ? /* @__PURE__ */ React.createElement("span", { style: { width: 20 } }) : /* @__PURE__ */ React.createElement(Check, { on, onChange: () => setOff({ ...off, [r.i]: !off[r.i] }), label: r.name }), /* @__PURE__ */ React.createElement("span", { style: { flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, r.name || /* @__PURE__ */ React.createElement("i", null, "no name")), !dis && assign && assign[r.i] ? /* @__PURE__ */ React.createElement("span", { className: "hzg-rtable", style: { fontSize: 12, whiteSpace: "nowrap", color: assign[r.i][0] === "!" ? "var(--bad)" : "var(--gold)", textDecoration: assign[r.i][0] === "!" ? "line-through" : "none" }, title: assign[r.i][0] === "!" ? "This table is full \u2014 the guest is added without a table" : "" }, "T", assign[r.i].replace(/^!/, "")) : null, /* @__PURE__ */ React.createElement("span", { style: { fontSize: 12.5, color: r.dupe ? "var(--ink3)" : r.ok ? "var(--ink2)" : "var(--bad)", whiteSpace: "nowrap" } }, r.dupe ? "already added" : r.ok ? HZ.fmtPhone(r.phone) : (r.phone || "no number") + " \xB7 check"));
  }));
}
function ImportModal({ invId, guests, tables, onTables, onClose, onDone, ui }) {
  const [lists, setLists] = useState(null);
  const [err, setErr] = useState(null);
  const [sel, setSel] = useState("");
  const [off, setOff] = useState({});
  const [prog, setProg] = useState(null);
  const have = useExisting(guests);
  useEffect(() => {
    HZ.repo().then((r) => r.guestLists.mine()).then((l) => {
      setLists(l);
      const s = l.find((x) => !x.importedAt && (x.entries || []).length);
      if (s) setSel(s.id);
    }).catch(setErr);
  }, []);
  const L = (lists || []).find((l) => l.id === sel);
  const rows = useMemo(() => L ? rowsFrom(L.entries, have) : [], [L, have]);
  const chosen = rows.filter((r) => !r.dupe && !r.noName && !off[r.i]);
  const bad = chosen.filter((r) => !r.ok).length;
  const use = useMemo(() => tableUse(guests), [guests]);
  const plan = seatPlan(tables, use, chosen, L ? L.tables : []);
  const seatOf = (x) => plan.assign[x.i] && plan.assign[x.i][0] !== "!" ? plan.assign[x.i] : "";
  const go = async () => {
    setProg(0);
    try {
      if (plan.changed && onTables) await onTables(plan.tabs);
      await call((r) => r.guests.addMany({ invitationId: invId, items: chosen.map((x) => ({ name: x.name, phone: x.phone, maxCompanions: 0, table: seatOf(x) })), onProgress: setProg }));
      try {
        await call((r) => r.guestLists.markImported({ id: L.id, invitationId: invId, count: chosen.length }));
      } catch (e) {
      }
      onDone(chosen.length);
    } catch (e) {
      setProg(null);
      ui.toast("Import stopped: " + errText(e), { tone: "bad" });
    }
  };
  return /* @__PURE__ */ React.createElement(Modal, { onClose: prog == null ? onClose : null, label: "Import a client's list", width: 560 }, /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { display: "grid", gap: 14 } }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h2", style: { fontSize: 20 } }, "Import a client's list"), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint" }, "Guests already on this invitation, and repeated names, are skipped automatically.")), err ? /* @__PURE__ */ React.createElement(Note, { tone: "bad", icon: I.alert }, errText(err)) : null, lists === null && !err ? /* @__PURE__ */ React.createElement(Skel, { h: 44 }) : null, lists && !lists.length ? /* @__PURE__ */ React.createElement(Note, { icon: I.info }, "No client lists yet. Create one on the ", /* @__PURE__ */ React.createElement("a", { href: "#/lists", style: { textDecoration: "underline" } }, "Guest lists"), " page and send it to your client.") : null, lists && lists.length ? /* @__PURE__ */ React.createElement(Field, { label: "Choose a list" }, /* @__PURE__ */ React.createElement(Select, { value: sel, onChange: (e) => {
    setSel(e.target.value);
    setOff({});
  }, options: [{ value: "", label: "\u2014" }].concat(lists.map((l) => ({ value: l.id, label: (l.label || l.weddingOf || "Untitled") + (l.clientName ? " \xB7 " + l.clientName : "") + " \xB7 " + (l.entries || []).length + " guests" + (l.importedAt ? " \xB7 imported" : l.status === "submitted" ? " \xB7 submitted" : "") }))) })) : null, L ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Badge, null, rows.length, " names"), /* @__PURE__ */ React.createElement(Badge, { tone: "ok" }, rows.filter((r) => !r.dupe && !r.noName).length, " new"), rows.filter((r) => r.dupe).length ? /* @__PURE__ */ React.createElement(Badge, null, rows.filter((r) => r.dupe).length, " already added / repeated") : null, bad ? /* @__PURE__ */ React.createElement(Badge, { tone: "bad" }, bad, " numbers to check") : null, Object.keys(plan.assign).length ? /* @__PURE__ */ React.createElement(Badge, { tone: "gold" }, /* @__PURE__ */ React.createElement(I.table, { size: 11 }), chosen.filter(seatOf).length, " with a table") : null, plan.missed ? /* @__PURE__ */ React.createElement(Badge, { tone: "bad" }, plan.missed, " table full \u2014 added without a table") : null), plan.changed ? /* @__PURE__ */ React.createElement(Note, { icon: I.table }, "The client's tables are added to this wedding: ", plan.tabs.map((t) => t.n + " (" + t.seats + ")").join(", "), ".") : null, rows.length ? /* @__PURE__ */ React.createElement(RowsPicker, { rows, off, setOff, assign: plan.assign }) : /* @__PURE__ */ React.createElement("p", { className: "hzs-muted", style: { margin: 0 } }, "This list is empty."), bad ? /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { margin: 0 } }, "Guests with a number to check are added too \u2014 fix their number later with \u201CEdit guest\u201D, or untick them now.") : null) : null), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { justifyContent: "flex-end", gap: 10, padding: "0 22px 22px" } }, /* @__PURE__ */ React.createElement(Button, { variant: "ghost", onClick: onClose, disabled: prog != null }, "Cancel"), /* @__PURE__ */ React.createElement(Button, { variant: "primary", onClick: go, disabled: !chosen.length || prog != null }, prog != null ? "Importing " + prog + " / " + chosen.length + "\u2026" : "Import " + plural(chosen.length, "guest", "guests"))));
}
function PasteModal({ invId, guests, tables, onTables, onClose, onDone, ui }) {
  const [text, setText] = useState("");
  const [off, setOff] = useState({});
  const [prog, setProg] = useState(null);
  const have = useExisting(guests);
  const rows = useMemo(() => rowsFrom(HZ.parseBulk(text), have), [text, have]);
  const chosen = rows.filter((r) => !r.dupe && !r.noName && !off[r.i]);
  const use = useMemo(() => tableUse(guests), [guests]);
  const plan = seatPlan(tables, use, chosen, []);
  const seatOf = (x) => plan.assign[x.i] && plan.assign[x.i][0] !== "!" ? plan.assign[x.i] : "";
  const go = async () => {
    setProg(0);
    try {
      if (plan.changed && onTables) await onTables(plan.tabs);
      await call((r) => r.guests.addMany({ invitationId: invId, items: chosen.map((x) => ({ name: x.name, phone: x.phone, maxCompanions: 0, table: seatOf(x) })), onProgress: setProg }));
      onDone(chosen.length);
    } catch (e) {
      setProg(null);
      ui.toast("Stopped: " + errText(e), { tone: "bad" });
    }
  };
  return /* @__PURE__ */ React.createElement(Modal, { onClose: prog == null ? onClose : null, label: "Paste a list", width: 560 }, /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { display: "grid", gap: 14 } }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h2", style: { fontSize: 20 } }, "Paste a list"), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint" }, "One guest per line \u2014 name and number, e.g. \u201CFatma Juma 0777 123 456\u201D. Add \u201Ctable 3\u201D (or \u201Cmeza 3\u201D) to seat them. Works with lists copied from WhatsApp, Excel or Notes.")), /* @__PURE__ */ React.createElement(Textarea, { rows: 6, value: text, onChange: (e) => {
    setText(e.target.value);
    setOff({});
  }, placeholder: "Fatma Juma 0777 123 456\nAsha Omar 0654 987 321", autoFocus: true }), plan.missed ? /* @__PURE__ */ React.createElement(Note, { tone: "bad", icon: I.alert }, plural(plan.missed, "guest", "guests"), " can't get their table \u2014 it's full. They're added without a table.") : null, rows.length ? /* @__PURE__ */ React.createElement(RowsPicker, { rows, off, setOff, assign: plan.assign }) : null), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { justifyContent: "flex-end", gap: 10, padding: "0 22px 22px" } }, /* @__PURE__ */ React.createElement(Button, { variant: "ghost", onClick: onClose, disabled: prog != null }, "Cancel"), /* @__PURE__ */ React.createElement(Button, { variant: "primary", onClick: go, disabled: !chosen.length || prog != null }, prog != null ? "Adding " + prog + " / " + chosen.length + "\u2026" : "Add " + plural(chosen.length, "guest", "guests"))));
}
function TablesModal({ tables, guests, q, onTables, ui, onClose }) {
  const [rows, setRows] = useState(() => tables.map((t) => ({ ...t, orig: t.n })));
  const [qn, setQn] = useState("10"), [qs, setQs] = useState("8");
  const [busy, setBusy] = useState(false);
  const use = useMemo(() => tableUse(guests), [guests]);
  const cOf = (r) => r.orig ? use[tlow(r.orig)] || 0 : 0;
  const names = {};
  rows.forEach((r) => {
    const l = tlow(r.n);
    if (l) names[l] = (names[l] || 0) + 1;
  });
  const errOf = (r) => !tname(r.n) ? "Write a name" : names[tlow(r.n)] > 1 ? "Name used twice" : !(parseInt(r.seats, 10) >= 1) ? "Seats?" : HZ.tbl.seats(r.seats) < cOf(r) ? "Needs " + cOf(r) + "+ seats" : "";
  const bad = rows.some(errOf);
  const set = (k, patch) => setRows((rs) => rs.map((r) => r.k === k ? { ...r, ...patch } : r));
  const make = () => {
    const n = Math.max(1, Math.min(150, parseInt(qn, 10) || 0)), seats = HZ.tbl.seats(qs);
    setRows((rs) => {
      const out = rs.slice();
      for (let i = 0; i < n && out.length < 300; i++) out.push({ k: HZ.tbl.key(), n: HZ.tbl.next(out), seats });
      return out;
    });
  };
  const add = () => setRows((rs) => [...rs, { k: HZ.tbl.key(), n: HZ.tbl.next(rs), seats: HZ.tbl.seats((rs[rs.length - 1] || {}).seats || qs) }]);
  const total = rows.reduce((a, r) => a + (parseInt(r.seats, 10) || 0), 0);
  const save = async () => {
    if (bad) return;
    const kept = (t) => rows.some((r) => r.orig && tlow(r.orig) === tlow(t.n));
    const removed = tables.filter((t) => !kept(t));
    const lost = guests.filter((g) => removed.some((t) => tlow(t.n) === tlow(g.table)));
    if (lost.length && !await ui.confirm({ title: "Remove " + plural(removed.length, "table", "tables") + "?", body: plural(lost.length, "guest is", "guests are") + " seated there and will have no table.", confirmText: "Remove", tone: "danger" })) return;
    setBusy(true);
    try {
      await onTables(rows.map((r) => ({ k: r.k, n: tname(r.n), seats: HZ.tbl.seats(r.seats) })));
      const upd = [];
      for (const g of guests) {
        const l = tlow(g.table);
        if (!l) continue;
        const r = rows.find((x) => x.orig && tlow(x.orig) === l);
        if (r) {
          if (tname(r.n) !== tname(g.table)) upd.push([g.id, tname(r.n)]);
        } else if (removed.some((t) => tlow(t.n) === l)) upd.push([g.id, ""]);
      }
      for (const [id, nt] of upd) await call((r) => r.guests.update({ id, table: nt }));
      if (upd.length) q.mutate((d) => (d || []).map((x) => {
        const u = upd.find((y) => y[0] === x.id);
        return u ? { ...x, table: u[1] } : x;
      }));
      ui.toast("Tables saved", { tone: "ok" });
      onClose();
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
      setBusy(false);
    }
  };
  return /* @__PURE__ */ React.createElement(Modal, { onClose: busy ? null : onClose, label: "Tables and seats", width: 560 }, /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { display: "grid", gap: 14 } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between" }, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h2", style: { fontSize: 20 } }, "Tables & seats"), /* @__PURE__ */ React.createElement(Button, { type: "button", variant: "ghost", size: "sm", icon: I.x, onClick: onClose, "aria-label": "Close", disabled: busy })), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { margin: 0 } }, "Write each table and how many seats it has. A full table can't be given to more guests, so no table is ever over-filled. Names can be numbers (1, 2, 3) or words (VIP, Family)."), rows.length ? /* @__PURE__ */ React.createElement("div", { className: "hzg-tlist", style: { maxHeight: 340, overflowY: "auto", paddingRight: 2 } }, /* @__PURE__ */ React.createElement("div", { className: "hzg-trow", style: { borderTop: 0, fontSize: 11, letterSpacing: ".14em", textTransform: "uppercase", color: "var(--ink3)", padding: "0 0 4px" } }, /* @__PURE__ */ React.createElement("span", null, "Table"), /* @__PURE__ */ React.createElement("span", null, "Seats"), /* @__PURE__ */ React.createElement("span", null, "Guests"), /* @__PURE__ */ React.createElement("span", null)), rows.map((r) => {
    const c = cOf(r), e = errOf(r);
    return /* @__PURE__ */ React.createElement("div", { key: r.k, className: "hzg-trow" }, /* @__PURE__ */ React.createElement(Input, { className: cx("hzg-tname", e && /name/i.test(e) && "bad"), value: r.n, maxLength: 12, onChange: (ev) => set(r.k, { n: ev.target.value.slice(0, 12) }), "aria-label": "Table name" }), /* @__PURE__ */ React.createElement(Input, { className: cx("hzg-tseats", e && !/name/i.test(e) && "bad"), type: "number", inputMode: "numeric", min: Math.max(1, c), max: 500, value: r.seats, onChange: (ev) => set(r.k, { seats: ev.target.value === "" ? "" : Math.min(500, parseInt(ev.target.value, 10) || 0) }), "aria-label": "Seats" }), /* @__PURE__ */ React.createElement("span", { style: { fontSize: 13, color: e ? "var(--bad)" : c >= (parseInt(r.seats, 10) || 0) ? "var(--ok)" : "var(--ink2)", lineHeight: 1.2 } }, e || c + "/" + r.seats), /* @__PURE__ */ React.createElement(Button, { type: "button", size: "sm", variant: "ghost", icon: I.trash, onClick: () => setRows((rs) => rs.filter((x) => x.k !== r.k)), "aria-label": "Remove table " + r.n }));
  })) : null, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, flexWrap: "wrap", alignItems: "center", fontSize: 13.5, color: "var(--ink2)" } }, /* @__PURE__ */ React.createElement(Input, { className: "hzg-qn", type: "number", inputMode: "numeric", min: 1, max: 150, value: qn, onChange: (e) => setQn(e.target.value), style: { width: 70, textAlign: "center" }, "aria-label": "How many tables" }), /* @__PURE__ */ React.createElement("span", null, "tables \xD7"), /* @__PURE__ */ React.createElement(Input, { className: "hzg-qs", type: "number", inputMode: "numeric", min: 1, max: 500, value: qs, onChange: (e) => setQs(e.target.value), style: { width: 70, textAlign: "center" }, "aria-label": "Seats per table" }), /* @__PURE__ */ React.createElement("span", null, "seats"), /* @__PURE__ */ React.createElement(Button, { type: "button", size: "sm", variant: rows.length ? "secondary" : "primary", icon: I.plus, onClick: make }, rows.length ? "Add these" : "Create tables"), rows.length ? /* @__PURE__ */ React.createElement(Button, { type: "button", size: "sm", variant: "ghost", icon: I.plus, onClick: add }, "One more table") : null), rows.length ? /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { margin: 0 } }, plural(rows.length, "table", "tables"), " \xB7 ", total, " seats \xB7 ", guests.length, " guests", guests.length > total ? " \u2014 " + (guests.length - total) + " more guests than seats" : "") : null), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { justifyContent: "flex-end", gap: 10, padding: "0 22px 22px" } }, /* @__PURE__ */ React.createElement(Button, { variant: "ghost", onClick: onClose, disabled: busy }, "Cancel"), /* @__PURE__ */ React.createElement(Button, { variant: "primary", onClick: save, busy, disabled: bad }, "Save tables")));
}

// studio/guests.jsx
function Guests() {
  useStudioCss();
  return /* @__PURE__ */ React.createElement(Shell, { active: "weddings" }, () => /* @__PURE__ */ React.createElement(Page, null));
}
function Page() {
  const { id } = useParams();
  const ui = useUI();
  const nav = useNavigate();
  const inv = useData((r) => r.invitations.get(id), [id]);
  const q = useData((r) => r.guests.list(id), [id]);
  useEffect(() => {
    const t = setInterval(() => {
      if (!document.hidden) q.reload && q.reload(true);
    }, 3e4);
    return () => clearInterval(t);
  }, [id]);
  const initial = /[?&]f=([a-z]+)/.exec(window.location.hash || "");
  if (inv.error) return /* @__PURE__ */ React.createElement("main", { className: "hzs-wrap" }, /* @__PURE__ */ React.createElement(Empty, { icon: I.alert, title: "This wedding couldn't be opened", text: errText(inv.error) }, /* @__PURE__ */ React.createElement(LinkButton, { to: "/dashboard", variant: "primary", icon: I.back }, "Back to weddings")));
  if (!inv.data) return /* @__PURE__ */ React.createElement("main", { className: "hzs-wrap" }, /* @__PURE__ */ React.createElement(Skel, { h: 14, w: 120 }), /* @__PURE__ */ React.createElement(Skel, { h: 40, w: 320, style: { marginTop: 14 } }), /* @__PURE__ */ React.createElement(Skel, { h: 160, r: 18, style: { marginTop: 28 } }));
  const form = inv.data;
  const link = HZ.base() + "#/i/" + form.slug;
  return /* @__PURE__ */ React.createElement("main", { className: "hzs-wrap", style: { display: "grid", gridTemplateColumns: "minmax(0,1fr)", gap: 18 } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-head", style: { marginBottom: 0 } }, /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0 } }, /* @__PURE__ */ React.createElement("a", { href: "#/dashboard", className: "hzs-eyebrow", style: { display: "inline-flex", alignItems: "center", gap: 6 } }, /* @__PURE__ */ React.createElement(I.back, { size: 12 }), "Weddings"), /* @__PURE__ */ React.createElement("h1", { className: "hzs-h1", style: { marginTop: 6 } }, "Guests ", /* @__PURE__ */ React.createElement("span", { className: "hzs-accent" }, (form.groomName || "") + " & " + (form.brideName || ""))), form.status !== "active" ? /* @__PURE__ */ React.createElement("p", { className: "hzs-sub", style: { color: "var(--warn)" } }, "The card is still a draft \u2014 make it live in the editor before sending invitations.") : null), /* @__PURE__ */ React.createElement("div", { className: "hzs-head-act", style: { display: "flex", gap: 8, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(LinkButton, { to: "/scan/" + id, variant: "primary", icon: I.scan }, "Check-in"), /* @__PURE__ */ React.createElement(LinkButton, { to: "/builder/" + id, variant: "secondary", icon: I.edit }, "Edit card"), /* @__PURE__ */ React.createElement(Menu, { title: "Invitation", items: [
    { label: "Copy main link", icon: I.link, onClick: () => copyText(link).then(() => ui.toast("Link copied")) },
    { label: "Open the card", icon: I.open, onClick: () => window.open(link, "_blank") },
    { label: "Client guest lists", icon: I.list, onClick: () => nav("/lists") }
  ] }))), /* @__PURE__ */ React.createElement(
    GuestsPanel,
    {
      invId: id,
      form,
      q,
      ui,
      initialFilter: initial ? initial[1] : null,
      onTables: async (list) => {
        await call((r) => r.invitations.update(id, { tables: list }));
        inv.mutate((d) => ({ ...d, tables: list }));
      }
    }
  ));
}
var guests_default = Guests;
export {
  guests_default as default
};
