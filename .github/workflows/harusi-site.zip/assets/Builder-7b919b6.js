import {
  AnimatePresence,
  Badge,
  Button,
  Card,
  Empty,
  Field,
  HZ,
  I,
  Input,
  LinkButton,
  Menu,
  Modal,
  Note,
  React,
  Section,
  Seg,
  Select,
  Shell,
  Skel,
  Spinner,
  Switch,
  Textarea,
  call,
  copyText,
  cx,
  downloadFile,
  errText,
  motion,
  useCallback,
  useEffect,
  useMemo,
  useNavigate,
  useRef,
  useState,
  useStudioCss,
  useUI
} from "./studio-S4HULNAO-7b919b6.js";

// studio/builder.jsx
import { u as useParams, Q as QRCodeSVG } from "./index-B4Ch-nvB-7b919b6.js";

// studio/bfields.jsx
var { createContext, useContext } = React;
var cache = /* @__PURE__ */ new Map();
function fetchT(url, ms) {
  const c = typeof AbortController !== "undefined" ? new AbortController() : null;
  const t = setTimeout(() => c && c.abort(), ms);
  return fetch(url, c ? { signal: c.signal } : void 0).finally(() => clearTimeout(t));
}
function decode(s) {
  const d = document.createElement("textarea");
  d.innerHTML = s;
  return d.value;
}
async function machine(text, from, to) {
  const key = from + ">" + to + ":" + text;
  if (cache.has(key)) return cache.get(key);
  let out = null;
  try {
    const r = await fetchT("https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + from + "&tl=" + to + "&dt=t&q=" + encodeURIComponent(text), 6500);
    if (r.ok) {
      const j = await r.json();
      const s = (j && j[0] ? j[0] : []).map((x) => x && x[0] || "").join("");
      if (s.trim()) out = s;
    }
  } catch (e) {
  }
  if (!out) {
    try {
      const r = await fetchT("https://api.mymemory.translated.net/get?q=" + encodeURIComponent(text) + "&langpair=" + from + "|" + to, 7500);
      const j = await r.json();
      const s = j && j.responseData && j.responseData.translatedText;
      if (s && String(j.responseStatus) === "200" && !/MYMEMORY WARNING|QUERY LENGTH LIMIT|INVALID/i.test(s)) out = decode(s);
    } catch (e) {
    }
  }
  if (out) cache.set(key, out);
  return out;
}
function keepWords(src, out) {
  let o = out;
  if (/\bAllah\b/.test(src) && !/\bAllah\b/.test(o)) o = o.replace(/\bMungu\b/g, "Allah").replace(/\bGod\b/g, "Allah");
  for (const w of ["Nikkah", "Walima", "Walimah", "Maulid", "Maulidi", "Insha'Allah", "InshaAllah", "Masha'Allah", "Zanzibar", "Stone Town", "Unguja", "Pemba"]) {
    if (src.includes(w) && !o.includes(w)) {
      const low = new RegExp(w.replace(/[.*+?^${}()|[\]\\']/g, "\\$&"), "i");
      if (low.test(o)) o = o.replace(low, w);
    }
  }
  return o;
}
function fixBold(src, out) {
  let o = String(out).replace(/\*\*\s*([^*]+?)\s*\*\*/g, "**$1**").replace(/\*\s+\*/g, "**");
  const want = [];
  String(src).replace(/\*\*(.+?)\*\*/g, (m, x) => {
    want.push(x);
    return m;
  });
  for (const w of want) {
    if (o.includes("**" + w + "**")) continue;
    if (o.includes(w)) o = o.replace(w, "**" + w + "**");
  }
  if (want.length && (o.match(/\*\*/g) || []).length % 2) o = o.replace(/\*\*/g, "");
  return o;
}
async function translate(text, from, to, kind) {
  const t = String(text || "").trim();
  if (!t) return { text: "", via: "empty" };
  if (kind === "family") return { text: String(t).split(/(\*\*.+?\*\*)/g).map((x) => x.startsWith("**") ? "**" + HZ.honor(x.slice(2, -2), to) + "**" : x ? HZ.honor(x, to) : x).join(""), via: "rules" };
  if (HZ.isTerm(t, from)) {
    const g = HZ.gloss(t, to);
    if (g) return { text: g, via: "glossary" };
  }
  if (kind === "brand") return { text: t, via: "copy" };
  const lines = String(text).split("\n");
  const out = [];
  for (const ln of lines) {
    if (!ln.trim()) {
      out.push(ln);
      continue;
    }
    if (HZ.isTerm(ln, from)) {
      const g = HZ.gloss(ln, to);
      if (g) {
        out.push(g);
        continue;
      }
    }
    const m = await machine(ln.trim(), from, to);
    if (m == null) return { text: "", via: "failed" };
    out.push(fixBold(ln, keepWords(ln, m)));
  }
  return { text: out.join("\n").trim(), via: "machine" };
}
var pairTop = (en, sw) => ({
  get: (f) => ({ en: f[en] || "", sw: f[sw] || "" }),
  put: (f, side, v) => ({ ...f, [side === "sw" ? sw : en]: v })
});
var pairItem = (list, key, en, sw) => ({
  get: (f) => {
    const x = (f[list] || []).find((z) => z && z.k === key) || {};
    return { en: x[en] || "", sw: x[sw] || "" };
  },
  put: (f, side, v) => ({ ...f, [list]: (f[list] || []).map((z) => z && z.k === key ? { ...z, [side === "sw" ? sw : en]: v } : z) })
});
var EdLang = createContext({ lang: "sw", setLang: () => {
} });
var LANG_NAME = { sw: "Kiswahili", en: "English" };
var setAutoFlag = (f, path, side) => {
  const a = { ...f.autoT || {} };
  if (side) a[path] = side;
  else delete a[path];
  return { ...f, autoT: a };
};
function useTwin({ path, pair, form, update, kind }) {
  const v = pair.get(form);
  const auto = (form.autoT || {})[path] || null;
  const [busy, setBusy] = useState(null);
  const [fail, setFail] = useState(null);
  const timer = useRef(null);
  const seq = useRef(0);
  useEffect(() => () => clearTimeout(timer.current), []);
  const run = (from, srcText, force) => {
    const to = from === "sw" ? "en" : "sw";
    clearTimeout(timer.current);
    const my = ++seq.current;
    timer.current = setTimeout(async () => {
      setBusy(to);
      setFail(null);
      const r = await translate(srcText, from, to, kind);
      if (my !== seq.current) return;
      setBusy(null);
      if (r.via === "failed") {
        setFail(to);
        return;
      }
      update((f) => {
        const cur = pair.get(f);
        const curAuto = (f.autoT || {})[path];
        if (cur[from] !== srcText) return f;
        if (!force && cur[to].trim() && curAuto !== to && curAuto !== "both") return f;
        return setAutoFlag(pair.put(f, to, r.text), path, r.text && r.text !== srcText ? to : null);
      });
    }, force ? 0 : kind === "text" ? 900 : 650);
  };
  const type = (side, val) => {
    const other = side === "sw" ? "en" : "sw";
    update((f) => {
      let g = pair.put(f, side, val);
      const a = (g.autoT || {})[path];
      if (a === side) g = setAutoFlag(g, path, null);
      if (!val.trim() && a === other) g = pair.put(setAutoFlag(g, path, null), other, "");
      return g;
    });
    if (val.trim() && (!v[other].trim() || auto === other || auto === "both")) run(side, val, false);
    else {
      clearTimeout(timer.current);
      seq.current++;
      setBusy(null);
    }
  };
  const accept = () => update((f) => setAutoFlag(f, path, null));
  const regen = (to) => {
    const from = to === "sw" ? "en" : "sw";
    if (v[from].trim()) run(from, v[from], true);
  };
  return { v, auto, busy, fail, type, accept, regen };
}
function OtherSide({ tw, lang, setLang, fb }) {
  const other = lang === "sw" ? "en" : "sw";
  const val = tw.v[other] || fb && fb[other] || "";
  return /* @__PURE__ */ React.createElement("button", { type: "button", className: "hzs-other", onClick: () => setLang(other), title: "Switch to " + LANG_NAME[other] }, /* @__PURE__ */ React.createElement("span", { className: "tag" }, other.toUpperCase()), tw.busy === other ? /* @__PURE__ */ React.createElement("span", { className: "mut" }, /* @__PURE__ */ React.createElement(Spinner, { size: 11 }), " translating\u2026") : tw.fail === other ? /* @__PURE__ */ React.createElement("span", { className: "bad" }, "couldn't translate \u2014 tap to write it") : val.trim() ? /* @__PURE__ */ React.createElement("span", { className: "txt" }, val.replace(/\*\*/g, "")) : /* @__PURE__ */ React.createElement("span", { className: "mut" }, tw.v[lang].trim() ? "will be translated" : "\u2014"), tw.auto === other && tw.busy !== other ? /* @__PURE__ */ React.createElement("span", { className: "auto" }, "auto") : null);
}
function AutoChip({ tw, lang }) {
  const other = lang === "sw" ? "en" : "sw";
  if (tw.busy === lang) return /* @__PURE__ */ React.createElement("span", { className: "hzs-bi-state" }, /* @__PURE__ */ React.createElement(Spinner, { size: 12 }), " translating\u2026");
  return /* @__PURE__ */ React.createElement("span", { style: { display: "inline-flex", gap: 6, alignItems: "center" } }, tw.auto === lang ? /* @__PURE__ */ React.createElement("button", { type: "button", className: "hzs-bi-auto", onClick: tw.accept, title: "Translated automatically \u2014 tap to confirm it reads well, or just edit it." }, /* @__PURE__ */ React.createElement(I.sparkle, { size: 11 }), "Auto \xB7 confirm", /* @__PURE__ */ React.createElement(I.check, { size: 12 })) : null, tw.v[other].trim() && tw.auto !== lang ? /* @__PURE__ */ React.createElement("button", { type: "button", className: "hzs-bi-re", onClick: () => tw.regen(lang), title: "Translate again from " + LANG_NAME[other], "aria-label": "Translate again" }, /* @__PURE__ */ React.createElement(I.languages, { size: 13 })) : null);
}
function Bi({ label, hint, path, pair, form, update, kind = "text", area, rows = 3, max = 600, phSw, phEn, right }) {
  const { lang, setLang } = useContext(EdLang);
  const tw = useTwin({ path, pair, form, update, kind });
  const Tag = area ? "textarea" : "input";
  return /* @__PURE__ */ React.createElement("div", { className: "hzs-field" }, /* @__PURE__ */ React.createElement("span", { className: "hzs-label" }, label, /* @__PURE__ */ React.createElement("span", { style: { marginLeft: "auto", display: "inline-flex", gap: 8, alignItems: "center" } }, /* @__PURE__ */ React.createElement(AutoChip, { tw, lang }), right)), /* @__PURE__ */ React.createElement(
    Tag,
    {
      className: cx(area ? "hzs-textarea" : "hzs-input", tw.auto === lang && "hzs-is-auto"),
      rows: area ? rows : void 0,
      maxLength: max,
      value: tw.v[lang],
      placeholder: lang === "sw" ? phSw : phEn,
      onChange: (e) => tw.type(lang, e.target.value),
      lang
    }
  ), /* @__PURE__ */ React.createElement(OtherSide, { tw, lang, setLang }), hint ? /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { marginTop: 4 } }, hint) : null);
}
var BI_CSS = `
.hzs-field,.hzb-ov,.hzb-line,.hzb-item,.hzb-item-b>*{min-width:0}
.hzs-other{max-width:100%}
.hzs-bi-state{display:inline-flex;align-items:center;gap:5px;font-size:11.5px;color:var(--ink3);font-weight:400}
.hzs-bi-auto{display:inline-flex;align-items:center;gap:5px;height:22px;padding:0 9px;border-radius:999px;border:1px solid var(--goldline);background:var(--goldbg);color:#7A5E26;font-size:11px;cursor:pointer;white-space:nowrap;font-weight:400}
.hzs-bi-auto:hover{background:#EFE3C8}
.hzs-bi-re{display:inline-grid;place-items:center;width:26px;height:22px;border-radius:999px;border:0;background:transparent;color:var(--ink3);cursor:pointer}
.hzs-bi-re:hover{background:rgba(30,26,18,.06);color:var(--ink)}
.hzs-is-auto{background:#FFFBF1!important;border-color:var(--goldline)!important}
.hzs-other{display:flex;align-items:center;gap:8px;width:100%;margin-top:6px;padding:3px 2px;border:0;background:none;cursor:pointer;text-align:left;font-size:12.5px;color:var(--ink3);min-width:0}
.hzs-other .tag{flex:none;font-size:9.5px;letter-spacing:.12em;padding:2px 6px;border-radius:6px;background:rgba(30,26,18,.06);color:var(--ink2)}
.hzs-other .txt{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}
.hzs-other .mut{font-style:italic;display:inline-flex;align-items:center;gap:5px}
.hzs-other .bad{color:var(--bad)}
.hzs-other .auto{flex:none;font-size:10px;padding:1px 7px;border-radius:999px;background:var(--goldbg);color:#7A5E26}
.hzs-other:hover .txt{color:var(--ink2)}
`;

// studio/catalog.json
var catalog_default = {
  "blush-swan": {
    dict: "Hh",
    keys: [
      "tapSeal",
      "weddingDay",
      "scrollDown",
      "twoSouls",
      "oneDestiny",
      "lifetime",
      "dearFriends",
      "beginsIn",
      "days",
      "hours",
      "minutes",
      "seconds",
      "schedule",
      "location",
      "openInMaps",
      "dressTitle",
      "dressText",
      "familyPre",
      "familyAnd",
      "familyPost",
      "addToCalendar",
      "confirmTitle",
      "confirmSub",
      "clickToOpen",
      "rsvpBefore",
      "yourName",
      "attendQ",
      "accept",
      "decline",
      "guestsAttending",
      "songLabel",
      "childrenLabel",
      "dietary",
      "submit",
      "rsvpDone",
      "rsvpWhats",
      "guestbook",
      "guestbookPh",
      "guestbookName",
      "guestbookSend",
      "guestbookThanks",
      "copy",
      "copied",
      "footer",
      "scanHint",
      "yourCode",
      "checkedInBadge",
      "hopeToSee"
    ]
  },
  "villa-rosa": {
    dict: "Hh",
    keys: [
      "tapSeal",
      "weddingDay",
      "scrollDown",
      "dearFriends",
      "beginsIn",
      "days",
      "hours",
      "minutes",
      "seconds",
      "schedule",
      "location",
      "openInMaps",
      "dressTitle",
      "dressText",
      "dressGents",
      "dressLadies",
      "familyPre",
      "familyAnd",
      "familyPost",
      "addToCalendar",
      "confirmTitle",
      "confirmSub",
      "clickToOpen",
      "rsvpBefore",
      "yourName",
      "attendQ",
      "accept",
      "decline",
      "guestsAttending",
      "songLabel",
      "childrenLabel",
      "dietary",
      "submit",
      "rsvpDone",
      "rsvpWhats",
      "guestbook",
      "guestbookPh",
      "guestbookName",
      "guestbookSend",
      "guestbookThanks",
      "copy",
      "copied",
      "footer",
      "scanHint",
      "yourCode",
      "checkedInBadge",
      "hopeToSee"
    ]
  },
  "midnight-garden": {
    dict: "Hh",
    keys: [
      "weddingDay",
      "scrollDown",
      "twoSouls",
      "oneDestiny",
      "lifetime",
      "dearFriends",
      "beginsIn",
      "days",
      "hours",
      "minutes",
      "seconds",
      "schedule",
      "location",
      "openInMaps",
      "dressTitle",
      "dressText",
      "dressGents",
      "dressLadies",
      "giftTitle",
      "familyPre",
      "familyAnd",
      "familyPost",
      "contactsTitle",
      "contactsSub",
      "callNow",
      "detailsTitle",
      "transportTitle",
      "transportText",
      "stayTitle",
      "stayText",
      "noBoxed",
      "giftsNote",
      "confirmTitle",
      "confirmSub",
      "clickToOpen",
      "rsvpBefore",
      "yourName",
      "attendQ",
      "accept",
      "decline",
      "guestsAttending",
      "songLabel",
      "childrenLabel",
      "dietary",
      "submit",
      "rsvpDone",
      "rsvpWhats",
      "guestbook",
      "guestbookPh",
      "guestbookName",
      "guestbookSend",
      "guestbookThanks",
      "copy",
      "footer",
      "scanHint",
      "yourCode",
      "checkedInBadge",
      "attendingBadge",
      "declinedBadge",
      "hopeToSee"
    ]
  },
  "rose-cascade": {
    dict: "RC_T",
    keys: [
      "tapSeal",
      "forYou",
      "scroll",
      "invited",
      "twoSouls",
      "oneDestiny",
      "familyPre",
      "familyPost",
      "beginsIn",
      "cdTitle",
      "days",
      "hours",
      "minutes",
      "seconds",
      "schedule",
      "celebration",
      "location",
      "whereWe",
      "openMaps",
      "addCal",
      "dressTitle",
      "whatToWear",
      "dressText",
      "dressGents",
      "dressLadies",
      "dressTag",
      "mapLink",
      "rsvp",
      "confirmTitle",
      "confirmSub",
      "rsvpBefore",
      "rsvpSealHint",
      "yourName",
      "attendQ",
      "accept",
      "decline",
      "guestsAttending",
      "songLabel",
      "childrenLabel",
      "dietary",
      "submit",
      "sending",
      "rsvpDone",
      "rsvpWhats",
      "attendingBadge",
      "declinedBadge",
      "yourCode",
      "scanHint",
      "checkedInBadge",
      "wmBless",
      "wmTime",
      "wmLove",
      "footer"
    ]
  },
  "emerald-arch": {
    dict: "EA",
    keys: [
      "forYou",
      "tapSeal",
      "scroll",
      "invited",
      "beginsIn",
      "cdTitle",
      "scheduleEye",
      "scheduleTitle",
      "locationEye",
      "locationTitle",
      "openMaps",
      "addCal",
      "dressEye",
      "dressTitle",
      "dressText",
      "dressGents",
      "dressGentsText",
      "dressLadies",
      "dressLadiesText",
      "rsvpEye",
      "rsvpTitle",
      "rsvpSub",
      "rsvpSealHint",
      "yourName",
      "attendQ",
      "accept",
      "decline",
      "guestsAttending",
      "songLabel",
      "childrenLabel",
      "dietary",
      "submit",
      "sending",
      "rsvpDone",
      "rsvpWhats",
      "attendingBadge",
      "declinedBadge",
      "codeEye",
      "codeTitle",
      "scanHint",
      "checkedInBadge",
      "hopeToSee",
      "galleryEye",
      "galleryTitle",
      "giftsEye",
      "giftsTitle",
      "contactsEye",
      "contactsTitle",
      "days",
      "hours",
      "minutes",
      "seconds",
      "footer",
      "twoSouls",
      "oneDestiny",
      "lifetime",
      "dearFriends",
      "familyPre",
      "familyAnd",
      "familyPost"
    ]
  },
  "royal-noor": {
    dict: "own",
    keys: [
      "tapSeal",
      "loading",
      "weddingDay",
      "scrollDown",
      "invitedLong",
      "twoSouls",
      "oneDestiny",
      "lifetime",
      "familyPre",
      "familyAnd",
      "familyPost",
      "dearFriends",
      "counting",
      "beginsIn",
      "days",
      "hours",
      "minutes",
      "seconds",
      "addToCalendar",
      "orderOfDay",
      "schedule",
      "whereWe",
      "venue",
      "openInMaps",
      "liveMap",
      "whatToWear",
      "dressTitle",
      "dressText",
      "gents",
      "ladies",
      "dressGents",
      "dressLadies",
      "copy",
      "copied",
      "hopeToSee",
      "kindlyRespond",
      "confirmTitle",
      "confirmSub",
      "clickToOpen",
      "yourName",
      "attendQ",
      "accept",
      "decline",
      "guestsAttending",
      "songLabel",
      "childrenLabel",
      "dietary",
      "submit",
      "rsvpWhats",
      "rsvpBefore",
      "rsvpDone",
      "rsvpDoneTitle",
      "yourCode",
      "scanHint",
      "entryEyebrow",
      "entryTitle",
      "footer"
    ],
    en: {
      tapSeal: "Tap the seal to open",
      loading: "Unsealing your invitation\u2026",
      weddingDay: "Wedding Day",
      scrollDown: "Scroll down",
      invitedLong: "You are warmly invited to the wedding of",
      twoSouls: "Two Souls",
      oneDestiny: "One destiny",
      lifetime: "A Lifetime written by Allah",
      familyPre: "The families of",
      familyAnd: "and",
      familyPost: "request the honour of your presence at the marriage of their beloved children",
      dearFriends: "Dear Friends and Family,",
      story: "With the grace of Allah, two families become one. It is with hearts full of joy that we invite you to share in the baraka of our wedding day \u2014 a day written for us long before we ever knew.",
      quote: "And among His signs is that He created for you spouses from among yourselves, that you may find tranquillity in them.",
      counting: "Counting Down",
      beginsIn: "The Celebration Begins In",
      days: "Days",
      hours: "Hours",
      minutes: "Minutes",
      seconds: "Seconds",
      addToCalendar: "Add to Calendar",
      orderOfDay: "The order of the day",
      schedule: "Schedule of Events",
      whereWe: "Where we celebrate",
      venue: "The Venue",
      openInMaps: "Open in Maps",
      liveMap: "Live map",
      whatToWear: "What to wear",
      dressTitle: "Dress Code",
      dressText: "We kindly invite you to dress in elegant attire that reflects the style and spirit of our special day.",
      gents: "Gentlemen",
      ladies: "Ladies",
      dressGents: "Gentlemen \u2014 well-tailored suits with classic dress shoes are preferred.",
      dressLadies: "Ladies \u2014 formal dresses in elegant, polished styles are encouraged.",
      goodToKnow: "Good to know",
      detailsTitle: "Details",
      transportTitle: "Transport & Parking",
      transportText: "Complimentary valet parking is available at the main gate. Shuttle service runs from the parking area to the courtyard every 15 minutes.",
      stayTitle: "Where to Stay",
      stayText: "For our guests travelling in, we recommend the nearby beach resorts of Nungwi and Kendwa \u2014 kindly book early for the season.",
      giftsEyebrow: "Gifts & Contributions",
      giftTitle: "Gift Preference",
      noBoxed: "Kindly, no boxed gifts please.",
      giftsNote: "Your presence is the greatest gift. Should you wish to honour us with a contribution:",
      copy: "Copy",
      copied: "Copied!",
      contactsEyebrow: "Contacts",
      hopeToSee: "Hope to see you there!",
      contactsSub: "For any inquiries, kindly reach us:",
      kindlyRespond: "Kindly Respond",
      confirmTitle: "Confirm Your Attendance",
      confirmSub: "To help us prepare for a joyful celebration, kindly confirm below.",
      clickToOpen: "Click to open",
      yourName: "Your name",
      attendQ: "Will you be attending?",
      accept: "Accepts with pleasure",
      decline: "Declines with regret",
      guestsAttending: "Number of Guests Attending",
      songLabel: "A Song That Gets You Dancing",
      childrenLabel: "Children Attending (names and ages)",
      dietary: "Dietary needs (optional)",
      submit: "Submit",
      rsvpWhats: "RSVP via WhatsApp",
      rsvpBefore: "Please RSVP before August 09",
      rsvpDone: "Thank you \u2014 your response has been received!",
      rsvpDoneTitle: "Shukran!",
      yourCode: "Your guest code",
      scanHint: "Show this code at the entrance",
      entryEyebrow: "At the door",
      entryTitle: "Your Entrance Code",
      duasEyebrow: "Dua & Salamu",
      guestbook: "Leave a Blessing",
      guestbookName: "Your name",
      guestbookPh: "Write your dua or message\u2026",
      guestbookSend: "Send Blessing",
      guestbookThanks: "Shukran! Your blessing has been added.",
      footer: "Made with love in Zanzibar"
    },
    sw: {
      tapSeal: "Gusa muhuri kufungua",
      loading: "Tunafungua mwaliko wako\u2026",
      weddingDay: "Siku ya Harusi",
      scrollDown: "Sogeza chini",
      invitedLong: "Umealikwa kwa heshima kubwa kwenye harusi ya",
      twoSouls: "Roho Mbili",
      oneDestiny: "Hatima moja",
      lifetime: "Maisha yaliyoandikwa na Allah",
      familyPre: "Familia za",
      familyAnd: "na",
      familyPost: "zinakuomba kwa heshima uhudhurie ndoa ya watoto wao wapendwa",
      dearFriends: "Wapendwa Ndugu na Marafiki,",
      story: "Kwa neema ya Allah, familia mbili zinakuwa moja. Kwa mioyo iliyojaa furaha tunakualika kushiriki baraka za siku yetu ya harusi \u2014 siku iliyoandikwa kwa ajili yetu.",
      quote: "Na katika Ishara Zake ni kuwa amekuumbieni wake kutokana na nafsi zenu, ili mpate utulivu kwao.",
      counting: "Tunahesabu",
      beginsIn: "Sherehe Inaanza Baada Ya",
      days: "Siku",
      hours: "Saa",
      minutes: "Dakika",
      seconds: "Sekunde",
      addToCalendar: "Weka kwenye Kalenda",
      orderOfDay: "Ratiba ya siku",
      schedule: "Ratiba ya Sherehe",
      whereWe: "Mahali tunaposherehekea",
      venue: "Mahali",
      openInMaps: "Fungua Ramani",
      liveMap: "Ramani",
      whatToWear: "Mavazi",
      dressTitle: "Mavazi",
      dressText: "Tunakualika kuvaa mavazi rasmi ya kifahari yanayoendana na uzuri na hadhi ya siku yetu maalum.",
      gents: "Wanaume",
      ladies: "Wanawake",
      dressGents: "Wanaume \u2014 suti zilizoshonwa vizuri pamoja na viatu rasmi.",
      dressLadies: "Wanawake \u2014 mavazi rasmi ya kifahari na ya staha yanapendekezwa.",
      goodToKnow: "Mambo ya kuzingatia",
      detailsTitle: "Maelezo",
      transportTitle: "Usafiri na Maegesho",
      transportText: "Maegesho ya bure yanapatikana kwenye lango kuu. Gari maalumu la wageni linapita kila baada ya dakika 15 kutoka maegeshoni hadi ukumbini.",
      stayTitle: "Malazi",
      stayText: "Kwa wageni wanaotoka mbali, tunapendekeza hoteli za ufukweni za Nungwi na Kendwa \u2014 tafadhali weka nafasi mapema.",
      giftsEyebrow: "Zawadi & Michango",
      giftTitle: "Zawadi",
      noBoxed: "Kwa heshima, tunaomba msilete zawadi za maboksi.",
      giftsNote: "Kuja kwako ndiyo zawadi kubwa zaidi. Ukipenda kutuchangia:",
      copy: "Nakili",
      copied: "Imenakiliwa!",
      contactsEyebrow: "Mawasiliano",
      hopeToSee: "Tunatarajia kukuona \u2014 karibu sana!",
      contactsSub: "Kwa maswali yoyote, wasiliana nasi:",
      kindlyRespond: "Tafadhali Jibu",
      confirmTitle: "Thibitisha Kuhudhuria",
      confirmSub: "Ili tuandae sherehe ya furaha, tafadhali thibitisha hapa chini.",
      clickToOpen: "Gusa kufungua",
      yourName: "Jina lako",
      attendQ: "Je, utahudhuria?",
      accept: "Nitahudhuria kwa furaha",
      decline: "Samahani, sitaweza kuhudhuria",
      guestsAttending: "Idadi ya Watakaohudhuria",
      songLabel: "Wimbo Unaokufanya Ucheze",
      childrenLabel: "Watoto wanaohudhuria (majina & umri)",
      dietary: "Mahitaji ya chakula (hiari)",
      submit: "Tuma Jibu",
      rsvpWhats: "Jibu kupitia WhatsApp",
      rsvpBefore: "Tafadhali jibu kabla ya Agosti 09",
      rsvpDone: "Asante \u2014 jibu lako limepokelewa!",
      rsvpDoneTitle: "Shukran!",
      yourCode: "Msimbo wako wa mgeni",
      scanHint: "Onyesha msimbo huu mlangoni",
      entryEyebrow: "Mlangoni",
      entryTitle: "Msimbo wa Kuingia",
      duasEyebrow: "Dua & Salamu",
      guestbook: "Acha Dua au Salamu",
      guestbookName: "Jina lako",
      guestbookPh: "Andika dua yako hapa\u2026",
      guestbookSend: "Tuma Dua",
      guestbookThanks: "Shukran! Dua yako imeongezwa.",
      footer: "Imetengenezwa kwa upendo Zanzibar"
    }
  },
  "kasri-dhahabu": {
    dict: "own",
    keys: [
      "tap",
      "tapCard",
      "forGuest",
      "weddingDay",
      "souls",
      "destiny",
      "lifetime",
      "familiesOf",
      "and",
      "inviteLine",
      "dear",
      "from",
      "scroll",
      "celebration",
      "today",
      "calendar",
      "programme",
      "venue",
      "directions",
      "dress",
      "palette",
      "dNote",
      "respond",
      "respondSub",
      "greet",
      "name",
      "attending",
      "yes",
      "no",
      "companions",
      "none",
      "notes",
      "submit",
      "sending",
      "failed",
      "change",
      "whatsapp",
      "yourCode",
      "showDoor",
      "hope",
      "made",
      "open"
    ],
    en: {
      tap: "Tap to open",
      tapCard: "Tap to open",
      forGuest: "Welcome, {n}",
      weddingDay: "Wedding Day",
      souls: "Two Souls",
      destiny: "One destiny",
      lifetime: "A lifetime written by Allah",
      familiesOf: "The families of",
      and: "and",
      inviteLine: "request the honour of your presence at the marriage of their beloved children",
      dear: "Dear Friends and Family,",
      from: "from {t}",
      scroll: "Scroll down",
      celebration: "The celebration begins in",
      days: "Days",
      hours: "Hours",
      minutes: "Minutes",
      seconds: "Seconds",
      today: "Today we celebrate",
      calendar: "Add to calendar",
      programme: "Order of the day",
      venue: "Venue",
      directions: "Open in Maps",
      dress: "Dress code",
      palette: "Colour palette",
      dNote: "We kindly invite you to dress in elegant attire that reflects the style and spirit of our special day.",
      respond: "Kindly respond",
      respondSub: "To help us prepare for a joyful celebration, kindly confirm below.",
      greet: "Dear {n}",
      name: "Your name",
      attending: "Will you be attending?",
      yes: "Accepts with pleasure",
      no: "Declines with regret",
      companions: "Guests coming with you",
      none: "Just me",
      notes: "Dietary needs (optional)",
      submit: "Send reply",
      sending: "Sending\u2026",
      failed: "We couldn't send your reply. Please try again.",
      thanksYes: "Thank you \u2014 your response has been received. We cannot wait to celebrate with you.",
      thanksNo: "Thank you for letting us know. You will be in our prayers.",
      change: "Change response",
      whatsapp: "Reply on WhatsApp",
      yourCode: "Your guest code",
      showDoor: "Show this code at the entrance",
      attendingBadge: "Attending \u2713",
      checkedInBadge: "Checked in \u2713",
      declinedBadge: "Regrets sent",
      hope: "Hope to see you there!",
      made: "Made with love in Zanzibar",
      open: "Open the invitation"
    },
    sw: {
      tap: "Gusa muhuri kufungua",
      tapCard: "Gusa kufungua",
      forGuest: "Karibu, {n}",
      weddingDay: "Siku ya Harusi",
      souls: "Roho Mbili",
      destiny: "Hatima moja",
      lifetime: "Maisha yaliyoandikwa na Allah",
      familiesOf: "Familia za",
      and: "na",
      inviteLine: "zinakuomba kwa heshima uhudhurie ndoa ya watoto wao wapendwa",
      dear: "Wapendwa Ndugu na Marafiki,",
      from: "kuanzia {t}",
      scroll: "Sogeza chini",
      celebration: "Sherehe inaanza baada ya",
      days: "Siku",
      hours: "Saa",
      minutes: "Dakika",
      seconds: "Sekunde",
      today: "Leo tunasherehekea",
      calendar: "Weka kwenye kalenda",
      programme: "Ratiba ya Sherehe",
      venue: "Mahali",
      directions: "Fungua Ramani",
      dress: "Mavazi",
      palette: "Rangi",
      dNote: "Tunakualika kuvaa mavazi rasmi ya kifahari yanayoendana na uzuri na hadhi ya siku yetu maalum.",
      respond: "Thibitisha kuhudhuria",
      respondSub: "Ili tuandae sherehe ya furaha, tafadhali thibitisha hapa chini.",
      greet: "Mpendwa {n}",
      name: "Jina lako",
      attending: "Je, utahudhuria?",
      yes: "Nitahudhuria kwa furaha",
      no: "Samahani, sitaweza kuhudhuria",
      companions: "Watakaoambatana nawe",
      none: "Mimi peke yangu",
      notes: "Mahitaji ya chakula (hiari)",
      submit: "Tuma jibu",
      sending: "Inatuma\u2026",
      failed: "Jibu halijatumwa. Tafadhali jaribu tena.",
      thanksYes: "Asante \u2014 jibu lako limepokelewa. Tunasubiri kwa hamu kusherehekea nawe.",
      thanksNo: "Asante kwa kutujulisha. Utakuwa katika dua zetu.",
      change: "Badilisha jibu",
      whatsapp: "Jibu kupitia WhatsApp",
      yourCode: "Msimbo wako wa mgeni",
      showDoor: "Onyesha msimbo huu mlangoni",
      attendingBadge: "Utahudhuria \u2713",
      checkedInBadge: "Umeingia \u2713",
      declinedBadge: "Udhuru umetumwa",
      hope: "Tunatarajia kukuona \u2014 karibu sana!",
      made: "Imetengenezwa kwa upendo Zanzibar",
      open: "Fungua mwaliko"
    }
  }
};

// studio/builder.jsx
var { useContext: useContext2 } = React;
var EA = "emerald-arch";
var rid = () => Math.random().toString(36).slice(2, 9);
var keyed = (arr) => (Array.isArray(arr) ? arr : []).filter(Boolean).map((x) => x && x.k ? x : { ...x, k: rid() });
var SECTIONS = [
  { id: "design", label: "Design", icon: I.palette },
  { id: "invite", label: "Invitation", icon: I.heart },
  { id: "events", label: "Events", icon: I.calendar },
  { id: "dress", label: "Dress code", icon: I.shirt },
  { id: "gifts", label: "Gifts & contacts", icon: I.gift },
  { id: "words", label: "All wording", icon: I.type },
  { id: "share", label: "Link & settings", icon: I.share }
];
var OLD_TABS = { template: "design", couple: "invite", wording: "invite", story: "invite" };
var CSS = `
.hzb{display:grid;grid-template-columns:220px minmax(0,1fr) 404px;gap:28px;max-width:1500px;margin:0 auto;padding:24px 24px 80px;align-items:start}
.hzb-rail{position:sticky;top:132px}
.hzb-rail a{display:flex;align-items:center;gap:11px;padding:10px 12px;border-radius:12px;color:var(--ink2);font-size:14.5px;cursor:pointer;transition:background .18s,color .18s;border:0;background:none;width:100%;text-align:left}
.hzb-rail a:hover{background:rgba(30,26,18,.045);color:var(--ink)}
.hzb-rail a.on{background:#fff;color:var(--ink);box-shadow:0 1px 2px rgba(30,26,18,.06),0 6px 16px -10px rgba(30,26,18,.25)}
.hzb-rail a .ok{margin-left:auto;color:var(--ok)}
.hzb-main{min-width:0;display:flex;flex-direction:column;gap:18px}
.hzb-prev{position:sticky;top:132px}
.hzb-phone{width:100%;max-width:380px;margin:0 auto;border-radius:44px;padding:11px;background:#1E1A12;box-shadow:0 40px 80px -30px rgba(30,26,18,.55),inset 0 0 0 1px rgba(255,255,255,.06)}
.hzb-screen{position:relative;border-radius:34px;overflow:hidden;background:#FBF8F2;aspect-ratio:390/780}
.hzb-screen iframe{position:absolute;top:0;left:0;width:390px;height:780px;border:0;transform-origin:0 0}
.hzb-bar{position:sticky;top:64px;z-index:35;background:rgba(251,248,242,.92);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border-bottom:1px solid var(--line)}
.hzb-bar-in{max-width:1500px;margin:0 auto;padding:10px 24px;display:flex;align-items:center;gap:14px;min-height:60px}
.hzb-names{font-family:'Great Vibes',cursive;font-size:26px;line-height:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.hzb-lang{display:flex;align-items:center;gap:8px}
.hzb-lang .lbl{font-size:12px;color:var(--ink3);white-space:nowrap}
.hzb-tabs{display:none}
.hzb-fab{display:none}
.hzb-only-sm{display:none}
.hzb-tpl{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px}
.hzb-tplc{display:flex;flex-direction:column;justify-content:flex-start;align-items:stretch;border:1.5px solid var(--line);border-radius:16px;overflow:hidden;background:#fff;cursor:pointer;text-align:left;padding:0;transition:border-color .2s,box-shadow .2s,transform .2s}
.hzb-tplc:hover{border-color:var(--line2);transform:translateY(-2px)}
.hzb-tplc.on{border-color:var(--ink);box-shadow:0 0 0 3px rgba(30,26,18,.08)}
.hzb-item{border:1px solid var(--line);border-radius:16px;background:var(--paper)}
.hzb-item-h{display:flex;align-items:center;gap:10px;padding:10px 12px;border-bottom:1px solid var(--line);flex-wrap:wrap}
.hzb-item-b{padding:14px 16px 16px;display:grid;gap:14px}
.hzb-num{width:26px;height:26px;border-radius:50%;display:grid;place-items:center;background:var(--goldbg);color:var(--gold);font-size:12.5px;font-weight:500;flex:none}
.hzb-choice{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
.hzb-choice button{text-align:left;padding:14px;border-radius:14px;border:1.5px solid var(--line);background:#fff;cursor:pointer;transition:all .18s}
.hzb-choice button.on{border-color:var(--ink);box-shadow:0 0 0 3px rgba(30,26,18,.07)}
.hzb-g2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.hzb-g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px}
.hzb-who{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px}
.hzb-who button{display:flex;flex-direction:column;gap:3px;text-align:left;padding:12px 14px;border-radius:14px;border:1.5px solid var(--line);background:#fff;cursor:pointer;transition:all .18s;font:inherit;color:var(--ink)}
.hzb-who button:hover{border-color:var(--line2)}
.hzb-who button.on{border-color:var(--ink);box-shadow:0 0 0 3px rgba(30,26,18,.07)}
.hzb-who button b{font-weight:500;font-size:14.5px}
.hzb-who button span{font-size:12.5px;color:var(--ink3);line-height:1.4}
.hzb-card{background:linear-gradient(180deg,#FFFDF8,#FBF6EA);border:1px solid var(--goldline);border-radius:18px;padding:22px 16px;text-align:center}
.hzb-card p{margin:0;padding:0 4px;white-space:pre-line}
.hzb-card .l-caps{font-family:'Jost',sans-serif;font-size:11px;letter-spacing:.3em;text-transform:uppercase;color:#8C6A33;line-height:1.9}
.hzb-card .l-lead{font-family:'Cormorant Garamond',serif;font-size:17px;color:#8C6A33;line-height:1.65}
.hzb-card .l-names{font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:600;color:#1F4E3D;line-height:1.4}
.hzb-card .l-body{font-family:'Cormorant Garamond',serif;font-size:17px;font-style:italic;color:#4A4434;line-height:1.6}
.hzb-card .l-script{font-family:'Great Vibes',cursive;font-size:32px;color:#1F4E3D;line-height:1.3}
.hzb-card .l-gold{font-family:'Cormorant Garamond',serif;font-size:17px;font-style:italic;color:#8C6A33;line-height:1.55}
.hzb-card .em{color:#1F4E3D;font-weight:600;font-style:normal}
.hzb-card .ph{color:var(--ink3);font-style:italic;font-family:inherit;font-size:14px}
.hzb-line{display:grid;gap:8px;padding:12px;border:1px solid var(--line);border-radius:14px;background:#fff}
.hzb-line-h{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
.hzb-line-h select{height:34px;font-size:13px;width:auto;padding-right:30px}
.hzb-bold{height:34px;min-width:34px;padding:0 10px;border-radius:10px;border:1px solid var(--line2);background:#fff;font:600 14px/1 'Cormorant Garamond',serif;cursor:pointer;color:var(--ink)}
.hzb-bold:hover{background:var(--goldbg);border-color:var(--goldline)}
.hzb-ov{display:grid;gap:4px;padding:12px 0;border-top:1px solid var(--line)}
.hzb-ov:first-child{border-top:0;padding-top:0}
.hzb-ov .k{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--ink3);letter-spacing:.02em}
.hzb-ov .k .chg{font-size:10.5px;padding:1px 7px;border-radius:999px;background:var(--goldbg);color:#7A5E26}
.hzb-ov .k .rs{border:0;background:none;color:var(--ink3);font-size:12px;cursor:pointer;display:inline-flex;gap:4px;align-items:center;padding:2px 4px;border-radius:6px}
.hzb-ov .k .rs:hover{color:var(--ink);background:rgba(30,26,18,.05)}
.hzb-hidden{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:46px;padding:0 6px 0 14px;border:1px dashed var(--line2);border-radius:12px;color:var(--ink3);font-size:13.5px;font-style:italic}
.hzb-hidden button{display:inline-flex;align-items:center;gap:6px;height:34px;padding:0 12px;border-radius:999px;border:1px solid var(--line2);background:#fff;color:var(--ink);font-size:12.5px;font-style:normal;cursor:pointer}
.hzb-grp{border:1px solid var(--line);border-radius:16px;background:#fff;overflow:hidden}
.hzb-grp>button{display:flex;width:100%;align-items:center;gap:10px;padding:14px 16px;border:0;background:none;cursor:pointer;font:inherit;color:var(--ink);text-align:left}
.hzb-grp>button b{font-weight:500;font-size:15px}
.hzb-grp>button .n{margin-left:auto;font-size:12px;color:var(--ink3)}
.hzb-grp>div{padding:2px 16px 16px}
@media (max-width:1320px){.hzb{grid-template-columns:200px minmax(0,1fr)}.hzb-prev{display:none}.hzb-fab{display:inline-flex}}
@media (max-width:900px){
 .hzb{grid-template-columns:minmax(0,1fr);padding:16px 16px calc(110px + env(safe-area-inset-bottom));gap:16px}
 .hzb-rail{display:none}
 .hzb-tabs{display:block;position:sticky;top:113px;z-index:30;margin:0 -16px;padding:8px 16px;box-shadow:0 -14px 0 rgba(251,248,242,.96);background:rgba(251,248,242,.94);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px)}
 .hzb-bar{top:58px}
 .hzb-bar-in{padding:8px 12px;gap:8px;min-height:56px}
 .hzb-fab{position:fixed;right:16px;bottom:calc(84px + env(safe-area-inset-bottom));z-index:46;box-shadow:0 14px 30px -10px rgba(30,26,18,.6)}
 .hzb-choice{grid-template-columns:1fr}
 .hzb-g3{grid-template-columns:1fr 1fr}
 .hzb-names{font-size:22px}
}
@media (max-width:640px){.hzb-hide-sm{display:none!important}.hzb-only-sm{display:inline-flex}.hzb-lang .lbl{display:none}.hzb-g2{grid-template-columns:1fr}.hzb-g3{grid-template-columns:1fr}.hzb-who{grid-template-columns:1fr 1fr}}
@media (max-width:380px){.hzb-names{display:none}}
`;
var cssDone = false;
function useBuilderCss() {
  useStudioCss();
  if (!cssDone) {
    cssDone = true;
    const s = document.createElement("style");
    s.textContent = CSS + BI_CSS;
    document.head.appendChild(s);
  }
}
function defaultsFor(tid) {
  const c = catalog_default[tid] || catalog_default["blush-swan"];
  const D = HZ.dict || {};
  return (lang, key) => {
    let v;
    if (c.dict === "own") v = (c[lang] || {})[key];
    else if (c.dict === "EA") {
      v = D.EA_T && D.EA_T[lang] ? D.EA_T[lang][key] : void 0;
      if (v == null && D.Hh) v = D.Hh[lang][key];
    } else v = D[c.dict] && D[c.dict][lang] ? D[c.dict][lang][key] : void 0;
    return typeof v === "string" ? v : "";
  };
}
var pairOv = (tid, key) => ({
  get: (f) => {
    const o = f.textOv && f.textOv[tid] || {};
    return { en: o.en && o.en[key] || "", sw: o.sw && o.sw[key] || "" };
  },
  put: (f, side, v) => {
    const all = { ...f.textOv || {} };
    const t = { ...all[tid] || {} };
    const s = { ...t[side] || {} };
    if (v) s[key] = v;
    else delete s[key];
    t[side] = s;
    all[tid] = t;
    return { ...f, textOv: all };
  }
});
var isEAHero = (tid, k) => tid === EA && k === "invited";
var ovPair = (tid, k) => isEAHero(tid, k) ? pairTop("heroIntroEn", "heroIntroSw") : pairOv(tid, k);
var ovPath = (tid, k) => isEAHero(tid, k) ? "heroIntro" : "ov." + tid + "." + k;
var OPENING_KEYS = ["weddingDay", "invited", "invitedLong"];
var LETTER_KEYS = [
  ["twoSouls", "Large script heading"],
  ["souls", "Large script heading"],
  ["oneDestiny", "Small capitals under it"],
  ["destiny", "Small capitals under it"],
  ["lifetime", "Italic line"],
  ["dearFriends", "Greeting before your letter"],
  ["dear", "Greeting before your letter"]
];
var FAMILY_KEYS = ["familyPre", "familyAnd", "familyPost", "familiesOf", "and", "inviteLine"];
var DRESS_KEYS = /^(dress\w*|whatToWear|gents|ladies|palette|dNote)$/;
var INVITE_SHOWN = /* @__PURE__ */ new Set([...OPENING_KEYS, ...LETTER_KEYS.map((x) => x[0]), ...FAMILY_KEYS, "guestsAttending", "childrenLabel", "companions", "none"]);
function allPairs(f) {
  const P = [
    ["groomFamily", pairTop("groomFamily", "groomFamilySw"), "family"],
    ["brideFamily", pairTop("brideFamily", "brideFamilySw"), "family"],
    ["heroIntro", pairTop("heroIntroEn", "heroIntroSw"), "text"],
    ["quote", pairTop("quoteEn", "quoteSw"), "text"],
    ["story", pairTop("storyEn", "storySw"), "text"],
    ["dressNote", pairTop("dressNoteEn", "dressNoteSw"), "text"],
    ["dressLadies", pairTop("dressLadiesEn", "dressLadiesSw"), "text"],
    ["dressGents", pairTop("dressGentsEn", "dressGentsSw"), "text"]
  ];
  for (const e of f.events || []) {
    P.push(["ev." + e.k + ".name", pairItem("events", e.k, "name", "nameSw"), "term"]);
    P.push(["ev." + e.k + ".dress", pairItem("events", e.k, "dressCode", "dressCodeSw"), "term"]);
    P.push(["ev." + e.k + ".notes", pairItem("events", e.k, "notes", "notesSw"), "text"]);
  }
  for (const g of f.gifts || []) {
    P.push(["gf." + g.k + ".label", pairItem("gifts", g.k, "label", "labelSw"), "brand"]);
    P.push(["gf." + g.k + ".acct", pairItem("gifts", g.k, "accountName", "accountNameSw"), "brand"]);
  }
  for (const c of f.contacts || []) P.push(["ct." + c.k + ".label", pairItem("contacts", c.k, "label", "labelSw"), "term"]);
  for (const l of f.wordingLines || []) P.push(["wl." + l.k, pairItem("wordingLines", l.k, "en", "sw"), lineKind(l)]);
  const tid = f.templateId;
  const ov = f.textOv && f.textOv[tid] || {};
  const keys = /* @__PURE__ */ new Set([...Object.keys(ov.en || {}), ...Object.keys(ov.sw || {})]);
  for (const k of keys) if (!isEAHero(tid, k)) P.push([ovPath(tid, k), pairOv(tid, k), "text"]);
  return P;
}
async function fillMissing(f0, update) {
  let n = 0;
  for (const [path, pair, kind] of allPairs(f0)) {
    const v = pair.get(f0);
    const from = v.sw.trim() && !v.en.trim() ? "sw" : v.en.trim() && !v.sw.trim() ? "en" : null;
    if (!from) continue;
    const to = from === "sw" ? "en" : "sw";
    const r = await translate(v[from], from, to, kind);
    if (!r.text) continue;
    n++;
    update((f) => {
      const cur = pair.get(f);
      if (cur[to].trim() || cur[from] !== v[from]) return f;
      const g = pair.put(f, to, r.text);
      return r.text === v[from] ? g : { ...g, autoT: { ...g.autoT || {}, [path]: to } };
    });
  }
  return n;
}
var lineKind = (l) => l.style === "names" || l.style === "name" ? "family" : "text";
function Builder() {
  useBuilderCss();
  return /* @__PURE__ */ React.createElement(Shell, { active: "weddings", wide: true }, (user) => /* @__PURE__ */ React.createElement(Editor, { user }));
}
function tabFromHash() {
  const m = /[?&]tab=([a-z]+)/.exec(window.location.hash || "");
  const t = m ? OLD_TABS[m[1]] || m[1] : "";
  return SECTIONS.some((s) => s.id === t) ? t : "design";
}
function Editor({ user }) {
  const { id } = useParams();
  const ui = useUI();
  const nav = useNavigate();
  const [form, setForm] = useState(null);
  const [loadErr, setLoadErr] = useState(null);
  const [sec, setSec] = useState(tabFromHash);
  const [save, setSave] = useState({ s: "saved", msg: "" });
  const [slugErr, setSlugErr] = useState("");
  const [lang, setLang] = useState("sw");
  const [prevOpen, setPrevOpen] = useState(false);
  const saved = useRef({});
  const timer = useRef(null);
  const formRef = useRef(null);
  formRef.current = form;
  useEffect(() => {
    if (/[?&]tab=guests/.test(window.location.hash || "")) nav("/guests/" + id, { replace: true });
  }, [id]);
  useEffect(() => {
    let live = true;
    (async () => {
      try {
        const r = await HZ.repo();
        const inv = await r.invitations.get(id);
        if (!live) return;
        const f = {
          ...inv,
          events: keyed(inv.events).map((e) => ({ ...e, date: HZ.ymd(e.date) })),
          gifts: keyed(inv.gifts),
          contacts: keyed(inv.contacts),
          wordingLines: keyed(inv.wordingLines),
          gallery: Array.isArray(inv.gallery) ? inv.gallery : [],
          autoT: inv.autoT || {},
          textOv: inv.textOv || {}
        };
        delete f.id;
        delete f.ownerId;
        const snap = {};
        for (const k in f) snap[k] = JSON.stringify(f[k]);
        saved.current = snap;
        setForm(f);
      } catch (e) {
        if (live) setLoadErr(e);
      }
    })();
    return () => {
      live = false;
    };
  }, [id]);
  const flush = useCallback(async () => {
    const f = formRef.current;
    if (!f) return;
    const changed = {};
    for (const k in f) {
      const j = JSON.stringify(f[k]);
      if (saved.current[k] !== j) changed[k] = f[k];
    }
    if (!Object.keys(changed).length) {
      setSave({ s: "saved", msg: "" });
      return;
    }
    const size = new Blob([JSON.stringify(f)]).size;
    if (size > 98e4) {
      setSave({ s: "error", msg: "Too large to save \u2014 use smaller photos" });
      return;
    }
    setSave({ s: "saving", msg: "" });
    try {
      const r = await HZ.repo();
      await r.invitations.update(id, changed);
      for (const k in changed) saved.current[k] = JSON.stringify(changed[k]);
      if ("slug" in changed) setSlugErr("");
      const still = Object.keys(formRef.current || {}).some((k) => saved.current[k] !== JSON.stringify(formRef.current[k]));
      setSave({ s: still ? "dirty" : "saved", msg: "" });
      if (still) {
        clearTimeout(timer.current);
        timer.current = setTimeout(flush, 900);
      }
      try {
        HZ.emit("*");
      } catch (e) {
      }
    } catch (e) {
      const m = errText(e);
      if (/link is taken/i.test(m)) {
        setSlugErr("That link is already used by another invitation \u2014 choose another.");
        setSave({ s: "error", msg: "Link already taken" });
      } else setSave({ s: "error", msg: m });
    }
  }, [id]);
  const update = useCallback((fn) => {
    setForm((f) => f ? fn(f) : f);
    setSave((s) => s.s === "saving" ? s : { s: "dirty", msg: "" });
    clearTimeout(timer.current);
    timer.current = setTimeout(flush, 1100);
  }, [flush]);
  const set = useCallback((k, v) => update((f) => ({ ...f, [k]: v })), [update]);
  useEffect(() => {
    const h = (e) => {
      if (save.s === "dirty" || save.s === "saving" || save.s === "error") {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", h);
    return () => window.removeEventListener("beforeunload", h);
  }, [save.s]);
  useEffect(() => () => {
    clearTimeout(timer.current);
  }, []);
  const go = (s) => {
    setSec(s);
    window.scrollTo({ top: 0, behavior: "smooth" });
    try {
      history.replaceState(null, "", "#/builder/" + id + "?tab=" + s);
    } catch (e) {
    }
  };
  const filled = useRef(false);
  useEffect(() => {
    if (!form || filled.current) return;
    filled.current = true;
    fillMissing(form, update).then((n) => {
      if (n) ui.toast(n === 1 ? "1 missing translation filled \u2014 marked Auto, please check it" : n + " missing translations filled \u2014 marked Auto, please check them", { ms: 6e3 });
    });
  }, [form, update]);
  const langCtx = useMemo(() => ({ lang, setLang }), [lang]);
  if (loadErr) return /* @__PURE__ */ React.createElement("main", { className: "hzs-wrap" }, /* @__PURE__ */ React.createElement(Empty, { icon: I.alert, title: "This invitation couldn't be opened", text: errText(loadErr) }, /* @__PURE__ */ React.createElement(LinkButton, { to: "/dashboard", variant: "primary", icon: I.back }, "Back to weddings")));
  if (!form) return /* @__PURE__ */ React.createElement("main", { className: "hzb" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-rail" }, /* @__PURE__ */ React.createElement(Skel, { h: 300, r: 16 })), /* @__PURE__ */ React.createElement("div", { className: "hzb-main" }, /* @__PURE__ */ React.createElement(Skel, { h: 60, r: 16 }), /* @__PURE__ */ React.createElement(Skel, { h: 360, r: 18 })));
  const isEA = form.templateId === EA;
  const done = {
    invite: !!(form.groomName && form.brideName),
    events: (form.events || []).some((e) => e.date),
    share: form.status === "active"
  };
  const link = HZ.base() + "#/i/" + form.slug;
  const props = { form, set, update, isEA, go, ui, lang, tid: form.templateId || "blush-swan" };
  const copyLink = () => copyText(link).then(() => ui.toast("Invitation link copied"));
  return /* @__PURE__ */ React.createElement(EdLang.Provider, { value: langCtx }, /* @__PURE__ */ React.createElement("div", { className: "hzb-bar" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-bar-in" }, /* @__PURE__ */ React.createElement(Button, { variant: "ghost", size: "sm", icon: I.back, onClick: () => nav("/dashboard"), "aria-label": "Back to weddings", title: "Back to weddings" }), /* @__PURE__ */ React.createElement("div", { className: "hzb-names" }, (form.groomName || "Groom") + " & " + (form.brideName || "Bride")), /* @__PURE__ */ React.createElement(SaveState, { s: save, onRetry: flush }), /* @__PURE__ */ React.createElement("div", { className: "hzb-lang", style: { marginLeft: "auto" } }, /* @__PURE__ */ React.createElement("span", { className: "lbl" }, "Writing in"), /* @__PURE__ */ React.createElement(Seg, { value: lang, onChange: setLang, items: [{ id: "sw", label: "Kiswahili" }, { id: "en", label: "English" }] })), /* @__PURE__ */ React.createElement("div", { style: { display: "flex", gap: 8, alignItems: "center" } }, /* @__PURE__ */ React.createElement("label", { className: "hzs-row hzb-hide-sm", style: { gap: 8, fontSize: 13, color: "var(--ink2)", cursor: "pointer" } }, /* @__PURE__ */ React.createElement(Switch, { on: form.status === "active", onChange: (v) => set("status", v ? "active" : "draft"), label: "Live" }), /* @__PURE__ */ React.createElement("span", { style: { whiteSpace: "nowrap" } }, form.status === "active" ? "Live" : "Draft")), /* @__PURE__ */ React.createElement(LinkButton, { to: "/guests/" + id, variant: "secondary", size: "sm", icon: I.users, className: "hzb-hide-sm" }, "Guests"), /* @__PURE__ */ React.createElement(Button, { variant: "primary", size: "sm", icon: I.link, onClick: copyLink, className: "hzb-hide-sm" }, "Copy link"), /* @__PURE__ */ React.createElement("span", { className: "hzb-only-sm" }, /* @__PURE__ */ React.createElement(Menu, { label: "More", items: [
    { label: form.status === "active" ? "Live \u2014 tap to make draft" : "Draft \u2014 tap to make live", icon: form.status === "active" ? I.pause : I.play, onClick: () => set("status", form.status === "active" ? "draft" : "active") },
    { label: "Guests & replies", icon: I.users, onClick: () => nav("/guests/" + id) },
    { label: "Check-in at the door", icon: I.scan, onClick: () => nav("/scan/" + id) },
    { label: "Copy invitation link", icon: I.link, onClick: copyLink },
    { label: "Open the card", icon: I.open, onClick: () => window.open(link, "_blank") }
  ] }))))), /* @__PURE__ */ React.createElement("main", { className: "hzb" }, /* @__PURE__ */ React.createElement("nav", { className: "hzb-rail", "aria-label": "Sections" }, SECTIONS.map((s) => /* @__PURE__ */ React.createElement("a", { key: s.id, className: cx(sec === s.id && "on"), onClick: () => go(s.id), role: "button", tabIndex: 0, onKeyDown: (e) => e.key === "Enter" && go(s.id) }, /* @__PURE__ */ React.createElement(s.icon, { size: 17 }), s.label, done[s.id] ? /* @__PURE__ */ React.createElement(I.check, { size: 15, className: "ok" }) : null)), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 18, padding: "14px 12px", borderTop: "1px solid var(--line)", display: "grid", gap: 8 } }, /* @__PURE__ */ React.createElement(LinkButton, { to: "/guests/" + id, variant: "secondary", size: "sm", icon: I.users, style: { width: "100%" } }, "Guests & replies"), /* @__PURE__ */ React.createElement(LinkButton, { to: "/scan/" + id, variant: "ghost", size: "sm", icon: I.scan, style: { width: "100%" } }, "Check-in at the door"))), /* @__PURE__ */ React.createElement("div", { className: "hzb-main" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-tabs" }, /* @__PURE__ */ React.createElement("div", { className: "hzs-tabs" }, SECTIONS.map((s) => /* @__PURE__ */ React.createElement("button", { key: s.id, ref: sec === s.id ? (el) => {
    if (el && el.parentElement) {
      const p = el.parentElement;
      p.scrollTo({ left: el.offsetLeft - (p.clientWidth - el.offsetWidth) / 2, behavior: "smooth" });
    }
  } : null, className: cx("hzs-tab", sec === s.id && "on"), onClick: () => go(s.id) }, /* @__PURE__ */ React.createElement(s.icon, { size: 14 }), s.label)))), /* @__PURE__ */ React.createElement(AnimatePresence, { mode: "wait", initial: false }, /* @__PURE__ */ React.createElement(motion.div, { key: sec, initial: { opacity: 0, y: 8 }, animate: { opacity: 1, y: 0 }, exit: { opacity: 0, y: -4 }, transition: { duration: 0.2 }, style: { display: "flex", flexDirection: "column", gap: 18 } }, sec === "design" ? /* @__PURE__ */ React.createElement(DesignSec, { ...props }) : null, sec === "invite" ? /* @__PURE__ */ React.createElement(InviteSec, { ...props }) : null, sec === "events" ? /* @__PURE__ */ React.createElement(EventsSec, { ...props }) : null, sec === "dress" ? /* @__PURE__ */ React.createElement(DressSec, { ...props }) : null, sec === "gifts" ? /* @__PURE__ */ React.createElement(GiftsSec, { ...props }) : null, sec === "words" ? /* @__PURE__ */ React.createElement(WordsSec, { ...props }) : null, sec === "share" ? /* @__PURE__ */ React.createElement(ShareSec, { ...props, id, link, slugErr, setSlugErr, nav }) : null)), /* @__PURE__ */ React.createElement(StepNav, { sec, go })), /* @__PURE__ */ React.createElement("aside", { className: "hzb-prev" }, /* @__PURE__ */ React.createElement(Preview, { form, lang, setLang }))), /* @__PURE__ */ React.createElement(Button, { variant: "primary", icon: I.eye, className: "hzb-fab", onClick: () => setPrevOpen(true) }, "Preview"), /* @__PURE__ */ React.createElement(AnimatePresence, null, prevOpen ? /* @__PURE__ */ React.createElement(PreviewSheet, { form, lang, setLang, onClose: () => setPrevOpen(false) }) : null));
}
function SaveState({ s, onRetry }) {
  if (s.s === "saving") return /* @__PURE__ */ React.createElement(Badge, { tone: "info" }, /* @__PURE__ */ React.createElement("span", { className: "hzs-dot", style: { animation: "hzs-pulse 1s infinite" } }), "Saving\u2026", /* @__PURE__ */ React.createElement("style", null, "@keyframes hzs-pulse{50%{opacity:.3}}"));
  if (s.s === "dirty") return /* @__PURE__ */ React.createElement(Badge, null, "Editing\u2026");
  if (s.s === "error") return /* @__PURE__ */ React.createElement("button", { className: "hzs-badge bad", onClick: onRetry, style: { border: 0, cursor: "pointer" }, title: "Tap to try again" }, /* @__PURE__ */ React.createElement(I.alert, { size: 12 }), " ", s.msg || "Not saved", " \xB7 retry");
  return /* @__PURE__ */ React.createElement(Badge, { tone: "ok" }, /* @__PURE__ */ React.createElement(I.check, { size: 12 }), "Saved");
}
function StepNav({ sec, go }) {
  const i = SECTIONS.findIndex((s) => s.id === sec);
  const prev = SECTIONS[i - 1], next = SECTIONS[i + 1];
  return /* @__PURE__ */ React.createElement("div", { className: "hzs-between", style: { marginTop: 6, gap: 8 } }, prev ? /* @__PURE__ */ React.createElement(Button, { variant: "ghost", icon: I.back, onClick: () => go(prev.id), style: { minWidth: 0 } }, /* @__PURE__ */ React.createElement("span", { className: "hzb-hide-sm" }, prev.label), /* @__PURE__ */ React.createElement("span", { className: "hzb-only-sm" }, "Back")) : /* @__PURE__ */ React.createElement("span", null), next ? /* @__PURE__ */ React.createElement(Button, { variant: "secondary", iconRight: I.right, onClick: () => go(next.id), style: { minWidth: 0 } }, "Next: ", next.label) : null);
}
function LangNote() {
  const { lang, setLang } = useContext2(EdLang);
  const other = lang === "sw" ? "en" : "sw";
  return /* @__PURE__ */ React.createElement(Note, { tone: "info", icon: I.languages }, "You're writing in ", /* @__PURE__ */ React.createElement("b", null, LANG_NAME[lang]), ". The ", LANG_NAME[other], " version fills itself and shows under each box \u2014", " ", /* @__PURE__ */ React.createElement("button", { type: "button", onClick: () => setLang(other), style: { border: 0, background: "none", padding: 0, color: "var(--gold)", cursor: "pointer", font: "inherit", textDecoration: "underline" } }, "switch to ", LANG_NAME[other]), " to check or change it.");
}
var SAMPLE_GUEST = { name: "Fatma Juma", code: "DEMO01", rsvpStatus: "pending", companions: 0, maxCompanions: 0, dietary: "", checkedIn: false };
function useFeed(frameRef, form, lang, nonce) {
  const ready = useRef(false);
  const last = useRef(null);
  const send = useCallback(() => {
    const w = frameRef.current && frameRef.current.contentWindow;
    if (!w || !ready.current || !last.current) return;
    w.postMessage(last.current, window.location.origin);
  }, [frameRef]);
  useEffect(() => {
    const h = (e) => {
      if (e.origin === window.location.origin && e.data && e.data.type === "hz-preview-ready" && frameRef.current && e.source === frameRef.current.contentWindow) {
        ready.current = true;
        send();
      }
    };
    window.addEventListener("message", h);
    return () => window.removeEventListener("message", h);
  }, [send, frameRef]);
  useEffect(() => {
    const t = setTimeout(() => {
      last.current = { type: "hz-preview", data: form, lang, guest: SAMPLE_GUEST, nonce, autoOpen: true };
      send();
    }, 350);
    return () => clearTimeout(t);
  }, [form, lang, nonce, send]);
}
function PhoneFrame({ form, lang, height }) {
  const ref = useRef(null);
  const box = useRef(null);
  const [scale, setScale] = useState(0.92);
  const [nonce, setNonce] = useState(0);
  useFeed(ref, form, lang, nonce);
  useEffect(() => {
    const el = box.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => setScale(el.clientWidth / 390));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return /* @__PURE__ */ React.createElement("div", { className: "hzb-phone", style: height ? { maxWidth: Math.round(height * 390 / 780) + 22 } : null }, /* @__PURE__ */ React.createElement("div", { className: "hzb-screen", ref: box }, /* @__PURE__ */ React.createElement("iframe", { ref, src: "./#/preview", title: "Live preview", style: { transform: "scale(" + scale + ")" } })), /* @__PURE__ */ React.createElement("div", { style: { display: "flex", justifyContent: "center", paddingTop: 9 } }, /* @__PURE__ */ React.createElement("button", { onClick: () => setNonce((n) => n + 1), style: { border: 0, background: "transparent", color: "rgba(251,248,242,.7)", fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 6 } }, /* @__PURE__ */ React.createElement(I.refresh, { size: 12 }), "Reload preview")));
}
function Preview({ form, lang, setLang }) {
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "hzs-between", style: { marginBottom: 12 } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-eyebrow", style: { fontSize: 10 } }, "Live preview"), /* @__PURE__ */ React.createElement(Seg, { value: lang, onChange: setLang, items: [{ id: "sw", label: "SW" }, { id: "en", label: "EN" }] })), /* @__PURE__ */ React.createElement(PhoneFrame, { form, lang }), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { textAlign: "center", marginTop: 12 } }, "Guests open the card in Kiswahili and can switch to English."));
}
function PreviewSheet({ form, lang, setLang, onClose }) {
  const h = typeof window !== "undefined" ? Math.min(window.innerHeight - 150, 760) : 680;
  return /* @__PURE__ */ React.createElement(Modal, { onClose, width: 440, label: "Preview" }, /* @__PURE__ */ React.createElement("div", { style: { padding: "14px 16px 18px", background: "var(--bg)" } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between", style: { marginBottom: 12 } }, /* @__PURE__ */ React.createElement(Seg, { value: lang, onChange: setLang, items: [{ id: "sw", label: "Kiswahili" }, { id: "en", label: "English" }] }), /* @__PURE__ */ React.createElement(Button, { variant: "ghost", size: "sm", icon: I.x, onClick: onClose, "aria-label": "Close preview" })), /* @__PURE__ */ React.createElement(PhoneFrame, { form, lang, height: h })));
}
var HIDE = "__hide__";
function OvField({ tid, k, label, hint, form, update, area, canHide }) {
  const { lang, setLang } = useContext2(EdLang);
  const def = useMemo(() => defaultsFor(tid), [tid]);
  const pair = useMemo(() => ovPair(tid, k), [tid, k]);
  const path = ovPath(tid, k);
  const tw = useTwin({ path, pair, form, update, kind: "text" });
  const d = { en: def("en", k), sw: def("sw", k) };
  const [focus, setFocus] = useState(false);
  const [txt, setTxt] = useState("");
  const shown = focus ? txt : tw.v[lang] || d[lang];
  const changed = !!(tw.v.en.trim() || tw.v.sw.trim());
  const long = area || Math.max(d.en.length, d.sw.length, shown.length) > 64;
  const Tag = long ? "textarea" : "input";
  const onChange = (e) => {
    const v = e.target.value;
    setTxt(v);
    tw.type(lang, v.trim() === d[lang].trim() ? "" : v);
  };
  const reset = () => update((f) => setAutoFlag(pair.put(pair.put(f, "en", ""), "sw", ""), path, null));
  const hidden = tw.v.en === HIDE || tw.v.sw === HIDE;
  const hide = () => update((f) => setAutoFlag(pair.put(pair.put(f, "en", HIDE), "sw", HIDE), path, null));
  if (hidden) {
    return /* @__PURE__ */ React.createElement("div", { className: "hzb-ov" }, /* @__PURE__ */ React.createElement("div", { className: "k" }, /* @__PURE__ */ React.createElement("span", null, label || humanKey(k)), /* @__PURE__ */ React.createElement("span", { className: "chg" }, "hidden")), /* @__PURE__ */ React.createElement("div", { className: "hzb-hidden" }, /* @__PURE__ */ React.createElement("span", null, "Not shown on the card"), /* @__PURE__ */ React.createElement("button", { type: "button", onClick: reset }, /* @__PURE__ */ React.createElement(I.eye, { size: 13 }), "Show again")));
  }
  return /* @__PURE__ */ React.createElement("div", { className: "hzb-ov" }, /* @__PURE__ */ React.createElement("div", { className: "k" }, /* @__PURE__ */ React.createElement("span", null, label || humanKey(k)), changed ? /* @__PURE__ */ React.createElement("span", { className: "chg" }, "changed") : null, /* @__PURE__ */ React.createElement(AutoChip, { tw, lang }), /* @__PURE__ */ React.createElement("span", { style: { marginLeft: "auto", display: "inline-flex", gap: 2 } }, changed ? /* @__PURE__ */ React.createElement("button", { type: "button", className: "rs", onClick: reset, title: "Go back to the template's own words" }, /* @__PURE__ */ React.createElement(I.undo, { size: 12 }), "Reset") : null, canHide ? /* @__PURE__ */ React.createElement("button", { type: "button", className: "rs", onClick: hide, title: "Take this line off the card" }, /* @__PURE__ */ React.createElement(I.x, { size: 12 }), "Hide") : null)), /* @__PURE__ */ React.createElement(
    Tag,
    {
      className: cx(long ? "hzs-textarea" : "hzs-input", tw.auto === lang && "hzs-is-auto"),
      rows: long ? 2 : void 0,
      value: shown,
      lang,
      maxLength: 400,
      onFocus: () => {
        setTxt(tw.v[lang] || d[lang]);
        setFocus(true);
      },
      onBlur: () => setFocus(false),
      onChange,
      placeholder: d[lang] || "Leave empty to keep the template's words"
    }
  ), /* @__PURE__ */ React.createElement(OtherSide, { tw, lang, setLang, fb: d }), hint ? /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { marginTop: 2 } }, hint) : null);
}
var KEY_NAMES = {
  tapSeal: "Tap the seal",
  tap: "Tap the seal",
  tapCard: "Tap the card",
  forYou: "\u201CFor\u201D (above the guest's name)",
  forGuest: "\u201CFor\u201D (above the guest's name)",
  scroll: "Scroll hint",
  scrollDown: "Scroll hint",
  weddingDay: "Line above your names",
  invited: "Line above your names",
  invitedLong: "Line above your names",
  beginsIn: "Countdown heading",
  cdTitle: "Countdown title",
  counting: "Countdown heading",
  rsvpBefore: "Reply-by line",
  confirmTitle: "Reply heading",
  confirmSub: "Reply text",
  clickToOpen: "Open the reply envelope",
  yourName: "\u201CYour name\u201D",
  attendQ: "Will you attend?",
  accept: "Accept button",
  decline: "Decline button",
  guestsAttending: "Number of guests",
  submit: "Send button",
  rsvpDone: "Thank-you after replying",
  rsvpWhats: "Reply on WhatsApp",
  yourCode: "Your entry code",
  scanHint: "Show this at the door",
  checkedInBadge: "Checked-in badge",
  hopeToSee: "Closing line",
  footer: "Footer",
  dressTitle: "Dress code title",
  dressText: "Dress code text",
  schedule: "Programme title",
  location: "Venue title",
  openInMaps: "Open in Maps",
  openMaps: "Open in Maps",
  addToCalendar: "Add to calendar",
  addCal: "Add to calendar",
  copy: "Copy button",
  copied: "Copied",
  giftTitle: "Gifts title",
  contactsTitle: "Contacts title"
};
function humanKey(k) {
  if (KEY_NAMES[k]) return KEY_NAMES[k];
  const s = k.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/Eye$/, " (small heading)").toLowerCase();
  return s.charAt(0).toUpperCase() + s.slice(1);
}
function DesignSec({ form, set }) {
  const T = HZ.templates || [];
  return /* @__PURE__ */ React.createElement(Section, { icon: I.palette, title: "Choose the design", sub: "You can switch at any time \u2014 your words, events and guests stay the same." }, /* @__PURE__ */ React.createElement("div", { className: "hzb-tpl" }, T.map((t) => /* @__PURE__ */ React.createElement("button", { key: t.id, className: cx("hzb-tplc", form.templateId === t.id && "on"), onClick: () => set("templateId", t.id), "aria-pressed": form.templateId === t.id }, /* @__PURE__ */ React.createElement("div", { style: { aspectRatio: "4 / 5", background: (t.palette || [])[0] || "#eee", overflow: "hidden" } }, /* @__PURE__ */ React.createElement("img", { src: t.previewImage, alt: "", loading: "lazy", style: { width: "100%", height: "100%", objectFit: "cover", objectPosition: "center top", display: "block" } })), /* @__PURE__ */ React.createElement("div", { style: { padding: "10px 12px 12px" } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between" }, /* @__PURE__ */ React.createElement("span", { style: { fontWeight: 500, fontSize: 14 } }, t.name), form.templateId === t.id ? /* @__PURE__ */ React.createElement(I.okCircle, { size: 16, style: { color: "var(--ok)" } }) : null), /* @__PURE__ */ React.createElement("div", { style: { display: "flex", gap: 4, marginTop: 7 } }, (t.palette || []).slice(0, 4).map((c) => /* @__PURE__ */ React.createElement("span", { key: c, style: { width: 12, height: 12, borderRadius: 99, background: c, border: "1px solid rgba(0,0,0,.08)" } }))), t.id === EA ? /* @__PURE__ */ React.createElement("div", { style: { fontSize: 11, color: "var(--gold)", marginTop: 7 } }, "Dress-code photos") : null)))));
}
var STYLES = [
  { value: "caps", label: "Small capitals" },
  { value: "lead", label: "Gold serif" },
  { value: "names", label: "Names \u2014 bold" },
  { value: "body", label: "Sentence \u2014 italic" },
  { value: "script", label: "Script \u2014 large" },
  { value: "gold", label: "Gold italic" }
];
var WHO = [
  { id: "families", t: "Both families", s: "The families of \u2026 and \u2026" },
  { id: "sisters", t: "Sisters of the bride", s: "The sisters of the bride request\u2026 \u2014 names optional" },
  { id: "brothers", t: "Brothers of the groom", s: "The brothers of the groom request\u2026 \u2014 names optional" },
  { id: "relatives", t: "Other relatives", s: "Aunts, uncles, grandparents, the family of\u2026" },
  { id: "brideParents", t: "Parents of the bride", s: "Mr & Mrs \u2026 request\u2026 their daughter" },
  { id: "groomParents", t: "Parents of the groom", s: "Mr & Mrs \u2026 request\u2026 their son" },
  { id: "couple", t: "The couple", s: "Together with their families\u2026" },
  { id: "blank", t: "Write my own", s: "Start from an empty line" }
];
function famWords(tid) {
  const t = defaultsFor(tid), e = defaultsFor(EA);
  const g = (lang, a, b) => t(lang, a) || t(lang, b) || e(lang, a);
  return (lang, k) => k === "pre" ? g(lang, "familyPre", "familiesOf") : k === "and" ? g(lang, "familyAnd", "and") : g(lang, "familyPost", "inviteLine");
}
var both = (style, en, sw) => ({ k: rid(), style, en, sw: sw == null ? en : sw });
var withLines = (f, arr) => {
  const a = {};
  for (const k in f.autoT || {}) if (!/^wl\./.test(k)) a[k] = f.autoT[k];
  for (const l of arr) a["wl." + l.k] = "both";
  return { ...f, wordingLines: arr, autoT: a };
};
var REL = {
  sisters: { en: "sisters", sw: "Dada", kin: { bride: ["sister", "dada yao"], groom: ["brother", "kaka yao"] } },
  brothers: { en: "brothers", sw: "Kaka", kin: { bride: ["sister", "dada yao"], groom: ["brother", "kaka yao"] } },
  aunts: { en: "aunts", sw: "Shangazi", kin: { bride: ["niece", "mpwa wao"], groom: ["nephew", "mpwa wao"] } },
  uncles: { en: "uncles", sw: "Wajomba", kin: { bride: ["niece", "mpwa wao"], groom: ["nephew", "mpwa wao"] } },
  grandparents: { en: "grandparents", sw: "Babu na Bibi", kin: { bride: ["granddaughter", "mjukuu wao"], groom: ["grandson", "mjukuu wao"] } },
  family: { en: "family", sw: "Familia", kin: { bride: ["daughter", "binti yao"], groom: ["son", "mwana wao"] } }
};
var REL_LABEL = { sisters: "Sisters", brothers: "Brothers", aunts: "Aunts", uncles: "Uncles", grandparents: "Grandparents", family: "The family" };
function relLines(form, x, G, B) {
  const r = REL[x.rel] || REL.sisters, side = x.side === "groom" ? "groom" : "bride";
  const who = side === "bride" ? B : G, other = side === "bride" ? G : B;
  const one = x.rel === "family";
  const names = x.showNames ? (x.names || "").trim() : "";
  const add = x.withName ? " **" + who + "**" : "";
  const enLead = (names ? r.en.charAt(0).toUpperCase() + r.en.slice(1) : "The " + r.en) + " of the " + side + add;
  const swLead = r.sw + (one ? " ya " : " wa ") + (side === "bride" ? "bibi harusi" : "bwana harusi") + add;
  const [kEn, kSw] = r.kin[side];
  return [
    ...names ? [both("names", "**" + names + "**", "**" + HZ.honor(names, "sw") + "**")] : [],
    both("lead", enLead, swLead),
    both(
      "body",
      (one ? "requests" : "request") + " the honour of your presence at the wedding of their beloved " + kEn,
      (one ? "inakuomba" : "wanakuomba") + " kwa heshima uhudhurie harusi ya " + kSw + " mpendwa"
    ),
    both("script", who + " & " + other)
  ];
}
function buildPreset(id, form, x) {
  const G = (form.groomName || "").trim() || "Groom", B = (form.brideName || "").trim() || "Bride";
  const fw = famWords(form.templateId);
  const fam = (en) => ({ en: en.trim(), sw: HZ.honor(en.trim(), "sw") });
  const names = (x.names || "").trim();
  switch (id) {
    case "families": {
      const gf = x.gf && x.gf === form.groomFamily && (form.groomFamilySw || "").trim() ? { en: x.gf.trim(), sw: form.groomFamilySw.trim() } : fam(x.gf || "");
      const bf = x.bf && x.bf === form.brideFamily && (form.brideFamilySw || "").trim() ? { en: x.bf.trim(), sw: form.brideFamilySw.trim() } : fam(x.bf || "");
      const join = (lang) => [gf[lang] ? "**" + gf[lang] + "**" : "", bf[lang] ? "**" + bf[lang] + "**" : ""].filter(Boolean).join(" " + fw(lang, "and") + " ");
      return [
        both("lead", fw("en", "pre") + " " + join("en"), fw("sw", "pre") + " " + join("sw")),
        both("body", fw("en", "post"), fw("sw", "post")),
        both("script", G + " & " + B)
      ];
    }
    case "sisters":
    case "brothers":
    case "relatives":
      return relLines(form, x, G, B);
    case "brideParents": {
      const p = fam(x.names || form.brideFamily || "");
      return [
        ...p.en ? [both("names", "**" + p.en + "**", "**" + p.sw + "**")] : [],
        both("body", "request the honour of your presence at the marriage of their beloved daughter", "wanakuomba kwa heshima uhudhurie ndoa ya binti yao mpendwa"),
        both("script", B + " & " + G)
      ];
    }
    case "groomParents": {
      const p = fam(x.names || form.groomFamily || "");
      return [
        ...p.en ? [both("names", "**" + p.en + "**", "**" + p.sw + "**")] : [],
        both("body", "request the honour of your presence at the marriage of their beloved son", "wanakuomba kwa heshima uhudhurie ndoa ya mwana wao mpendwa"),
        both("script", G + " & " + B)
      ];
    }
    case "couple":
      return [
        both("caps", "Together with their families", "Pamoja na familia zao"),
        both("script", G + " & " + B),
        both("body", "joyfully invite you to celebrate their wedding", "wanakualika kwa furaha kusherehekea harusi yao")
      ];
    default:
      return [both("lead", "", "")];
  }
}
function standardLines(form) {
  const fw = famWords(form.templateId);
  const gf = (form.groomFamily || "").trim(), bf = (form.brideFamily || "").trim();
  const gfs = (form.groomFamilySw || "").trim() || (gf ? HZ.honor(gf, "sw") : ""), bfs = (form.brideFamilySw || "").trim() || (bf ? HZ.honor(bf, "sw") : "");
  if (!gf && !bf) return [];
  const j = (a, b, lang) => [a ? "**" + a + "**" : "", b ? "**" + b + "**" : ""].filter(Boolean).join(" " + fw(lang, "and") + " ");
  return [
    { style: "lead", en: fw("en", "pre") + " " + j(gf, bf, "en"), sw: fw("sw", "pre") + " " + j(gfs, bfs, "sw") },
    { style: "body", en: fw("en", "post"), sw: fw("sw", "post") }
  ];
}
function MiniCard({ lines, lang, empty }) {
  const L = (lines || []).map((l) => ({ s: l.style === "name" ? "names" : l.style || "body", t: (lang === "sw" ? l.sw || l.en : l.en || l.sw) || "" }));
  const rich = (t) => String(t).split(/\*\*(.+?)\*\*/g).map((p, i) => i % 2 ? /* @__PURE__ */ React.createElement("span", { key: i, className: "em" }, p) : p);
  return /* @__PURE__ */ React.createElement("div", { className: "hzb-card", lang }, L.some((l) => l.t.trim()) ? L.map((l, i) => /* @__PURE__ */ React.createElement("p", { key: i, className: "l-" + l.s, style: { marginTop: i ? l.s === "body" || l.s === "script" ? 10 : 4 : 0 } }, l.t.trim() ? rich(l.t) : /* @__PURE__ */ React.createElement("span", { className: "ph" }, "(empty line)"))) : /* @__PURE__ */ React.createElement("p", { className: "ph" }, empty || "Nothing here yet"));
}
function InviteSec({ form, set, update, tid, ui }) {
  const { lang } = useContext2(EdLang);
  const keys = (catalog_default[tid] || {}).keys || [];
  const has = (k) => keys.includes(k) || isEAHero(tid, k);
  const opening = OPENING_KEYS.find((k) => has(k));
  const letter = LETTER_KEYS.filter(([k]) => has(k));
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(LangNote, null), /* @__PURE__ */ React.createElement(Section, { icon: I.heart, title: "The couple", sub: "Names are written exactly as you type them, in both languages." }, /* @__PURE__ */ React.createElement("div", { className: "hzb-g2" }, /* @__PURE__ */ React.createElement(Field, { label: "Groom's name" }, /* @__PURE__ */ React.createElement(Input, { value: form.groomName || "", onChange: (e) => set("groomName", e.target.value), placeholder: "Yusuf", maxLength: 40 })), /* @__PURE__ */ React.createElement(Field, { label: "Bride's name" }, /* @__PURE__ */ React.createElement(Input, { value: form.brideName || "", onChange: (e) => set("brideName", e.target.value), placeholder: "Amina", maxLength: 40 }))), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 16 } }, /* @__PURE__ */ React.createElement(Field, { label: "Wax-seal letters", hint: "Up to 9 characters \u2014 initials look best. Leave empty for the couple's initials." }, /* @__PURE__ */ React.createElement(Input, { value: form.sealText || "", onChange: (e) => set("sealText", e.target.value.slice(0, 9)), placeholder: "Y & A", style: { maxWidth: 220, letterSpacing: ".18em", textAlign: "center" } }))), opening ? /* @__PURE__ */ React.createElement("div", { style: { marginTop: 6 } }, /* @__PURE__ */ React.createElement(OvField, { tid, k: opening, label: "Line above your names", form, update, canHide: !isEAHero(tid, opening) })) : null), /* @__PURE__ */ React.createElement(WhoSec, { form, set, update, ui, lang }), /* @__PURE__ */ React.createElement(Section, { icon: I.book, title: "The letter", sub: "The words around your invitation, from the large heading to your message and blessing." }, letter.length ? /* @__PURE__ */ React.createElement("div", { style: { marginBottom: 8 } }, letter.map(([k, l]) => /* @__PURE__ */ React.createElement(OvField, { key: k, tid, k, label: l, form, update, canHide: true }))) : null, /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 18, marginTop: 8 } }, /* @__PURE__ */ React.createElement(Bi, { area: true, rows: 5, label: "Your message to guests", kind: "text", path: "story", pair: pairTop("storyEn", "storySw"), form, update, max: 900, phSw: "Kwa neema ya Allah, tunayo furaha kuwakaribisha\u2026", phEn: "By the grace of Allah, we are delighted to welcome you\u2026", hint: "A few warm sentences \u2014 how you met, or a welcome. Press Enter for a new paragraph. Leave empty to leave it off the card." }), /* @__PURE__ */ React.createElement(Bi, { area: true, rows: 3, label: "Blessing or Qur'an verse", kind: "text", path: "quote", pair: pairTop("quoteEn", "quoteSw"), form, update, max: 400, phSw: "Na katika Ishara Zake\u2026", phEn: "And among His signs\u2026", hint: "Shown in gold italic under your message. Leave empty to leave it off the card." }))));
}
function WhoSec({ form, set, update, ui, lang }) {
  const lines = form.wordingLines || [];
  const custom = lines.length > 0;
  const [pick, setPick] = useState(null);
  const put = (arr) => set("wordingLines", arr.slice(0, 10));
  const move = (i, d) => {
    const a = lines.slice();
    const j = i + d;
    if (j < 0 || j >= a.length) return;
    [a[i], a[j]] = [a[j], a[i]];
    put(a);
  };
  const toStandard = async () => {
    if (await ui.confirm({ title: "Go back to the standard wording?", body: "Your own lines will be removed and the card shows \u201CThe families of \u2026 and \u2026\u201D.", confirmText: "Use standard" })) set("wordingLines", []);
  };
  const editStandard = () => update((f) => withLines(f, buildPreset("families", f, { gf: f.groomFamily || "", bf: f.brideFamily || "" })));
  return /* @__PURE__ */ React.createElement(
    Section,
    {
      icon: I.users,
      title: "Who is inviting?",
      sub: "Choose who the invitation is from \u2014 every line can then be rewritten in your own words, each with its own style.",
      right: custom ? /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.undo, onClick: toStandard }, "Standard wording") : null
    },
    /* @__PURE__ */ React.createElement("div", { className: "hzb-who", role: "list" }, WHO.map((w) => /* @__PURE__ */ React.createElement("button", { key: w.id, type: "button", onClick: () => setPick(w) }, /* @__PURE__ */ React.createElement("b", null, w.t), /* @__PURE__ */ React.createElement("span", null, w.s)))),
    /* @__PURE__ */ React.createElement("div", { style: { marginTop: 20 } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-label" }, "On the card \xB7 ", LANG_NAME[lang]), /* @__PURE__ */ React.createElement(MiniCard, { lines: custom ? lines : standardLines(form), lang, empty: "Add the two families below, or choose who is inviting above." })),
    !custom ? /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 16, marginTop: 18 } }, /* @__PURE__ */ React.createElement(Bi, { label: "Groom's family", kind: "family", path: "groomFamily", pair: pairTop("groomFamily", "groomFamilySw"), form, update, max: 90, phSw: "Bw. na Bi. Salim Juma", phEn: "Mr. & Mrs. Salim Juma" }), /* @__PURE__ */ React.createElement(Bi, { label: "Bride's family", kind: "family", path: "brideFamily", pair: pairTop("brideFamily", "brideFamilySw"), form, update, max: 90, phSw: "Bw. na Bi. Ali Hassan", phEn: "Mr. & Mrs. Ali Hassan", hint: "Titles switch by themselves \u2014 Mr. & Mrs. \u2194 Bw. na Bi." }), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "secondary", icon: I.edit, onClick: editStandard }, "Rewrite these lines myself"))) : /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 10, marginTop: 18 } }, lines.map((l, i) => /* @__PURE__ */ React.createElement(LineRow, { key: l.k, l, i, n: lines.length, form, update, onMove: move, onRemove: () => put(lines.filter((z) => z.k !== l.k)) })), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, flexWrap: "wrap", marginTop: 4 } }, lines.length < 10 ? /* @__PURE__ */ React.createElement(Button, { variant: "secondary", size: "sm", icon: I.plus, onClick: () => put([...lines, both(lines.length ? "body" : "lead", "", "")]) }, "Add a line") : null), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint" }, "Select words and press ", /* @__PURE__ */ React.createElement("b", null, "B"), " to make them stand out (for names). Styles: ", /* @__PURE__ */ React.createElement("b", null, "Small capitals"), " for short openers \xB7 ", /* @__PURE__ */ React.createElement("b", null, "Gold serif"), " for the main line \xB7 ", /* @__PURE__ */ React.createElement("b", null, "Names"), " for people \xB7 ", /* @__PURE__ */ React.createElement("b", null, "Sentence"), " for the invitation \xB7 ", /* @__PURE__ */ React.createElement("b", null, "Script"), " for the couple \xB7 ", /* @__PURE__ */ React.createElement("b", null, "Gold italic"), " for joining words.")),
    /* @__PURE__ */ React.createElement(AnimatePresence, null, pick ? /* @__PURE__ */ React.createElement(PresetModal, { w: pick, form, hasLines: custom, onClose: () => setPick(null), onUse: (arr) => {
      update((f) => withLines(f, arr));
      setPick(null);
      ui.toast("Wording set \u2014 change any line below");
    } }) : null)
  );
}
function PresetModal({ w, form, hasLines, onClose, onUse }) {
  const { lang } = useContext2(EdLang);
  const isRel = w.id === "sisters" || w.id === "brothers" || w.id === "relatives";
  const [x, setX] = useState(() => ({
    gf: form.groomFamily || "",
    bf: form.brideFamily || "",
    names: w.id === "brideParents" ? form.brideFamily || "" : w.id === "groomParents" ? form.groomFamily || "" : "",
    rel: w.id === "brothers" ? "brothers" : w.id === "relatives" ? "aunts" : "sisters",
    side: w.id === "brothers" ? "groom" : "bride",
    showNames: false,
    withName: false
  }));
  const lines = buildPreset(w.id, form, x);
  const ask = w.id === "families" ? "fam" : isRel ? "rel" : w.id === "brideParents" || w.id === "groomParents" ? "Parents' names" : null;
  const sideName = x.side === "bride" ? form.brideName || "the bride" : form.groomName || "the groom";
  return /* @__PURE__ */ React.createElement(Modal, { onClose, width: 520, label: w.t }, /* @__PURE__ */ React.createElement("div", { style: { padding: "20px 22px 22px", display: "grid", gap: 16 } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between" }, /* @__PURE__ */ React.createElement("h2", { className: "hzs-h2", style: { fontSize: 20 } }, w.t), /* @__PURE__ */ React.createElement(Button, { variant: "ghost", size: "sm", icon: I.x, onClick: onClose, "aria-label": "Close" })), ask === "fam" ? /* @__PURE__ */ React.createElement("div", { className: "hzb-g2" }, /* @__PURE__ */ React.createElement(Field, { label: "Groom's family" }, /* @__PURE__ */ React.createElement(Input, { value: x.gf, onChange: (e) => setX({ ...x, gf: e.target.value }), placeholder: "Mr. & Mrs. Salim Juma" })), /* @__PURE__ */ React.createElement(Field, { label: "Bride's family" }, /* @__PURE__ */ React.createElement(Input, { value: x.bf, onChange: (e) => setX({ ...x, bf: e.target.value }), placeholder: "Mr. & Mrs. Ali Hassan" }))) : ask === "rel" ? /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 14 } }, /* @__PURE__ */ React.createElement("div", { className: "hzb-g2" }, /* @__PURE__ */ React.createElement(Field, { label: "Who is inviting?" }, /* @__PURE__ */ React.createElement(Select, { value: x.rel, onChange: (e) => setX({ ...x, rel: e.target.value }), options: Object.keys(REL).map((k) => ({ value: k, label: REL_LABEL[k] })) })), /* @__PURE__ */ React.createElement(Field, { label: "Of the" }, /* @__PURE__ */ React.createElement(Seg, { value: x.side, onChange: (v) => setX({ ...x, side: v }), items: [{ id: "bride", label: "Bride" }, { id: "groom", label: "Groom" }] }))), /* @__PURE__ */ React.createElement(Field, { label: "Write their names on the card?" }, /* @__PURE__ */ React.createElement(Seg, { value: x.showNames ? "yes" : "no", onChange: (v) => setX({ ...x, showNames: v === "yes" }), items: [{ id: "no", label: "No names" }, { id: "yes", label: "Write their names" }] })), x.showNames ? /* @__PURE__ */ React.createElement(Field, { label: "Their names", hint: "e.g. Zainab, Mwanaisha & Rehema" }, /* @__PURE__ */ React.createElement(Input, { value: x.names, onChange: (e) => setX({ ...x, names: e.target.value }), autoFocus: true })) : null, /* @__PURE__ */ React.createElement("label", { className: "hzs-row", style: { gap: 10, fontSize: 14, cursor: "pointer" } }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: x.withName, onChange: (e) => setX({ ...x, withName: e.target.checked }), style: { width: 18, height: 18, accentColor: "#1E1A12" } }), /* @__PURE__ */ React.createElement("span", null, "Add ", sideName, "'s name after it \u2014 \u201C\u2026 of the ", x.side, " ", /* @__PURE__ */ React.createElement("b", { style: { fontWeight: 600 } }, sideName), "\u201D"))) : ask ? /* @__PURE__ */ React.createElement(Field, { label: ask, hint: "e.g. Mr. & Mrs. Ali Hassan \u2014 titles switch to Bw. na Bi. by themselves." }, /* @__PURE__ */ React.createElement(Input, { value: x.names, onChange: (e) => setX({ ...x, names: e.target.value }), autoFocus: true })) : null, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "hzs-label" }, "Preview \xB7 ", LANG_NAME[lang]), /* @__PURE__ */ React.createElement(MiniCard, { lines, lang, empty: "An empty line to write in" })), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { margin: 0 } }, "Written in Kiswahili and English. You can change every word afterwards.", hasLines ? " This replaces the wording you have now." : ""), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { justifyContent: "flex-end", gap: 8 } }, /* @__PURE__ */ React.createElement(Button, { variant: "ghost", onClick: onClose }, "Cancel"), /* @__PURE__ */ React.createElement(Button, { variant: "primary", icon: I.check, onClick: () => onUse(lines) }, "Use this wording"))));
}
function LineRow({ l, i, n, form, update, onMove, onRemove }) {
  const { lang, setLang } = useContext2(EdLang);
  const pair = useMemo(() => pairItem("wordingLines", l.k, "en", "sw"), [l.k]);
  const tw = useTwin({ path: "wl." + l.k, pair, form, update, kind: lineKind(l) });
  const ref = useRef(null);
  const v = tw.v[lang];
  const setStyle = (st) => update((f) => ({ ...f, wordingLines: f.wordingLines.map((z) => z.k === l.k ? { ...z, style: st } : z) }));
  const bold = () => {
    const el = ref.current;
    if (!el) return;
    let a = el.selectionStart, b = el.selectionEnd;
    if (a === b) {
      a = 0;
      b = v.length;
    }
    while (a < b && v[a] === " ") a++;
    while (b > a && v[b - 1] === " ") b--;
    if (a === b) return;
    let out, ca, cb;
    if (v.slice(a - 2, a) === "**" && v.slice(b, b + 2) === "**") {
      out = v.slice(0, a - 2) + v.slice(a, b) + v.slice(b + 2);
      ca = a - 2;
      cb = b - 2;
    } else if (v.slice(a, a + 2) === "**" && v.slice(b - 2, b) === "**" && b - a > 4) {
      out = v.slice(0, a) + v.slice(a + 2, b - 2) + v.slice(b);
      ca = a;
      cb = b - 4;
    } else {
      const inner = v.slice(a, b).replace(/\*\*/g, "");
      out = v.slice(0, a) + "**" + inner + "**" + v.slice(b);
      ca = a + 2;
      cb = a + 2 + inner.length;
    }
    tw.type(lang, out);
    requestAnimationFrame(() => {
      try {
        el.focus();
        el.setSelectionRange(ca, cb);
      } catch (e) {
      }
    });
  };
  const rows = Math.min(4, Math.max(1, Math.ceil((v.length || 1) / 46)));
  return /* @__PURE__ */ React.createElement("div", { className: "hzb-line" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-line-h" }, /* @__PURE__ */ React.createElement("span", { className: "hzb-num" }, i + 1), /* @__PURE__ */ React.createElement(Select, { value: l.style === "name" ? "names" : l.style || "body", onChange: (e) => setStyle(e.target.value), options: STYLES, "aria-label": "Style" }), /* @__PURE__ */ React.createElement("button", { type: "button", className: "hzb-bold", onMouseDown: (e) => e.preventDefault(), onClick: bold, title: "Make the selected words bold (for names)" }, "B"), /* @__PURE__ */ React.createElement(AutoChip, { tw, lang }), /* @__PURE__ */ React.createElement("span", { style: { marginLeft: "auto", display: "flex", gap: 2 } }, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.up, disabled: !i, onClick: () => onMove(i, -1), "aria-label": "Move up" }), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.down, disabled: i === n - 1, onClick: () => onMove(i, 1), "aria-label": "Move down" }), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.trash, onClick: onRemove, "aria-label": "Remove line" }))), /* @__PURE__ */ React.createElement(
    "textarea",
    {
      ref,
      className: cx("hzs-textarea", tw.auto === lang && "hzs-is-auto"),
      rows,
      value: v,
      lang,
      maxLength: 240,
      style: { minHeight: 0, resize: "vertical" },
      placeholder: lang === "sw" ? "Andika mstari huu kwa Kiswahili" : "Write this line in English",
      onChange: (e) => tw.type(lang, e.target.value.replace(/\n{2,}/g, "\n"))
    }
  ), /* @__PURE__ */ React.createElement(OtherSide, { tw, lang, setLang }));
}
var QUICK = [
  { en: "Nikkah Ceremony", sw: "Sherehe ya Nikkah", time: "10:00" },
  { en: "Walima Reception", sw: "Karamu ya Walima", time: "19:00" },
  { en: "Henna Night", sw: "Usiku wa Henna", time: "19:00" },
  { en: "Send-off", sw: "Sherehe ya Kumuaga Bibi Harusi", time: "18:00" },
  { en: "Kitchen Party", sw: "Kitchen Party (Sherehe ya Jikoni)", time: "14:00" },
  { en: "Reception", sw: "Karamu", time: "18:00" }
];
function EventsSec({ form, set, update, ui, lang }) {
  const ev = form.events || [];
  const first = ev.find((e) => e.date);
  const add = (q) => update((f) => ({ ...f, events: [...f.events || [], { k: rid(), name: q ? q.en : "", nameSw: q ? q.sw : "", date: first ? first.date : "", time: q ? q.time : "", venue: first ? first.venue || "" : "", mapsUrl: first ? first.mapsUrl || "" : "", dressCode: "", dressCodeSw: "", notes: "", notesSw: "" }] }));
  const upd = (k, field, v) => update((f) => ({ ...f, events: f.events.map((e) => e.k === k ? { ...e, [field]: v } : e) }));
  const move = (i, d) => {
    const a = ev.slice();
    const j = i + d;
    if (j < 0 || j >= a.length) return;
    [a[i], a[j]] = [a[j], a[i]];
    set("events", a);
  };
  const remove = async (e) => {
    if (await ui.confirm({ title: "Remove this event?", body: "\u201C" + (e.nameSw || e.name || "Untitled event") + "\u201D will be removed from the card.", confirmText: "Remove", tone: "danger" })) update((f) => ({ ...f, events: f.events.filter((z) => z.k !== e.k) }));
  };
  return /* @__PURE__ */ React.createElement(Section, { icon: I.calendar, title: "Events", sub: "The first event sets the countdown and the main venue. On the Kiswahili card times show as Swahili time (16:00 \u2192 Saa 10 jioni)." }, !ev.length ? /* @__PURE__ */ React.createElement("div", { style: { textAlign: "center", padding: "10px 0 6px" } }, /* @__PURE__ */ React.createElement("p", { className: "hzs-muted", style: { margin: "0 0 14px" } }, "No events yet. Add the ceremonies guests are invited to."), /* @__PURE__ */ React.createElement(Button, { variant: "primary", icon: I.plus, onClick: () => {
    add(QUICK[0]);
    add(QUICK[1]);
  } }, "Add Nikkah & Walima")) : /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 14 } }, ev.map((e, i) => /* @__PURE__ */ React.createElement("div", { key: e.k, className: "hzb-item" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-item-h" }, /* @__PURE__ */ React.createElement("span", { className: "hzb-num" }, i + 1), /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0, flex: "1 1 160px" } }, /* @__PURE__ */ React.createElement("div", { style: { fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" } }, (lang === "sw" ? e.nameSw || e.name : e.name || e.nameSw) || "Untitled event"), /* @__PURE__ */ React.createElement("div", { className: "hzs-hint", style: { margin: 0 } }, [e.date ? HZ.dateLong(e.date, lang) : "No date", e.time ? HZ.time(e.time, lang) : ""].filter(Boolean).join(" \xB7 "))), /* @__PURE__ */ React.createElement("div", { style: { marginLeft: "auto", display: "flex", gap: 2 } }, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.up, disabled: !i, onClick: () => move(i, -1), "aria-label": "Move up" }), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.down, disabled: i === ev.length - 1, onClick: () => move(i, 1), "aria-label": "Move down" }), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.trash, onClick: () => remove(e), "aria-label": "Remove event" }))), /* @__PURE__ */ React.createElement("div", { className: "hzb-item-b" }, /* @__PURE__ */ React.createElement(Bi, { label: "Event name", kind: "term", path: "ev." + e.k + ".name", pair: pairItem("events", e.k, "name", "nameSw"), form, update, max: 60, phSw: "Sherehe ya Nikkah", phEn: "Nikkah Ceremony" }), /* @__PURE__ */ React.createElement("div", { className: "hzb-g2" }, /* @__PURE__ */ React.createElement(Field, { label: "Date" }, /* @__PURE__ */ React.createElement(Input, { type: "date", value: e.date || "", onChange: (x) => upd(e.k, "date", x.target.value) })), /* @__PURE__ */ React.createElement(Field, { label: "Time", hint: e.time ? "Kiswahili card: " + HZ.swTime(e.time) : null }, /* @__PURE__ */ React.createElement(Input, { type: "time", value: e.time || "", onChange: (x) => upd(e.k, "time", x.target.value) }))), /* @__PURE__ */ React.createElement(Field, { label: "Venue", hint: "Name, then area \u2014 e.g. \u201CGolden Tulip, Stone Town\u201D." }, /* @__PURE__ */ React.createElement(Input, { value: e.venue || "", onChange: (x) => upd(e.k, "venue", x.target.value), placeholder: "Masjid Jibreel, Stone Town", maxLength: 90 })), /* @__PURE__ */ React.createElement(Field, { label: "Google Maps link", right: e.venue ? /* @__PURE__ */ React.createElement("a", { href: "https://www.google.com/maps/search/" + encodeURIComponent(e.venue), target: "_blank", rel: "noreferrer", style: { color: "var(--gold)", fontSize: 12.5 } }, "Find on Maps \u2197") : null }, /* @__PURE__ */ React.createElement(Input, { value: e.mapsUrl || "", onChange: (x) => upd(e.k, "mapsUrl", x.target.value.trim()), placeholder: "https://maps.app.goo.gl/\u2026", inputMode: "url" })), /* @__PURE__ */ React.createElement(Bi, { label: "Dress code (optional)", kind: "term", path: "ev." + e.k + ".dress", pair: pairItem("events", e.k, "dressCode", "dressCodeSw"), form, update, max: 80, phSw: "Mavazi ya staha", phEn: "Modest attire" }), /* @__PURE__ */ React.createElement(Bi, { label: "Note (optional)", kind: "text", path: "ev." + e.k + ".notes", pair: pairItem("events", e.k, "notes", "notesSw"), form, update, max: 200, phSw: "Wanawake pekee", phEn: "Ladies only" }))))), ev.length ? /* @__PURE__ */ React.createElement("div", { style: { marginTop: 16 } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-label" }, "Add an event"), /* @__PURE__ */ React.createElement("div", { className: "hzs-wrapflex" }, QUICK.map((q) => /* @__PURE__ */ React.createElement("button", { key: q.en, className: "hzs-chip", onClick: () => add(q) }, /* @__PURE__ */ React.createElement(I.plus, { size: 13 }), lang === "sw" ? q.sw : q.en)), /* @__PURE__ */ React.createElement("button", { className: "hzs-chip", onClick: () => add(null) }, /* @__PURE__ */ React.createElement(I.plus, { size: 13 }), lang === "sw" ? "Nyingine" : "Other"))) : null);
}
function compress(file) {
  return new Promise((res, rej) => {
    if (!file || !/^image\//.test(file.type)) return rej(new Error("Please choose a photo (JPG, PNG or WebP)."));
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      const enc = (maxW, q) => {
        const sc = Math.min(1, maxW / img.naturalWidth, maxW * 1.6 / img.naturalHeight);
        const cw = Math.round(img.naturalWidth * sc), ch = Math.round(img.naturalHeight * sc);
        const cv = document.createElement("canvas");
        cv.width = cw;
        cv.height = ch;
        const c = cv.getContext("2d");
        c.fillStyle = "#f6efdd";
        c.fillRect(0, 0, cw, ch);
        c.drawImage(img, 0, 0, cw, ch);
        let d2 = cv.toDataURL("image/webp", q);
        if (!/^data:image\/webp/.test(d2)) d2 = cv.toDataURL("image/jpeg", q);
        return d2;
      };
      let d = enc(960, 0.8);
      if (d.length > 33e4) d = enc(860, 0.72);
      if (d.length > 33e4) d = enc(740, 0.64);
      if (d.length > 33e4) d = enc(640, 0.58);
      res(d);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      rej(new Error("This photo couldn't be read. Try a JPG or PNG."));
    };
    img.src = url;
  });
}
function Upload({ label, value, onChange }) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [over, setOver] = useState(false);
  const ref = useRef(null);
  const pick = (f) => {
    setErr("");
    setBusy(true);
    compress(f).then(onChange).catch((e) => setErr(e.message)).finally(() => setBusy(false));
  };
  const kb = value ? Math.round(value.length * 0.75 / 1024) : 0;
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "hzs-label" }, label), /* @__PURE__ */ React.createElement(
    "div",
    {
      onDragOver: (e) => {
        e.preventDefault();
        setOver(true);
      },
      onDragLeave: () => setOver(false),
      onDrop: (e) => {
        e.preventDefault();
        setOver(false);
        e.dataTransfer.files[0] && pick(e.dataTransfer.files[0]);
      },
      style: { display: "flex", gap: 16, alignItems: "center", padding: 14, borderRadius: 16, border: "1.5px dashed " + (over ? "var(--gold)" : "var(--goldline)"), background: over ? "var(--goldbg)" : "var(--paper)" }
    },
    /* @__PURE__ */ React.createElement("div", { style: { width: 84, aspectRatio: "3 / 4", borderRadius: "42px 42px 8px 8px", overflow: "hidden", background: "var(--goldbg)", border: "1px solid var(--goldline)", flex: "none", display: "grid", placeItems: "center", color: "var(--gold)" } }, value ? /* @__PURE__ */ React.createElement("img", { src: value, alt: "", style: { width: "100%", height: "100%", objectFit: "cover", objectPosition: "center 18%" } }) : /* @__PURE__ */ React.createElement(I.image, { size: 22 })),
    /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0, flex: 1 } }, /* @__PURE__ */ React.createElement("p", { style: { margin: 0, fontSize: 14 } }, busy ? "Preparing photo\u2026" : value ? "Photo ready \xB7 " + kb + " KB" : "No photo yet \u2014 the template's illustration shows."), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { marginTop: 2 } }, "Portrait photos look best. Drag a photo here or choose one."), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, marginTop: 10, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "primary", icon: I.upload, busy, onClick: () => ref.current && ref.current.click() }, value ? "Replace" : "Upload photo"), value ? /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.trash, onClick: () => onChange("") }, "Remove") : null), err ? /* @__PURE__ */ React.createElement("p", { className: "hzs-err" }, err) : null),
    /* @__PURE__ */ React.createElement("input", { ref, type: "file", accept: "image/*", hidden: true, onChange: (e) => {
      e.target.files[0] && pick(e.target.files[0]);
      e.target.value = "";
    } })
  ));
}
function DressSec({ form, set, update, isEA, tid }) {
  const mode = form.dressMode || "";
  const keys = ((catalog_default[tid] || {}).keys || []).filter((k) => DRESS_KEYS.test(k) && !(isEA && k === "dressText"));
  const opts = [["", "Template illustration", "The built-in artwork, as in the demo"], ["ladies", "Ladies only", "One photo \u2014 for a ladies' event"], ["both", "Ladies & gentlemen", "A photo for each"]];
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(LangNote, null), isEA ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Section, { icon: I.shirt, title: "Who is the dress code for?" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-choice" }, opts.map(([v, t, sub]) => /* @__PURE__ */ React.createElement("button", { key: v || "d", className: mode === v ? "on" : "", onClick: () => set("dressMode", v) }, /* @__PURE__ */ React.createElement("span", { className: "hzs-row", style: { gap: 8 } }, /* @__PURE__ */ React.createElement("span", { style: { width: 16, height: 16, borderRadius: 99, border: "1.5px solid " + (mode === v ? "var(--ink)" : "var(--line2)"), display: "grid", placeItems: "center" } }, mode === v ? /* @__PURE__ */ React.createElement("span", { style: { width: 8, height: 8, borderRadius: 99, background: "var(--ink)" } }) : null), /* @__PURE__ */ React.createElement("b", { style: { fontWeight: 500 } }, t)), /* @__PURE__ */ React.createElement("span", { className: "hzs-hint", style: { display: "block", marginTop: 4 } }, sub))))), mode ? /* @__PURE__ */ React.createElement(Section, { icon: I.image, title: "Photos", sub: "Resized automatically. Guests can tap a photo to see it full screen." }, /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 20 } }, /* @__PURE__ */ React.createElement(Upload, { label: "Ladies", value: form.dressImgLadies || "", onChange: (v) => set("dressImgLadies", v) }), /* @__PURE__ */ React.createElement(Bi, { label: "Ladies \u2014 caption (optional)", kind: "text", path: "dressLadies", pair: pairTop("dressLadiesEn", "dressLadiesSw"), form, update, max: 220, phSw: "Gauni ndefu rasmi za rangi ya kijani au krimu.", phEn: "Formal floor-length gowns in emerald or ivory." }), mode === "both" ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { style: { height: 1, background: "var(--line)" } }), /* @__PURE__ */ React.createElement(Upload, { label: "Gentlemen", value: form.dressImgGents || "", onChange: (v) => set("dressImgGents", v) }), /* @__PURE__ */ React.createElement(Bi, { label: "Gentlemen \u2014 caption (optional)", kind: "text", path: "dressGents", pair: pairTop("dressGentsEn", "dressGentsSw"), form, update, max: 220, phSw: "Suti au kanzu na koti.", phEn: "A suit, or kanzu with a coat." })) : null)) : null, /* @__PURE__ */ React.createElement(Section, { icon: I.type, title: "Description", sub: "The text under \u201CDress Code\u201D. Leave empty to keep the template's text." }, /* @__PURE__ */ React.createElement(Bi, { area: true, rows: 3, kind: "text", path: "dressNote", pair: pairTop("dressNoteEn", "dressNoteSw"), form, update, max: 320, phSw: "Wanawake \u2014 gauni ndefu za rangi ya zumaridi\u2026", phEn: "Ladies \u2014 elegant floor-length gowns in soft emerald\u2026" }))) : null, keys.length ? /* @__PURE__ */ React.createElement(Section, { icon: I.type, title: isEA ? "Dress code headings" : "Dress code wording", sub: "Prefilled with the template's words \u2014 change anything, or press Reset to go back." }, keys.map((k) => /* @__PURE__ */ React.createElement(OvField, { key: k, tid, k, form, update }))) : null, !isEA ? /* @__PURE__ */ React.createElement(Note, { tone: "gold", icon: I.image }, "Dress-code photos for ladies and gentlemen are available on the ", /* @__PURE__ */ React.createElement("b", null, "Emerald Arch"), " design. A dress code for each event can be added in ", /* @__PURE__ */ React.createElement("b", null, "Events"), ".") : null);
}
var GIFT_QUICK = [{ label: "M-Pesa", provider: "Vodacom M-Pesa" }, { label: "Mixx by Yas", provider: "Mixx by Yas (Tigo Pesa)" }, { label: "Airtel Money", provider: "Airtel Money" }, { label: "HaloPesa", provider: "HaloPesa" }, { label: "Bank", provider: "" }];
function GiftsSec({ form, set, update }) {
  const gifts = form.gifts || [], contacts = form.contacts || [];
  const updG = (k, f2, v) => update((f) => ({ ...f, gifts: f.gifts.map((g) => g.k === k ? { ...g, [f2]: v } : g) }));
  const updC = (k, f2, v) => update((f) => ({ ...f, contacts: f.contacts.map((g) => g.k === k ? { ...g, [f2]: v } : g) }));
  const wa = HZ.phone(form.whatsappNumber);
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Section, { icon: I.gift, title: "Gifts & contributions", sub: "Each shows on the card with a one-tap copy button. Leave the number empty to hide it." }, /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 12 } }, gifts.map((g) => /* @__PURE__ */ React.createElement("div", { key: g.k, className: "hzb-item" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-item-h" }, /* @__PURE__ */ React.createElement(I.coins, { size: 16, style: { color: "var(--gold)" } }), /* @__PURE__ */ React.createElement("b", { style: { fontWeight: 500 } }, g.label || "Payment"), !String(g.accountNumber || "").trim() ? /* @__PURE__ */ React.createElement(Badge, { tone: "warn" }, "hidden \u2014 no number") : null, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.trash, style: { marginLeft: "auto" }, "aria-label": "Remove", onClick: () => update((f) => ({ ...f, gifts: f.gifts.filter((z) => z.k !== g.k) })) })), /* @__PURE__ */ React.createElement("div", { className: "hzb-item-b" }, /* @__PURE__ */ React.createElement(Bi, { label: "Label", kind: "brand", path: "gf." + g.k + ".label", pair: pairItem("gifts", g.k, "label", "labelSw"), form, update, max: 40, phSw: "M-Pesa", phEn: "M-Pesa" }), /* @__PURE__ */ React.createElement("div", { className: "hzb-g2" }, /* @__PURE__ */ React.createElement(Field, { label: "Provider" }, /* @__PURE__ */ React.createElement(Input, { value: g.provider || "", onChange: (e) => updG(g.k, "provider", e.target.value), placeholder: "Vodacom M-Pesa", maxLength: 50 })), /* @__PURE__ */ React.createElement(Field, { label: "Number / account" }, /* @__PURE__ */ React.createElement(Input, { value: g.accountNumber || "", onChange: (e) => updG(g.k, "accountNumber", e.target.value), placeholder: "0754 000 000", maxLength: 40 }))), /* @__PURE__ */ React.createElement(Bi, { label: "Account name", kind: "brand", path: "gf." + g.k + ".acct", pair: pairItem("gifts", g.k, "accountName", "accountNameSw"), form, update, max: 60, phSw: "Kamati ya Harusi", phEn: "Wedding Committee" }))))), /* @__PURE__ */ React.createElement("div", { className: "hzs-wrapflex", style: { marginTop: 14 } }, GIFT_QUICK.map((q) => /* @__PURE__ */ React.createElement("button", { key: q.label, className: "hzs-chip", onClick: () => update((f) => ({ ...f, gifts: [...f.gifts || [], { k: rid(), label: q.label, labelSw: q.label === "Bank" ? "Benki" : "", provider: q.provider, accountName: "", accountNameSw: "", accountNumber: "" }] })) }, /* @__PURE__ */ React.createElement(I.plus, { size: 13 }), q.label)))), /* @__PURE__ */ React.createElement(Section, { icon: I.phone, title: "Contacts", sub: "People guests can call with questions." }, /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 12 } }, contacts.map((c) => /* @__PURE__ */ React.createElement("div", { key: c.k, className: "hzb-item" }, /* @__PURE__ */ React.createElement("div", { className: "hzb-item-h" }, /* @__PURE__ */ React.createElement(I.user, { size: 16, style: { color: "var(--gold)" } }), /* @__PURE__ */ React.createElement("b", { style: { fontWeight: 500 } }, c.name || "Contact"), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.trash, style: { marginLeft: "auto" }, "aria-label": "Remove", onClick: () => update((f) => ({ ...f, contacts: f.contacts.filter((z) => z.k !== c.k) })) })), /* @__PURE__ */ React.createElement("div", { className: "hzb-item-b" }, /* @__PURE__ */ React.createElement(Bi, { label: "Role", kind: "term", path: "ct." + c.k + ".label", pair: pairItem("contacts", c.k, "label", "labelSw"), form, update, max: 50, phSw: "Mratibu wa Harusi", phEn: "Wedding Coordinator" }), /* @__PURE__ */ React.createElement("div", { className: "hzb-g2" }, /* @__PURE__ */ React.createElement(Field, { label: "Name" }, /* @__PURE__ */ React.createElement(Input, { value: c.name || "", onChange: (e) => updC(c.k, "name", e.target.value), placeholder: "Bi. Khadija Rashid", maxLength: 50 })), /* @__PURE__ */ React.createElement(Field, { label: "Phone" }, /* @__PURE__ */ React.createElement(Input, { value: c.phone || "", onChange: (e) => updC(c.k, "phone", e.target.value), placeholder: "+255 754 111 222", inputMode: "tel", maxLength: 20 }))))))), /* @__PURE__ */ React.createElement(Button, { variant: "secondary", size: "sm", icon: I.plus, style: { marginTop: 14 }, onClick: () => update((f) => ({ ...f, contacts: [...f.contacts || [], { k: rid(), label: "", labelSw: "", name: "", phone: "" }] })) }, "Add contact")), /* @__PURE__ */ React.createElement(Section, { icon: I.chat, title: "Replies on WhatsApp", sub: "Guests who reply on WhatsApp message this number." }, /* @__PURE__ */ React.createElement(Field, { error: form.whatsappNumber && !wa.ok ? "This doesn't look like a WhatsApp number." : null, hint: wa.ok ? "Will open: " + HZ.fmtPhone(wa.num) : "Tanzanian numbers can start with 07\u2026 or 06\u2026" }, /* @__PURE__ */ React.createElement(Input, { value: form.whatsappNumber || "", onChange: (e) => set("whatsappNumber", e.target.value), onBlur: () => wa.ok && set("whatsappNumber", wa.num), placeholder: "0777 123 456", inputMode: "tel", style: { maxWidth: 280 }, className: form.whatsappNumber && !wa.ok ? "bad" : "" }))));
}
var GROUPS = [
  ["Opening & envelope", /^(tap|tapSeal|tapCard|forYou|forGuest|scroll|scrollDown|loading|open)$/],
  ["Countdown", /^(beginsIn|cdTitle|counting|days|hours|minutes|seconds|today)$/],
  ["Programme & venue", /^(schedule\w*|orderOfDay|celebration|programme|location\w*|whereWe|venue|openMaps|openInMaps|mapLink|directions|liveMap|addCal|addToCalendar|calendar)$/],
  ["Gifts, contacts & details", /^(gift\w*|contacts\w*|callNow|details\w*|transport\w*|stay\w*|noBoxed|copy|copied|gallery\w*)$/],
  ["Replies (RSVP)", /^(rsvp\w*|confirm\w*|respond\w*|kindlyRespond|clickToOpen|yourName|attendQ|accept|decline|guestsAttending|songLabel|childrenLabel|dietary|submit|sending|failed|change|whatsapp|greet|name|attending|yes|no|companions|none|notes|attendingBadge|declinedBadge)$/],
  ["Guest pass & entry", /^(yourCode|scanHint|checkedInBadge|codeEye|codeTitle|showDoor|entry\w*)$/],
  ["Guestbook", /^guestbook\w*$/],
  ["Closing", /^(hopeToSee|hope|footer|made|from|wm\w*)$/]
];
function WordsSec({ form, update, tid }) {
  const { lang } = useContext2(EdLang);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(() => /* @__PURE__ */ new Set(["Opening & envelope"]));
  const def = useMemo(() => defaultsFor(tid), [tid]);
  const keys = ((catalog_default[tid] || {}).keys || []).filter((k) => !INVITE_SHOWN.has(k) && !DRESS_KEYS.test(k));
  const ov = form.textOv && form.textOv[tid] || {};
  const val = (k, l) => (ov[l] || {})[k] || def(l, k) || "";
  const groups = GROUPS.map(([g, re]) => [g, keys.filter((k) => re.test(k))]);
  const used = new Set(groups.flatMap((x) => x[1]));
  const rest = keys.filter((k) => !used.has(k));
  if (rest.length) groups.push(["Other", rest]);
  const needle = q.trim().toLowerCase();
  const match = (k) => !needle || [k, humanKey(k), val(k, "sw"), val(k, "en")].some((s) => s.toLowerCase().includes(needle));
  const changedN = new Set([...Object.keys(ov.en || {}), ...Object.keys(ov.sw || {})].filter((k) => keys.includes(k))).size;
  const toggle = (g) => setOpen((s) => {
    const n = new Set(s);
    n.has(g) ? n.delete(g) : n.add(g);
    return n;
  });
  const tname = ((HZ.templates || []).find((t) => t.id === tid) || {}).name || "this design";
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(LangNote, null), /* @__PURE__ */ React.createElement(
    Section,
    {
      icon: I.type,
      title: "All wording",
      sub: "Every other word on " + tname + " \u2014 headings, buttons, the reply form. Prefilled with the template's words: change anything, or press Reset to go back.",
      right: changedN ? /* @__PURE__ */ React.createElement(Badge, { tone: "gold" }, changedN, " changed") : null
    },
    /* @__PURE__ */ React.createElement("div", { style: { position: "relative", marginBottom: 14 } }, /* @__PURE__ */ React.createElement(I.search, { size: 16, style: { position: "absolute", left: 13, top: 13, color: "var(--ink3)" } }), /* @__PURE__ */ React.createElement(Input, { value: q, onChange: (e) => setQ(e.target.value), placeholder: "Search the words on the card\u2026", style: { paddingLeft: 38 } })),
    /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 10 } }, groups.map(([g, ks]) => {
      const list = ks.filter(match);
      if (!list.length) return null;
      const isOpen = !!needle || open.has(g);
      return /* @__PURE__ */ React.createElement("div", { key: g, className: "hzb-grp" }, /* @__PURE__ */ React.createElement("button", { type: "button", onClick: () => toggle(g), "aria-expanded": isOpen }, isOpen ? /* @__PURE__ */ React.createElement(I.down, { size: 16 }) : /* @__PURE__ */ React.createElement(I.right, { size: 16 }), /* @__PURE__ */ React.createElement("b", null, g), /* @__PURE__ */ React.createElement("span", { className: "n" }, list.length)), isOpen ? /* @__PURE__ */ React.createElement("div", null, list.map((k) => /* @__PURE__ */ React.createElement(OvField, { key: k, tid, k, form, update }))) : null);
    })),
    /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { marginTop: 14 } }, "Your changes are kept for ", tname, ". If you switch design, that design keeps its own words. Names, events, gifts and your letter are edited in their own steps.")
  ));
}
function svgToPng(svgEl, size, name) {
  const xml = new XMLSerializer().serializeToString(svgEl);
  const img = new Image();
  img.onload = () => {
    const cv = document.createElement("canvas");
    const pad = Math.round(size * 0.08);
    cv.width = size + pad * 2;
    cv.height = size + pad * 2;
    const c = cv.getContext("2d");
    c.fillStyle = "#fff";
    c.fillRect(0, 0, cv.width, cv.height);
    c.drawImage(img, pad, pad, size, size);
    cv.toBlob((b) => b && downloadFile(name, b, "image/png"), "image/png");
  };
  img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(xml);
}
function ShareSec({ form, set, id, link, slugErr, setSlugErr, ui, nav }) {
  const qr = useRef(null);
  const [slug, setSlug] = useState(form.slug || "");
  useEffect(() => setSlug(form.slug || ""), [form.slug]);
  const commit = () => {
    const s = slug.toLowerCase().replace(/[^a-z0-9-]/g, "").replace(/^-+|-+$/g, "");
    if (s.length < 3) {
      setSlugErr("Use at least 3 letters or numbers.");
      return;
    }
    setSlugErr("");
    if (s !== form.slug) set("slug", s);
    setSlug(s);
  };
  const trash = async () => {
    if (!await ui.confirm({ title: "Delete this invitation?", body: "Guests will no longer be able to open it. It moves to the trash and can be restored by the admin.", confirmText: "Delete", tone: "danger" })) return;
    try {
      await call((r) => r.invitations.trash({ id }));
      ui.toast("Invitation deleted");
      nav("/dashboard");
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
    }
  };
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Section, { icon: I.eye, title: "Live or draft", sub: "While it's a draft, only you can open the card. Make it live before sending invitations." }, /* @__PURE__ */ React.createElement("label", { className: "hzs-row", style: { gap: 12, cursor: "pointer" } }, /* @__PURE__ */ React.createElement(Switch, { on: form.status === "active", onChange: (v) => set("status", v ? "active" : "draft"), label: "Live" }), /* @__PURE__ */ React.createElement("span", null, form.status === "active" ? /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("b", { style: { fontWeight: 500 } }, "Live"), " \u2014 guests can open their invitations") : /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("b", { style: { fontWeight: 500 } }, "Draft"), " \u2014 guests can't open it yet")))), /* @__PURE__ */ React.createElement(Section, { icon: I.users, title: "Guests & invitations", sub: "Each guest gets a personal card with their name and entry code. Add guests, send them on WhatsApp and follow replies and arrivals on the Guests page." }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(LinkButton, { to: "/guests/" + id, variant: "primary", size: "sm", icon: I.users }, "Open guests"), /* @__PURE__ */ React.createElement(LinkButton, { to: "/scan/" + id, variant: "secondary", size: "sm", icon: I.scan }, "Check-in at the door"))), /* @__PURE__ */ React.createElement(Section, { icon: I.link, title: "Main link", sub: "Opens the card without a guest name \u2014 handy for a group chat. Personal links come from the Guests page." }, /* @__PURE__ */ React.createElement(Field, { label: "Link name", error: slugErr || null, hint: !slugErr ? "Letters, numbers and dashes. Changing it breaks links you've already sent." : null }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 0, alignItems: "stretch" } }, /* @__PURE__ */ React.createElement("span", { style: { display: "grid", placeItems: "center", padding: "0 12px", border: "1px solid var(--line2)", borderRight: 0, borderRadius: "12px 0 0 12px", background: "rgba(30,26,18,.03)", color: "var(--ink3)", fontSize: 13.5, whiteSpace: "nowrap" } }, "#/i/"), /* @__PURE__ */ React.createElement(Input, { value: slug, onChange: (e) => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "")), onBlur: commit, onKeyDown: (e) => e.key === "Enter" && commit(), style: { borderRadius: "0 12px 12px 0" }, maxLength: 40, className: slugErr ? "bad" : "" }))), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, marginTop: 14, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Button, { variant: "primary", size: "sm", icon: I.copy, onClick: () => copyText(link).then(() => ui.toast("Link copied")) }, "Copy link"), /* @__PURE__ */ React.createElement("a", { className: "hzs-btn secondary sm", href: link, target: "_blank", rel: "noreferrer" }, /* @__PURE__ */ React.createElement(I.open, { size: 15 }), "Open"))), /* @__PURE__ */ React.createElement(Section, { icon: I.qr, title: "QR code for printed cards", sub: "Opens the invitation when scanned with a phone camera." }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 20, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("div", { ref: qr, style: { padding: 12, borderRadius: 16, background: "#fff", border: "1px solid var(--line)" } }, /* @__PURE__ */ React.createElement(QRCodeSVG, { value: link, size: 150, fgColor: "#1E1A12", level: "M" })), /* @__PURE__ */ React.createElement(Button, { variant: "secondary", size: "sm", icon: I.download, onClick: () => {
    const s = qr.current && qr.current.querySelector("svg");
    s && svgToPng(s, 900, "harusi-" + form.slug + "-qr.png");
  } }, "Download PNG"))), /* @__PURE__ */ React.createElement(Section, { icon: I.image, title: "Photos", sub: "Optional. Paste public image links (for example from Google Photos \u201Ccopy image address\u201D)." }, /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 16 } }, /* @__PURE__ */ React.createElement(Field, { label: "Hero photo link", hint: "Replaces the template's artwork at the top on designs that support it." }, /* @__PURE__ */ React.createElement(Input, { value: form.heroImage || "", onChange: (e) => set("heroImage", e.target.value.trim()), placeholder: "https://\u2026", inputMode: "url" })), /* @__PURE__ */ React.createElement(Field, { label: "Gallery photo links \u2014 one per line, up to 8" }, /* @__PURE__ */ React.createElement(Textarea, { rows: 3, value: (form.gallery || []).join("\n"), onChange: (e) => set("gallery", e.target.value.split("\n").map((x) => x.trim()).filter(Boolean).slice(0, 8)), placeholder: "https://\u2026/photo1.jpg\nhttps://\u2026/photo2.jpg" })))), /* @__PURE__ */ React.createElement(Card, { pad: true, style: { borderColor: "rgba(163,71,58,.22)" } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between", style: { flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h3" }, "Delete invitation"), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { marginTop: 2 } }, "Moves it to the trash. Guests can no longer open it.")), /* @__PURE__ */ React.createElement(Button, { variant: "dangerSoft", size: "sm", icon: I.trash, onClick: trash }, "Delete"))));
}
var builder_default = Builder;
export {
  builder_default as default
};
