// rc/Scan.jsx
import { c as h, u as f, a as S, r as p, t as x, j as e, L as j, A as b, h as k, m as N } from "./index-B4Ch-nvB.js";
import { S as C, a as v, C as I } from "./Dashboard-B6tzCIQb.js";
const Fragment=e.Fragment,jsx=e.jsx,jsxs=e.jsxs;
var ErrIco = h("circle-x", [["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }], ["path", { d: "m15 9-6 6", key: "1uzhvr" }], ["path", { d: "m9 9 6 6", key: "z0biqf" }]]);
var UndoIco = h("undo-2", [["path", { d: "M9 14 4 9l5-5", key: "102s5s" }], ["path", { d: "M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11", key: "f3b9sd" }]]);
var CamIco = h("camera", [["path", { d: "M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z", key: "c1x" }], ["circle", { cx: "12", cy: "13", r: "3", key: "c2x" }]]);
var ZapIco = h("zap", [["path", { d: "M13 2 3 14h9l-1 8 10-12h-9l1-8z", key: "z1x" }]]);
var XIco = h("x", [["path", { d: "M18 6 6 18", key: "x1x" }], ["path", { d: "m6 6 12 12", key: "x2x" }]]);
var GOLD = "#c9a227";
var OK = "#7fc79a";
var BAD = "#e07070";
var PANEL = "#06281f";
var SERIF = "'Cormorant Garamond', serif";
var SANS = "'Jost', sans-serif";
var Lnk = j;
var ShellC = C;
var ScanIco = v;
var CheckIco = I;
var AnP = k;
var BackIco = b;
var extractCode = (raw) => {
  if (!raw) return null;
  let m = /[?&#]code=([A-Za-z0-9]{2,14})/i.exec(raw);
  if (!m) m = /\/i\/[^/&#?]+\/([A-Za-z0-9]{2,14})/i.exec(raw);
  const v2 = (m ? m[1] : raw).trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
  return /^[A-Z0-9]{4,8}$/.test(v2) ? v2 : null;
};
var actx = null;
var tone = (ok) => {
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    actx = actx || new AC();
    if (actx.state === "suspended") actx.resume();
    const t0 = actx.currentTime;
    const mk = (fr, dt, dur, type, g) => {
      const o = actx.createOscillator(), gn = actx.createGain();
      o.type = type || "sine";
      o.frequency.value = fr;
      gn.gain.setValueAtTime(g || 0.055, t0 + dt);
      gn.gain.exponentialRampToValueAtTime(1e-4, t0 + dt + dur);
      o.connect(gn);
      gn.connect(actx.destination);
      o.start(t0 + dt);
      o.stop(t0 + dt + dur + 0.02);
    };
    if (ok) {
      mk(920, 0, 0.09);
      mk(1380, 0.1, 0.13);
    } else {
      mk(185, 0, 0.24, "square", 0.045);
    }
  } catch (_) {
  }
};
var buzz = (ok) => {
  try {
    if (navigator.vibrate) navigator.vibrate(ok ? 25 : [55, 45, 55]);
  } catch (_) {
  }
};
var jsqrPromise = null;
var loadJsQR = () => {
  if (window.jsQR) return Promise.resolve();
  jsqrPromise = jsqrPromise || new Promise((res, rej) => {
    const sc = document.createElement("script");
    sc.src = "assets/jsqr.min.js";
    sc.async = true;
    sc.onload = () => window.jsQR ? res() : rej(new Error("jsQR missing"));
    sc.onerror = () => rej(new Error("jsQR failed to load"));
    document.head.appendChild(sc);
  });
  return jsqrPromise;
};
function ScanPage() {
  const { id: u } = f(), c = u ?? "";
  const { user: y } = S({ redirectOnUnauthenticated: true });
  const [a, l] = p.useState("");
  const [t, i] = p.useState(null);
  const [cam, setCam] = p.useState(null);
  const [camOn, setCamOn] = p.useState(false);
  const [camErr, setCamErr] = p.useState("");
  const [torchOn, setTorchOn] = p.useState(false);
  const [torchOk, setTorchOk] = p.useState(false);
  const videoRef = p.useRef(null);
  const scanRef = p.useRef({ stopped: true, stream: null, track: null, timer: 0 });
  const lastRef = p.useRef({ code: "", at: 0 });
  const utils = x.useUtils();
  const n = x.guests.checkIn.useMutation({
    onSuccess: (s, g) => {
      i({ name: s.guest.name, companions: s.guest.companions, status: s.guest.rsvpStatus, undo: g.undo, already: s.alreadyCheckedIn, checkedInAt: s.guest.checkedInAt });
      l("");
      utils.guests.list.invalidate();
      if (!g.undo) {
        const ok = !s.alreadyCheckedIn;
        setCam({
          ok,
          title: ok ? s.guest.name : "Already inside",
          sub: ok ? s.guest.companions > 0 ? "Karibu! Party of " + (s.guest.companions + 1) : "Karibu! Welcome inside" : s.guest.checkedInAt ? "Scanned at " + new Date(s.guest.checkedInAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) + " \u2014 do not admit again" : "Do not admit again"
        });
        tone(ok);
        buzz(ok);
      }
    },
    onError: (e2, g) => {
      i({ error: "No guest found with code \u201C" + String(g && g.code || "").toUpperCase() + "\u201D" });
      if (!g || !g.undo) {
        setCam({ ok: false, title: "Unknown code", sub: String(g && g.code || "").toUpperCase() + " is not on this guest list" });
        tone(false);
        buzz(false);
      }
    }
  });
  const submit = (code, undo) => {
    const v2 = String(code || "").trim().toUpperCase();
    if (v2.length < 4) return;
    n.mutate({ invitationId: c, code: v2, undo: !!undo });
  };
  const onScan = (raw) => {
    const code = extractCode(raw);
    if (!code) return;
    const now = Date.now();
    if (now - lastRef.current.at < 450) return;
    if (code === lastRef.current.code && now - lastRef.current.at < 3200) return;
    lastRef.current = { code, at: now };
    submit(code, false);
  };
  const scanCbRef = p.useRef(onScan);
  scanCbRef.current = onScan;
  p.useEffect(() => {
    if (!camOn) return void 0;
    const st = scanRef.current;
    st.stopped = false;
    setCamErr("");
    let cancelled = false;
    const stopAll = () => {
      cancelled = true;
      st.stopped = true;
      clearTimeout(st.timer);
      if (st.stream) st.stream.getTracks().forEach((tr) => {
        try {
          tr.stop();
        } catch (_) {
        }
      });
      st.stream = null;
      st.track = null;
      setTorchOn(false);
      setTorchOk(false);
    };
    (async () => {
      if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setCamErr("The camera needs a secure (https) page \u2014 type the code by hand below.");
        return;
      }
      let stream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false
        });
      } catch (_) {
        setCamErr("Camera access was denied \u2014 allow it in your browser, or type the code by hand below.");
        return;
      }
      if (cancelled) {
        stream.getTracks().forEach((tr) => {
          try {
            tr.stop();
          } catch (_) {
          }
        });
        return;
      }
      st.stream = stream;
      const track = stream.getVideoTracks()[0];
      st.track = track;
      try {
        setTorchOk(!!(track.getCapabilities && track.getCapabilities().torch));
      } catch (_) {
      }
      const v2 = videoRef.current;
      if (!v2) {
        stopAll();
        return;
      }
      v2.srcObject = stream;
      try {
        await v2.play();
      } catch (_) {
      }
      const pump = (fn, ms) => {
        const step = async () => {
          if (cancelled || st.stopped) return;
          if (v2.readyState >= 2) {
            try {
              await fn();
            } catch (_) {
            }
          }
          st.timer = setTimeout(step, ms);
        };
        step();
      };
      if ("BarcodeDetector" in window) {
        try {
          const det = new window.BarcodeDetector({ formats: ["qr_code"] });
          pump(async () => {
            const found = await det.detect(v2);
            if (found && found.length && found[0].rawValue) scanCbRef.current(found[0].rawValue);
          }, 110);
          return;
        } catch (_) {
        }
      }
      try {
        await loadJsQR();
      } catch (_) {
        setCamErr("The scanner engine couldn't load \u2014 check your connection, or type the code by hand below.");
        return;
      }
      if (cancelled || st.stopped) return;
      const cv = document.createElement("canvas");
      const cx = cv.getContext("2d", { willReadFrequently: true });
      pump(() => {
        const w2 = v2.videoWidth;
        if (!w2) return;
        const sc = Math.min(1, 620 / w2);
        cv.width = Math.round(w2 * sc);
        cv.height = Math.round(v2.videoHeight * sc);
        cx.drawImage(v2, 0, 0, cv.width, cv.height);
        const img = cx.getImageData(0, 0, cv.width, cv.height);
        const q = window.jsQR(img.data, cv.width, cv.height, { inversionAttempts: "attemptBoth" });
        if (q && q.data) scanCbRef.current(q.data);
      }, 200);
    })();
    return stopAll;
  }, [camOn]);
  p.useEffect(() => {
    if (!cam) return void 0;
    const id = setTimeout(() => setCam(null), 1700);
    return () => clearTimeout(id);
  }, [cam]);
  const toggleTorch = async () => {
    const st = scanRef.current;
    if (!st.track) return;
    const next = !torchOn;
    try {
      await st.track.applyConstraints({ advanced: [{ torch: next }] });
      setTorchOn(next);
    } catch (_) {
    }
  };
  const o = x.guests.list.useQuery({ invitationId: c }, { enabled: !!y });
  return /* @__PURE__ */ jsxs(ShellC, { children: [
    /* @__PURE__ */ jsxs(Lnk, { to: "/dashboard", className: "flex items-center gap-1.5 text-sm opacity-70 hover:opacity-100 mb-6", style: { fontFamily: SANS }, children: [
      /* @__PURE__ */ jsx(BackIco, { size: 15 }),
      " Dashboard"
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "max-w-lg mx-auto text-center", children: [
      /* @__PURE__ */ jsx(ScanIco, { size: 36, className: "mx-auto", style: { color: GOLD } }),
      /* @__PURE__ */ jsx("h1", { className: "text-4xl mt-3", style: { fontFamily: SERIF, fontWeight: 600 }, children: "Door Check-in" }),
      /* @__PURE__ */ jsx("p", { className: "opacity-60 mt-1 text-sm", style: { fontFamily: SANS }, children: o.data ? `${o.data.filter((s) => s.checkedIn).length} of ${o.data.length} guests inside` : "" }),
      !camOn ? /* @__PURE__ */ jsxs(
        "button",
        {
          onClick: () => setCamOn(true),
          className: "mt-7 inline-flex items-center gap-2.5 px-7 py-3.5 rounded-full text-sm uppercase tracking-wider font-semibold cursor-pointer",
          style: { background: GOLD, color: "#04160f", fontFamily: SANS, border: 0, boxShadow: "0 14px 34px -12px rgba(201,162,39,0.55)" },
          children: [
            /* @__PURE__ */ jsx(CamIco, { size: 17 }),
            " Scan with Camera"
          ]
        }
      ) : /* @__PURE__ */ jsxs("div", { className: "mt-7 rounded-2xl overflow-hidden", style: { border: "1px solid rgba(201,162,39,0.4)", background: PANEL, textAlign: "left" }, children: [
        /* @__PURE__ */ jsxs("div", { style: { position: "relative", background: "#010d0a" }, children: [
          /* @__PURE__ */ jsx(
            "video",
            {
              ref: videoRef,
              muted: true,
              playsInline: true,
              autoPlay: true,
              style: { display: "block", width: "100%", aspectRatio: "4 / 3", objectFit: "cover" }
            }
          ),
          [["0%", "0%", "borderLeftWidth", "borderTopWidth"], ["0%", "auto", "borderRightWidth", "borderTopWidth"], ["auto", "0%", "borderLeftWidth", "borderBottomWidth"], ["auto", "auto", "borderRightWidth", "borderBottomWidth"]].map((cn, qi) => /* @__PURE__ */ jsx("div", { "aria-hidden": "true", style: {
            position: "absolute",
            top: cn[0] === "auto" ? "auto" : "7%",
            bottom: cn[0] === "auto" ? "7%" : "auto",
            left: cn[1] === "auto" ? "auto" : "9%",
            right: cn[1] === "auto" ? "9%" : "auto",
            width: 34,
            height: 34,
            border: "0 solid " + GOLD,
            [cn[2]]: 3,
            [cn[3]]: 3,
            borderRadius: cn[0] === "0%" && cn[1] === "0%" ? "8px 0 0 0" : cn[0] === "0%" ? "0 8px 0 0" : cn[1] === "0%" ? "0 0 0 8px" : "0 0 8px 0",
            opacity: 0.95
          } }, qi)),
          /* @__PURE__ */ jsx("div", { "aria-hidden": "true", style: {
            position: "absolute",
            left: "10%",
            right: "10%",
            height: 2,
            top: "8%",
            background: "linear-gradient(90deg, transparent, " + GOLD + ", transparent)",
            boxShadow: "0 0 14px rgba(201,162,39,0.85)",
            animation: "hsDoorScan 2.6s ease-in-out infinite"
          } }),
          /* @__PURE__ */ jsx("style", { children: "@keyframes hsDoorScan{0%,100%{top:8%}50%{top:92%}}" }),
          /* @__PURE__ */ jsx(AnP, { mode: "wait", children: cam ? /* @__PURE__ */ jsxs(
            N.div,
            {
              initial: { opacity: 0, scale: 0.85, y: 8 },
              animate: { opacity: 1, scale: 1, y: 0 },
              exit: { opacity: 0, scale: 0.92 },
              transition: { duration: 0.18 },
              style: {
                position: "absolute",
                left: 12,
                right: 12,
                bottom: 12,
                borderRadius: 14,
                padding: "11px 16px",
                textAlign: "center",
                border: "2px solid " + (cam.ok ? OK : BAD),
                background: cam.ok ? "rgba(4,38,24,0.93)" : "rgba(42,8,10,0.93)",
                boxShadow: "0 12px 30px -10px rgba(0,0,0,0.6)"
              },
              children: [
                /* @__PURE__ */ jsx("p", { style: { margin: 0, fontFamily: SERIF, fontWeight: 600, fontSize: 21, color: cam.ok ? OK : BAD }, children: cam.ok ? "Karibu \u2014 " + cam.title : cam.title }),
                /* @__PURE__ */ jsx("p", { style: { margin: "2px 0 0", fontFamily: SANS, fontSize: 12, opacity: 0.85 }, children: cam.sub })
              ]
            },
            (cam.ok ? "k" : "b") + cam.title + cam.sub
          ) : null }),
          /* @__PURE__ */ jsxs("div", { style: { position: "absolute", top: 10, right: 10, display: "flex", gap: 8 }, children: [
            torchOk ? /* @__PURE__ */ jsx(
              "button",
              {
                onClick: toggleTorch,
                "aria-label": "Torch",
                style: {
                  width: 36,
                  height: 36,
                  borderRadius: "50%",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  border: "1px solid rgba(201,162,39,0.5)",
                  background: torchOn ? "rgba(201,162,39,0.85)" : "rgba(4,22,15,0.75)",
                  color: torchOn ? "#04160f" : GOLD
                },
                children: /* @__PURE__ */ jsx(ZapIco, { size: 15 })
              }
            ) : null,
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: () => setCamOn(false),
                "aria-label": "Close camera",
                style: {
                  width: 36,
                  height: 36,
                  borderRadius: "50%",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  border: "1px solid rgba(201,162,39,0.5)",
                  background: "rgba(4,22,15,0.75)",
                  color: GOLD
                },
                children: /* @__PURE__ */ jsx(XIco, { size: 15 })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { style: { padding: "10px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }, children: [
          /* @__PURE__ */ jsx("p", { style: { margin: 0, fontFamily: SANS, fontSize: 12, opacity: 0.65, lineHeight: 1.5 }, children: camErr || "Point at a guest's QR code \u2014 it checks them in automatically, one after another." }),
          !camErr ? /* @__PURE__ */ jsx(
            N.span,
            {
              animate: { opacity: [1, 0.3, 1] },
              transition: { duration: 1.6, repeat: Infinity, ease: "easeInOut" },
              style: { fontFamily: SANS, fontSize: 10, letterSpacing: "0.22em", textTransform: "uppercase", color: GOLD, whiteSpace: "nowrap" },
              children: "\u25CF Live"
            }
          ) : null
        ] })
      ] }),
      /* @__PURE__ */ jsx("p", { className: "mt-9 mb-3 text-[11px] uppercase tracking-[0.3em] opacity-50", style: { fontFamily: SANS }, children: camOn ? "or type the code by hand" : "enter the code by hand" }),
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row gap-3", children: [
        /* @__PURE__ */ jsx(
          "input",
          {
            value: a,
            onChange: (s) => {
              l(s.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6));
              i(null);
            },
            onKeyDown: (s) => s.key === "Enter" && submit(a, false),
            placeholder: "ENTER CODE",
            className: "flex-1 min-w-0 text-center text-2xl tracking-[0.4em] rounded-xl py-4 bg-transparent outline-none uppercase",
            style: { border: `2px solid ${GOLD}`, color: "#f5e9c8", fontFamily: SANS, textIndent: "0.4em" },
            maxLength: 6
          }
        ),
        /* @__PURE__ */ jsx(
          "button",
          {
            onClick: () => submit(a, false),
            disabled: a.length < 4 || n.isPending,
            className: "px-6 py-4 sm:py-0 rounded-xl text-sm uppercase tracking-wider font-semibold cursor-pointer disabled:opacity-40",
            style: { background: GOLD, color: "#04160f", fontFamily: SANS, border: 0 },
            children: "Confirm"
          }
        )
      ] }),
      /* @__PURE__ */ jsx(AnP, { mode: "wait", children: t ? /* @__PURE__ */ jsx(
        N.div,
        {
          initial: { opacity: 0, scale: 0.9, y: 10 },
          animate: "error" in t || !t.already ? { opacity: 1, scale: 1, y: 0 } : { opacity: 1, scale: 1, y: 0, x: [0, -9, 9, -6, 6, 0] },
          exit: { opacity: 0 },
          className: "mt-6 rounded-2xl p-6",
          style: { border: `2px solid ${"error" in t || t.already ? BAD : OK}`, background: "error" in t || t.already ? "rgba(224,112,112,0.08)" : "rgba(127,199,154,0.08)" },
          children: "error" in t ? /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(ErrIco, { size: 32, className: "mx-auto", style: { color: BAD } }),
            /* @__PURE__ */ jsx("p", { className: "mt-2 text-lg", children: t.error })
          ] }) : t.already ? /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(ErrIco, { size: 36, className: "mx-auto", style: { color: BAD } }),
            /* @__PURE__ */ jsx("p", { className: "mt-3 text-xs uppercase tracking-[0.3em] font-semibold", style: { color: BAD, fontFamily: SANS }, children: "Rejected \u2014 Already Inside" }),
            /* @__PURE__ */ jsx("p", { className: "mt-2 text-2xl", style: { fontFamily: SERIF, fontWeight: 600 }, children: t.name }),
            /* @__PURE__ */ jsxs("p", { className: "text-sm opacity-70 mt-1", style: { fontFamily: SANS }, children: [
              "This invitation was already scanned",
              t.checkedInAt ? ` at ${new Date(t.checkedInAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` : "",
              ". Do not admit again."
            ] })
          ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(CheckIco, { size: 36, className: "mx-auto", style: { color: t.undo ? GOLD : OK } }),
            /* @__PURE__ */ jsx("p", { className: "mt-2 text-2xl", style: { fontFamily: SERIF, fontWeight: 600 }, children: t.name }),
            /* @__PURE__ */ jsx("p", { className: "text-sm opacity-70 mt-1", style: { fontFamily: SANS }, children: t.undo ? "Check-in undone" : `Karibu! Welcome inside${t.companions > 0 ? ` \xB7 party of ${t.companions + 1}` : ""}` })
          ] })
        },
        JSON.stringify(t)
      ) : null }),
      /* @__PURE__ */ jsx("div", { className: "mt-10 text-left space-y-2 max-h-80 overflow-y-auto", children: o.data ? o.data.map((s) => /* @__PURE__ */ jsxs(
        "div",
        {
          className: "flex items-center justify-between rounded-xl px-4 py-3",
          style: { background: PANEL, border: "1px solid rgba(201,162,39,0.15)" },
          children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("p", { style: { fontWeight: 600, margin: 0 }, children: s.name }),
              /* @__PURE__ */ jsxs("p", { className: "text-xs opacity-50", style: { fontFamily: SANS, margin: 0 }, children: [
                "#",
                s.code
              ] })
            ] }),
            s.checkedIn ? /* @__PURE__ */ jsxs(
              "button",
              {
                onClick: () => submit(s.code, true),
                className: "flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full cursor-pointer",
                style: { border: "1px solid rgba(224,112,112,0.5)", color: BAD, fontFamily: SANS, background: "transparent" },
                children: [
                  /* @__PURE__ */ jsx(UndoIco, { size: 12 }),
                  " Undo"
                ]
              }
            ) : /* @__PURE__ */ jsx(
              "button",
              {
                onClick: () => submit(s.code, false),
                className: "text-xs px-3 py-1.5 rounded-full cursor-pointer",
                style: { background: "rgba(127,199,154,0.15)", border: "1px solid " + OK, color: OK, fontFamily: SANS },
                children: "Check in"
              }
            )
          ]
        },
        s.id
      )) : null })
    ] })
  ] });
}
export {
  ScanPage as default
};
