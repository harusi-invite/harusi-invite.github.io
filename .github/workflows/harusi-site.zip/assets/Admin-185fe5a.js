import {
  listState
} from "./studio-NGQFTLHN-185fe5a.js";
import {
  AnimatePresence,
  Badge,
  Button,
  Card,
  Check,
  Empty,
  Field,
  HZ,
  I,
  Input,
  LinkButton,
  Menu,
  Note,
  PageHead,
  React,
  Rise,
  Section,
  Select,
  Shell,
  Skel,
  Stat,
  Tabs,
  call,
  copyText,
  downloadFile,
  errText,
  fmtDate,
  fmtWhen,
  initials,
  motion,
  plural,
  useData,
  useEffect,
  useState,
  useUI,
  weddingDates,
  whenLabel
} from "./studio-S4HULNAO-185fe5a.js";

// studio/admin.jsx
function Admin() {
  return /* @__PURE__ */ React.createElement(Shell, { admin: true, active: "admin" }, (user) => /* @__PURE__ */ React.createElement(AdminPage, { user }));
}
var TABS = [
  { id: "overview", label: "Overview", icon: I.home },
  { id: "weddings", label: "Weddings", icon: I.heart },
  { id: "hosts", label: "Hosts", icon: I.users },
  { id: "cleanup", label: "Clean-up", icon: I.broom },
  { id: "pricing", label: "Pricing", icon: I.coins }
];
function AdminPage({ user }) {
  const [tab, setTab] = useState(() => {
    const m = /[?&]tab=([a-z]+)/.exec(location.hash);
    return m && TABS.some((t) => t.id === m[1]) ? m[1] : "overview";
  });
  const invQ = useData((r) => r.admin.invitations(), []);
  const hostQ = useData((r) => r.admin.hosters(), []);
  const reloadAll = () => {
    invQ.reload();
    hostQ.reload();
  };
  return /* @__PURE__ */ React.createElement("main", { className: "hzs-wrap" }, /* @__PURE__ */ React.createElement(PageHead, { eyebrow: "Admin", title: "Platform", accent: "overview", sub: "Every host and wedding on Harusi, logins for new clients, prices and safe clean-up." }), /* @__PURE__ */ React.createElement(Tabs, { value: tab, onChange: (t) => {
    setTab(t);
    history.replaceState(null, "", "#/admin?tab=" + t);
  }, items: TABS, style: { marginBottom: 22 } }), tab === "overview" ? /* @__PURE__ */ React.createElement(Overview, { invQ, hostQ, go: setTab, reloadAll }) : null, tab === "weddings" ? /* @__PURE__ */ React.createElement(WeddingsTab, { invQ }) : null, tab === "hosts" ? /* @__PURE__ */ React.createElement(HostsTab, { hostQ, invQ, me: user }) : null, tab === "cleanup" ? /* @__PURE__ */ React.createElement(Cleanup, { invQ, hostQ, reloadAll }) : null, tab === "pricing" ? /* @__PURE__ */ React.createElement(Pricing, null) : null);
}
var alive = (inv) => !inv.trashedAt;
function isPast(inv, days) {
  const { last } = weddingDates(inv);
  if (!last) return false;
  return (/* @__PURE__ */ new Date(last + "T23:59:59")).getTime() < Date.now() - (days || 0) * 864e5;
}
function Overview({ invQ, hostQ, go, reloadAll }) {
  const inv = (invQ.data || []).filter(alive);
  const hosts = (hostQ.data || []).filter((h) => h.status !== "removed");
  const counts = useData((r) => r.admin.counts(), []);
  const live = inv.filter((i) => i.status === "active").length;
  const upcoming = inv.filter((i) => weddingDates(i).first && !isPast(i, 0)).sort((a, b) => weddingDates(a).first.localeCompare(weddingDates(b).first)).slice(0, 6);
  const pastOpen = inv.filter((i) => isPast(i, 14) && i.status !== "archived").length;
  const trashed = (invQ.data || []).filter((i) => i.trashedAt).length;
  const guests = inv.reduce((a, i) => a + (i.guestCount || 0), 0);
  if (invQ.loading || hostQ.loading) return /* @__PURE__ */ React.createElement("div", { className: "hzs-grid hzs-g4" }, [0, 1, 2, 3].map((i) => /* @__PURE__ */ React.createElement(Skel, { key: i, h: 110, r: 18 })));
  if (invQ.error) return /* @__PURE__ */ React.createElement(Empty, { icon: I.alert, title: "Couldn't load the platform", text: errText(invQ.error) }, /* @__PURE__ */ React.createElement(Button, { variant: "primary", onClick: reloadAll }, "Try again"));
  return /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 22 } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-grid hzs-g4" }, /* @__PURE__ */ React.createElement(Rise, { i: 0 }, /* @__PURE__ */ React.createElement(Stat, { icon: I.users, label: "Hosts", value: hosts.length, sub: hosts.filter((h) => h.status === "suspended").length + " paused" })), /* @__PURE__ */ React.createElement(Rise, { i: 1 }, /* @__PURE__ */ React.createElement(Stat, { icon: I.heart, label: "Weddings", value: inv.length, sub: live + " live \xB7 " + (inv.length - live) + " draft/archived" })), /* @__PURE__ */ React.createElement(Rise, { i: 2 }, /* @__PURE__ */ React.createElement(Stat, { icon: I.userPlus, label: "Guests", value: guests, sub: inv.reduce((a, i) => a + (i.attending || 0), 0) + " attending" })), /* @__PURE__ */ React.createElement(Rise, { i: 3 }, /* @__PURE__ */ React.createElement(Stat, { icon: I.database, label: "Database", value: counts.data ? (counts.data.users || 0) + (counts.data.invitations || 0) + (counts.data.guests || 0) + (counts.data.messages || 0) + (counts.data.guestLists || 0) : "\u2014", sub: "records stored" }))), pastOpen || trashed ? /* @__PURE__ */ React.createElement(Note, { tone: "warn", icon: I.broom }, pastOpen ? /* @__PURE__ */ React.createElement(React.Fragment, null, plural(pastOpen, "wedding finished more than two weeks ago and is", "weddings finished more than two weeks ago and are"), " still open. ") : null, trashed ? /* @__PURE__ */ React.createElement(React.Fragment, null, plural(trashed, "invitation is", "invitations are"), " in the trash. ") : null, /* @__PURE__ */ React.createElement("button", { onClick: () => go("cleanup"), style: { border: 0, background: "none", color: "inherit", textDecoration: "underline", cursor: "pointer", padding: 0, font: "inherit" } }, "Review in Clean-up")) : null, /* @__PURE__ */ React.createElement("div", { className: "hzs-grid hzs-split", style: { gap: 22 } }, /* @__PURE__ */ React.createElement(Section, { icon: I.calendar, title: "Coming up", sub: "The next weddings on the platform." }, !upcoming.length ? /* @__PURE__ */ React.createElement("p", { className: "hzs-muted", style: { margin: 0 } }, "No upcoming weddings with a date.") : /* @__PURE__ */ React.createElement("div", { className: "hzs-list", style: { margin: "-6px -22px -22px" } }, upcoming.map((i) => {
    const w = whenLabel(weddingDates(i).first);
    return /* @__PURE__ */ React.createElement("div", { key: i.id, className: "hzs-item", style: { padding: "12px 22px" } }, /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0, flex: 1 } }, /* @__PURE__ */ React.createElement("div", { style: { fontFamily: "'Great Vibes', cursive", fontSize: 23, lineHeight: 1.1 } }, i.groomName, " & ", i.brideName), /* @__PURE__ */ React.createElement("div", { className: "hzs-hint", style: { margin: 0 } }, fmtDate(weddingDates(i).first, { weekday: "short", day: "numeric", month: "short" }), " \xB7 ", i.ownerName, " \xB7 ", plural(i.guestCount || 0, "guest", "guests"))), /* @__PURE__ */ React.createElement(Badge, { tone: w.tone }, w.text), /* @__PURE__ */ React.createElement(LinkButton, { to: "/builder/" + i.id, size: "sm", variant: "ghost", icon: I.edit, "aria-label": "Open editor" }));
  }))), /* @__PURE__ */ React.createElement(CreateHost, { onCreated: () => hostQ.reload() })));
}
function genPass() {
  const w = ["baraka", "neema", "amani", "faraja", "raha", "heri", "tulia", "imara", "pendo", "zawadi"];
  return w[Math.floor(Math.random() * w.length)] + Math.floor(1e3 + Math.random() * 9e3);
}
function CreateHost({ onCreated }) {
  const ui = useUI();
  const [name, setName] = useState(""), [email, setEmail] = useState(""), [pass, setPass] = useState(genPass);
  const [busy, setBusy] = useState(false), [err, setErr] = useState(""), [done, setDone] = useState(null);
  const msg = (d) => "Karibu Harusi! \u{1F48D}\nAkaunti yako ya mwaliko wa kidijitali iko tayari. / Your digital invitation account is ready.\n\nEmail: " + d.email + "\nPassword: " + d.pass + "\nIngia / Sign in: " + HZ.base() + "#/login\n\nTafadhali hifadhi taarifa hizi. Kwaheri!";
  const create = async () => {
    setErr("");
    setBusy(true);
    try {
      const u = await call((r) => r.admin.createHost({ name: name.trim(), email: email.trim(), password: pass }));
      setDone({ email: u.email, pass });
      setName("");
      setEmail("");
      setPass(genPass());
      onCreated();
    } catch (e) {
      setErr(errText(e));
    }
    setBusy(false);
  };
  return /* @__PURE__ */ React.createElement(Section, { icon: I.key, title: "Issue a host login", sub: "After a client pays, create their login and send it." }, /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 14 } }, /* @__PURE__ */ React.createElement(Field, { label: "Client name" }, /* @__PURE__ */ React.createElement(Input, { value: name, onChange: (e) => setName(e.target.value), placeholder: "Amina & Yusuf" })), /* @__PURE__ */ React.createElement(Field, { label: "Login email" }, /* @__PURE__ */ React.createElement(Input, { type: "email", value: email, onChange: (e) => setEmail(e.target.value), placeholder: "client@email.com", autoComplete: "off" })), /* @__PURE__ */ React.createElement(Field, { label: "Password", right: /* @__PURE__ */ React.createElement("button", { onClick: () => setPass(genPass()), style: { border: 0, background: "none", color: "var(--gold)", cursor: "pointer", fontSize: 12.5 } }, "New password") }, /* @__PURE__ */ React.createElement(Input, { value: pass, onChange: (e) => setPass(e.target.value), autoComplete: "off" })), err ? /* @__PURE__ */ React.createElement(Note, { tone: "bad", icon: I.alert }, err) : null, /* @__PURE__ */ React.createElement(Button, { variant: "primary", onClick: create, busy, disabled: !email.trim() || pass.length < 6 }, "Create login"), /* @__PURE__ */ React.createElement(AnimatePresence, null, done ? /* @__PURE__ */ React.createElement(motion.div, { initial: { opacity: 0, height: 0 }, animate: { opacity: 1, height: "auto" }, exit: { opacity: 0, height: 0 }, style: { overflow: "hidden" } }, /* @__PURE__ */ React.createElement(Note, { tone: "ok", icon: I.okCircle }, "Login ready for ", /* @__PURE__ */ React.createElement("b", null, done.email), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, marginTop: 10, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "secondary", icon: I.copy, onClick: () => copyText(msg(done)).then(() => ui.toast("Login details copied")) }, "Copy details"), /* @__PURE__ */ React.createElement("a", { className: "hzs-btn sm", style: { background: "#1F8F4E", color: "#fff" }, href: "https://wa.me/?text=" + encodeURIComponent(msg(done)), target: "_blank", rel: "noreferrer" }, /* @__PURE__ */ React.createElement(I.chat, { size: 15 }), "WhatsApp"), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", onClick: () => setDone(null) }, "Done")))) : null)));
}
function WeddingsTab({ invQ }) {
  const ui = useUI();
  const [term, setTerm] = useState("");
  const [f, setF] = useState("all");
  const all = (invQ.data || []).filter(alive);
  const shown = all.filter((i) => {
    if (f === "live" && i.status !== "active") return false;
    if (f === "draft" && i.status !== "draft") return false;
    if (f === "archived" && i.status !== "archived") return false;
    if (f === "upcoming" && isPast(i, 0)) return false;
    if (f === "past" && !isPast(i, 0)) return false;
    const t = term.trim().toLowerCase();
    return !t || (i.groomName + " " + i.brideName + " " + i.slug + " " + i.ownerName + " " + i.ownerEmail).toLowerCase().includes(t);
  });
  const setStatus = async (i, status) => {
    try {
      await call((r) => r.admin.setStatus({ id: i.id, status }));
      invQ.mutate((d) => d.map((x) => x.id === i.id ? { ...x, status } : x));
      ui.toast("Status updated");
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
    }
  };
  const trash = async (i) => {
    if (!await ui.confirm({ title: "Move to trash?", body: /* @__PURE__ */ React.createElement(React.Fragment, null, "\u201C", i.groomName, " & ", i.brideName, "\u201D will stop opening for guests. You can restore it from Clean-up \u2192 Trash."), confirmText: "Move to trash", tone: "danger" })) return;
    try {
      await call((r) => r.admin.trashMany({ ids: [i.id] }));
      invQ.mutate((d) => d.map((x) => x.id === i.id ? { ...x, trashedAt: Date.now() } : x));
      ui.toast("Moved to trash", { action: { label: "Undo", fn: async () => {
        await call((r) => r.admin.restoreMany({ ids: [i.id] }));
        invQ.reload();
      } } });
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
    }
  };
  return /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "hzs-sec", style: { display: "flex", gap: 12, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("div", { style: { position: "relative", flex: "1 1 240px" } }, /* @__PURE__ */ React.createElement(I.search, { size: 16, style: { position: "absolute", left: 13, top: 14, color: "var(--ink3)" } }), /* @__PURE__ */ React.createElement(Input, { placeholder: "Search couple, link or host", value: term, onChange: (e) => setTerm(e.target.value), style: { paddingLeft: 38 } })), /* @__PURE__ */ React.createElement(Select, { value: f, onChange: (e) => setF(e.target.value), style: { width: "auto" }, options: [{ value: "all", label: "All (" + all.length + ")" }, { value: "upcoming", label: "Upcoming" }, { value: "past", label: "Past" }, { value: "live", label: "Live" }, { value: "draft", label: "Draft" }, { value: "archived", label: "Archived" }] })), invQ.loading ? /* @__PURE__ */ React.createElement("div", { className: "hzs-pad" }, /* @__PURE__ */ React.createElement(Skel, { h: 50 })) : !shown.length ? /* @__PURE__ */ React.createElement("div", { className: "hzs-pad hzs-muted", style: { textAlign: "center" } }, "No weddings match.") : /* @__PURE__ */ React.createElement("div", { className: "hzs-list" }, shown.map((i) => {
    const d = weddingDates(i).first;
    const w = whenLabel(d);
    const t = (HZ.templates || []).find((x) => x.id === i.templateId);
    return /* @__PURE__ */ React.createElement("div", { key: i.id, className: "hzs-item", style: { flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("img", { src: t && t.previewImage || "./art/blush-arch-gold.png", alt: "", style: { width: 44, height: 56, objectFit: "cover", objectPosition: "top", borderRadius: "22px 22px 6px 6px", flex: "none" } }), /* @__PURE__ */ React.createElement("div", { style: { flex: "1 1 240px", minWidth: 0 } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("b", { style: { fontWeight: 500 } }, i.groomName || "\u2014", " & ", i.brideName || "\u2014"), /* @__PURE__ */ React.createElement(Badge, { tone: i.status === "active" ? "ok" : i.status === "archived" ? "" : "warn", dot: true }, i.status === "active" ? "Live" : i.status === "archived" ? "Archived" : "Draft"), d ? /* @__PURE__ */ React.createElement(Badge, { tone: w.tone }, w.text) : null), /* @__PURE__ */ React.createElement("div", { className: "hzs-hint", style: { margin: "3px 0 0" } }, d ? fmtDate(d) + " \xB7 " : "", t && t.name || i.templateId, " \xB7 by ", i.ownerName, " ", i.ownerEmail ? "(" + i.ownerEmail + ")" : ""), /* @__PURE__ */ React.createElement("div", { className: "hzs-hint", style: { margin: 0 } }, i.guestCount || 0, " guests \xB7 ", i.attending || 0, " attending \xB7 ", i.checkedIn || 0, " checked in \xB7 /i/", i.slug)), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 6 } }, /* @__PURE__ */ React.createElement(LinkButton, { to: "/builder/" + i.id, size: "sm", variant: "secondary", icon: I.edit }, "Edit"), /* @__PURE__ */ React.createElement(Menu, { items: [
      { label: "Open invitation", icon: I.open, onClick: () => window.open(HZ.base() + "#/i/" + i.slug, "_blank") },
      { label: "Guests & replies", icon: I.users, onClick: () => {
        location.hash = "#/guests/" + i.id;
      } },
      { label: "Check-in scanner", icon: I.scan, onClick: () => {
        location.hash = "#/scan/" + i.id;
      } },
      "-",
      i.status !== "active" ? { label: "Mark live", icon: I.play, onClick: () => setStatus(i, "active") } : null,
      i.status !== "draft" ? { label: "Mark draft", icon: I.pause, onClick: () => setStatus(i, "draft") } : null,
      i.status !== "archived" ? { label: "Archive (stops opening)", icon: I.archive, onClick: () => setStatus(i, "archived") } : null,
      "-",
      { label: "Move to trash", icon: I.trash, danger: true, onClick: () => trash(i) }
    ] })));
  })));
}
function HostsTab({ hostQ, invQ, me }) {
  const ui = useUI();
  const [term, setTerm] = useState("");
  const [showRemoved, setShowRemoved] = useState(false);
  const hosts = (hostQ.data || []).filter((h) => showRemoved || h.status !== "removed");
  const shown = hosts.filter((h) => {
    const t = term.trim().toLowerCase();
    return !t || (String(h.name) + " " + String(h.email)).toLowerCase().includes(t);
  }).sort((a, b) => (a.role === "admin" ? -1 : 0) - (b.role === "admin" ? -1 : 0) || (b.createdAt || 0) - (a.createdAt || 0));
  const act = async (fn, okMsg) => {
    try {
      await call(fn);
      hostQ.reload();
      invQ.reload();
      ui.toast(okMsg);
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
    }
  };
  const pause = (h) => act((r) => r.admin.setUserStatus({ id: h.id, status: h.status === "suspended" ? "active" : "suspended" }), h.status === "suspended" ? "Host reactivated" : "Host paused \u2014 they can't sign in");
  const role = async (h) => {
    if (h.id === me.id) return ui.toast("You can't change your own role", { tone: "bad" });
    if (!await ui.confirm({ title: h.role === "admin" ? "Remove admin rights?" : "Make " + (h.name || h.email) + " an admin?", body: h.role === "admin" ? "They keep their weddings but lose access to this panel." : "Admins can see and change every wedding and host.", confirmText: h.role === "admin" ? "Remove admin" : "Make admin", tone: h.role === "admin" ? "danger" : void 0 })) return;
    act((r) => r.admin.setRole({ id: h.id, role: h.role === "admin" ? "user" : "admin" }), "Role updated");
  };
  const remove = async (h) => {
    if (!await ui.confirm({ title: "Remove " + (h.name || h.email) + "?", body: /* @__PURE__ */ React.createElement(React.Fragment, null, "Their login is closed and their ", plural(h.invitationCount || 0, "invitation moves", "invitations move"), " to the trash. You can restore the host and their weddings later from Clean-up."), confirmText: "Remove host", tone: "danger", typeToConfirm: "REMOVE" })) return;
    act((r) => r.admin.removeHost({ id: h.id }), "Host removed");
  };
  const restore = (h) => act((r) => r.admin.restoreHost({ id: h.id }), "Host restored \u2014 restore their weddings from Clean-up \u2192 Trash");
  return /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "hzs-sec", style: { display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" } }, /* @__PURE__ */ React.createElement("div", { style: { position: "relative", flex: "1 1 240px" } }, /* @__PURE__ */ React.createElement(I.search, { size: 16, style: { position: "absolute", left: 13, top: 14, color: "var(--ink3)" } }), /* @__PURE__ */ React.createElement(Input, { placeholder: "Search name or email", value: term, onChange: (e) => setTerm(e.target.value), style: { paddingLeft: 38 } })), /* @__PURE__ */ React.createElement("label", { className: "hzs-row", style: { gap: 8, fontSize: 13.5, color: "var(--ink2)", cursor: "pointer" } }, /* @__PURE__ */ React.createElement(Check, { on: showRemoved, onChange: setShowRemoved, label: "Show removed" }), "Show removed")), hostQ.loading ? /* @__PURE__ */ React.createElement("div", { className: "hzs-pad" }, /* @__PURE__ */ React.createElement(Skel, { h: 50 })) : !shown.length ? /* @__PURE__ */ React.createElement("div", { className: "hzs-pad hzs-muted", style: { textAlign: "center" } }, "No hosts.") : /* @__PURE__ */ React.createElement("div", { className: "hzs-list" }, shown.map((h) => /* @__PURE__ */ React.createElement("div", { key: h.id, className: "hzs-item", style: { flexWrap: "wrap", opacity: h.status === "removed" ? 0.6 : 1 } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-avatar", style: { width: 40, height: 40 } }, initials(h.name || h.email)), /* @__PURE__ */ React.createElement("div", { style: { flex: "1 1 220px", minWidth: 0 } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("b", { style: { fontWeight: 500 } }, h.name || "Unnamed"), h.role === "admin" ? /* @__PURE__ */ React.createElement(Badge, { tone: "dark" }, "Admin") : null, h.status === "suspended" ? /* @__PURE__ */ React.createElement(Badge, { tone: "warn" }, "Paused") : h.status === "removed" ? /* @__PURE__ */ React.createElement(Badge, { tone: "bad" }, "Removed") : /* @__PURE__ */ React.createElement(Badge, { tone: "ok", dot: true }, "Active"), h.id === me.id ? /* @__PURE__ */ React.createElement(Badge, null, "You") : null), /* @__PURE__ */ React.createElement("div", { className: "hzs-hint", style: { margin: "3px 0 0" } }, [h.email || "no email", fmtWhen(h.createdAt) ? "joined " + fmtWhen(h.createdAt) : "", plural(h.invitationCount || 0, "wedding", "weddings"), plural(h.guestCount || 0, "guest", "guests")].filter(Boolean).join(" \xB7 "))), h.id !== me.id ? /* @__PURE__ */ React.createElement(Menu, { items: h.status === "removed" ? [{ label: "Restore host", icon: I.undo, onClick: () => restore(h) }] : [
    h.role !== "admin" ? { label: h.status === "suspended" ? "Reactivate login" : "Pause login", icon: h.status === "suspended" ? I.play : I.pause, onClick: () => pause(h) } : null,
    { label: h.role === "admin" ? "Remove admin rights" : "Make admin", icon: I.shield, onClick: () => role(h) },
    h.role !== "admin" ? "-" : null,
    h.role !== "admin" ? { label: "Remove host\u2026", icon: I.trash, danger: true, onClick: () => remove(h) } : null
  ] }) : null))));
}
function Cleanup({ invQ, hostQ, reloadAll }) {
  const ui = useUI();
  const [days, setDays] = useState("14");
  const [sel, setSel] = useState({});
  const [tsel, setTsel] = useState({});
  const [busy, setBusy] = useState(null);
  const listsQ = useData((r) => r.admin.allLists(), []);
  const all = invQ.data || [];
  const past = all.filter((i) => alive(i) && isPast(i, Number(days))).sort((a, b) => weddingDates(a).last.localeCompare(weddingDates(b).last));
  const noDate = all.filter((i) => alive(i) && !weddingDates(i).first && Date.now() - (i.createdAt || 0) > 60 * 864e5);
  const trash = all.filter((i) => i.trashedAt).sort((a, b) => a.trashedAt - b.trashedAt);
  const ids = (m) => Object.keys(m).filter((k) => m[k]);
  const pastIds = ids(sel).filter((k) => past.concat(noDate).some((i) => i.id === k));
  const trashIds = ids(tsel).filter((k) => trash.some((i) => i.id === k));
  const oldLists = (listsQ.data || []).filter((l) => l.importedAt ? Date.now() - l.importedAt > 30 * 864e5 : Date.now() - (l.updatedAt || l.createdAt || 0) > 90 * 864e5);
  const removedHosts = (hostQ.data || []).filter((h) => h.status === "removed");
  const run = async (key, fn, msg) => {
    setBusy(key);
    try {
      await call(fn);
      ui.toast(msg);
      reloadAll();
      setSel({});
      setTsel({});
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
    }
    setBusy(null);
  };
  const archive = () => run("arch", (r) => r.admin.archiveMany({ ids: pastIds }), plural(pastIds.length, "wedding archived", "weddings archived") + " \u2014 guests can no longer open them");
  const toTrash = async () => {
    if (!await ui.confirm({ title: "Move " + plural(pastIds.length, "wedding", "weddings") + " to the trash?", body: "They stop opening for guests and leave the hosts' dashboards. Nothing is deleted yet \u2014 you can restore them from the Trash below.", confirmText: "Move to trash" })) return;
    run("trash", (r) => r.admin.trashMany({ ids: pastIds }), "Moved to trash");
  };
  const restore = () => run("restore", (r) => r.admin.restoreMany({ ids: trashIds }), plural(trashIds.length, "wedding restored", "weddings restored"));
  const backup = async (list) => {
    const r = await HZ.repo();
    const data = await r.admin.backup({ ids: list });
    downloadFile("harusi-backup-" + (/* @__PURE__ */ new Date()).toISOString().slice(0, 10) + "-" + list.length + ".json", JSON.stringify(data, null, 1), "application/json");
    return data;
  };
  const purge = async () => {
    const chosen = trash.filter((i) => trashIds.includes(i.id));
    const g = chosen.reduce((a, i) => a + (i.guestCount || 0), 0);
    if (!await ui.confirm({
      title: "Delete permanently?",
      tone: "danger",
      typeToConfirm: "FUTA",
      confirmText: "Delete forever",
      body: /* @__PURE__ */ React.createElement(React.Fragment, null, plural(chosen.length, "wedding", "weddings"), " with ", plural(g, "guest", "guests"), " and all their blessings will be erased from the database. A backup file downloads first so you keep a copy. ", /* @__PURE__ */ React.createElement("b", null, "This can't be undone."))
    })) return;
    setBusy("purge");
    try {
      await backup(trashIds);
      const r = await HZ.repo();
      await r.admin.purge({ ids: trashIds });
      HZ.emit("*");
      ui.toast("Deleted permanently \u2014 backup saved to your downloads");
      setTsel({});
      reloadAll();
    } catch (e) {
      ui.toast("Stopped: " + errText(e), { tone: "bad" });
    }
    setBusy(null);
  };
  const delLists = async () => {
    if (!await ui.confirm({ title: "Delete " + plural(oldLists.length, "old guest list", "old guest lists") + "?", body: "Their client links stop working. Lists already imported keep their guests on the invitation.", confirmText: "Delete lists", tone: "danger" })) return;
    run("lists", (r) => r.admin.deleteLists({ ids: oldLists.map((l) => l.id) }), "Old guest lists deleted");
    listsQ.reload();
  };
  const toggleAll = (rows, m, setM) => {
    const on = rows.every((r) => m[r.id]);
    const n = {};
    if (!on) rows.forEach((r) => n[r.id] = true);
    setM(n);
  };
  return /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 22 } }, /* @__PURE__ */ React.createElement(Note, { tone: "gold", icon: I.shield }, "Nothing is erased in one step. ", /* @__PURE__ */ React.createElement("b", null, "Archive"), " keeps everything but stops the card opening \xB7 ", /* @__PURE__ */ React.createElement("b", null, "Trash"), " hides it and can be restored \xB7 ", /* @__PURE__ */ React.createElement("b", null, "Delete permanently"), " needs a typed confirmation and downloads a backup first."), /* @__PURE__ */ React.createElement(
    Section,
    {
      icon: I.calendar,
      title: "Finished weddings",
      sub: "Weddings whose last event is in the past \u2014 archive them, or move them to the trash.",
      right: /* @__PURE__ */ React.createElement(Select, { value: days, onChange: (e) => {
        setDays(e.target.value);
        setSel({});
      }, style: { width: "auto", height: 38 }, options: [{ value: "0", label: "Any past date" }, { value: "14", label: "Over 2 weeks ago" }, { value: "30", label: "Over a month ago" }, { value: "90", label: "Over 3 months ago" }] })
    },
    /* @__PURE__ */ React.createElement(
      RowList,
      {
        rows: past.concat(noDate),
        m: sel,
        setM: setSel,
        toggleAll,
        empty: "No finished weddings in this range.",
        meta: (i) => {
          const d = weddingDates(i).last;
          return (d ? "Last event " + fmtDate(d) : "No date \xB7 created " + fmtWhen(i.createdAt)) + " \xB7 " + (i.ownerName || "\u2014") + " \xB7 " + (i.guestCount || 0) + " guests" + (i.status === "archived" ? " \xB7 archived" : "");
        }
      }
    ),
    past.length + noDate.length ? /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 10, marginTop: 16, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Button, { variant: "secondary", icon: I.archive, disabled: !pastIds.length, busy: busy === "arch", onClick: archive }, "Archive", pastIds.length ? " " + pastIds.length : ""), /* @__PURE__ */ React.createElement(Button, { variant: "dangerSoft", icon: I.trash, disabled: !pastIds.length, busy: busy === "trash", onClick: toTrash }, "Move to trash", pastIds.length ? " " + pastIds.length : "")) : null
  ), /* @__PURE__ */ React.createElement(Section, { icon: I.trash, title: "Trash" + (trash.length ? " \xB7 " + trash.length : ""), sub: "Restore what was removed by mistake, or delete permanently to free the database. Items trashed over 30 days ago are safe to delete." }, /* @__PURE__ */ React.createElement(
    RowList,
    {
      rows: trash,
      m: tsel,
      setM: setTsel,
      toggleAll,
      empty: "The trash is empty.",
      meta: (i) => "Trashed " + fmtWhen(i.trashedAt) + (Date.now() - i.trashedAt > 30 * 864e5 ? " (over 30 days)" : "") + " \xB7 " + (i.ownerName || "\u2014") + " \xB7 " + (i.guestCount || 0) + " guests"
    }
  ), trash.length ? /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 10, marginTop: 16, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Button, { variant: "secondary", icon: I.undo, disabled: !trashIds.length, busy: busy === "restore", onClick: restore }, "Restore", trashIds.length ? " " + trashIds.length : ""), /* @__PURE__ */ React.createElement(Button, { variant: "secondary", icon: I.download, disabled: !trashIds.length, onClick: () => backup(trashIds).then(() => ui.toast("Backup downloaded")).catch((e) => ui.toast(errText(e), { tone: "bad" })) }, "Download backup"), /* @__PURE__ */ React.createElement(Button, { variant: "danger", icon: I.trash, disabled: !trashIds.length, busy: busy === "purge", onClick: purge, style: { marginLeft: "auto" } }, "Delete permanently", trashIds.length ? " " + trashIds.length : "")) : null), /* @__PURE__ */ React.createElement(Section, { icon: I.list, title: "Old guest lists", sub: "Client lists imported over 30 days ago, or untouched for 3 months." }, listsQ.loading ? /* @__PURE__ */ React.createElement(Skel, { h: 40 }) : !oldLists.length ? /* @__PURE__ */ React.createElement("p", { className: "hzs-muted", style: { margin: 0 } }, "Nothing to tidy.") : /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "hzs-wrapflex" }, oldLists.slice(0, 12).map((l) => /* @__PURE__ */ React.createElement(Badge, { key: l.id, tone: listState(l).tone }, (l.label || l.clientName || "Untitled") + " \xB7 " + (l.entries || []).length)), oldLists.length > 12 ? /* @__PURE__ */ React.createElement(Badge, null, "+", oldLists.length - 12, " more") : null), /* @__PURE__ */ React.createElement(Button, { variant: "dangerSoft", icon: I.trash, busy: busy === "lists", onClick: delLists, style: { marginTop: 14 } }, "Delete ", plural(oldLists.length, "list", "lists")))), removedHosts.length ? /* @__PURE__ */ React.createElement(Section, { icon: I.users, title: "Removed hosts", sub: "Their logins are closed. Restore one from Hosts \u2192 Show removed." }, /* @__PURE__ */ React.createElement("div", { className: "hzs-wrapflex" }, removedHosts.map((h) => /* @__PURE__ */ React.createElement(Badge, { key: h.id }, h.name || h.email)))) : null);
}
function RowList({ rows, m, setM, toggleAll, meta, empty }) {
  if (!rows.length) return /* @__PURE__ */ React.createElement("p", { className: "hzs-muted", style: { margin: 0 } }, empty);
  const allOn = rows.every((r) => m[r.id]);
  return /* @__PURE__ */ React.createElement("div", { style: { border: "1px solid var(--line)", borderRadius: 14, overflow: "hidden" } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-item", style: { padding: "10px 14px", background: "rgba(30,26,18,.025)", fontSize: 13, color: "var(--ink2)" } }, /* @__PURE__ */ React.createElement(Check, { on: allOn, onChange: () => toggleAll(rows, m, setM), label: "Select all" }), " ", /* @__PURE__ */ React.createElement("span", null, allOn ? "All selected" : "Select all", " \xB7 ", rows.length)), /* @__PURE__ */ React.createElement("div", { className: "hzs-list", style: { maxHeight: 360, overflowY: "auto", borderTop: "1px solid var(--line)" } }, rows.map((i) => /* @__PURE__ */ React.createElement("div", { key: i.id, className: "hzs-item", style: { padding: "11px 14px", cursor: "pointer" }, onClick: () => setM({ ...m, [i.id]: !m[i.id] }) }, /* @__PURE__ */ React.createElement(Check, { on: !!m[i.id], onChange: () => setM({ ...m, [i.id]: !m[i.id] }), label: i.groomName + " & " + i.brideName }), /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0, flex: 1 } }, /* @__PURE__ */ React.createElement("div", { style: { fontWeight: 500, fontSize: 14.5 } }, i.groomName || "\u2014", " & ", i.brideName || "\u2014"), /* @__PURE__ */ React.createElement("div", { className: "hzs-hint", style: { margin: 0 } }, meta(i)))))));
}
function Pricing() {
  const ui = useUI();
  const q = useData((r) => r.admin.getPricing(), []);
  const [v, setV] = useState(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (q.data !== void 0 && !v) setV({ per: String(q.data && q.data.perGuestRate || 1200), extra: String(q.data && q.data.extraGuestRate || 1400), custom: String(q.data && q.data.customTemplateFee || 1e5) });
  }, [q.data]);
  if (!v) return /* @__PURE__ */ React.createElement(Skel, { h: 200, r: 18 });
  const n = (x) => Number(String(x).replace(/[^\d]/g, ""));
  const save = async () => {
    if (!(n(v.per) > 0) || !(n(v.extra) > 0) || !(n(v.custom) >= 0)) return ui.toast("Enter valid amounts", { tone: "bad" });
    setBusy(true);
    try {
      await call((r) => r.admin.savePricing({ perGuestRate: n(v.per), extraGuestRate: n(v.extra), customTemplateFee: n(v.custom) }));
      ui.toast("Saved \u2014 the website now shows these prices");
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
    }
    setBusy(false);
  };
  const tz = (x) => n(x).toLocaleString("en-US") + " TZS";
  return /* @__PURE__ */ React.createElement(Section, { icon: I.coins, title: "Pricing", sub: "These rates power the price calculator on the homepage." }, /* @__PURE__ */ React.createElement("div", { className: "hzs-grid hzs-g3" }, /* @__PURE__ */ React.createElement(Field, { label: "Bundle rate \u2014 TZS per guest", hint: "200 guests = " + tz(n(v.per) * 200) }, /* @__PURE__ */ React.createElement(Input, { inputMode: "numeric", value: v.per, onChange: (e) => setV({ ...v, per: e.target.value }) })), /* @__PURE__ */ React.createElement(Field, { label: "Extra guest rate \u2014 TZS" }, /* @__PURE__ */ React.createElement(Input, { inputMode: "numeric", value: v.extra, onChange: (e) => setV({ ...v, extra: e.target.value }) })), /* @__PURE__ */ React.createElement(Field, { label: "Bespoke template service \u2014 TZS" }, /* @__PURE__ */ React.createElement(Input, { inputMode: "numeric", value: v.custom, onChange: (e) => setV({ ...v, custom: e.target.value }) }))), /* @__PURE__ */ React.createElement(Button, { variant: "primary", onClick: save, busy, style: { marginTop: 18 } }, "Save prices"));
}
var admin_default = Admin;
export {
  admin_default as default
};
