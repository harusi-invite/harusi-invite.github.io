// studio/ui.jsx
import { r as React, a as useAuth, b as useNavigate, L as Link, m as motion, h as AnimatePresence, c as mkIcon, hz as HZ } from "./index-B4Ch-nvB-59ff981.js";
var { useState, useEffect, useRef, useCallback, useMemo, createContext, useContext } = React;
var P = (d) => ["path", { d, key: d.slice(0, 12) }];
var Cc = (cx2, cy, r) => ["circle", { cx: String(cx2), cy: String(cy), r: String(r), key: "c" + cx2 + cy + r }];
var R = (x, y, w, h, rx) => ["rect", { x: String(x), y: String(y), width: String(w), height: String(h), rx: String(rx || 0), key: "r" + x + y + w + h }];
var I = {
  back: mkIcon("hz-back", [P("m12 19-7-7 7-7"), P("M19 12H5")]),
  plus: mkIcon("hz-plus", [P("M5 12h14"), P("M12 5v14")]),
  edit: mkIcon("hz-edit", [P("M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"), P("m15 5 4 4")]),
  scan: mkIcon("hz-scan", [P("M3 7V5a2 2 0 0 1 2-2h2"), P("M17 3h2a2 2 0 0 1 2 2v2"), P("M21 17v2a2 2 0 0 1-2 2h-2"), P("M7 21H5a2 2 0 0 1-2-2v-2"), P("M7 12h10")]),
  share: mkIcon("hz-share", [Cc(18, 5, 3), Cc(6, 12, 3), Cc(18, 19, 3), P("m8.59 13.51 6.83 3.98"), P("m15.41 6.51-6.82 3.98")]),
  open: mkIcon("hz-open", [P("M15 3h6v6"), P("M10 14 21 3"), P("M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6")]),
  copy: mkIcon("hz-copy", [R(8, 8, 14, 14, 2), P("M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2")]),
  check: mkIcon("hz-check", [P("M20 6 9 17l-5-5")]),
  trash: mkIcon("hz-trash", [P("M3 6h18"), P("M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"), P("M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"), P("M10 11v6"), P("M14 11v6")]),
  users: mkIcon("hz-users", [P("M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"), Cc(9, 7, 4), P("M22 21v-2a4 4 0 0 0-3-3.87"), P("M16 3.13a4 4 0 0 1 0 7.75")]),
  userPlus: mkIcon("hz-userplus", [P("M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"), Cc(9, 7, 4), P("M19 8v6"), P("M22 11h-6")]),
  calendar: mkIcon("hz-cal", [P("M8 2v4"), P("M16 2v4"), R(3, 4, 18, 18, 2), P("M3 10h18")]),
  clock: mkIcon("hz-clock", [Cc(12, 12, 10), P("M12 6v6l4 2")]),
  gift: mkIcon("hz-gift", [R(3, 8, 18, 4, 1), P("M12 8v13"), P("M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"), P("M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5")]),
  phone: mkIcon("hz-phone", [P("M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z")]),
  chat: mkIcon("hz-chat", [P("M7.9 20A9 9 0 1 0 4 16.1L2 22Z")]),
  search: mkIcon("hz-search", [Cc(11, 11, 8), P("m21 21-4.3-4.3")]),
  x: mkIcon("hz-x", [P("M18 6 6 18"), P("m6 6 12 12")]),
  down: mkIcon("hz-down", [P("m6 9 6 6 6-6")]),
  up: mkIcon("hz-up", [P("m18 15-6-6-6 6")]),
  right: mkIcon("hz-right", [P("m9 18 6-6-6-6")]),
  more: mkIcon("hz-more", [Cc(12, 12, 1), Cc(19, 12, 1), Cc(5, 12, 1)]),
  logout: mkIcon("hz-logout", [P("m16 17 5-5-5-5"), P("M21 12H9"), P("M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4")]),
  home: mkIcon("hz-home", [P("M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"), P("M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z")]),
  list: mkIcon("hz-list", [R(8, 2, 8, 4, 1), P("M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"), P("M12 11h4"), P("M12 16h4"), P("M8 11h.01"), P("M8 16h.01")]),
  shield: mkIcon("hz-shield", [P("M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"), P("m9 12 2 2 4-4")]),
  eye: mkIcon("hz-eye", [P("M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"), Cc(12, 12, 3)]),
  upload: mkIcon("hz-upload", [P("M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"), P("m17 8-5-5-5 5"), P("M12 3v12")]),
  download: mkIcon("hz-download", [P("M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"), P("m7 10 5 5 5-5"), P("M12 15V3")]),
  image: mkIcon("hz-image", [R(3, 3, 18, 18, 2), Cc(9, 9, 2), P("m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21")]),
  type: mkIcon("hz-type", [P("M4 7V4h16v3"), P("M9 20h6"), P("M12 4v16")]),
  shirt: mkIcon("hz-shirt", [P("M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z")]),
  palette: mkIcon("hz-palette", [Cc(13.5, 6.5, 0.5), Cc(17.5, 10.5, 0.5), Cc(8.5, 7.5, 0.5), Cc(6.5, 12.5, 0.5), P("M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z")]),
  heart: mkIcon("hz-heart", [P("M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z")]),
  book: mkIcon("hz-book", [P("M12 7v14"), P("M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z")]),
  globe: mkIcon("hz-globe", [Cc(12, 12, 10), P("M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"), P("M2 12h20")]),
  languages: mkIcon("hz-lang", [P("m5 8 6 6"), P("m4 14 6-6 2-3"), P("M2 5h12"), P("M7 2h1"), P("m22 22-5-10-5 10"), P("M14 18h6")]),
  alert: mkIcon("hz-alert", [P("m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"), P("M12 9v4"), P("M12 17h.01")]),
  info: mkIcon("hz-info", [Cc(12, 12, 10), P("M12 16v-4"), P("M12 8h.01")]),
  undo: mkIcon("hz-undo", [P("M3 7v6h6"), P("M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13")]),
  archive: mkIcon("hz-archive", [R(2, 3, 20, 5, 1), P("M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"), P("M10 12h4")]),
  qr: mkIcon("hz-qr", [R(3, 3, 5, 5, 1), R(16, 3, 5, 5, 1), R(3, 16, 5, 5, 1), P("M21 16h-3a2 2 0 0 0-2 2v3"), P("M21 21v.01"), P("M12 7v3a2 2 0 0 1-2 2H7"), P("M3 12h.01"), P("M12 3h.01"), P("M12 16v.01"), P("M16 12h1"), P("M21 12v.01"), P("M12 21v-1")]),
  camera: mkIcon("hz-camera", [P("M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"), Cc(12, 13, 3)]),
  flash: mkIcon("hz-flash", [P("M13 2 3 14h9l-1 8 10-12h-9l1-8z")]),
  refresh: mkIcon("hz-refresh", [P("M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"), P("M21 3v5h-5"), P("M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"), P("M8 16H3v5")]),
  okCircle: mkIcon("hz-okc", [Cc(12, 12, 10), P("m9 12 2 2 4-4")]),
  xCircle: mkIcon("hz-xc", [Cc(12, 12, 10), P("m15 9-6 6"), P("m9 9 6 6")]),
  link: mkIcon("hz-link", [P("M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"), P("M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71")]),
  pin: mkIcon("hz-pin", [P("M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"), Cc(12, 10, 3)]),
  key: mkIcon("hz-key", [P("m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4"), P("m21 2-9.6 9.6"), Cc(7.5, 15.5, 5.5)]),
  pause: mkIcon("hz-pause", [R(14, 4, 4, 16, 1), R(6, 4, 4, 16, 1)]),
  play: mkIcon("hz-play", [P("M6 3 20 12 6 21Z")]),
  sparkle: mkIcon("hz-sparkle", [P("M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z")]),
  broom: mkIcon("hz-broom", [P("m13 11 9-9"), P("M14.6 12.6c.8.8.9 2.1.2 3L10 22l-8-8 6.4-4.8c.9-.7 2.2-.6 3 .2Z"), P("m6.8 10.4 6.8 6.8"), P("m5 17 1.4-1.4")]),
  coins: mkIcon("hz-coins", [Cc(8, 8, 6), P("M18.09 10.37A6 6 0 1 1 10.34 18"), P("M7 6h1v4"), P("m16.71 13.88.7.71-2.82 2.82")]),
  grip: mkIcon("hz-grip", [Cc(9, 12, 1), Cc(9, 5, 1), Cc(9, 19, 1), Cc(15, 12, 1), Cc(15, 5, 1), Cc(15, 19, 1)]),
  database: mkIcon("hz-db", [["ellipse", { cx: "12", cy: "5", rx: "9", ry: "3", key: "e1" }], P("M3 5V19A9 3 0 0 0 21 19V5"), P("M3 12A9 3 0 0 0 21 12")]),
  user: mkIcon("hz-user", [P("M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"), Cc(12, 7, 4)]),
  settings: mkIcon("hz-settings", [P("M20 7h-9"), P("M14 17H5"), Cc(17, 17, 3), Cc(7, 7, 3)])
};
var CSS = `
.hzs,.hzs-layer{--bg:#FBF8F2;--paper:#FFFDF9;--card:#FFFFFF;--line:rgba(30,26,18,.09);--line2:rgba(30,26,18,.16);--ink:#1E1A12;--ink2:#5D5444;--ink3:#8E8473;
--gold:#A07D3B;--gold2:#C6A45E;--goldbg:#F6EFE0;--goldline:rgba(160,125,59,.35);--ok:#2E6A46;--okbg:#E8F1EA;--bad:#A3473A;--badbg:#F8E8E4;--warn:#8A5D0B;--warnbg:#FAF0DA;--info:#2D5876;--infobg:#E7EFF5;
--r:18px;--shadow:0 1px 2px rgba(30,26,18,.04),0 8px 24px -12px rgba(30,26,18,.14);
min-height:100vh;background:var(--bg);color:var(--ink);font-family:'Jost',system-ui,sans-serif;font-size:15px;line-height:1.5;-webkit-font-smoothing:antialiased;-webkit-tap-highlight-color:transparent}
.hzs *,.hzs *:before,.hzs *:after,.hzs-layer *,.hzs-layer *:before,.hzs-layer *:after{box-sizing:border-box}
.hzs-layer{min-height:0!important;background:none!important}
.hzs button,.hzs input,.hzs select,.hzs textarea,.hzs-layer button,.hzs-layer input,.hzs-layer select,.hzs-layer textarea{font:inherit;color:inherit}
.hzs a,.hzs-layer a{color:inherit;text-decoration:none}
.hzs :focus-visible,.hzs-layer :focus-visible{outline:2px solid var(--gold2);outline-offset:2px;border-radius:10px}
.hzs-top{position:sticky;top:0;z-index:40;background:rgba(251,248,242,.86);backdrop-filter:saturate(1.2) blur(12px);-webkit-backdrop-filter:saturate(1.2) blur(12px);border-bottom:1px solid var(--line)}
.hzs-top-in{max-width:1180px;margin:0 auto;height:64px;padding:0 20px;display:flex;align-items:center;gap:20px}
.hzs-brand{display:flex;align-items:center;gap:10px;white-space:nowrap}
.hzs-brand b{font-family:'Marcellus',serif;font-weight:400;font-size:21px;letter-spacing:.02em}
.hzs-brand i{font-style:normal;font-size:9.5px;letter-spacing:.32em;text-transform:uppercase;color:var(--gold);padding-top:3px}
.hzs-mark{width:15px;height:15px;transform:rotate(45deg);border:1.5px solid var(--gold);display:grid;place-items:center}
.hzs-mark:after{content:"";width:5px;height:5px;background:var(--gold)}
.hzs-nav{display:flex;gap:4px;margin-left:12px}
.hzs-nav a{display:flex;align-items:center;gap:8px;padding:8px 14px;border-radius:999px;font-size:14px;color:var(--ink2);transition:background .2s,color .2s}
.hzs-nav a:hover{background:rgba(30,26,18,.05);color:var(--ink)}
.hzs-nav a.on{background:var(--ink);color:#FBF8F2}
.hzs-user{margin-left:auto;display:flex;align-items:center;gap:10px}
.hzs-avatar{width:34px;height:34px;border-radius:50%;background:var(--goldbg);border:1px solid var(--goldline);display:grid;place-items:center;font-family:'Marcellus',serif;color:var(--gold);font-size:15px;flex:none}
.hzs-uname{font-size:13.5px;color:var(--ink2);max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.hzs-bottom{display:none}
.hzs-wrap{max-width:1180px;margin:0 auto;padding:32px 20px 64px}
.hzs-eyebrow{display:flex;align-items:center;gap:10px;font-size:10.5px;letter-spacing:.32em;text-transform:uppercase;color:var(--gold)}
.hzs-eyebrow:before{content:"";width:22px;height:1px;background:var(--gold)}
.hzs-h1{font-family:'Marcellus',serif;font-weight:400;font-size:clamp(30px,4.4vw,42px);line-height:1.08;margin:10px 0 0;letter-spacing:-.005em}
.hzs-h2{font-family:'Marcellus',serif;font-weight:400;font-size:22px;line-height:1.2;margin:0}
.hzs-h3{font-family:'Jost',sans-serif;font-weight:500;font-size:15.5px;margin:0}
.hzs-accent{font-family:'Cormorant Garamond',serif;font-style:italic;color:var(--gold);font-weight:500}
.hzs-sub{color:var(--ink2);font-size:15px;margin:8px 0 0;max-width:620px}
.hzs-muted{color:var(--ink3)}
.hzs-head{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;flex-wrap:wrap;margin-bottom:28px}
.hzs-head-act{display:flex;gap:10px;flex-wrap:wrap}
.hzs-card{background:var(--card);border:1px solid var(--line);border-radius:var(--r);box-shadow:var(--shadow)}
.hzs-pad{padding:22px}
.hzs-sec{padding:22px;border-bottom:1px solid var(--line)}
.hzs-sec:last-child{border-bottom:0}
.hzs-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;height:42px;padding:0 18px;border-radius:999px;border:1px solid transparent;cursor:pointer;font-size:14px;font-weight:500;letter-spacing:.01em;white-space:nowrap;transition:background .18s,border-color .18s,color .18s,transform .12s,box-shadow .18s;user-select:none}
.hzs-btn:active{transform:translateY(1px)}
.hzs-btn[disabled]{opacity:.45;cursor:not-allowed;transform:none}
.hzs-btn.primary{background:var(--ink);color:#FBF8F2;box-shadow:0 6px 16px -8px rgba(30,26,18,.6)}
.hzs-btn.primary:hover:not([disabled]){background:#2E281C}
.hzs-btn.gold{background:linear-gradient(180deg,#C9A961,#A9873F);color:#1E1A12;box-shadow:0 6px 16px -8px rgba(160,125,59,.8)}
.hzs-btn.secondary{background:var(--card);border-color:var(--line2);color:var(--ink)}
.hzs-btn.secondary:hover:not([disabled]){border-color:var(--ink3);background:#fff}
.hzs-btn.ghost{background:transparent;color:var(--ink2)}
.hzs-btn.ghost:hover:not([disabled]){background:rgba(30,26,18,.05);color:var(--ink)}
.hzs-btn.danger{background:var(--bad);color:#fff}
.hzs-btn.danger:hover:not([disabled]){background:#8E3B30}
.hzs-btn.dangerSoft{background:var(--badbg);color:var(--bad)}
.hzs-btn.okSoft{background:var(--okbg);color:var(--ok)}
.hzs-btn.sm{height:34px;padding:0 13px;font-size:13px;gap:6px}
.hzs-btn.xs{height:28px;padding:0 10px;font-size:12px;gap:5px}
.hzs-btn.icon{width:38px;padding:0}
.hzs-btn.icon.sm{width:34px}
.hzs-btn.block{width:100%}
.hzs-field{display:block}
.hzs-label{display:flex;align-items:center;gap:8px;font-size:12.5px;font-weight:500;color:var(--ink2);margin:0 0 7px;letter-spacing:.01em}
.hzs-hint{font-size:12.5px;color:var(--ink3);margin:6px 0 0;line-height:1.45}
.hzs-err{font-size:12.5px;color:var(--bad);margin:6px 0 0}
.hzs-input,.hzs-select,.hzs-textarea{width:100%;height:44px;padding:0 14px;border-radius:12px;border:1px solid var(--line2);background:var(--paper);font-size:15px;outline:none;transition:border-color .18s,box-shadow .18s,background .18s;-webkit-appearance:none;appearance:none}
.hzs-textarea{height:auto;min-height:92px;padding:11px 14px;line-height:1.55;resize:vertical}
.hzs-select{padding-right:36px;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%238E8473' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 13px center;cursor:pointer}
.hzs-input:hover,.hzs-select:hover,.hzs-textarea:hover{border-color:rgba(30,26,18,.26)}
.hzs-input:focus,.hzs-select:focus,.hzs-textarea:focus{border-color:var(--gold);box-shadow:0 0 0 4px rgba(198,164,94,.16);background:#fff}
.hzs-input::placeholder,.hzs-textarea::placeholder{color:#B4AA98}
.hzs-input.bad{border-color:var(--bad)}
.hzs-badge{display:inline-flex;align-items:center;gap:5px;height:24px;padding:0 10px;border-radius:999px;font-size:11.5px;font-weight:500;letter-spacing:.02em;white-space:nowrap;background:rgba(30,26,18,.06);color:var(--ink2)}
.hzs-badge.ok{background:var(--okbg);color:var(--ok)}.hzs-badge.bad{background:var(--badbg);color:var(--bad)}.hzs-badge.warn{background:var(--warnbg);color:var(--warn)}.hzs-badge.info{background:var(--infobg);color:var(--info)}.hzs-badge.gold{background:var(--goldbg);color:var(--gold)}.hzs-badge.dark{background:var(--ink);color:#FBF8F2}
.hzs-dot{width:7px;height:7px;border-radius:50%;background:currentColor;flex:none}
.hzs-tabs{display:inline-flex;gap:4px;padding:4px;border-radius:999px;background:rgba(30,26,18,.05);overflow-x:auto;scrollbar-width:none;max-width:100%}
.hzs-tabs::-webkit-scrollbar{display:none}
.hzs-tab{display:inline-flex;align-items:center;gap:7px;height:36px;padding:0 15px;border-radius:999px;border:0;background:transparent;cursor:pointer;font-size:13.5px;color:var(--ink2);white-space:nowrap;transition:background .2s,color .2s,box-shadow .2s}
.hzs-tab:hover{color:var(--ink)}
.hzs-tab.on{background:#fff;color:var(--ink);box-shadow:0 1px 2px rgba(30,26,18,.08),0 4px 10px -6px rgba(30,26,18,.2)}
.hzs-tab .n{font-size:11.5px;color:var(--ink3)}
.hzs-chip{display:inline-flex;align-items:center;gap:6px;height:32px;padding:0 12px;border-radius:999px;border:1px solid var(--line2);background:var(--card);cursor:pointer;font-size:13px;color:var(--ink2);white-space:nowrap;transition:all .18s}
.hzs-chip:hover{border-color:var(--ink3);color:var(--ink)}
.hzs-chip.on{background:var(--ink);border-color:var(--ink);color:#FBF8F2}
.hzs-grid{display:grid;gap:16px}
.hzs-g2{grid-template-columns:repeat(2,minmax(0,1fr))}
.hzs-g3{grid-template-columns:repeat(3,minmax(0,1fr))}
.hzs-g4{grid-template-columns:repeat(4,minmax(0,1fr))}
.hzs-split{grid-template-columns:minmax(0,1.2fr) minmax(0,1fr)}
.hzs-row{display:flex;align-items:center;gap:10px}
.hzs-between{display:flex;align-items:center;justify-content:space-between;gap:12px}
.hzs-wrapflex{display:flex;flex-wrap:wrap;gap:8px}
.hzs-stat{padding:18px 20px}
.hzs-stat .v{font-family:'Jost',sans-serif;font-weight:300;font-size:32px;line-height:1.1;margin-top:6px;font-variant-numeric:lining-nums tabular-nums;letter-spacing:-.01em}
.hzs-stat .l{font-size:11.5px;letter-spacing:.14em;text-transform:uppercase;color:var(--ink3);display:flex;align-items:center;gap:7px}
.hzs-stat .s{font-size:12.5px;color:var(--ink3);margin-top:4px}
.hzs-empty{text-align:center;padding:56px 24px;border:1px dashed var(--goldline);border-radius:var(--r);background:rgba(255,255,255,.5)}
.hzs-empty .ic{width:56px;height:56px;margin:0 auto;border-radius:50%;display:grid;place-items:center;background:var(--goldbg);color:var(--gold)}
.hzs-skel{position:relative;overflow:hidden;background:rgba(30,26,18,.06);border-radius:12px}
.hzs-skel:after{content:"";position:absolute;inset:0;transform:translateX(-100%);background:linear-gradient(90deg,transparent,rgba(255,255,255,.65),transparent);animation:hzs-sh 1.4s infinite}
@keyframes hzs-sh{to{transform:translateX(100%)}}
.hzs-list>*+*{border-top:1px solid var(--line)}
.hzs-item{display:flex;align-items:center;gap:14px;padding:14px 18px}
.hzs-check{width:20px;height:20px;border-radius:6px;border:1.5px solid var(--line2);display:grid;place-items:center;background:#fff;cursor:pointer;flex:none;transition:all .15s;color:#fff}
.hzs-check.on{background:var(--ink);border-color:var(--ink)}
.hzs-progress{height:6px;border-radius:999px;background:rgba(30,26,18,.07);overflow:hidden;display:flex}
.hzs-progress>span{height:100%}
.hzs-note{display:flex;gap:12px;padding:14px 16px;border-radius:14px;font-size:13.5px;line-height:1.5}
.hzs-note.gold{background:var(--goldbg);color:#6D5422}.hzs-note.info{background:var(--infobg);color:var(--info)}.hzs-note.warn{background:var(--warnbg);color:var(--warn)}.hzs-note.bad{background:var(--badbg);color:var(--bad)}.hzs-note.ok{background:var(--okbg);color:var(--ok)}
.hzs-modal-bg{position:fixed;inset:0;z-index:200;background:rgba(30,26,18,.42);backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px);display:flex;align-items:center;justify-content:center;padding:20px}
.hzs-modal{width:100%;max-width:460px;background:var(--paper);border-radius:22px;border:1px solid var(--line);box-shadow:0 30px 80px -20px rgba(30,26,18,.45);overflow:hidden}
.hzs-toasts{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:300;display:flex;flex-direction:column;gap:8px;align-items:center;pointer-events:none;width:min(92vw,440px)}
.hzs-toast{pointer-events:auto;display:flex;align-items:center;gap:12px;padding:11px 12px 11px 16px;border-radius:14px;background:var(--ink);color:#FBF8F2;font-size:14px;box-shadow:0 18px 40px -14px rgba(30,26,18,.6);width:100%}
.hzs-toast .act{margin-left:auto;background:rgba(251,248,242,.12);border:0;color:#F2E2BC;border-radius:999px;height:30px;padding:0 12px;cursor:pointer;font-size:13px;flex:none}
.hzs-toast.bad{background:#7E3328}
.hzs-menu{position:absolute;right:0;top:calc(100% + 6px);min-width:200px;background:#fff;border:1px solid var(--line);border-radius:14px;box-shadow:0 18px 44px -14px rgba(30,26,18,.35);padding:6px;z-index:60}
.hzs-menu button,.hzs-menu a{display:flex;align-items:center;gap:10px;width:100%;padding:9px 11px;border:0;background:transparent;border-radius:9px;cursor:pointer;font-size:14px;color:var(--ink);text-align:left}
.hzs-menu button:hover,.hzs-menu a:hover{background:rgba(30,26,18,.05)}
.hzs-menu .bad{color:var(--bad)}
.hzs-pop{position:fixed;min-width:220px;max-width:min(92vw,320px);background:#fff;border:1px solid var(--line);border-radius:14px;box-shadow:0 18px 44px -14px rgba(30,26,18,.35);padding:6px;z-index:260}
.hzs-pop button{display:flex;align-items:center;gap:10px;width:100%;padding:10px 12px;border:0;background:transparent;border-radius:9px;cursor:pointer;font-size:14px;color:var(--ink);text-align:left}
.hzs-pop button:hover{background:rgba(30,26,18,.05)}
.hzs-pop .bad,.hzs-sheet .bad{color:var(--bad)}
.hzs-sheet-bg{position:fixed;inset:0;z-index:255;background:rgba(30,26,18,.38)}
.hzs-sheet{position:fixed;left:0;right:0;bottom:0;z-index:260;background:var(--paper);border-radius:22px 22px 0 0;padding:8px 12px calc(14px + env(safe-area-inset-bottom));box-shadow:0 -20px 50px -20px rgba(30,26,18,.5)}
.hzs-sheet .grab{width:42px;height:4px;border-radius:9px;background:rgba(30,26,18,.18);margin:4px auto 10px}
.hzs-sheet .ttl{font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--ink3);padding:0 8px 6px}
.hzs-sheet button{display:flex;align-items:center;gap:14px;width:100%;min-height:52px;padding:0 12px;border:0;background:transparent;border-radius:12px;font-size:16px;color:var(--ink);text-align:left;cursor:pointer}
.hzs-sheet button:active{background:rgba(30,26,18,.06)}
.hzs-sheet .cancel{justify-content:center;margin-top:6px;background:rgba(30,26,18,.06);font-weight:500}
.hzs-kbd{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12.5px;letter-spacing:.06em;padding:2px 7px;border-radius:7px;background:rgba(30,26,18,.06);color:var(--ink2)}
.hzs-seg{display:inline-flex;padding:3px;border-radius:999px;background:rgba(30,26,18,.06)}
.hzs-seg button{height:30px;padding:0 12px;border-radius:999px;border:0;background:transparent;cursor:pointer;font-size:12.5px;color:var(--ink2);letter-spacing:.04em}
.hzs-seg button.on{background:#fff;color:var(--ink);box-shadow:0 1px 3px rgba(30,26,18,.12)}
.hzs-switch{position:relative;width:42px;height:24px;border-radius:999px;background:rgba(30,26,18,.18);border:0;cursor:pointer;transition:background .2s;flex:none}
.hzs-switch:after{content:"";position:absolute;top:3px;left:3px;width:18px;height:18px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.25);transition:transform .2s}
.hzs-switch.on{background:var(--ok)}
.hzs-switch.on:after{transform:translateX(18px)}
@media (max-width:900px){
 .hzs-nav,.hzs-uname{display:none}
 .hzs-bottom{display:flex;position:fixed;left:0;right:0;bottom:0;z-index:45;background:rgba(251,248,242,.94);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);border-top:1px solid var(--line);padding:6px 8px calc(6px + env(safe-area-inset-bottom))}
 .hzs-bottom a{flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;padding:6px 4px;border-radius:12px;font-size:11px;color:var(--ink3)}
 .hzs-bottom a.on{color:var(--ink)}
 .hzs-bottom a.on svg{color:var(--gold)}
 .hzs-wrap{padding:24px 16px calc(96px + env(safe-area-inset-bottom))}
 .hzs-g4{grid-template-columns:repeat(2,minmax(0,1fr))}
 .hzs-g3{grid-template-columns:1fr}
 .hzs-split{grid-template-columns:1fr}
 .hzs-toasts{bottom:calc(84px + env(safe-area-inset-bottom))}
}
@media (max-width:640px){
 .hzs-g2{grid-template-columns:1fr}
 .hzs-head{margin-bottom:22px}
 .hzs-pad,.hzs-sec{padding:18px}
 .hzs-top-in{height:58px;padding:0 16px}
 .hzs-item{padding:13px 14px}
}
@media (prefers-reduced-motion:reduce){.hzs *{transition:none!important;animation:none!important}}
`;
var cssDone = false;
function useStudioCss() {
  if (!cssDone && typeof document !== "undefined") {
    cssDone = true;
    const s = document.createElement("style");
    s.id = "hzs-css";
    s.textContent = CSS;
    document.head.appendChild(s);
  }
}
var cx = (...a) => a.filter(Boolean).join(" ");
function copyText(text) {
  try {
    if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
  } catch (e) {
  }
  return new Promise((res) => {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand("copy");
    } catch (e) {
    }
    document.body.removeChild(ta);
    res();
  });
}
function downloadFile(name, content, type) {
  const blob = content instanceof Blob ? content : new Blob([content], { type: type || "application/octet-stream" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2e3);
}
function csvOf(rows) {
  return "\uFEFF" + rows.map((r) => r.map((v) => {
    const s = String(v ?? "");
    return /[",\n;]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }).join(",")).join("\n");
}
function plural(n, one, many) {
  return n + " " + (n === 1 ? one : many);
}
function initials(s) {
  const p = String(s || "").trim().split(/\s+/);
  return ((p[0] || "?")[0] + (p.length > 1 ? p[p.length - 1][0] : "")).toUpperCase();
}
function fmtDate(v, opt) {
  const y = HZ.ymd(v);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(y)) return "";
  const d = /* @__PURE__ */ new Date(y + "T12:00:00");
  return d.toLocaleDateString("en-GB", opt || { day: "numeric", month: "short", year: "numeric" });
}
function fmtWhen(ms) {
  if (!ms || ms < 9466848e5) return "";
  const d = new Date(ms);
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}
function weddingDates(inv) {
  const ds = (inv && Array.isArray(inv.events) ? inv.events : []).map((e) => HZ.ymd(e && e.date)).filter((x) => /^\d{4}-\d{2}-\d{2}$/.test(x)).sort();
  return { first: ds[0] || "", last: ds[ds.length - 1] || "" };
}
function daysFromToday(ymd) {
  if (!ymd) return null;
  const t = /* @__PURE__ */ new Date();
  t.setHours(12, 0, 0, 0);
  const d = /* @__PURE__ */ new Date(ymd + "T12:00:00");
  return Math.round((d - t) / 864e5);
}
function whenLabel(ymd) {
  const n = daysFromToday(ymd);
  if (n === null) return { text: "No date yet", tone: "" };
  if (n === 0) return { text: "Today", tone: "gold" };
  if (n === 1) return { text: "Tomorrow", tone: "gold" };
  if (n > 1) return { text: "In " + n + " days", tone: n <= 14 ? "warn" : "info" };
  if (n === -1) return { text: "Yesterday", tone: "" };
  return { text: -n + " days ago", tone: "" };
}
var repoP = null;
function repo() {
  return repoP = repoP || HZ.repo();
}
function useData(fn, deps, opt) {
  const [st, setSt] = useState({ data: void 0, error: null, loading: true });
  const [tick, setTick] = useState(0);
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const enabled = !opt || opt.enabled !== false;
  useEffect(() => {
    if (!enabled) return;
    let live = true;
    setSt((s) => ({ ...s, loading: s.data === void 0, error: null }));
    repo().then((r) => fnRef.current(r)).then((data) => {
      if (live) setSt({ data, error: null, loading: false });
    }).catch((error) => {
      if (live) setSt((s) => ({ ...s, error, loading: false }));
    });
    return () => {
      live = false;
    };
  }, [...deps || [], tick, enabled]);
  const reload = useCallback(() => setTick((t) => t + 1), []);
  const mutate = useCallback((f) => setSt((s) => ({ ...s, data: typeof f === "function" ? f(s.data) : f })), []);
  return { ...st, reload, mutate };
}
async function call(fn) {
  const r = await repo();
  const out = await fn(r);
  try {
    HZ.emit("*");
  } catch (e) {
  }
  return out;
}
function errText(e) {
  const m = e && e.message || String(e || "");
  if (/permission|insufficient/i.test(m)) return "You don't have permission to do that.";
  if (/network|offline|unavailable|Failed to fetch/i.test(m)) return "No connection \u2014 check your internet and try again.";
  return m || "Something went wrong.";
}
var UICtx = createContext(null);
function useUI() {
  return useContext(UICtx);
}
function UIProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const [dlg, setDlg] = useState(null);
  const toast = useCallback((text, o) => {
    const id = Math.random().toString(36).slice(2);
    const t = { id, text, tone: o && o.tone || "", action: o && o.action, ms: o && o.ms || (o && o.action ? 7e3 : 3200) };
    setToasts((a) => [...a.slice(-2), t]);
    setTimeout(() => setToasts((a) => a.filter((x) => x.id !== id)), t.ms);
  }, []);
  const confirm = useCallback((o) => new Promise((res) => setDlg({ ...o, res })), []);
  const close = (v) => {
    if (dlg) dlg.res(v);
    setDlg(null);
  };
  const api = useMemo(() => ({ toast, confirm }), [toast, confirm]);
  return /* @__PURE__ */ React.createElement(UICtx.Provider, { value: api }, children, /* @__PURE__ */ React.createElement("div", { className: "hzs-toasts", "aria-live": "polite" }, /* @__PURE__ */ React.createElement(AnimatePresence, { initial: false }, toasts.map((t) => /* @__PURE__ */ React.createElement(motion.div, { key: t.id, className: cx("hzs-toast", t.tone), initial: { opacity: 0, y: 14, scale: 0.98 }, animate: { opacity: 1, y: 0, scale: 1 }, exit: { opacity: 0, y: 8 }, transition: { duration: 0.22 } }, /* @__PURE__ */ React.createElement("span", null, t.text), t.action ? /* @__PURE__ */ React.createElement("button", { className: "act", onClick: () => {
    t.action.fn();
    setToasts((a) => a.filter((x) => x.id !== t.id));
  } }, t.action.label) : null)))), /* @__PURE__ */ React.createElement(AnimatePresence, null, dlg ? /* @__PURE__ */ React.createElement(ConfirmDialog, { key: "dlg", o: dlg, onClose: close }) : null));
}
function Modal({ onClose, children, width, label }) {
  useEffect(() => {
    const k = (e) => e.key === "Escape" && onClose && onClose();
    window.addEventListener("keydown", k);
    const o = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", k);
      document.body.style.overflow = o;
    };
  }, [onClose]);
  return HZ.portal(
    /* @__PURE__ */ React.createElement(
      motion.div,
      {
        className: "hzs-modal-bg hzs-layer",
        role: "dialog",
        "aria-modal": "true",
        "aria-label": label,
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        exit: { opacity: 0 },
        transition: { duration: 0.18 },
        onMouseDown: (e) => {
          if (e.target === e.currentTarget && onClose) onClose();
        }
      },
      /* @__PURE__ */ React.createElement(motion.div, { className: "hzs-modal", style: width ? { maxWidth: width } : null, initial: { opacity: 0, y: 12, scale: 0.98 }, animate: { opacity: 1, y: 0, scale: 1 }, exit: { opacity: 0, y: 8, scale: 0.99 }, transition: { duration: 0.22, ease: [0.22, 1, 0.36, 1] } }, children)
    )
  );
}
function ConfirmDialog({ o, onClose }) {
  const [typed, setTyped] = useState("");
  const need = o.typeToConfirm ? String(o.typeToConfirm) : "";
  const ok = !need || typed.trim().toUpperCase() === need.toUpperCase();
  const Ic = o.tone === "danger" ? I.alert : I.info;
  return /* @__PURE__ */ React.createElement(Modal, { onClose: () => onClose(false), label: o.title }, /* @__PURE__ */ React.createElement("div", { style: { padding: "24px 24px 8px" } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { alignItems: "flex-start", gap: 14 } }, /* @__PURE__ */ React.createElement("div", { style: { width: 40, height: 40, borderRadius: 12, display: "grid", placeItems: "center", flex: "none", background: o.tone === "danger" ? "var(--badbg)" : "var(--goldbg)", color: o.tone === "danger" ? "var(--bad)" : "var(--gold)" } }, /* @__PURE__ */ React.createElement(Ic, { size: 19 })), /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0 } }, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h2", style: { fontSize: 20 } }, o.title), o.body ? /* @__PURE__ */ React.createElement("div", { className: "hzs-sub", style: { fontSize: 14.5, marginTop: 6 } }, o.body) : null)), need ? /* @__PURE__ */ React.createElement("div", { style: { marginTop: 18 } }, /* @__PURE__ */ React.createElement("label", { className: "hzs-label" }, "Type ", /* @__PURE__ */ React.createElement("span", { className: "hzs-kbd" }, need), " to confirm"), /* @__PURE__ */ React.createElement("input", { className: "hzs-input", autoFocus: true, value: typed, onChange: (e) => setTyped(e.target.value), onKeyDown: (e) => {
    if (e.key === "Enter" && ok) onClose(true);
  }, autoCapitalize: "characters", autoComplete: "off" })) : null), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { justifyContent: "flex-end", padding: "16px 24px 22px", gap: 10 } }, /* @__PURE__ */ React.createElement("button", { className: "hzs-btn ghost", onClick: () => onClose(false) }, o.cancelText || "Cancel"), /* @__PURE__ */ React.createElement("button", { className: cx("hzs-btn", o.tone === "danger" ? "danger" : "primary"), disabled: !ok, onClick: () => onClose(true), autoFocus: !need }, o.confirmText || "Confirm")));
}
function Button({ variant = "secondary", size, icon: Ic, iconRight: IcR, block, className, children, busy, ...p }) {
  return /* @__PURE__ */ React.createElement("button", { className: cx("hzs-btn", variant, size, block && "block", !children && "icon", className), ...p, disabled: p.disabled || busy }, busy ? /* @__PURE__ */ React.createElement(Spinner, null) : Ic ? /* @__PURE__ */ React.createElement(Ic, { size: size === "xs" ? 13 : size === "sm" ? 15 : 16 }) : null, children, IcR ? /* @__PURE__ */ React.createElement(IcR, { size: 15 }) : null);
}
function LinkButton({ variant = "secondary", size, icon: Ic, to, href, className, children, ...p }) {
  const cls = cx("hzs-btn", variant, size, !children && "icon", className);
  const inner = /* @__PURE__ */ React.createElement(React.Fragment, null, Ic ? /* @__PURE__ */ React.createElement(Ic, { size: size === "sm" ? 15 : 16 }) : null, children);
  return href ? /* @__PURE__ */ React.createElement("a", { className: cls, href, target: "_blank", rel: "noreferrer", ...p }, inner) : /* @__PURE__ */ React.createElement(Link, { className: cls, to, ...p }, inner);
}
function Spinner({ size = 15 }) {
  return /* @__PURE__ */ React.createElement("svg", { width: size, height: size, viewBox: "0 0 24 24", style: { animation: "hzs-spin .8s linear infinite" }, "aria-hidden": "true" }, /* @__PURE__ */ React.createElement("style", null, "@keyframes hzs-spin{to{transform:rotate(360deg)}}"), /* @__PURE__ */ React.createElement("circle", { cx: "12", cy: "12", r: "9", fill: "none", stroke: "currentColor", strokeOpacity: ".25", strokeWidth: "3" }), /* @__PURE__ */ React.createElement("path", { d: "M21 12a9 9 0 0 0-9-9", fill: "none", stroke: "currentColor", strokeWidth: "3", strokeLinecap: "round" }));
}
function Field({ label, hint, error, children, right, style }) {
  return /* @__PURE__ */ React.createElement("label", { className: "hzs-field", style }, label ? /* @__PURE__ */ React.createElement("span", { className: "hzs-label" }, label, right ? /* @__PURE__ */ React.createElement("span", { style: { marginLeft: "auto" } }, right) : null) : null, children, error ? /* @__PURE__ */ React.createElement("p", { className: "hzs-err" }, error) : hint ? /* @__PURE__ */ React.createElement("p", { className: "hzs-hint" }, hint) : null);
}
function Input(p) {
  return /* @__PURE__ */ React.createElement("input", { ...p, className: cx("hzs-input", p.className) });
}
function Textarea(p) {
  return /* @__PURE__ */ React.createElement("textarea", { ...p, className: cx("hzs-textarea", p.className) });
}
function Select({ options, ...p }) {
  return /* @__PURE__ */ React.createElement("select", { ...p, className: cx("hzs-select", p.className) }, options.map((o) => /* @__PURE__ */ React.createElement("option", { key: o.value, value: o.value }, o.label)));
}
function Badge({ tone, dot, children, style }) {
  return /* @__PURE__ */ React.createElement("span", { className: cx("hzs-badge", tone), style }, dot ? /* @__PURE__ */ React.createElement("span", { className: "hzs-dot" }) : null, children);
}
function Switch({ on, onChange, label }) {
  return /* @__PURE__ */ React.createElement("button", { type: "button", role: "switch", "aria-checked": !!on, "aria-label": label, className: cx("hzs-switch", on && "on"), onClick: () => onChange(!on) });
}
function Check({ on, onChange, label }) {
  return /* @__PURE__ */ React.createElement("button", { type: "button", role: "checkbox", "aria-checked": !!on, "aria-label": label, className: cx("hzs-check", on && "on"), onClick: (e) => {
    e.stopPropagation();
    onChange(!on);
  } }, on ? /* @__PURE__ */ React.createElement(I.check, { size: 13, strokeWidth: 3 }) : null);
}
function Tabs({ items, value, onChange, style }) {
  return /* @__PURE__ */ React.createElement("div", { className: "hzs-tabs", role: "tablist", style }, items.map((t) => /* @__PURE__ */ React.createElement("button", { key: t.id, role: "tab", "aria-selected": value === t.id, className: cx("hzs-tab", value === t.id && "on"), onClick: () => onChange(t.id) }, t.icon ? /* @__PURE__ */ React.createElement(t.icon, { size: 15 }) : null, t.label, t.n != null ? /* @__PURE__ */ React.createElement("span", { className: "n" }, t.n) : null)));
}
function Seg({ items, value, onChange }) {
  return /* @__PURE__ */ React.createElement("div", { className: "hzs-seg" }, items.map((t) => /* @__PURE__ */ React.createElement("button", { key: t.id, className: value === t.id ? "on" : "", onClick: () => onChange(t.id), type: "button" }, t.label)));
}
function Card({ children, pad, style, className, ...p }) {
  return /* @__PURE__ */ React.createElement("div", { className: cx("hzs-card", pad && "hzs-pad", className), style, ...p }, children);
}
function Section({ title, sub, icon: Ic, right, children, style }) {
  return /* @__PURE__ */ React.createElement(Card, { style }, /* @__PURE__ */ React.createElement("div", { className: "hzs-sec", style: { paddingBottom: children ? 0 : void 0, borderBottom: 0 } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between", style: { alignItems: "flex-start", flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { alignItems: "flex-start", gap: 12, flex: "1 1 260px", minWidth: 0 } }, Ic ? /* @__PURE__ */ React.createElement("div", { style: { width: 34, height: 34, borderRadius: 10, background: "var(--goldbg)", color: "var(--gold)", display: "grid", placeItems: "center", flex: "none" } }, /* @__PURE__ */ React.createElement(Ic, { size: 17 })) : null, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h2", { className: "hzs-h2", style: { fontSize: 19 } }, title), sub ? /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { marginTop: 3, fontSize: 13.5 } }, sub) : null)), right)), children ? /* @__PURE__ */ React.createElement("div", { className: "hzs-sec", style: { paddingTop: 18 } }, children) : null);
}
function Stat({ icon: Ic, label, value, sub }) {
  return /* @__PURE__ */ React.createElement(Card, { className: "hzs-stat" }, /* @__PURE__ */ React.createElement("div", { className: "l" }, Ic ? /* @__PURE__ */ React.createElement(Ic, { size: 14 }) : null, label), /* @__PURE__ */ React.createElement("div", { className: "v" }, value), sub ? /* @__PURE__ */ React.createElement("div", { className: "s" }, sub) : null);
}
function Empty({ icon: Ic = I.sparkle, title, text, children }) {
  return /* @__PURE__ */ React.createElement("div", { className: "hzs-empty" }, /* @__PURE__ */ React.createElement("div", { className: "ic" }, /* @__PURE__ */ React.createElement(Ic, { size: 24 })), /* @__PURE__ */ React.createElement("p", { className: "hzs-h2", style: { marginTop: 16 } }, title), text ? /* @__PURE__ */ React.createElement("p", { className: "hzs-sub", style: { margin: "6px auto 0" } }, text) : null, children ? /* @__PURE__ */ React.createElement("div", { style: { marginTop: 20, display: "flex", justifyContent: "center", gap: 10, flexWrap: "wrap" } }, children) : null);
}
function Skel({ h = 16, w = "100%", r, style }) {
  return /* @__PURE__ */ React.createElement("div", { className: "hzs-skel", style: { height: h, width: w, borderRadius: r, ...style } });
}
function Note({ tone = "gold", icon: Ic = I.info, children, style }) {
  return /* @__PURE__ */ React.createElement("div", { className: cx("hzs-note", tone), style }, /* @__PURE__ */ React.createElement(Ic, { size: 17, style: { flex: "none", marginTop: 1 } }), /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0 } }, children));
}
function Menu({ items, label = "More", size = "sm", title }) {
  const [open, setOpen] = useState(null);
  const btn = useRef(null);
  const list = items.filter(Boolean);
  const show = () => {
    const r = btn.current.getBoundingClientRect();
    const mobile = window.matchMedia("(max-width: 640px)").matches;
    if (mobile) return setOpen({ mobile: true });
    const n = list.length, h = n * 42 + 14;
    const below = r.bottom + 6 + h < window.innerHeight - 8;
    const left = Math.max(8, Math.min(window.innerWidth - 236, r.right - 228));
    setOpen({ mobile: false, left, top: below ? r.bottom + 6 : Math.max(8, r.top - 6 - h) });
  };
  useEffect(() => {
    if (!open) return;
    const k = (e) => e.key === "Escape" && setOpen(null);
    const s2 = () => !open.mobile && setOpen(null);
    window.addEventListener("keydown", k);
    window.addEventListener("scroll", s2, true);
    window.addEventListener("resize", s2);
    return () => {
      window.removeEventListener("keydown", k);
      window.removeEventListener("scroll", s2, true);
      window.removeEventListener("resize", s2);
    };
  }, [open]);
  const pick = (it) => {
    setOpen(null);
    setTimeout(() => it.onClick(), 0);
  };
  const rows = (cls) => list.map((it, i) => it === "-" ? /* @__PURE__ */ React.createElement("div", { key: i, style: { height: 1, background: "var(--line)", margin: "5px 6px" } }) : /* @__PURE__ */ React.createElement("button", { key: i, className: it.danger ? "bad" : "", onClick: () => pick(it) }, it.icon ? /* @__PURE__ */ React.createElement(it.icon, { size: cls ? 19 : 16 }) : null, it.label));
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("span", { ref: btn, style: { display: "inline-flex" } }, /* @__PURE__ */ React.createElement(Button, { variant: "ghost", size, icon: I.more, "aria-label": label, "aria-haspopup": "menu", "aria-expanded": !!open, onClick: () => open ? setOpen(null) : show() })), HZ.portal(
    /* @__PURE__ */ React.createElement(AnimatePresence, null, open && open.mobile ? /* @__PURE__ */ React.createElement("div", { className: "hzs-layer", key: "sheet" }, /* @__PURE__ */ React.createElement(motion.div, { className: "hzs-sheet-bg", initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, onClick: () => setOpen(null) }), /* @__PURE__ */ React.createElement(motion.div, { className: "hzs-sheet", role: "menu", initial: { y: "100%" }, animate: { y: 0 }, exit: { y: "100%" }, transition: { type: "tween", duration: 0.24, ease: [0.22, 1, 0.36, 1] } }, /* @__PURE__ */ React.createElement("div", { className: "grab" }), title ? /* @__PURE__ */ React.createElement("div", { className: "ttl" }, title) : null, rows(true), /* @__PURE__ */ React.createElement("button", { className: "cancel", onClick: () => setOpen(null) }, "Cancel"))) : open ? /* @__PURE__ */ React.createElement("div", { className: "hzs-layer", key: "pop" }, /* @__PURE__ */ React.createElement("div", { style: { position: "fixed", inset: 0, zIndex: 255 }, onMouseDown: () => setOpen(null) }), /* @__PURE__ */ React.createElement(motion.div, { className: "hzs-pop", role: "menu", style: { left: open.left, top: open.top }, initial: { opacity: 0, y: -4 }, animate: { opacity: 1, y: 0 }, exit: { opacity: 0 }, transition: { duration: 0.14 } }, rows(false))) : null)
  ));
}
function Progress({ parts }) {
  const total = parts.reduce((a, p) => a + p.v, 0) || 1;
  return /* @__PURE__ */ React.createElement("div", { className: "hzs-progress" }, parts.map((p, i) => p.v ? /* @__PURE__ */ React.createElement("span", { key: i, style: { width: 100 * p.v / total + "%", background: p.c } }) : null));
}
function Rise({ children, i = 0, style, className }) {
  return /* @__PURE__ */ React.createElement(motion.div, { className, style, initial: { opacity: 0, y: 10 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.38, delay: Math.min(i, 8) * 0.04, ease: [0.22, 1, 0.36, 1] } }, children);
}
function PageHead({ eyebrow, title, accent, sub, children }) {
  return /* @__PURE__ */ React.createElement("div", { className: "hzs-head" }, /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0 } }, eyebrow ? /* @__PURE__ */ React.createElement("div", { className: "hzs-eyebrow" }, eyebrow) : null, /* @__PURE__ */ React.createElement("h1", { className: "hzs-h1" }, title, accent ? /* @__PURE__ */ React.createElement(React.Fragment, null, " ", /* @__PURE__ */ React.createElement("span", { className: "hzs-accent" }, accent)) : null), sub ? /* @__PURE__ */ React.createElement("p", { className: "hzs-sub" }, sub) : null), children ? /* @__PURE__ */ React.createElement("div", { className: "hzs-head-act" }, children) : null);
}
function Shell({ children, admin, active, bare, wide, noBottom }) {
  useStudioCss();
  const auth = useAuth({ redirectOnUnauthenticated: true });
  const user = auth.user;
  const nav = [
    { id: "weddings", to: "/dashboard", label: "Weddings", icon: I.home },
    { id: "lists", to: "/lists", label: "Guest lists", icon: I.list },
    user && user.role === "admin" ? { id: "admin", to: "/admin", label: "Admin", icon: I.shield } : null
  ].filter(Boolean);
  useEffect(() => {
    document.documentElement.lang = "en";
  }, []);
  let body;
  if (auth.isLoading || !user) {
    body = /* @__PURE__ */ React.createElement("div", { className: "hzs-wrap" }, /* @__PURE__ */ React.createElement(Skel, { h: 14, w: 120 }), /* @__PURE__ */ React.createElement(Skel, { h: 40, w: 320, style: { marginTop: 14 } }), /* @__PURE__ */ React.createElement("div", { className: "hzs-grid hzs-g2", style: { marginTop: 32 } }, /* @__PURE__ */ React.createElement(Skel, { h: 220, r: 18 }), /* @__PURE__ */ React.createElement(Skel, { h: 220, r: 18 })));
  } else if (admin && user.role !== "admin") {
    body = /* @__PURE__ */ React.createElement("div", { className: "hzs-wrap" }, /* @__PURE__ */ React.createElement(Empty, { icon: I.shield, title: "Admins only", text: "This area manages every host and wedding on Harusi." }, /* @__PURE__ */ React.createElement(LinkButton, { to: "/dashboard", variant: "primary" }, "Go to my weddings")));
  } else {
    body = typeof children === "function" ? children(user, auth) : children;
  }
  return /* @__PURE__ */ React.createElement("div", { className: "hzs" }, /* @__PURE__ */ React.createElement(UIProvider, null, bare ? null : /* @__PURE__ */ React.createElement("header", { className: "hzs-top" }, /* @__PURE__ */ React.createElement("div", { className: "hzs-top-in", style: wide ? { maxWidth: "none" } : null }, /* @__PURE__ */ React.createElement(Link, { to: "/dashboard", className: "hzs-brand", "aria-label": "Harusi Studio" }, /* @__PURE__ */ React.createElement("span", { className: "hzs-mark" }), /* @__PURE__ */ React.createElement("b", null, "Harusi"), /* @__PURE__ */ React.createElement("i", null, "Studio")), /* @__PURE__ */ React.createElement("nav", { className: "hzs-nav" }, nav.map((n) => /* @__PURE__ */ React.createElement(Link, { key: n.id, to: n.to, className: active === n.id ? "on" : "" }, /* @__PURE__ */ React.createElement(n.icon, { size: 16 }), n.label))), user ? /* @__PURE__ */ React.createElement("div", { className: "hzs-user" }, /* @__PURE__ */ React.createElement("span", { className: "hzs-uname" }, user.name || user.email), /* @__PURE__ */ React.createElement("span", { className: "hzs-avatar", title: user.email }, initials(user.name || user.email)), /* @__PURE__ */ React.createElement(Button, { variant: "ghost", size: "sm", icon: I.logout, "aria-label": "Sign out", title: "Sign out", onClick: auth.logout })) : null)), body, bare || noBottom || !user ? null : /* @__PURE__ */ React.createElement("nav", { className: "hzs-bottom" }, nav.map((n) => /* @__PURE__ */ React.createElement(Link, { key: n.id, to: n.to, className: active === n.id ? "on" : "" }, /* @__PURE__ */ React.createElement(n.icon, { size: 20 }), n.label)))));
}

export {
  React,
  useNavigate,
  Link,
  motion,
  AnimatePresence,
  HZ,
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
  I,
  useStudioCss,
  cx,
  copyText,
  downloadFile,
  csvOf,
  plural,
  initials,
  fmtDate,
  fmtWhen,
  weddingDates,
  whenLabel,
  useData,
  call,
  errText,
  useUI,
  Modal,
  Button,
  LinkButton,
  Spinner,
  Field,
  Input,
  Textarea,
  Select,
  Badge,
  Switch,
  Check,
  Tabs,
  Seg,
  Card,
  Section,
  Stat,
  Empty,
  Skel,
  Note,
  Menu,
  Progress,
  Rise,
  PageHead,
  Shell
};
