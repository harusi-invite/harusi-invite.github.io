import {
  AnimatePresence,
  Badge,
  Button,
  Card,
  Empty,
  Field,
  HZ,
  I,
  Input,
  Menu,
  Note,
  PageHead,
  React,
  Rise,
  Shell,
  Skel,
  Tabs,
  call,
  copyText,
  csvOf,
  downloadFile,
  errText,
  motion,
  useData,
  useState,
  useUI
} from "./studio-IQ3KHCEJ-d3456d0.js";

// studio/lists.jsx
var listWaMsg = (id) => "Assalamu alaikum! \u{1F49B}\nTafadhali jaza orodha ya wageni wako hapa \u2014 andika jina la kila mgeni na namba yake ya WhatsApp. Inajihifadhi yenyewe, unaweza kuendelea baadaye:\n" + HZ.listLink(id) + "\n\nPlease fill in your guest list here (each guest's name and WhatsApp number). It saves automatically.\n\u2014 Harusi";
function ago(ts) {
  if (!ts) return "";
  const m = Math.round((Date.now() - ts) / 6e4);
  if (m < 1) return "just now";
  if (m < 60) return m + " min ago";
  const h = Math.round(m / 60);
  if (h < 24) return h + " h ago";
  const d = Math.round(h / 24);
  return d < 30 ? d + " days ago" : new Date(ts).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}
function listState(l) {
  if (l.importedAt) return { label: "Imported", tone: "info" };
  if (l.status === "submitted") return { label: "Submitted", tone: "ok" };
  if ((l.entries || []).length || l.clientName) return { label: "Being filled", tone: "warn" };
  return { label: "Not opened", tone: "" };
}
function listCsv(l) {
  const rows = [["#", "Name", "WhatsApp", "Table", "Check"]].concat((l.entries || []).map((e, i) => {
    const p = HZ.phone(e.phone);
    return [i + 1, e.name || "", p.num || e.phone || "", HZ.tbl.name(e.table), p.empty ? "no number" : p.ok ? "ok" : "check number"];
  }));
  downloadFile("guest-list-" + String(l.clientName || l.label || l.id).replace(/[^\w]+/g, "-") + ".csv", csvOf(rows), "text/csv");
}
function Lists() {
  return /* @__PURE__ */ React.createElement(Shell, { active: "lists" }, () => /* @__PURE__ */ React.createElement(ListsPage, null));
}
function ListsPage() {
  const ui = useUI();
  const q = useData((r) => r.guestLists.mine(), []);
  const [label, setLabel] = useState("");
  const [busy, setBusy] = useState(false);
  const [fresh, setFresh] = useState(null);
  const [open, setOpen] = useState(null);
  const [tab, setTab] = useState("active");
  const lists = q.data || [];
  const active = lists.filter((l) => !l.importedAt);
  const done = lists.filter((l) => l.importedAt);
  const tabEff = tab === "active" && !active.length && done.length ? "all" : tab;
  const shown = tabEff === "active" ? active : tabEff === "imported" ? done : lists;
  const create = async () => {
    setBusy(true);
    try {
      const d = await call((r) => r.guestLists.create({ label: label.trim(), token: HZ.token() }));
      setFresh(d.id);
      setLabel("");
      q.reload();
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
    }
    setBusy(false);
  };
  const remove = async (l) => {
    const ok = await ui.confirm({ title: "Delete this guest list?", body: /* @__PURE__ */ React.createElement(React.Fragment, null, "The client's link will stop working and ", (l.entries || []).length, " names will be removed. Download the CSV first if you may need them."), confirmText: "Delete list", tone: "danger" });
    if (!ok) return;
    try {
      await call((r) => r.guestLists.remove({ id: l.id }));
      q.mutate((d) => (d || []).filter((x) => x.id !== l.id));
      ui.toast("Guest list deleted");
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
    }
  };
  return /* @__PURE__ */ React.createElement("main", { className: "hzs-wrap" }, /* @__PURE__ */ React.createElement(PageHead, { eyebrow: "Client links", title: "Guest", accent: "lists", sub: "Send a client one link \u2014 they type their guests' names, WhatsApp numbers and table numbers, no login needed. Then import the list into their invitation from the Guests step." }), /* @__PURE__ */ React.createElement(Card, { pad: true, style: { marginBottom: 26 } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 12, alignItems: "flex-end", flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Field, { label: "New link \u2014 label only you will see", style: { flex: "1 1 280px" } }, /* @__PURE__ */ React.createElement(Input, { value: label, onChange: (e) => setLabel(e.target.value), placeholder: "e.g. Amina & Yusuf \u2014 bride's side", onKeyDown: (e) => e.key === "Enter" && !busy && create() })), /* @__PURE__ */ React.createElement(Button, { variant: "primary", icon: I.plus, onClick: create, busy }, "Create link")), /* @__PURE__ */ React.createElement(AnimatePresence, null, fresh ? /* @__PURE__ */ React.createElement(motion.div, { initial: { opacity: 0, height: 0 }, animate: { opacity: 1, height: "auto" }, exit: { opacity: 0, height: 0 }, style: { overflow: "hidden" } }, /* @__PURE__ */ React.createElement(Note, { tone: "ok", icon: I.okCircle, style: { marginTop: 18 } }, /* @__PURE__ */ React.createElement("div", { style: { fontWeight: 500 } }, "Link ready \u2014 send it to your client"), /* @__PURE__ */ React.createElement("div", { style: { wordBreak: "break-all", fontSize: 13, marginTop: 4, opacity: 0.9 } }, HZ.listLink(fresh)), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, marginTop: 12, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "secondary", icon: I.copy, onClick: () => copyText(HZ.listLink(fresh)).then(() => ui.toast("Link copied")) }, "Copy link"), /* @__PURE__ */ React.createElement("a", { className: "hzs-btn sm", style: { background: "#1F8F4E", color: "#fff" }, href: "https://wa.me/?text=" + encodeURIComponent(listWaMsg(fresh)), target: "_blank", rel: "noreferrer" }, /* @__PURE__ */ React.createElement(I.chat, { size: 15 }), "Send on WhatsApp"), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", onClick: () => setFresh(null) }, "Done")))) : null)), q.loading ? /* @__PURE__ */ React.createElement("div", { className: "hzs-grid" }, [0, 1, 2].map((i) => /* @__PURE__ */ React.createElement(Skel, { key: i, h: 92, r: 18 }))) : q.error ? /* @__PURE__ */ React.createElement(Empty, { icon: I.alert, title: "Couldn't load guest lists", text: errText(q.error) }, /* @__PURE__ */ React.createElement(Button, { variant: "primary", onClick: q.reload, icon: I.refresh }, "Try again")) : !lists.length ? /* @__PURE__ */ React.createElement(Empty, { icon: I.list, title: "No guest lists yet", text: "Create a link above and send it to a client on WhatsApp." }) : /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement(Tabs, { value: tabEff, onChange: setTab, style: { marginBottom: 16 }, items: [{ id: "active", label: "Waiting / ready", n: active.length }, { id: "imported", label: "Imported", n: done.length }, { id: "all", label: "All", n: lists.length }] }), !shown.length ? /* @__PURE__ */ React.createElement(Card, { pad: true, style: { textAlign: "center", color: "var(--ink3)" } }, "Nothing here.") : /* @__PURE__ */ React.createElement("div", { className: "hzs-grid" }, shown.map((l, i) => {
    const ent = l.entries || [];
    const bad = ent.filter((e) => !HZ.phone(e.phone).ok).length;
    const st = listState(l);
    const isOpen = open === l.id;
    return /* @__PURE__ */ React.createElement(Rise, { key: l.id, i }, /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { display: "flex", gap: 14, alignItems: "flex-start", flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("div", { style: { flex: "1 1 260px", minWidth: 0 } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 10, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("h3", { className: "hzs-h2", style: { fontSize: 19 } }, l.label || l.weddingOf || "Untitled list"), /* @__PURE__ */ React.createElement(Badge, { tone: st.tone, dot: true }, st.label)), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { marginTop: 4 } }, l.clientName ? "Filled by " + l.clientName : "Client hasn't opened it yet", l.weddingOf && l.label ? " \xB7 " + l.weddingOf : "", " \xB7 updated ", ago(l.updatedAt), l.importedAt ? " \xB7 " + (l.importedCount || 0) + " imported" : ""), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 6, marginTop: 10, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Badge, null, ent.length, " ", ent.length === 1 ? "guest" : "guests"), bad ? /* @__PURE__ */ React.createElement(Badge, { tone: "bad" }, bad, " ", bad === 1 ? "number" : "numbers", " to check") : null, (l.tables || []).length ? /* @__PURE__ */ React.createElement(Badge, { tone: "gold" }, l.tables.length, " ", l.tables.length === 1 ? "table" : "tables", " \xB7 ", l.tables.reduce((a, t) => a + (parseInt(t.seats, 10) || 0), 0), " seats \xB7 ", ent.filter((e) => HZ.tbl.name(e.table)).length, " seated") : null)), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8 } }, /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "secondary", icon: I.copy, onClick: () => copyText(HZ.listLink(l.id)).then(() => ui.toast("Link copied")) }, "Copy link"), /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "secondary", icon: isOpen ? I.up : I.down, onClick: () => setOpen(isOpen ? null : l.id) }, isOpen ? "Hide" : "View"), /* @__PURE__ */ React.createElement(Menu, { items: [
      { label: "Send on WhatsApp", icon: I.chat, onClick: () => window.open("https://wa.me/?text=" + encodeURIComponent(listWaMsg(l.id)), "_blank") },
      { label: "Open client page", icon: I.open, onClick: () => window.open(HZ.listLink(l.id), "_blank") },
      ent.length ? { label: "Download CSV", icon: I.download, onClick: () => listCsv(l) } : null,
      "-",
      { label: "Delete list", icon: I.trash, danger: true, onClick: () => remove(l) }
    ] }))), /* @__PURE__ */ React.createElement(AnimatePresence, { initial: false }, isOpen ? /* @__PURE__ */ React.createElement(motion.div, { initial: { height: 0, opacity: 0 }, animate: { height: "auto", opacity: 1 }, exit: { height: 0, opacity: 0 }, transition: { duration: 0.25 }, style: { overflow: "hidden" } }, /* @__PURE__ */ React.createElement("div", { style: { borderTop: "1px solid var(--line)" } }, ent.length ? /* @__PURE__ */ React.createElement("div", { className: "hzs-list", style: { maxHeight: 420, overflowY: "auto" } }, ent.map((e, k) => {
      const p = HZ.phone(e.phone);
      return /* @__PURE__ */ React.createElement("div", { key: k, className: "hzs-item", style: { padding: "10px 22px" } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-muted", style: { width: 26, fontSize: 12.5 } }, k + 1), /* @__PURE__ */ React.createElement("span", { style: { flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, e.name || /* @__PURE__ */ React.createElement("i", { className: "hzs-muted" }, "no name")), HZ.tbl.name(e.table) ? /* @__PURE__ */ React.createElement("span", { className: "hzl-table", style: { fontSize: 12.5, color: "var(--gold)", whiteSpace: "nowrap" } }, "Table ", HZ.tbl.name(e.table)) : null, /* @__PURE__ */ React.createElement("span", { style: { fontSize: 13.5, color: p.ok ? "var(--ink2)" : "var(--bad)", whiteSpace: "nowrap" } }, p.ok ? HZ.fmtPhone(p.num) : e.phone || "no number"));
    })) : /* @__PURE__ */ React.createElement("p", { className: "hzs-muted", style: { padding: "16px 22px", margin: 0 } }, "Nothing filled in yet."))) : null)));
  }))));
}
var lists_default = Lists;

export {
  listWaMsg,
  listState,
  listCsv,
  lists_default
};
