import {
  Badge,
  Button,
  Card,
  Empty,
  HZ,
  I,
  Input,
  Link,
  LinkButton,
  Menu,
  PageHead,
  Progress,
  React,
  Rise,
  Shell,
  Skel,
  Stat,
  Tabs,
  call,
  copyText,
  errText,
  fmtDate,
  useData,
  useMemo,
  useNavigate,
  useState,
  useUI,
  weddingDates,
  whenLabel
} from "./studio-S4HULNAO-59ff981.js";

// studio/dashboard.jsx
function Dashboard() {
  return /* @__PURE__ */ React.createElement(Shell, { active: "weddings" }, (user) => /* @__PURE__ */ React.createElement(Weddings, { user }));
}
function Weddings({ user }) {
  const ui = useUI();
  const nav = useNavigate();
  const q = useData((r) => r.invitations.mine(), []);
  const [tab, setTab] = useState("upcoming");
  const [term, setTerm] = useState("");
  const [creating, setCreating] = useState(false);
  const list = q.data || [];
  const tpl = (id) => (HZ.templates || []).find((t) => t.id === id);
  const groups = useMemo(() => {
    const up = [], past = [];
    for (const inv of list) {
      const { last } = weddingDates(inv);
      const isPast = last && /* @__PURE__ */ new Date(last + "T23:59:59") < /* @__PURE__ */ new Date();
      (isPast ? past : up).push(inv);
    }
    const by = (a, b) => (weddingDates(a).first || "9999").localeCompare(weddingDates(b).first || "9999");
    up.sort(by);
    past.sort((a, b) => -by(a, b));
    return { upcoming: up, past, all: [...up, ...past] };
  }, [list]);
  const shown = (groups[tab] || []).filter((inv) => {
    if (!term.trim()) return true;
    const s = (inv.groomName + " " + inv.brideName + " " + inv.slug).toLowerCase();
    return s.includes(term.trim().toLowerCase());
  });
  const totals = useMemo(() => list.reduce((a, inv) => {
    const s = inv.stats || {};
    a.guests += s.total || 0;
    a.attending += s.attending || 0;
    a.pending += s.pending || 0;
    a.inside += s.checkedIn || 0;
    return a;
  }, { guests: 0, attending: 0, pending: 0, inside: 0 }), [list]);
  const create = async () => {
    setCreating(true);
    try {
      const inv = await call((r) => r.invitations.create());
      nav("/builder/" + inv.id);
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
      setCreating(false);
    }
  };
  const trash = async (inv) => {
    const ok = await ui.confirm({ title: "Delete this invitation?", body: /* @__PURE__ */ React.createElement(React.Fragment, null, "\u201C", inv.groomName, " & ", inv.brideName, "\u201D will stop opening for guests. It moves to the trash, so it can still be restored by the admin."), confirmText: "Delete", tone: "danger" });
    if (!ok) return;
    try {
      await call((r) => r.invitations.trash({ id: inv.id }));
      q.mutate((d) => (d || []).filter((x) => x.id !== inv.id));
      ui.toast("Invitation deleted", { action: { label: "Undo", fn: async () => {
        await call((r) => r.invitations.restore({ id: inv.id }));
        q.reload();
      } } });
    } catch (e) {
      ui.toast(errText(e), { tone: "bad" });
    }
  };
  const link = (inv) => HZ.base() + "#/i/" + inv.slug;
  return /* @__PURE__ */ React.createElement("main", { className: "hzs-wrap" }, /* @__PURE__ */ React.createElement(PageHead, { eyebrow: "Karibu, " + (user.name || "host"), title: "Your", accent: "weddings", sub: "Every invitation you're preparing, its guests and replies \u2014 all in one place." }, /* @__PURE__ */ React.createElement(Button, { variant: "primary", icon: I.plus, onClick: create, busy: creating }, "New invitation")), q.loading ? /* @__PURE__ */ React.createElement("div", { className: "hzs-grid hzs-g2" }, [0, 1].map((i) => /* @__PURE__ */ React.createElement(Card, { key: i, style: { overflow: "hidden" } }, /* @__PURE__ */ React.createElement(Skel, { h: 150, r: 0 }), /* @__PURE__ */ React.createElement("div", { className: "hzs-pad" }, /* @__PURE__ */ React.createElement(Skel, { h: 22, w: "60%" }), /* @__PURE__ */ React.createElement(Skel, { h: 12, w: "40%", style: { marginTop: 10 } }), /* @__PURE__ */ React.createElement(Skel, { h: 6, style: { marginTop: 22 } }))))) : q.error ? /* @__PURE__ */ React.createElement(Empty, { icon: I.alert, title: "Couldn't load your weddings", text: errText(q.error) }, /* @__PURE__ */ React.createElement(Button, { variant: "primary", icon: I.refresh, onClick: q.reload }, "Try again")) : !list.length ? /* @__PURE__ */ React.createElement(Empty, { icon: I.heart, title: "No invitations yet", text: "Create your first invitation \u2014 choose a template, add the couple and events, then invite guests on WhatsApp." }, /* @__PURE__ */ React.createElement(Button, { variant: "primary", icon: I.plus, onClick: create, busy: creating }, "Create invitation")) : /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "hzs-grid hzs-g4", style: { marginBottom: 28 } }, /* @__PURE__ */ React.createElement(Rise, { i: 0 }, /* @__PURE__ */ React.createElement(Stat, { icon: I.heart, label: "Weddings", value: list.length, sub: groups.upcoming.length + " upcoming" })), /* @__PURE__ */ React.createElement(Rise, { i: 1 }, /* @__PURE__ */ React.createElement(Stat, { icon: I.users, label: "Guests", value: totals.guests, sub: "invited" })), /* @__PURE__ */ React.createElement(Rise, { i: 2 }, /* @__PURE__ */ React.createElement(Stat, { icon: I.okCircle, label: "Attending", value: totals.attending, sub: totals.pending + " still to reply" })), /* @__PURE__ */ React.createElement(Rise, { i: 3 }, /* @__PURE__ */ React.createElement(Stat, { icon: I.scan, label: "Checked in", value: totals.inside, sub: "at the door" }))), /* @__PURE__ */ React.createElement("div", { className: "hzs-between", style: { marginBottom: 16, flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(Tabs, { value: tab, onChange: setTab, items: [{ id: "upcoming", label: "Upcoming", n: groups.upcoming.length }, { id: "past", label: "Past", n: groups.past.length }, { id: "all", label: "All", n: list.length }] }), list.length > 3 ? /* @__PURE__ */ React.createElement("div", { style: { position: "relative", width: "min(100%, 280px)" } }, /* @__PURE__ */ React.createElement(I.search, { size: 16, style: { position: "absolute", left: 13, top: 14, color: "var(--ink3)" } }), /* @__PURE__ */ React.createElement(Input, { placeholder: "Search couples", value: term, onChange: (e) => setTerm(e.target.value), style: { paddingLeft: 38, height: 42 } })) : null), !shown.length ? /* @__PURE__ */ React.createElement(Card, { pad: true, style: { textAlign: "center", color: "var(--ink3)" } }, term ? "No couple matches \u201C" + term + "\u201D." : tab === "past" ? "No past weddings yet." : "Nothing upcoming \u2014 create a new invitation or check Past.") : /* @__PURE__ */ React.createElement("div", { className: "hzs-grid hzs-g2" }, shown.map((inv, i) => /* @__PURE__ */ React.createElement(Rise, { key: inv.id, i }, /* @__PURE__ */ React.createElement(WeddingCard, { inv, t: tpl(inv.templateId), onTrash: () => trash(inv), link: link(inv), ui }))))));
}
function lum(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ""));
  if (!m) return 0;
  const n = parseInt(m[1], 16), c = [n >> 16 & 255, n >> 8 & 255, n & 255].map((v) => {
    v /= 255;
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
}
function bandOf(t) {
  const p = t && t.palette || ["#2A2116", "#3A2E1E", "#C6A45E"];
  const a = p[0], b = p[1] || p[0];
  const light = (lum(a) + lum(b)) / 2 > 0.45;
  return { bg: "linear-gradient(135deg," + a + " 0%," + b + " 100%)", ink: light ? "#2A2116" : "#FBF6EA", line: light ? "rgba(42,33,22,.25)" : "rgba(251,246,234,.35)" };
}
function WeddingCard({ inv, t, onTrash, link, ui }) {
  const s = inv.stats || { total: 0, attending: 0, pending: 0, checkedIn: 0 };
  const declined = Math.max(0, (s.total || 0) - (s.attending || 0) - (s.pending || 0));
  const { first } = weddingDates(inv);
  const when = whenLabel(first);
  const live = inv.status === "active";
  const band = bandOf(t);
  return /* @__PURE__ */ React.createElement(Card, { style: { overflow: "hidden", display: "flex", flexDirection: "column", height: "100%" } }, /* @__PURE__ */ React.createElement(Link, { to: "/builder/" + inv.id, style: { position: "relative", display: "flex", alignItems: "stretch", minHeight: 150, background: band.bg, color: band.ink, overflow: "hidden" }, "aria-label": "Edit " + inv.groomName + " & " + inv.brideName }, /* @__PURE__ */ React.createElement("div", { style: { position: "absolute", inset: 0, background: "radial-gradient(120% 90% at 100% 0%, rgba(255,255,255,.16), transparent 55%)" } }), /* @__PURE__ */ React.createElement("div", { style: { position: "relative", flex: 1, minWidth: 0, padding: "16px 0 18px 20px", display: "flex", flexDirection: "column" } }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement(Badge, { tone: live ? "ok" : inv.status === "archived" ? "" : "warn", dot: true, style: { background: live ? "rgba(232,241,234,.96)" : "rgba(250,240,218,.96)" } }, live ? "Live" : inv.status === "archived" ? "Archived" : "Draft")), /* @__PURE__ */ React.createElement("div", { style: { marginTop: "auto", paddingTop: 14 } }, /* @__PURE__ */ React.createElement("div", { style: { fontFamily: "'Great Vibes', cursive", fontSize: 32, lineHeight: 1.05, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" } }, (inv.groomName || "Groom") + " & " + (inv.brideName || "Bride")), /* @__PURE__ */ React.createElement("div", { style: { fontSize: 11, letterSpacing: ".2em", textTransform: "uppercase", opacity: 0.78, marginTop: 4 } }, t && t.name || inv.templateId))), /* @__PURE__ */ React.createElement("div", { style: { position: "relative", width: 104, flex: "none", padding: "14px 16px 0 0", display: "flex", alignItems: "flex-end" } }, /* @__PURE__ */ React.createElement("img", { src: t && t.previewImage || "./art/blush-arch-gold.png", alt: "", loading: "lazy", style: { width: 88, height: 122, objectFit: "cover", objectPosition: "center top", borderRadius: "44px 44px 0 0", border: "1px solid " + band.line, borderBottom: 0, display: "block", boxShadow: "0 -6px 24px rgba(0,0,0,.18)" } }))), /* @__PURE__ */ React.createElement("div", { className: "hzs-pad", style: { display: "flex", flexDirection: "column", gap: 14, flex: 1 } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between" }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, color: "var(--ink2)", fontSize: 14 } }, /* @__PURE__ */ React.createElement(I.calendar, { size: 16 }), first ? fmtDate(first, { weekday: "short", day: "numeric", month: "short", year: "numeric" }) : "Add the event date"), /* @__PURE__ */ React.createElement(Badge, { tone: when.tone }, when.text)), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement(Progress, { parts: [{ v: s.attending || 0, c: "#3D7A55" }, { v: declined, c: "#C08A7F" }, { v: s.pending || 0, c: "rgba(30,26,18,.12)" }] }), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 14, marginTop: 9, fontSize: 12.5, color: "var(--ink2)", flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement("span", null, /* @__PURE__ */ React.createElement("b", { style: { fontWeight: 600, color: "var(--ink)" } }, s.total || 0), " guests"), /* @__PURE__ */ React.createElement("span", { style: { color: "#3D7A55" } }, "\u25CF ", s.attending || 0, " attending"), /* @__PURE__ */ React.createElement("span", { style: { color: "var(--ink3)" } }, "\u25CF ", s.pending || 0, " pending"), s.checkedIn ? /* @__PURE__ */ React.createElement("span", { style: { color: "var(--gold)" } }, "\u25CF ", s.checkedIn, " inside") : null, /* @__PURE__ */ React.createElement(Link, { to: "/guests/" + inv.id, style: { marginLeft: "auto", color: "var(--gold)" } }, "See guests \u2192"))), /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, marginTop: "auto", flexWrap: "wrap" } }, /* @__PURE__ */ React.createElement(LinkButton, { to: "/builder/" + inv.id, variant: "primary", size: "sm", icon: I.edit }, "Edit card"), /* @__PURE__ */ React.createElement(LinkButton, { to: "/guests/" + inv.id, variant: "secondary", size: "sm", icon: I.users }, "Guests"), /* @__PURE__ */ React.createElement(LinkButton, { to: "/scan/" + inv.id, variant: "secondary", size: "sm", icon: I.scan }, "Check-in"), /* @__PURE__ */ React.createElement("div", { style: { marginLeft: "auto" } }, /* @__PURE__ */ React.createElement(Menu, { title: (inv.groomName || "") + " & " + (inv.brideName || ""), items: [
    { label: "Copy invitation link", icon: I.link, onClick: () => copyText(link).then(() => ui.toast("Invitation link copied")) },
    { label: "Open invitation", icon: I.open, onClick: () => window.open(link, "_blank") },
    "-",
    { label: "Delete invitation", icon: I.trash, danger: true, onClick: onTrash }
  ] })))));
}
var D = { __proto__: null, default: Dashboard };
var dashboard_default = Dashboard;
export {
  D,
  dashboard_default as default
};
