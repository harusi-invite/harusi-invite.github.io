import {
  AnimatePresence,
  Badge,
  Button,
  Card,
  Empty,
  HZ,
  I,
  Input,
  LinkButton,
  React,
  Shell,
  Skel,
  cx,
  errText,
  initials,
  motion,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  useStudioCss,
  useUI
} from "./studio-IQ3KHCEJ-b536c49.js";

// studio/scan.jsx
import { u as useParams } from "./index-B4Ch-nvB-b536c49.js";
var CSS = `
.hzc{max-width:1080px;margin:0 auto;padding:18px 16px calc(100px + env(safe-area-inset-bottom));display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,1fr);gap:20px;align-items:start}
.hzc-cam{position:relative;border-radius:24px;overflow:hidden;background:#15110B;aspect-ratio:1/1;box-shadow:0 30px 60px -30px rgba(30,26,18,.7)}
.hzc-cam video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.hzc-frame{position:absolute;inset:16%;pointer-events:none}
.hzc-frame i{position:absolute;width:34px;height:34px;border-color:#E9D29A;border-style:solid;border-width:0}
.hzc-frame i:nth-child(1){top:0;left:0;border-top-width:3px;border-left-width:3px;border-top-left-radius:14px}
.hzc-frame i:nth-child(2){top:0;right:0;border-top-width:3px;border-right-width:3px;border-top-right-radius:14px}
.hzc-frame i:nth-child(3){bottom:0;left:0;border-bottom-width:3px;border-left-width:3px;border-bottom-left-radius:14px}
.hzc-frame i:nth-child(4){bottom:0;right:0;border-bottom-width:3px;border-right-width:3px;border-bottom-right-radius:14px}
.hzc-line{position:absolute;left:18%;right:18%;height:2px;background:linear-gradient(90deg,transparent,#E9D29A,transparent);top:20%;animation:hzc-scan 2.2s ease-in-out infinite;opacity:.85}
@keyframes hzc-scan{50%{top:78%}}
.hzc-tools{position:absolute;left:0;right:0;bottom:0;display:flex;gap:8px;justify-content:center;padding:14px;background:linear-gradient(transparent,rgba(0,0,0,.55))}
.hzc-tools button{height:40px;padding:0 14px;border-radius:999px;border:1px solid rgba(255,255,255,.25);background:rgba(20,16,10,.55);color:#FBF6EA;display:inline-flex;align-items:center;gap:7px;font-size:13px;cursor:pointer;backdrop-filter:blur(6px)}
.hzc-tools button.on{background:#E9D29A;color:#1E1A12;border-color:#E9D29A}
.hzc-res{border-radius:22px;padding:20px 22px;color:#fff}
.hzc-res.ok{background:linear-gradient(160deg,#2F7A50,#1F5A3A)}
.hzc-res.warn{background:linear-gradient(160deg,#B07A1C,#8A5D0B)}
.hzc-res.bad{background:linear-gradient(160deg,#B4483A,#8A3328)}
.hzc-big{font-family:'Marcellus',serif;font-size:30px;line-height:1.1;margin:6px 0 0}
.hzc-table{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-top:14px;padding:10px 18px;border-radius:16px;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.4)}
.hzc-table .l{font-size:11px;letter-spacing:.22em;text-transform:uppercase;line-height:1.5;opacity:.9}
.hzc-table b{font-family:'Marcellus',serif;font-weight:400;font-size:46px;line-height:1;letter-spacing:.02em}
.hzc-notable{margin-top:12px;font-size:13.5px;padding:8px 12px;border-radius:12px;background:rgba(0,0,0,.14)}
.hzc-flash{position:absolute;left:12px;right:12px;top:12px;z-index:3;border-radius:16px;padding:10px 16px;color:#fff;display:flex;align-items:center;justify-content:space-between;gap:12px;box-shadow:0 12px 30px rgba(0,0,0,.35)}
.hzc-flash.ok{background:rgba(31,90,58,.94)}.hzc-flash.warn{background:rgba(138,93,11,.94)}.hzc-flash.bad{background:rgba(138,51,40,.94)}
.hzc-flash .n{font-family:'Marcellus',serif;font-size:19px;line-height:1.15;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.hzc-flash .s{font-size:11px;letter-spacing:.14em;text-transform:uppercase;opacity:.85}
.hzc-flash .t{flex:none;text-align:center;line-height:1}.hzc-flash .t small{display:block;font-size:9.5px;letter-spacing:.2em;text-transform:uppercase;opacity:.85;margin-bottom:3px}
.hzc-flash .t b{font-family:'Marcellus',serif;font-weight:400;font-size:34px}
.hzc-tb{display:inline-flex;align-items:center;gap:4px;color:var(--gold);font-weight:600}
@media (max-width:860px){.hzc{grid-template-columns:1fr;padding-bottom:calc(40px + env(safe-area-inset-bottom))}.hzc-cam{aspect-ratio:1/1;max-height:56vh;margin:0 auto;width:100%}}
`;
var cssDone = false;
var SEG_BTN = { flex: 1, display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 7, height: 36, fontSize: 13.5 };
var AC = typeof window !== "undefined" ? window.AudioContext || window.webkitAudioContext : null;
var actx = null;
function tone(kind) {
  try {
    if (!AC) return;
    actx = actx || new AC();
    if (actx.state === "suspended") actx.resume();
    if (kind === "init") return;
    const t0 = actx.currentTime;
    const beep = (f, dt, dur, type, g) => {
      const o = actx.createOscillator(), gn = actx.createGain();
      o.type = type || "sine";
      o.frequency.value = f;
      gn.gain.setValueAtTime(g || 0.06, t0 + dt);
      gn.gain.exponentialRampToValueAtTime(1e-4, t0 + dt + dur);
      o.connect(gn);
      gn.connect(actx.destination);
      o.start(t0 + dt);
      o.stop(t0 + dt + dur + 0.02);
    };
    if (kind === "ok") {
      beep(880, 0, 0.09);
      beep(1320, 0.1, 0.14);
    } else if (kind === "warn") {
      beep(660, 0, 0.14, "triangle");
      beep(660, 0.2, 0.14, "triangle");
    } else {
      beep(220, 0, 0.28, "square", 0.05);
    }
  } catch (e) {
  }
  try {
    navigator.vibrate && navigator.vibrate(kind === "ok" ? 30 : kind === "warn" ? [40, 60, 40] : [80, 50, 80]);
  } catch (e) {
  }
}
function parseScan(raw) {
  const s = String(raw || "").trim();
  if (!s) return null;
  let code = null, slug = null;
  const q = /[?&#]code=([A-Za-z0-9]{3,14})/i.exec(s);
  const p = /\/i\/([^/?&#\s]+)(?:\/([A-Za-z0-9]{3,14}))?/i.exec(s);
  if (p) {
    slug = decodeURIComponent(p[1]).toLowerCase();
    if (p[2]) code = p[2];
  }
  if (q) code = q[1];
  if (!code && !/[/:.?]/.test(s)) code = s.replace(/^NOOR\s*[·.\-:]?\s*/i, "");
  if (!code) return slug ? { code: null, slug } : null;
  code = code.toUpperCase().replace(/[^A-Z0-9]/g, "");
  return /^[A-Z0-9]{3,10}$/.test(code) ? { code, slug } : null;
}
var jsqrP = null;
function loadJsQR() {
  if (window.jsQR) return Promise.resolve();
  return jsqrP = jsqrP || new Promise((res, rej) => {
    const sc = document.createElement("script");
    sc.src = "assets/jsqr.min.js";
    sc.async = true;
    sc.onload = () => window.jsQR ? res() : rej(new Error("jsQR missing"));
    sc.onerror = () => rej(new Error("Scanner engine couldn't load"));
    document.head.appendChild(sc);
  });
}
function Scan() {
  useStudioCss();
  if (!cssDone) {
    cssDone = true;
    const s = document.createElement("style");
    s.textContent = CSS;
    document.head.appendChild(s);
  }
  return /* @__PURE__ */ React.createElement(Shell, { active: "weddings", noBottom: true }, () => /* @__PURE__ */ React.createElement(Door, null));
}
function Door() {
  const { id } = useParams();
  const ui = useUI();
  const [inv, setInv] = useState(null);
  const [guests, setGuests] = useState(null);
  const [err, setErr] = useState(null);
  const [res, setRes] = useState(null);
  const [log, setLog] = useState([]);
  const [queue, setQueue] = useState([]);
  const [term, setTerm] = useState("");
  const tname = (n) => HZ.tbl.name(n);
  const [view, setView] = useState(() => /[?&]view=list/.test(window.location.hash || "") ? "list" : "scan");
  const gRef = useRef(null);
  gRef.current = guests;
  const invRef = useRef(null);
  invRef.current = inv;
  const qRef = useRef([]);
  qRef.current = queue;
  const last = useRef({ code: "", at: 0 });
  const admitted = useRef({});
  const load = useCallback(async (quiet) => {
    try {
      const r = await HZ.repo();
      const [a, b] = await Promise.all([invRef.current ? Promise.resolve(invRef.current) : r.invitations.get(id), r.guests.list(id)]);
      setInv(a);
      const pend = new Map(qRef.current.map((x) => [x.id, x]));
      setGuests(b.map((g) => pend.has(g.id) ? { ...g, checkedIn: !pend.get(g.id).undo, checkedInAt: pend.get(g.id).undo ? null : pend.get(g.id).at } : g));
    } catch (e) {
      if (!quiet) setErr(e);
    }
  }, [id]);
  useEffect(() => {
    load();
    const t2 = setInterval(() => load(true), 2e4);
    return () => clearInterval(t2);
  }, [load]);
  const flushing = useRef(false);
  const flush = useCallback(async () => {
    if (flushing.current || !qRef.current.length) return;
    flushing.current = true;
    const r = await HZ.repo();
    for (const it of qRef.current.slice()) {
      try {
        await r.guests.setCheckIn({ id: it.id, undo: it.undo });
        setQueue((q) => q.filter((x) => x !== it));
      } catch (e) {
        break;
      }
    }
    flushing.current = false;
  }, []);
  useEffect(() => {
    if (queue.length) flush();
    const t2 = setInterval(flush, 5e3);
    return () => clearInterval(t2);
  }, [queue.length, flush]);
  useEffect(() => {
    const h = (e) => {
      if (qRef.current.length) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", h);
    return () => window.removeEventListener("beforeunload", h);
  }, []);
  const byCode = useMemo(() => {
    const m = /* @__PURE__ */ new Map();
    (guests || []).forEach((g) => m.set(String(g.code).toUpperCase(), g));
    return m;
  }, [guests]);
  const show = (o) => {
    setRes({ ...o, at: Date.now() });
    tone(o.kind);
  };
  const admit = (g) => {
    const at = Date.now();
    admitted.current[g.id] = at;
    setGuests((gs) => gs.map((x) => x.id === g.id ? { ...x, checkedIn: true, checkedInAt: at } : x));
    setQueue((q) => [...q.filter((x) => x.id !== g.id), { id: g.id, undo: false, at }]);
    setLog((l) => [{ g, at }, ...l].slice(0, 12));
    show({ kind: "ok", g, title: g.name, sub: "Karibu! Welcome inside", note: g.rsvpStatus === "declined" ? "Note: this guest had declined" : g.rsvpStatus !== "attending" ? "Didn't RSVP \u2014 welcome them anyway" : "" });
  };
  const undo = (g) => {
    setGuests((gs) => gs.map((x) => x.id === g.id ? { ...x, checkedIn: false, checkedInAt: null } : x));
    setQueue((q) => [...q.filter((x) => x.id !== g.id), { id: g.id, undo: true, at: Date.now() }]);
    setLog((l) => l.filter((x) => x.g.id !== g.id));
    delete admitted.current[g.id];
    setRes(null);
    ui.toast(g.name + " marked not arrived");
  };
  const admitFromList = (g) => {
    admit(g);
    ui.toast(g.name + " checked in", { tone: "ok" });
  };
  const handle = useCallback(async (raw, typed) => {
    const p = parseScan(raw);
    if (!p) {
      if (typed) show({ kind: "bad", title: "Not a guest code", sub: "Codes are 4\u20136 letters and numbers, e.g. FJ6K" });
      return;
    }
    const now = Date.now();
    if (!typed && p.code === last.current.code && now - last.current.at < 6e3) {
      last.current.at = now;
      return;
    }
    last.current = { code: p.code || "", at: now };
    const iv = invRef.current;
    if (p.slug && iv && p.slug !== String(iv.slug).toLowerCase()) {
      show({ kind: "bad", title: "Different wedding", sub: "This invitation is for another wedding (/" + p.slug + ")" });
      return;
    }
    if (!p.code) {
      show({ kind: "bad", title: "No guest code", sub: "This is the main invitation link, not a personal one" });
      return;
    }
    let g = byCodeRef.current.get(p.code);
    if (!g) {
      await load(true);
      g = new Map((gRef.current || []).map((x) => [String(x.code).toUpperCase(), x])).get(p.code);
    }
    if (!g) {
      show({ kind: "bad", title: "Not on this list", sub: p.code + " isn't a guest of this wedding" });
      return;
    }
    if (g.checkedIn && !typed && admitted.current[g.id] && now - admitted.current[g.id] < 9e4) return;
    if (g.checkedIn) {
      show({ kind: "warn", g, title: "Already inside", sub: g.name + (g.checkedInAt ? " \xB7 came in at " + new Date(g.checkedInAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""), note: "Don't admit this code twice" });
      return;
    }
    admit(g);
  }, [load]);
  const byCodeRef = useRef(byCode);
  byCodeRef.current = byCode;
  const handleRef = useRef(handle);
  handleRef.current = handle;
  if (err) return /* @__PURE__ */ React.createElement("main", { className: "hzs-wrap" }, /* @__PURE__ */ React.createElement(Empty, { icon: I.alert, title: "Couldn't open the guest list", text: errText(err) }, /* @__PURE__ */ React.createElement(Button, { variant: "primary", onClick: () => {
    setErr(null);
    load();
  } }, "Try again")));
  if (!inv || !guests) return /* @__PURE__ */ React.createElement("main", { className: "hzc" }, /* @__PURE__ */ React.createElement(Skel, { h: 420, r: 24 }), /* @__PURE__ */ React.createElement(Skel, { h: 420, r: 22 }));
  const inside = guests.filter((g) => g.checkedIn).length;
  const expected = guests.filter((g) => g.rsvpStatus === "attending").length;
  const hasTables = HZ.tbl.clean(inv.tables).length > 0 || guests.some((g) => tname(g.table));
  const resG = res && res.g ? guests.find((x) => x.id === res.g.id) || res.g : null;
  const t = term.trim().toLowerCase();
  const matches = t ? guests.filter((g) => String(g.name).toLowerCase().includes(t) || String(g.code).toLowerCase().startsWith(t) || t.replace(/\D/g, "").length > 3 && String(g.phone || "").includes(t.replace(/\D/g, ""))).slice(0, 8) : [];
  return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { style: { borderBottom: "1px solid var(--line)", background: "rgba(251,248,242,.9)" } }, /* @__PURE__ */ React.createElement("div", { style: { maxWidth: 1080, margin: "0 auto", padding: "10px 16px", display: "flex", alignItems: "center", gap: 12 } }, /* @__PURE__ */ React.createElement(LinkButton, { to: "/guests/" + id, variant: "ghost", size: "sm", icon: I.back, "aria-label": "Back to guests" }), /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0 } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-eyebrow", style: { fontSize: 9.5 } }, "Check-in"), /* @__PURE__ */ React.createElement("div", { style: { fontFamily: "'Great Vibes', cursive", fontSize: 25, lineHeight: 1.1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" } }, inv.groomName, " & ", inv.brideName)), /* @__PURE__ */ React.createElement("button", { onClick: () => setView(view === "list" ? "scan" : "list"), style: { marginLeft: "auto", textAlign: "right", border: 0, background: "none", cursor: "pointer", color: "inherit", padding: 0 }, title: "Guest list" }, /* @__PURE__ */ React.createElement("div", { style: { fontSize: 24, fontWeight: 300, lineHeight: 1 } }, inside, /* @__PURE__ */ React.createElement("span", { style: { color: "var(--ink3)", fontSize: 15 } }, " / ", guests.length)), /* @__PURE__ */ React.createElement("div", { style: { fontSize: 11, color: "var(--ink3)", letterSpacing: ".08em" } }, "INSIDE \xB7 ", expected, " EXPECTED"))), /* @__PURE__ */ React.createElement("div", { style: { maxWidth: 1080, margin: "0 auto", padding: "0 16px 10px" } }, /* @__PURE__ */ React.createElement("div", { className: "hzs-seg", style: { width: "100%", display: "flex" } }, /* @__PURE__ */ React.createElement("button", { className: view === "scan" ? "on" : "", style: SEG_BTN, onClick: () => setView("scan") }, /* @__PURE__ */ React.createElement(I.scan, { size: 15 }), "Scan"), /* @__PURE__ */ React.createElement("button", { className: view === "list" ? "on" : "", style: SEG_BTN, onClick: () => setView("list") }, /* @__PURE__ */ React.createElement(I.users, { size: 15 }), "Guest list \xB7 ", inside, "/", guests.length)))), view === "list" ? /* @__PURE__ */ React.createElement(GuestProgress, { guests, inside, expected, queue, onIn: admitFromList, onUndo: undo }) : /* @__PURE__ */ React.createElement("main", { className: "hzc" }, /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 14 } }, /* @__PURE__ */ React.createElement(Camera, { onCode: (c) => handleRef.current(c, false), flash: res ? { at: res.at, kind: res.kind, title: res.kind === "warn" ? "Already inside \xB7 " + (resG ? resG.name : "") : res.title, sub: res.kind === "ok" ? "Welcome" : res.kind === "warn" ? "Stop" : "Not admitted", table: resG && res.kind !== "bad" ? tname(resG.table) : "" } : null }), queue.length ? /* @__PURE__ */ React.createElement(Badge, { tone: "warn", style: { justifySelf: "start" } }, /* @__PURE__ */ React.createElement(I.refresh, { size: 12 }), queue.length, " waiting to sync \u2014 keep this page open") : /* @__PURE__ */ React.createElement(Badge, { tone: "ok", style: { justifySelf: "start" } }, /* @__PURE__ */ React.createElement(I.check, { size: 12 }), "All check-ins saved")), /* @__PURE__ */ React.createElement("div", { style: { display: "grid", gap: 16 } }, /* @__PURE__ */ React.createElement(AnimatePresence, { mode: "wait" }, res ? /* @__PURE__ */ React.createElement(motion.div, { key: res.at, initial: { opacity: 0, scale: 0.97, y: 6 }, animate: { opacity: 1, scale: 1, y: 0 }, exit: { opacity: 0 }, transition: { duration: 0.18 }, className: cx("hzc-res", res.kind), role: "status", "aria-live": "assertive" }, /* @__PURE__ */ React.createElement("div", { className: "hzs-row", style: { gap: 8, fontSize: 12, letterSpacing: ".16em", textTransform: "uppercase", opacity: 0.9 } }, res.kind === "ok" ? /* @__PURE__ */ React.createElement(I.okCircle, { size: 16 }) : res.kind === "warn" ? /* @__PURE__ */ React.createElement(I.alert, { size: 16 }) : /* @__PURE__ */ React.createElement(I.xCircle, { size: 16 }), res.kind === "ok" ? "Welcome" : res.kind === "warn" ? "Stop" : "Not admitted"), /* @__PURE__ */ React.createElement("div", { className: "hzc-big" }, res.title), /* @__PURE__ */ React.createElement("div", { style: { marginTop: 6, fontSize: 15, opacity: 0.95 } }, res.sub), resG && res.kind !== "bad" ? tname(resG.table) ? /* @__PURE__ */ React.createElement("div", { className: "hzc-table", "aria-label": "Table " + tname(resG.table) }, /* @__PURE__ */ React.createElement("span", { className: "l" }, "Table", /* @__PURE__ */ React.createElement("br", null), "Meza"), /* @__PURE__ */ React.createElement("b", null, tname(resG.table))) : hasTables ? /* @__PURE__ */ React.createElement("div", { className: "hzc-notable" }, "No table given \u2014 ask the hosts where to seat them") : null : null, res.note ? /* @__PURE__ */ React.createElement("div", { style: { marginTop: 8, fontSize: 13, opacity: 0.85 } }, res.note) : null, res.kind === "ok" && res.g ? /* @__PURE__ */ React.createElement("button", { onClick: () => undo(res.g), style: { marginTop: 14, height: 34, padding: "0 14px", borderRadius: 999, border: "1px solid rgba(255,255,255,.4)", background: "rgba(255,255,255,.12)", color: "#fff", cursor: "pointer", fontSize: 13, display: "inline-flex", alignItems: "center", gap: 6 } }, /* @__PURE__ */ React.createElement(I.undo, { size: 14 }), "Undo") : null) : /* @__PURE__ */ React.createElement(motion.div, { key: "idle", initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 } }, /* @__PURE__ */ React.createElement(Card, { pad: true, style: { textAlign: "center" } }, /* @__PURE__ */ React.createElement("div", { style: { width: 52, height: 52, borderRadius: 99, margin: "0 auto", display: "grid", placeItems: "center", background: "var(--goldbg)", color: "var(--gold)" } }, /* @__PURE__ */ React.createElement(I.qr, { size: 24 })), /* @__PURE__ */ React.createElement("p", { className: "hzs-h2", style: { marginTop: 12, fontSize: 20 } }, "Ready to scan"), /* @__PURE__ */ React.createElement("p", { className: "hzs-hint" }, "Point the camera at the guest's QR code, or find them by name below.")))), /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "hzs-sec" }, /* @__PURE__ */ React.createElement("form", { onSubmit: (e) => {
    e.preventDefault();
    const ps = parseScan(term);
    if (matches.length === 1 && !(ps && ps.code && byCode.has(ps.code))) {
      matches[0].checkedIn ? handle(matches[0].code, true) : admit(matches[0]);
      setTerm("");
    } else {
      handle(term, true);
      setTerm("");
    }
  } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-label" }, "Find a guest \u2014 name, code or phone"), /* @__PURE__ */ React.createElement("div", { style: { position: "relative" } }, /* @__PURE__ */ React.createElement(I.search, { size: 16, style: { position: "absolute", left: 13, top: 14, color: "var(--ink3)" } }), /* @__PURE__ */ React.createElement(Input, { value: term, onChange: (e) => setTerm(e.target.value), placeholder: "e.g. Fatma or FJ6K", style: { paddingLeft: 38 }, autoCapitalize: "none", autoComplete: "off", enterKeyHint: "search" })))), t ? matches.length ? /* @__PURE__ */ React.createElement("div", { className: "hzs-list" }, matches.map((g) => /* @__PURE__ */ React.createElement("div", { key: g.id, className: "hzs-item" }, /* @__PURE__ */ React.createElement("span", { className: "hzs-avatar", style: { width: 36, height: 36, fontSize: 13 } }, initials(g.name)), /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0, flex: 1 } }, /* @__PURE__ */ React.createElement("div", { style: { fontWeight: 500 } }, g.name), /* @__PURE__ */ React.createElement("div", { className: "hzs-hint", style: { margin: 0 } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-kbd" }, g.code), tname(g.table) ? /* @__PURE__ */ React.createElement(React.Fragment, null, " \xB7 ", /* @__PURE__ */ React.createElement("span", { className: "hzc-tb" }, "Table ", tname(g.table))) : null, " \xB7 ", g.rsvpStatus === "attending" ? "attending" : g.rsvpStatus === "declined" ? "declined" : "no reply")), g.checkedIn ? /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.undo, onClick: () => undo(g) }, "Inside \xB7 undo") : /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "primary", icon: I.check, onClick: () => {
    admit(g);
    setTerm("");
  } }, "Check in")))) : /* @__PURE__ */ React.createElement("div", { className: "hzs-pad hzs-muted", style: { textAlign: "center", paddingTop: 0 } }, "No guest matches \u201C", term, "\u201D.") : null), log.length ? /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "hzs-sec", style: { paddingBottom: 10 } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-label", style: { margin: 0 } }, "Just arrived")), /* @__PURE__ */ React.createElement("div", { className: "hzs-list" }, log.map((x) => /* @__PURE__ */ React.createElement("div", { key: x.g.id + x.at, className: "hzs-item", style: { padding: "10px 22px" } }, /* @__PURE__ */ React.createElement(I.okCircle, { size: 16, style: { color: "var(--ok)" } }), /* @__PURE__ */ React.createElement("span", { style: { flex: 1, minWidth: 0 } }, x.g.name, tname(x.g.table) ? /* @__PURE__ */ React.createElement("span", { className: "hzc-tb", style: { marginLeft: 8, fontSize: 13 } }, "\xB7 Table ", tname(x.g.table)) : null), /* @__PURE__ */ React.createElement("span", { className: "hzs-hint", style: { margin: 0 } }, new Date(x.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })))))) : null)));
}
function GuestProgress({ guests, inside, expected, queue, onIn, onUndo }) {
  const [f, setF] = useState("away");
  const [term, setTerm] = useState("");
  const t = term.trim().toLowerCase();
  const rank = (g) => g.rsvpStatus === "attending" ? 0 : g.rsvpStatus === "declined" ? 2 : 1;
  const list = guests.filter((g) => f === "away" ? !g.checkedIn : f === "inside" ? g.checkedIn : true).filter((g) => !t || String(g.name).toLowerCase().includes(t) || String(g.code).toLowerCase().startsWith(t) || HZ.tbl.name(g.table) && ["table " + HZ.tbl.name(g.table).toLowerCase(), "meza " + HZ.tbl.name(g.table).toLowerCase(), HZ.tbl.name(g.table).toLowerCase()].includes(t) || t.replace(/\D/g, "").length > 3 && String(g.phone || "").includes(t.replace(/\D/g, ""))).sort((a, b) => f === "inside" ? (b.checkedInAt || 0) - (a.checkedInAt || 0) : rank(a) - rank(b) || String(a.name).localeCompare(String(b.name)));
  const pct = guests.length ? Math.round(100 * inside / guests.length) : 0;
  return /* @__PURE__ */ React.createElement("main", { style: { maxWidth: 760, margin: "0 auto", padding: "16px 16px calc(40px + env(safe-area-inset-bottom))", display: "grid", gap: 14 } }, /* @__PURE__ */ React.createElement(Card, { pad: true }, /* @__PURE__ */ React.createElement("div", { className: "hzs-between", style: { alignItems: "baseline", flexWrap: "wrap", gap: 8 } }, /* @__PURE__ */ React.createElement("div", { style: { fontSize: 30, fontWeight: 300, lineHeight: 1.1 } }, inside, /* @__PURE__ */ React.createElement("span", { style: { fontSize: 16, color: "var(--ink3)" } }, " of ", guests.length, " inside")), /* @__PURE__ */ React.createElement("span", { className: "hzs-hint", style: { margin: 0 } }, expected, " said they're attending")), /* @__PURE__ */ React.createElement("div", { className: "hzs-progress", style: { marginTop: 12, height: 8 } }, /* @__PURE__ */ React.createElement("span", { style: { width: pct + "%", background: "var(--gold)", transition: "width .4s" } })), queue.length ? /* @__PURE__ */ React.createElement("p", { className: "hzs-hint", style: { marginTop: 10, color: "var(--warn)" } }, queue.length, " change", queue.length === 1 ? "" : "s", " waiting to sync \u2014 keep this page open") : null), /* @__PURE__ */ React.createElement(Card, null, /* @__PURE__ */ React.createElement("div", { className: "hzs-sec", style: { display: "grid", gap: 12 } }, /* @__PURE__ */ React.createElement("div", { style: { position: "relative" } }, /* @__PURE__ */ React.createElement(I.search, { size: 16, style: { position: "absolute", left: 13, top: 14, color: "var(--ink3)" } }), /* @__PURE__ */ React.createElement(Input, { value: term, onChange: (e) => setTerm(e.target.value), placeholder: "Find a guest \u2014 name, code, phone or table", style: { paddingLeft: 38 }, autoCapitalize: "none", autoComplete: "off" })), /* @__PURE__ */ React.createElement("div", { style: { display: "flex", gap: 6, flexWrap: "wrap" } }, [["away", "Not arrived", guests.length - inside], ["inside", "Inside", inside], ["all", "Everyone", guests.length]].map(([id, l, n]) => /* @__PURE__ */ React.createElement("button", { key: id, className: cx("hzs-chip", f === id && "on"), onClick: () => setF(id) }, l, /* @__PURE__ */ React.createElement("span", { style: { opacity: 0.65 } }, n))))), !list.length ? /* @__PURE__ */ React.createElement("div", { className: "hzs-pad hzs-muted", style: { textAlign: "center", paddingTop: 4 } }, t ? "No guest matches \u201C" + term + "\u201D." : f === "away" ? "Everyone is inside." : "Nobody here yet.") : /* @__PURE__ */ React.createElement("div", { className: "hzs-list" }, list.map((g) => {
    const att = g.rsvpStatus === "attending";
    return /* @__PURE__ */ React.createElement("div", { key: g.id, className: "hzs-item", style: { alignItems: "center" } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-avatar", style: { width: 36, height: 36, fontSize: 13, background: g.checkedIn ? "var(--goldbg)" : void 0 } }, g.checkedIn ? /* @__PURE__ */ React.createElement(I.check, { size: 16, style: { color: "var(--gold)" } }) : initials(g.name)), /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0, flex: 1 } }, /* @__PURE__ */ React.createElement("div", { style: { fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" } }, g.name), /* @__PURE__ */ React.createElement("div", { className: "hzs-hint", style: { margin: 0 } }, /* @__PURE__ */ React.createElement("span", { className: "hzs-kbd" }, g.code), HZ.tbl.name(g.table) ? /* @__PURE__ */ React.createElement(React.Fragment, null, " \xB7 ", /* @__PURE__ */ React.createElement("span", { className: "hzc-tb" }, "Table ", HZ.tbl.name(g.table))) : null, " \xB7 ", g.checkedIn ? "came in " + (g.checkedInAt ? new Date(g.checkedInAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "") : att ? "attending" : g.rsvpStatus === "declined" ? "declined" : "no reply")), g.checkedIn ? /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "ghost", icon: I.undo, onClick: () => onUndo(g) }, "Undo") : /* @__PURE__ */ React.createElement(Button, { size: "sm", variant: "primary", icon: I.check, onClick: () => onIn(g) }, "Check in"));
  }))));
}
function Camera({ onCode, flash }) {
  const [, tick] = useState(0);
  useEffect(() => {
    if (!flash) return;
    const t = setTimeout(() => tick((x) => x + 1), 8200);
    return () => clearTimeout(t);
  }, [flash && flash.at]);
  const showFlash = flash && Date.now() - flash.at < 8e3;
  const video = useRef(null);
  const st = useRef({ stream: null, track: null, timer: 0, stop: true });
  const [on, setOn] = useState(false);
  const [msg, setMsg] = useState("");
  const [torch, setTorch] = useState(false);
  const [torchOk, setTorchOk] = useState(false);
  const [facing, setFacing] = useState("environment");
  const cb = useRef(onCode);
  cb.current = onCode;
  useEffect(() => {
    if (!on) return;
    const s = st.current;
    s.stop = false;
    let cancelled = false;
    const stopAll = () => {
      cancelled = true;
      s.stop = true;
      clearTimeout(s.timer);
      if (s.stream) s.stream.getTracks().forEach((t) => {
        try {
          t.stop();
        } catch (e) {
        }
      });
      s.stream = null;
      s.track = null;
      setTorch(false);
      setTorchOk(false);
    };
    (async () => {
      setMsg("");
      if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setMsg("The camera needs a secure (https) page \u2014 use the search box instead.");
        setOn(false);
        return;
      }
      let stream;
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: facing }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false });
      } catch (e) {
        setMsg("Camera access was blocked \u2014 allow the camera for this site, or use the search box.");
        setOn(false);
        return;
      }
      if (cancelled) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }
      s.stream = stream;
      s.track = stream.getVideoTracks()[0];
      try {
        const c = s.track.getCapabilities && s.track.getCapabilities();
        setTorchOk(!!(c && c.torch));
      } catch (e) {
      }
      const v = video.current;
      if (!v) {
        stopAll();
        return;
      }
      v.srcObject = stream;
      v.setAttribute("playsinline", "");
      v.muted = true;
      try {
        await v.play();
      } catch (e) {
      }
      const pump = (fn, ms) => {
        const step = async () => {
          if (cancelled || s.stop) return;
          if (v.readyState >= 2) {
            try {
              await fn();
            } catch (e) {
            }
          }
          s.timer = setTimeout(step, ms);
        };
        step();
      };
      let det = null;
      if ("BarcodeDetector" in window) {
        try {
          const f = await window.BarcodeDetector.getSupportedFormats();
          if (f.includes("qr_code")) det = new window.BarcodeDetector({ formats: ["qr_code"] });
        } catch (e) {
        }
      }
      if (det) {
        pump(async () => {
          const r = await det.detect(v);
          if (r && r.length && r[0].rawValue) cb.current(r[0].rawValue);
        }, 110);
        return;
      }
      try {
        await loadJsQR();
      } catch (e) {
        setMsg("The scanner couldn't load \u2014 check the connection, or use the search box.");
        return;
      }
      const cv = document.createElement("canvas"), cx2 = cv.getContext("2d", { willReadFrequently: true });
      let flip = false;
      pump(() => {
        const w = v.videoWidth, h = v.videoHeight;
        if (!w) return;
        const side = Math.min(w, h), sx = (w - side) / 2, sy = (h - side) / 2, out = Math.min(560, side);
        cv.width = out;
        cv.height = out;
        cx2.drawImage(v, sx, sy, side, side, 0, 0, out, out);
        const img = cx2.getImageData(0, 0, out, out);
        flip = !flip;
        const r = window.jsQR(img.data, out, out, { inversionAttempts: flip ? "attemptBoth" : "dontInvert" });
        if (r && r.data) cb.current(r.data);
      }, 90);
    })();
    return stopAll;
  }, [on, facing]);
  useEffect(() => {
    const t = st.current.track;
    if (t && torchOk) {
      try {
        t.applyConstraints({ advanced: [{ torch }] });
      } catch (e) {
      }
    }
  }, [torch, torchOk]);
  useEffect(() => {
    const h = () => {
      if (document.hidden) setOn(false);
    };
    document.addEventListener("visibilitychange", h);
    return () => document.removeEventListener("visibilitychange", h);
  }, []);
  return /* @__PURE__ */ React.createElement("div", { className: "hzc-cam" }, /* @__PURE__ */ React.createElement("video", { ref: video, playsInline: true, muted: true, style: { opacity: on ? 1 : 0 } }), on && showFlash ? /* @__PURE__ */ React.createElement("div", { className: cx("hzc-flash", flash.kind), role: "status" }, /* @__PURE__ */ React.createElement("div", { style: { minWidth: 0 } }, /* @__PURE__ */ React.createElement("div", { className: "s" }, flash.sub), /* @__PURE__ */ React.createElement("div", { className: "n" }, flash.title)), flash.table ? /* @__PURE__ */ React.createElement("div", { className: "t" }, /* @__PURE__ */ React.createElement("small", null, "Table"), /* @__PURE__ */ React.createElement("b", null, flash.table)) : null) : null, on ? /* @__PURE__ */ React.createElement("div", { className: "hzc-frame" }, /* @__PURE__ */ React.createElement("i", null), /* @__PURE__ */ React.createElement("i", null), /* @__PURE__ */ React.createElement("i", null), /* @__PURE__ */ React.createElement("i", null), /* @__PURE__ */ React.createElement("div", { className: "hzc-line", style: { left: "6%", right: "6%" } })) : /* @__PURE__ */ React.createElement("div", { style: { position: "absolute", inset: 0, display: "grid", placeItems: "center", textAlign: "center", padding: 24, color: "#F2E8D0" } }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { style: { width: 64, height: 64, borderRadius: 99, margin: "0 auto", display: "grid", placeItems: "center", border: "1px solid rgba(233,210,154,.5)", color: "#E9D29A" } }, /* @__PURE__ */ React.createElement(I.camera, { size: 26 })), /* @__PURE__ */ React.createElement("p", { style: { fontFamily: "'Marcellus', serif", fontSize: 22, margin: "16px 0 0" } }, "Scan entrance codes"), /* @__PURE__ */ React.createElement("p", { style: { fontSize: 13.5, opacity: 0.75, margin: "6px auto 18px", maxWidth: 280 } }, msg || "Each guest's QR is on their invitation. Works offline for the list already loaded."), /* @__PURE__ */ React.createElement("button", { onClick: () => {
    tone("init");
    setOn(true);
  }, className: "hzs-btn gold" }, /* @__PURE__ */ React.createElement(I.camera, { size: 16 }), "Start camera"))), on ? /* @__PURE__ */ React.createElement("div", { className: "hzc-tools" }, /* @__PURE__ */ React.createElement("button", { onClick: () => setOn(false) }, /* @__PURE__ */ React.createElement(I.x, { size: 15 }), "Stop"), torchOk ? /* @__PURE__ */ React.createElement("button", { className: torch ? "on" : "", onClick: () => setTorch(!torch) }, /* @__PURE__ */ React.createElement(I.flash, { size: 15 }), "Light") : null, /* @__PURE__ */ React.createElement("button", { onClick: () => setFacing(facing === "environment" ? "user" : "environment") }, /* @__PURE__ */ React.createElement(I.refresh, { size: 15 }), "Flip")) : null);
}
var scan_default = Scan;
export {
  scan_default as default,
  parseScan
};
